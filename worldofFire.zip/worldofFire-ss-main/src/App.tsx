/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import {
  ShieldAlert,
  Flame,
  Swords,
  Droplets,
  Scroll,
  MapPin,
  Bot,
  ExternalLink,
  Crown,
  ChevronRight,
  Sparkles,
  CheckCircle2,
  XCircle,
  Clock,
  Compass,
  DollarSign,
  Send,
  MessageSquare,
  Zap,
  Target,
  RefreshCw,
  Landmark,
  Globe2,
  Store,
  FileText,
  UserX,
  AlertTriangle,
  Building,
  ArrowRightLeft,
  Check,
  Scale,
  HandCoins,
  History,
  TrendingUp,
  Users,
  Wind,
  Sun,
  Waves,
  Factory,
  Radio,
  Share2,
  Video,
  Award,
  Hammer,
  TrendingDown,
  Rocket,
  Shield,
  LifeBuoy,
  FileCheck,
  Play,
  Pause,
  Flag,
  UserCheck,
  FlaskConical,
  CreditCard,
  Package,
} from 'lucide-react';

// تابع تبدیل ارقام فارسی و انگلیسی به عدد صحیح استاندارد
function parseInputNumber(val: string | number): number {
  if (typeof val === 'number') return Math.max(0, Math.floor(val));
  const s = String(val ?? '')
    .replace(/[۰-۹]/g, (d) => String(d.charCodeAt(0) - 0x06f0))
    .replace(/[٠-٩]/g, (d) => String(d.charCodeAt(0) - 0x0660))
    .replace(/[,٬\s]/g, '');
  const n = parseInt(s, 10);
  return Number.isFinite(n) && n > 0 ? n : 0;
}

// فرمت‌دهی با ارقام انگلیسی استاندارد طبق درخواست کاربر
function fmt(num: number): string {
  return Number(num || 0).toLocaleString('en-US');
}

interface CountryOffer {
  id: string;
  countryName: string;
  flag: string;
  barrels: number;
  pricePerBarrel: number;
}

interface OilContract {
  id: string;
  fromCountry: string;
  fromFlag: string;
  toCountry: string;
  toFlag: string;
  dailyBarrels: number;
  dailyPrice: number;
  status: 'active' | 'pending' | 'cancelled';
}

interface SovereignLoan {
  id: string;
  lenderCountry: string;
  lenderFlag: string;
  borrowerCountry: string;
  borrowerFlag: string;
  initialAmount: number;
  remainingAmount: number;
  createdAt: string;
}

interface MarketCommodity {
  key: string;
  name: string;
  unit: string;
  price: number;
  stock: number;
  icon: string;
}

interface PublicOffer {
  id: string;
  sellerCountry: string;
  sellerFlag: string;
  itemKey: string;
  itemName: string;
  unit: string;
  quantity: number;
  pricePerUnit: number;
}

interface CentralBankAudit {
  id: string;
  amount: number;
  reason: string;
  type: 'tax' | 'aid';
  time: string;
}

interface BlueChipStock {
  key: string;
  name: string;
  sector: string;
  price: number;
  growth: number;
  dividend: number;
  emoji: string;
}

interface CustomEnterprise {
  id: string;
  category: string;
  categoryName: string;
  name: string;
  logo: string;
  tier: number;
  cycleIncome: number;
  scienceBoost: number;
}

interface DailyMission {
  id: string;
  title: string;
  desc: string;
  targetCount: number;
  currentCount: number;
  unit: string;
  rewardCash: number;
  rewardShahi: number;
  rewardOil: number;
  completed: boolean;
  claimed: boolean;
}

export default function App() {
  const [activeTab, setActiveTab] = useState<
    | 'overview'
    | 'commander'
    | 'barracks'
    | 'people'
    | 'construction'
    | 'research_logs'
    | 'shahi'
    | 'oil_economy'
    | 'oil_trade'
    | 'loans'
    | 'markets'
    | 'central_bank'
    | 'admin_panel'
    | 'bot_preview'
  >('overview');


  // بازخورد پیام‌ها
  const [feedbackMsg, setFeedbackMsg] = useState<{ text: string; ok: boolean } | null>(null);

  const showFeedback = (text: string, ok = true) => {
    setFeedbackMsg({ text, ok });
    setTimeout(() => setFeedbackMsg(null), 4500);
  };

  // ۱. مشخصات کشور کاربر
  const [userCountry, setUserCountry] = useState({
    name: 'ایران',
    flag: '🇮🇷',
    leader: 'سردار حبیب',
    rank: 'ارتشبد ارشد',
    oilRichness: 78,
    isBanned: false,
    hasOwnership: true,
    population: 85000000,
    scienceScore: 45,
    internet: '4G',
  });

  // موجودی‌های اصلی
  const [treasuryDollars, setTreasuryDollars] = useState<number>(1450000000);
  const [safeVaultDollars, setSafeVaultDollars] = useState<number>(200000000);
  const [shahiCoins, setShahiCoins] = useState<number>(45);
  const [oilReserve, setOilReserve] = useState<number>(650000); // ظرفیت کل
  const [currentOil, setCurrentOil] = useState<number>(420000); // موجودی فعلی بشکه
  const [oilRigs, setOilRigs] = useState<number>(18);
  const [oilWorkers, setOilWorkers] = useState<number>(350);

  // سامانه ماموریت‌های روزانه با جایزه سکه شاهی و نفت
  const [missions, setMissions] = useState<DailyMission[]>([
    {
      id: 'exp_oil_50k',
      title: 'صادرات ۵۰ هزار بشکه نفت',
      desc: 'صادرات و فروش حداقل ۵۰ هزار بشکه نفت خام در بازارهای جهانی یا محموله‌های کشتی',
      targetCount: 50000,
      currentCount: 38500,
      unit: 'بشکه',
      rewardCash: 60000000,
      rewardShahi: 25,
      rewardOil: 2500,
      completed: false,
      claimed: false,
    },
    {
      id: 'prod_power_10k',
      title: 'تولید ۱۰ هزار مگاوات برق',
      desc: 'تولید و تامین ۱۰ هزار مگاوات برق پایدار توسط نیروگاه‌های خورشیدی، بادی یا سدهای کشور',
      targetCount: 10000,
      currentCount: 10000,
      unit: 'مگاوات',
      rewardCash: 50000000,
      rewardShahi: 20,
      rewardOil: 5000,
      completed: true,
      claimed: false,
    },
    {
      id: 'military_readiness',
      title: 'تقویت آمادگی نظامی پادگان',
      desc: 'تجهیز پادگان و فعال‌سازی سامانه دفاع خودکار مرزها جهت آمادگی رزمی کامل',
      targetCount: 1,
      currentCount: 1,
      unit: 'عملیات',
      rewardCash: 35000000,
      rewardShahi: 15,
      rewardOil: 1500,
      completed: true,
      claimed: false,
    },
    {
      id: 'clean_infiltrators',
      title: 'پاکسازی نفوذی‌ها و امنیت ملی',
      desc: 'عملیات رصد اطلاعاتی و شناسایی و خنثی‌سازی مهره‌های نفوذی در مرزها و زیرساخت‌ها',
      targetCount: 1,
      currentCount: 0,
      unit: 'عملیات',
      rewardCash: 25000000,
      rewardShahi: 10,
      rewardOil: 1000,
      completed: false,
      claimed: false,
    },
  ]);

  // سامانه پادگان نظامی و دفاع خودکار (+۲۵٪ بانس)
  const [autoDefenseActive, setAutoDefenseActive] = useState<boolean>(true);
  const [militaryUnits, setMilitaryUnits] = useState([
    { id: 't90', name: 'تانک پیشرفته تی-۹۰', category: 'ground', count: 120, power: 120, emoji: '🛡️' },
    { id: 'bmp3', name: 'نفربر زرهی BMP-3', category: 'ground', count: 85, power: 75, emoji: '🪖' },
    { id: 'artillery', name: 'سامانه توپخانه سنگین', category: 'ground', count: 64, power: 90, emoji: '💥' },
    { id: 'infantry', name: 'لشکر تفنگداران زمینی', category: 'ground', count: 45000, power: 2, emoji: '🎖️' },
    { id: 'su35', name: 'جنگنده سوخو-۳۵', category: 'air', count: 14, power: 340, emoji: '✈️' },
    { id: 'shahed', name: 'پهپاد شناسایی-انتحاری', category: 'air', count: 48, power: 85, emoji: '🛩️' },
    { id: 'cargo_plane', name: 'هواپیمای ترابری تاکتیکی', category: 'air', count: 6, power: 60, emoji: '🛫', special: 'کاهش زمان اعزام به ۶ دقیقه' },
    { id: 'mowj', name: 'ناو محافظ موشک‌انداز', category: 'naval', count: 8, power: 450, emoji: '🚢' },
    { id: 'cargo_ship', name: 'ناو ترابری و تجهیزات‌بر', category: 'naval', count: 4, power: 90, emoji: '⛴️', special: 'مجوز حمله به کشورهای جزیره‌ای' },
    { id: 'khordad15', name: 'سامانه موشکی خرداد ۱۵', category: 'defense', count: 12, power: 280, emoji: '🎯' },
    { id: 's300', name: 'سامانه پدافند هوایی S-300', category: 'defense', count: 5, power: 550, emoji: '🛡️' },
  ]);

  // نبردهای فعال جاری با تایمر شمارش معکوس واقعی ۱۰ دقیقه‌ای (بدون فتح آبکی)
  const [activeBattles, setActiveBattles] = useState([
    {
      id: 'bat_1',
      attackerCountry: 'عربستان',
      attackerFlag: '🇸🇦',
      defenderCountry: 'ایران',
      defenderFlag: '🇮🇷',
      type: 'حمله ترکیبی زمینی-هوایی',
      remainingSeconds: 432, // ۷ دقیقه و ۱۲ ثانیه
      totalDurationSeconds: 600,
      unitsCount: 160,
      status: 'moving',
      speedBonus: 'هواپیمای ترابری هوایی (سرعت ۴۰٪ افزایش یافته)',
    },
  ]);

  // تایمر فعال شمارش معکوس نبردها
  useEffect(() => {
    const timer = setInterval(() => {
      setActiveBattles((prev) =>
        prev.map((b) => {
          if (b.remainingSeconds > 0) {
            return { ...b, remainingSeconds: b.remainingSeconds - 1 };
          }
          return b;
        })
      );
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  // مدیریت سهامدار عمده ۵۱٪
  const [controllingStock, setControllingStock] = useState<any | null>(null);
  const [newStockNameInput, setNewStockNameInput] = useState<string>('');
  const [newStockSectorInput, setNewStockSectorInput] = useState<string>('');

  // تنظیمات ادمین برای واریزهای دوره‌ای (توقف/فریز و تغییر بازه زمانی)
  const [isPayoutFrozen, setIsPayoutFrozen] = useState<boolean>(false);
  const [payoutIntervalMinutes, setPayoutIntervalMinutes] = useState<number>(10);

  // دریافت پاداش ماموریت روزانه
  const handleClaimMission = (missionId: string) => {
    setMissions((prev) =>
      prev.map((m) => {
        if (m.id === missionId && !m.claimed) {
          setTreasuryDollars((t) => t + m.rewardCash);
          setShahiCoins((s) => s + m.rewardShahi);
          setCurrentOil((o) => Math.min(oilReserve, o + m.rewardOil));
          showFeedback(
            `🎉 پاداش دریافت شد: +${fmt(m.rewardShahi)} سکه شاهی 👑 و +${fmt(m.rewardOil)} بشکه نفت جایزه و +${fmt(m.rewardCash)} $!`
          );
          return { ...m, claimed: true, completed: true };
        }
        return m;
      })
    );
  };

  // صادرات دستی ۱۱,۵۰۰ بشکه نفت برای تکمیل زنده ماموریت اول
  const handleExportOilForMission = () => {
    const needed = 11500;
    if (currentOil < needed) {
      showFeedback(`موجودی نفت کافی نیست. نیاز به ${fmt(needed)} بشکه دارید.`, false);
      return;
    }
    setCurrentOil((o) => o - needed);
    setTreasuryDollars((t) => t + needed * 75);
    setMissions((prev) =>
      prev.map((m) => {
        if (m.id === 'exp_oil_50k') {
          return { ...m, currentCount: 50000, completed: true };
        }
        return m;
      })
    );
    showFeedback(`🚢 تعداد ${fmt(needed)} بشکه نفت صادر شد و ماموریت ۵۰ هزار بشکه‌ای تکمیل گردید!`);
  };

  // عملیات ضدجاسوسی برای تکمیل زنده ماموریت چهارم
  const handleInfiltratorCleanup = () => {
    setMissions((prev) =>
      prev.map((m) => {
        if (m.id === 'clean_infiltrators') {
          return { ...m, currentCount: 1, completed: true };
        }
        return m;
      })
    );
    showFeedback(`🕵️‍♂️ عملیات رصد ضدجاسوسی اجرا شد و نفوذی‌ها در نوار مرزی مهار شدند.`);
  };

  // =============================================================
  // ۲. بخش خدمات عمومی مردم، نیروگاه‌ها، قطعی و شورش
  // =============================================================
  const [powerPlants, setPowerPlants] = useState<{ [key: string]: number }>({
    wind: 2,
    solar: 2,
    hydro_dam: 1,
    fuel_plant: 1, // نیاز به ۲۰۰۰ بشکه نفت
    nuclear: 0,
  });

  const [waterPlants, setWaterPlants] = useState<{ [key: string]: number }>({
    wastewater: 1,
    groundwater: 2,
    desalination: 0,
  });

  const [gasPlants, setGasPlants] = useState<{ [key: string]: number }>({
    gas_storage: 2,
    flare_gas_capture: 1, // نیازمند حداقل ۵ دکل نفت
  });

  // ساعات قطعی برنامه‌ریزی‌شده
  const [powerOutageHours, setPowerOutageHours] = useState<number>(2);
  const [waterOutageHours, setWaterOutageHours] = useState<number>(1);
  const [gasOutageHours, setGasOutageHours] = useState<number>(1);

  // مودال قطعی دلخواه
  const [outageModalCat, setOutageModalCat] = useState<'power' | 'water' | 'gas' | null>(null);
  const [outageInputHours, setOutageInputHours] = useState<string>('4');

  // وضعیت شورش
  const [rebelRatio, setRebelRatio] = useState<number>(0);
  const [rebellionActive, setRebellionActive] = useState<boolean>(false);
  const [rebellionSecondsElapsed, setRebellionSecondsElapsed] = useState<number>(0);

  // محاسبه درصد پوشش با شرط خاموشی نیروگاه سوختی در نبود نفت
  const isFuelPlantOperational = currentOil >= 2000;
  const powerCoverage = Math.min(
    100,
    powerPlants.wind * 10 +
      powerPlants.solar * 15 +
      powerPlants.hydro_dam * 30 +
      (isFuelPlantOperational ? powerPlants.fuel_plant * 25 : 0) +
      powerPlants.nuclear * 50
  );

  const waterCoverage = Math.min(
    100,
    waterPlants.wastewater * 15 + waterPlants.groundwater * 25 + waterPlants.desalination * 40
  );

  const gasCoverage = Math.min(
    100,
    gasPlants.gas_storage * 20 + gasPlants.flare_gas_capture * 35
  );

  // محاسبه نارضایتی مردم
  let calculatedDissatisfaction = 20;
  if (powerCoverage < 60) calculatedDissatisfaction += (60 - powerCoverage) * 0.5;
  if (waterCoverage < 60) calculatedDissatisfaction += (60 - waterCoverage) * 0.6;
  if (gasCoverage < 60) calculatedDissatisfaction += (60 - gasCoverage) * 0.5;

  if (powerOutageHours > 6) calculatedDissatisfaction += (powerOutageHours - 6) * 5;
  if (waterOutageHours > 3) calculatedDissatisfaction += (waterOutageHours - 3) * 7;
  if (gasOutageHours > 4) calculatedDissatisfaction += (gasOutageHours - 4) * 6;

  calculatedDissatisfaction = Math.min(100, Math.round(calculatedDissatisfaction));
  const publicSatisfaction = Math.max(0, 100 - calculatedDissatisfaction);

  // تحریک خودکار شورش در صورت نارضایتی بالای ۷۰٪
  useEffect(() => {
    if (calculatedDissatisfaction >= 75 && !rebellionActive) {
      setRebellionActive(true);
      setRebelRatio(15);
      showFeedback('🚨 هشدار امنیتی: به دلیل قطعی مکرر و کمبود انرژی، مردم دست به شورش مسلحانه زدند!', false);
    }
  }, [calculatedDissatisfaction, rebellionActive]);

  // تشدید شورش هر ۱۰ دقیقه
  useEffect(() => {
    if (!rebellionActive) return;
    const interval = setInterval(() => {
      setRebellionSecondsElapsed((s) => s + 10);
      setRebelRatio((prev) => Math.min(100, prev + 5));
    }, 10000);
    return () => clearInterval(interval);
  }, [rebellionActive]);

  // =============================================================
  // ۳. بخش ساخت‌وساز، پژوهش، سهام، شرکت‌های اختصاصی، مگاپروژه‌ها و رسانه
  // =============================================================
  const [stocksList, setStocksList] = useState<BlueChipStock[]>([
    { key: 'petro_pars', name: 'پتروشیمی بین‌المللی پارس', sector: 'نفت و انرژی', price: 5400, growth: 12.5, dividend: 420, emoji: '🛢' },
    { key: 'steel_mobarakeh', name: 'صنایع فولاد متالورژی', sector: 'صنایع سنگین', price: 8200, growth: 8.2, dividend: 650, emoji: '🏗' },
    { key: 'iran_khodro', name: 'هولدینگ خودروسازی ملی', sector: 'ترابری', price: 3100, growth: -3.4, dividend: 190, emoji: '🚗' },
    { key: 'telecom_holding', name: 'ارتباطات ماهواره‌ای کوانتوم', sector: 'فناوری اطلاعات', price: 12500, growth: 16.8, dividend: 1100, emoji: '📡' },
    { key: 'pharma_sina', name: 'داروسازی بیوتکنولوژی سینا', sector: 'زیست‌پزشکی', price: 6900, growth: 5.1, dividend: 520, emoji: '💊' },
  ]);

  const [userStockHoldings, setUserStockHoldings] = useState<{ [key: string]: number }>({
    petro_pars: 520, // دارنده ۵۲٪ سهام (صاحب اکثریت مطلق ۵۱٪+)
    telecom_holding: 50,
  });
  const [buyStockQtyInput, setBuyStockQtyInput] = useState<string>('50');

  // شرکت‌های اختصاصی
  const [customEnterprises, setCustomEnterprises] = useState<CustomEnterprise[]>([
    {
      id: 'ent_1',
      category: 'gamedev',
      categoryName: 'بازی‌سازی',
      name: 'استودیو بازی‌های آریا',
      logo: '🎮',
      tier: 2,
      cycleIncome: 14000000,
      scienceBoost: 18,
    },
    {
      id: 'ent_2',
      category: 'automotive',
      categoryName: 'خودروسازی',
      name: 'پارس الکتریک موتورز',
      logo: '🏎️',
      tier: 1,
      cycleIncome: 18000000,
      scienceBoost: 15,
    },
  ]);
  const [newEntCat, setNewEntCat] = useState<string>('fashion');
  const [newEntName, setNewEntName] = useState<string>('خانه مد کیمیا');
  const [newEntLogo, setNewEntLogo] = useState<string>('👗');

  // مگاپروژه‌ها
  const [builtMegaprojects, setBuiltMegaprojects] = useState<string[]>(['national_tower']);

  // رسانه و اپراتور
  const [telecomOperator, setTelecomOperator] = useState<{
    name: string;
    logo: string;
    antennas: number;
    subscribers: number;
    cycleDividend: number;
  } | null>({
    name: 'همراه ملی پارس',
    logo: '📶',
    antennas: 85,
    subscribers: 3500000,
    cycleDividend: 20000000,
  });
  const [newOperatorName, setNewOperatorName] = useState<string>('ایرانسل کوانتوم');
  const [newOperatorLogo, setNewOperatorLogo] = useState<string>('🌐');

  // پست‌های ویدیویی رسانه‌ای
  const [mediaPosts, setMediaPosts] = useState<
    { id: string; caption: string; videoUrl: string; status: 'approved' | 'pending'; time: string }[]
  >([
    {
      id: 'post_1',
      caption: 'مراسم افتتاح توربین‌های بادی جدید در سواحل جنوبی کشور',
      videoUrl: 'https://t.me/c/worldwarfire/104',
      status: 'approved',
      time: '15 دقیقه قبل',
    },
  ]);
  const [videoCaptionInput, setVideoCaptionInput] = useState<string>('');
  const [videoUrlInput, setVideoUrlInput] = useState<string>('');
  const [lastPostTimestamp, setLastPostTimestamp] = useState<number>(0);

  // ۴. بازار نفت کشورها و قراردادها
  const [countryOilOffers, setCountryOilOffers] = useState<CountryOffer[]>([
    { id: 'off_1', countryName: 'روسیه', flag: '🇷🇺', barrels: 120000, pricePerBarrel: 72 },
    { id: 'off_2', countryName: 'عربستان', flag: '🇸🇦', barrels: 250000, pricePerBarrel: 69 },
    { id: 'off_3', countryName: 'عراق', flag: '🇮🇶', barrels: 90000, pricePerBarrel: 65 },
  ]);
  const [oilContracts, setOilContracts] = useState<OilContract[]>([
    {
      id: 'ct_1',
      fromCountry: 'ایران',
      fromFlag: '🇮🇷',
      toCountry: 'چین',
      toFlag: '🇨🇳',
      dailyBarrels: 50000,
      dailyPrice: 3500000,
      status: 'active',
    },
  ]);

  // ۵. وام‌های بین‌کشوری با کسر ۸۰٪ از درآمد
  const [sovereignLoans, setSovereignLoans] = useState<SovereignLoan[]>([
    {
      id: 'loan_1',
      lenderCountry: 'چین',
      lenderFlag: '🇨🇳',
      borrowerCountry: 'ایران',
      borrowerFlag: '🇮🇷',
      initialAmount: 500000000,
      remainingAmount: 280000000,
      createdAt: 'دیروز',
    },
  ]);

  // ۶. بازار جهانی و عمومی
  const [globalCommodities, setGlobalCommodities] = useState<MarketCommodity[]>([
    { key: 'wood', name: 'چوب صنعتی', unit: 'تن', price: 1200, stock: 95000, icon: '🪵' },
    { key: 'cement', name: 'سیمان ساختمانی', unit: 'تن', price: 2500, stock: 140000, icon: '🧱' },
    { key: 'steel', name: 'فولاد آلیاژی', unit: 'تن', price: 8000, stock: 65000, icon: '🏗️' },
    { key: 'iron', name: 'سنگ آهن فرآوری‌شده', unit: 'تن', price: 6500, stock: 80000, icon: '⚙️' },
    { key: 'aluminum', name: 'شمش آلومینیوم', unit: 'تن', price: 4200, stock: 45000, icon: '⛓️' },
    { key: 'microchips', name: 'ریزتراشه‌های نظامی', unit: 'بسته', price: 25000, stock: 12000, icon: '💾' },
  ]);

  // ۷. بانک مرکزی
  const [centralBankBudget, setCentralBankBudget] = useState<number>(890000000);
  const [centralBankAuditLog, setCentralBankAuditLog] = useState<CentralBankAudit[]>([
    { id: 'a_1', amount: 15000000, reason: 'کارمزد 1.5% فروش نفت دوجانبه', type: 'tax', time: '10 دقیقه قبل' },
    { id: 'a_2', amount: 24000000, reason: 'کارمزد 3% فروش فوری نفت به بازار جهانی', type: 'tax', time: '35 دقیقه قبل' },
  ]);

  // ۸. تنظیمات قیمت ادمین (قابل ویرایش)
  const [adminPlantCosts, setAdminPlantCosts] = useState({
    wind: 25000000,
    solar: 40000000,
    hydro_dam: 120000000,
    fuel_plant: 70000000,
    nuclear: 350000000,
    wastewater: 30000000,
    groundwater: 50000000,
    desalination: 150000000,
    gas_storage: 45000000,
    flare_gas_capture: 85000000,
  });

  const [adminQuellCosts, setAdminQuellCosts] = useState({
    police: 35000000,
    military: 60000000,
    apology: 5000000,
    reform_amnesty: 50000000,
  });

  // فیلدهای ورودی دوگانه فارسی/انگلیسی
  const [customRigsQtyStr, setCustomRigsQtyStr] = useState<string>('1');
  const [customWorkersQtyStr, setCustomWorkersQtyStr] = useState<string>('20');
  const [customVaultInputStr, setCustomVaultInputStr] = useState<string>('50000000');
  const [vaultConfirmModal, setVaultConfirmModal] = useState<boolean>(false);
  const [exploreConfirmModal, setExploreConfirmModal] = useState<boolean>(false);

  // ۹. سامانه فرمانده کل و هیئت وزیران (انتصاب افراد بدون کشور)
  const [minister, setMinister] = useState<{
    telegramId: number;
    displayName: string;
    appointedAt: string;
    rank: string;
  } | null>({
    telegramId: 88765432,
    displayName: 'سرهنگ کاوه راد',
    appointedAt: '2026-10-25',
    rank: 'وزیر دفاع و جانشین فرماندهی',
  });
  const [candidates, setCandidates] = useState([
    { telegramId: 99432101, displayName: 'امیرحسین تهرانی', status: 'آماده خدمت', experience: 'سابقه ۳ پیروزی استراتژیک' },
    { telegramId: 77651234, displayName: 'مهندس آریا پارسا', status: 'آنلاین', experience: 'متخصص پدافند و لجستیک' },
    { telegramId: 55439871, displayName: 'دکتر سام نوبخت', status: 'آماده خدمت', experience: 'کارشناس اقتصاد و غنی‌سازی' },
    { telegramId: 66321980, displayName: 'سردار روزبه پیروز', status: 'آنلاین', experience: 'فرمانده زرهی و تاکتیکی' },
  ]);

  // ۱۰. سامانه خرید VIP سکه شاهی با پول واقعی (تومان، کارت به کارت و فیش)
  const [shahiPriceToman, setShahiPriceToman] = useState<number>(50000);
  const [paymentCardNumber] = useState<string>('۶۰۳۷-۹۹۷۵-۱۲۳۴-۵۶۷۸');
  const [paymentCardHolder] = useState<string>('حساب ارزی مدیریت جنگ جهانی');
  const [vipCoinPackage, setVipCoinPackage] = useState<number>(10);
  const [vipReceiptText, setVipReceiptText] = useState<string>('');
  const [vipCustomCount, setVipCustomCount] = useState<string>('15');
  const [shahiOrders, setShahiOrders] = useState([
    {
      id: 'ord_101',
      displayName: 'فرمانده آرمان',
      telegramId: 19827364,
      countryFlag: '🇮🇷',
      countryName: 'ایران',
      coinsCount: 20,
      totalPriceToman: 1000000,
      status: 'pending_admin',
      receiptType: 'photo',
      receiptText: 'واریز از همراه بانک سامان پیگیری ۹۲۸۳۷۴',
      createdAt: '12 دقیقه قبل',
    },
    {
      id: 'ord_102',
      displayName: 'ژنرال حمید',
      telegramId: 98214472,
      countryFlag: '🇩🇪',
      countryName: 'آلمان',
      coinsCount: 10,
      totalPriceToman: 500000,
      status: 'pending_admin',
      receiptType: 'text',
      receiptText: 'کد رهگیری: 84920198 بانک ملت',
      createdAt: '28 دقیقه قبل',
    },
  ]);

  // ۱۱. لاگ زنده پژوهش‌ها و پیشرفت‌های ملی (منتشرشده در کانال تلگرام بدون اسپم پی‌وی)
  const [researchLogs, setResearchLogs] = useState([
    {
      id: 'rlog_1',
      countryName: 'ایران',
      countryFlag: '🇮🇷',
      type: 'internet_upgrade',
      title: 'ارتقای شبکه اینترنت ملی به نسل فراکوانتومی 7G هیپرسیگنال',
      details: 'شبکه از 6G به 7G ارتقا یافت (+65 امتیاز علمی و +25٪ رضایت مردمی). بدون ارسال پیام خصوصی در پی‌وی، مستقیماً در کانال بازی ثبت شد.',
      timestamp: '۵ دقیقه پیش',
      badgeColor: 'sky',
    },
    {
      id: 'rlog_2',
      countryName: 'آلمان',
      countryFlag: '🇩🇪',
      type: 'megaproject',
      title: 'احداث مگاپروژه ملی: کلان‌شهر هوشمند آینده 🏙️',
      details: 'کلان‌شهر هوشمند با مصرف ۸۰۰ تن فولاد، ۹۰۰ تن سیمان و ۱۲۰۰ بشکه نفت به بهره‌برداری کامل رسید (+۴۰ علم).',
      timestamp: '۱۸ دقیقه پیش',
      badgeColor: 'emerald',
    },
    {
      id: 'rlog_3',
      countryName: 'ژاپن',
      countryFlag: '🇯🇵',
      type: 'enterprise',
      title: 'تاسیس شرکت صنایع رباتیک و هوش نسل ۵ 🤖',
      details: 'ثبت برند اختصاصی در بورس فناوری با سود تضمین‌شده هر چرخه +۲۵M$ و +۲۰ امتیاز علمی.',
      timestamp: '۴۵ دقیقه پیش',
      badgeColor: 'purple',
    },
  ]);

  // ۱۲. مدیریت مصالح مگاپروژه‌ها توسط ادمین در پنل
  const [projectMaterialsConfig, setProjectMaterialsConfig] = useState<Record<string, {
    name: string;
    emoji: string;
    cost: number;
    science: number;
    materials: Record<string, number>;
  }>>({
    artificial_island: {
      name: 'جزیره مصنوعی خلیج',
      emoji: '🏝',
      cost: 800000000,
      science: 15,
      materials: { cement: 300, iron: 150, oil: 500 },
    },
    national_tower: {
      name: 'برج ملی و نماد حاکمیت',
      emoji: '🗼',
      cost: 1200000000,
      science: 25,
      materials: { steel: 400, cement: 250, copper: 80 },
    },
    megacity: {
      name: 'کلان‌شهر هوشمند آینده',
      emoji: '🏙',
      cost: 2500000000,
      science: 40,
      materials: { steel: 800, cement: 900, copper: 200, oil: 1200 },
    },
    moon_mission: {
      name: 'پروژه فضایی فرود بر ماه',
      emoji: '🌕',
      cost: 5000000000,
      science: 70,
      materials: { steel: 1500, copper: 600, oil: 3000 },
    },
    space_station: {
      name: 'ساخت پایگاه فضایی مداری',
      emoji: '🛰',
      cost: 10000000000,
      science: 100,
      materials: { steel: 3000, copper: 1200, oil: 6000 },
    },
  });

  const [selectedAdminProjectKey, setSelectedAdminProjectKey] = useState<string>('megacity');

  // =============================================================
  // عملیات هسته سیستم خدمات عمومی و نیروگاه‌ها
  // =============================================================


  // خرید نیروگاه برق
  const handleBuyPowerPlant = (key: string, name: string) => {
    const cost = (adminPlantCosts as any)[key] || 30000000;
    if (treasuryDollars < cost) {
      showFeedback(`بودجه خزانه برای احداث ${name} کافی نیست. نیاز به ${fmt(cost)} $ دارید.`, false);
      return;
    }
    setTreasuryDollars((t) => t - cost);
    setPowerPlants((prev) => ({ ...prev, [key]: (prev[key] || 0) + 1 }));
    showFeedback(`✅ احداث ${name} با موفقیت انجام شد! هزینه ${fmt(cost)} $ پرداخت گردید.`);
  };

  // خرید تاسیسات آب
  const handleBuyWaterPlant = (key: string, name: string) => {
    const cost = (adminPlantCosts as any)[key] || 35000000;
    if (treasuryDollars < cost) {
      showFeedback(`بودجه خزانه کافی نیست. نیاز به ${fmt(cost)} $ دارید.`, false);
      return;
    }
    setTreasuryDollars((t) => t - cost);
    setWaterPlants((prev) => ({ ...prev, [key]: (prev[key] || 0) + 1 }));
    showFeedback(`✅ احداث ${name} با هزینه ${fmt(cost)} $ تکمیل شد.`);
  };

  // خرید تاسیسات گاز با شرط حداقل ۵ دکل برای مشعل
  const handleBuyGasPlant = (key: string, name: string) => {
    if (key === 'flare_gas_capture' && oilRigs < 5) {
      showFeedback(`❌ پیش‌شرط احداث رعایت نشده است! کشور شما باید حداقل ۵ دکل نفتی فعال داشته باشد (دکل فعلی: ${fmt(oilRigs)}).`, false);
      return;
    }
    const cost = (adminPlantCosts as any)[key] || 45000000;
    if (treasuryDollars < cost) {
      showFeedback(`بودجه خزانه کافی نیست. نیاز به ${fmt(cost)} $ دارید.`, false);
      return;
    }
    setTreasuryDollars((t) => t - cost);
    setGasPlants((prev) => ({ ...prev, [key]: (prev[key] || 0) + 1 }));
    showFeedback(`✅ تاسیسات گازی «${name}» با موفقیت به شبکه متصل شد.`);
  };

  // اعمال ساعات قطعی دلخواه
  const handleApplyOutage = () => {
    if (!outageModalCat) return;
    const hours = parseInputNumber(outageInputHours);
    if (outageModalCat === 'power') {
      setPowerOutageHours(hours);
      if (hours > 6) {
        showFeedback(`⚠️ قطعی برق به ${fmt(hours)} ساعت تنظیم شد. به دلیل قطعی بالای 6 ساعت، نارضایتی مردم اوج گرفت!`, false);
      } else {
        showFeedback(`✅ ساعات قطعی برق به ${fmt(hours)} ساعت تنظیم شد (در محدوده مجاز).`);
      }
    } else if (outageModalCat === 'water') {
      setWaterOutageHours(hours);
      if (hours > 3) {
        showFeedback(`⚠️ قطعی آب به ${fmt(hours)} ساعت تنظیم شد. به دلیل قطعی بالای 3 ساعت، نارضایتی مردم اوج گرفت!`, false);
      } else {
        showFeedback(`✅ ساعات قطعی آب به ${fmt(hours)} ساعت تنظیم شد.`);
      }
    } else if (outageModalCat === 'gas') {
      setGasOutageHours(hours);
      if (hours > 4) {
        showFeedback(`⚠️ قطعی گاز به ${fmt(hours)} ساعت تنظیم شد. به دلیل قطعی بالای 4 ساعت، نارضایتی مردم اوج گرفت!`, false);
      } else {
        showFeedback(`✅ ساعات قطعی گاز به ${fmt(hours)} ساعت تنظیم شد.`);
      }
    }
    setOutageModalCat(null);
  };

  // سرکوب شورش با ۴ شیوه
  const handleQuellRebellion = (method: 'police' | 'military' | 'apology' | 'reform_amnesty') => {
    const cost = adminQuellCosts[method];
    if (treasuryDollars < cost) {
      showFeedback(`بودجه کافی برای اجرای این دستور امنیتی وجود ندارد (${fmt(cost)} $).`, false);
      return;
    }
    setTreasuryDollars((t) => t - cost);

    if (method === 'police') {
      setRebelRatio((r) => Math.max(0, r - 45));
      if (rebelRatio <= 45) setRebellionActive(false);
      showFeedback(`👮 استقرار یگان ویژه: خیابان‌های بحرانی آزاد شدند و 45% از جمعیت شورشیان متفرق گردیدند.`);
    } else if (method === 'military') {
      setRebelRatio(0);
      setRebellionActive(false);
      showFeedback(`⚔️ سرکوب قهرآمیز ارتش: شورش با آتش سنگین سرکوب شد، اما مشروعیت کشور نزد نهادهای بین‌المللی سقوط کرد.`, false);
    } else if (method === 'apology') {
      setRebelRatio((r) => Math.max(0, r - 35));
      if (rebelRatio <= 35) setRebellionActive(false);
      showFeedback(`📜 پیام عذرخواهی رسمی: تواضع دولت و وعده حل فوری قطعی‌ها باعث آرام شدن 35% شورشیان شد.`);
    } else if (method === 'reform_amnesty') {
      setRebelRatio(0);
      setRebellionActive(false);
      setPowerOutageHours(0);
      setWaterOutageHours(0);
      setGasOutageHours(0);
      showFeedback(`🕊️ تشکیل شورای اصلاحات ملی و عفو عمومی: مطالبات معیشتی مردم تصویب و شورش به طور 100% ریشه‌کن شد!`);
    }
  };

  // =============================================================
  // عملیات ساخت‌وساز، پژوهش، بورس، شرکت‌ها و رسانه
  // =============================================================

  // خرید سهام بورس
  const handleBuyStock = (stock: BlueChipStock) => {
    const qty = parseInputNumber(buyStockQtyInput);
    if (qty <= 0) {
      showFeedback('تعداد سهم درخواستی نامعتبر است.', false);
      return;
    }
    const totalCost = qty * stock.price;
    if (treasuryDollars < totalCost) {
      showFeedback(`بودجه خزانه کافی نیست. نیاز به ${fmt(totalCost)} $ دارید.`, false);
      return;
    }
    setTreasuryDollars((t) => t - totalCost);
    setUserStockHoldings((prev) => ({ ...prev, [stock.key]: (prev[stock.key] || 0) + qty }));
    setUserCountry((u) => ({ ...u, scienceScore: u.scienceScore + Math.max(1, Math.floor(qty * 0.05)) }));
    showFeedback(`✅ تعداد ${fmt(qty)} سهم از «${stock.name}» خریداری شد. +${Math.max(1, Math.floor(qty * 0.05))} به امتیاز علم کشور افزوده شد.`);
  };

  // ثبت شرکت اختصاصی
  const handleCreateEnterprise = () => {
    const cost = 50000000;
    if (treasuryDollars < cost) {
      showFeedback(`برای ثبت شرکت اختصاصی به ${fmt(cost)} $ نیاز دارید.`, false);
      return;
    }
    const catNames: { [k: string]: string } = {
      fashion: 'لباس و مد',
      gamedev: 'بازی‌سازی',
      film: 'فیلم‌سازی',
      automotive: 'خودروسازی',
      pharma: 'شرکت دارویی',
    };
    const newEnt: CustomEnterprise = {
      id: `ent_${Date.now()}`,
      category: newEntCat,
      categoryName: catNames[newEntCat] || 'تولیدی',
      name: newEntName.trim() || 'شرکت پیشگام',
      logo: newEntLogo.trim() || '🏢',
      tier: 1,
      cycleIncome: 12000000,
      scienceBoost: 12,
    };
    setTreasuryDollars((t) => t - cost);
    setCustomEnterprises([newEnt, ...customEnterprises]);
    setUserCountry((u) => ({ ...u, scienceScore: u.scienceScore + newEnt.scienceBoost }));
    showFeedback(`🎉 شرکت «${newEnt.logo} ${newEnt.name}» با موفقیت ثبت شد! درآمد هر چرخه: +${fmt(newEnt.cycleIncome)} $`);
  };

  // ارتقای شرکت اختصاصی
  const handleUpgradeEnterprise = (entId: string) => {
    const ent = customEnterprises.find((e) => e.id === entId);
    if (!ent || ent.tier >= 5) return;
    const cost = ent.cycleIncome * 3;
    if (treasuryDollars < cost) {
      showFeedback(`برای ارتقا به سطح ${ent.tier + 1} به ${fmt(cost)} $ نیاز دارید.`, false);
      return;
    }
    setTreasuryDollars((t) => t - cost);
    setCustomEnterprises((prev) =>
      prev.map((e) =>
        e.id === entId
          ? { ...e, tier: e.tier + 1, cycleIncome: Math.round(e.cycleIncome * 1.8), scienceBoost: e.scienceBoost + 10 }
          : e
      )
    );
    setUserCountry((u) => ({ ...u, scienceScore: u.scienceScore + 10 }));
    showFeedback(`⬆️ شرکت «${ent.name}» به سطح ${ent.tier + 1} ارتقا یافت! درآمد دوره‌ای: +${fmt(Math.round(ent.cycleIncome * 1.8))} $`);
  };

  // احداث مگاپروژه با ثبت در لاگ پژوهش و اطلاعیه کانال
  const handleBuildMegaproject = (key: string, name: string, cost: number, scienceBonus: number) => {
    if (builtMegaprojects.includes(key)) return;
    if (treasuryDollars < cost) {
      showFeedback(`بودجه خزانه برای این مگاپروژه تاریخی کافی نیست (${fmt(cost)} $).`, false);
      return;
    }
    setTreasuryDollars((t) => t - cost);
    setBuiltMegaprojects([...builtMegaprojects, key]);
    setUserCountry((u) => ({ ...u, scienceScore: u.scienceScore + scienceBonus }));

    // ثبت در لاگ پژوهش ملی و اطلاعیه کانال تلگرام
    const newLog = {
      id: `rlog_${Date.now()}`,
      countryName: userCountry.name,
      countryFlag: userCountry.flag,
      type: 'megaproject',
      title: `احداث موفقیت‌آمیز مگاپروژه تمدنی: ${name} 🗼`,
      details: `پروژه تاریخی «${name}» با سرمایه‌گذاری ${fmt(cost)} $ تکمیل شد و +${fmt(scienceBonus)} امتیاز علم به اقتدار علمی کشور افزود. گزارش رسمی به کانال تلگرام ارسال شد.`,
      timestamp: 'هم‌اکنون',
      badgeColor: 'emerald',
    };
    setResearchLogs((prev) => [newLog, ...prev]);
    showFeedback(`🗼 افتتاح تاریخی: مگاپروژه «${name}» ساخته شد! +${fmt(scienceBonus)} امتیاز علم ملی کسب شد و در کانال ثبت گردید.`);
  };

  // ارتقای بی‌نهایت نسل اینترنت (بدون سقف: 7G, 8G, 9G... با ارسال به کانال و بدون اسپم پی‌وی)
  const handleUpgradeInternet = () => {
    // استخراج عدد نسل فعلی
    const currentNum = parseInt(userCountry.internet.replace(/\D/g, ''), 10) || 3;
    const nextNum = currentNum + 1;
    const nextTier = `${nextNum}G`;

    // هزینه و علم مقیاس‌پذیر بی‌نهایت
    let cost = 50000000;
    let scienceBonus = 15;
    if (nextNum === 4) {
      cost = 50000000;
      scienceBonus = 15;
    } else if (nextNum === 5) {
      cost = 150000000;
      scienceBonus = 25;
    } else if (nextNum === 6) {
      cost = 400000000;
      scienceBonus = 40;
    } else {
      // فرمول مقیاس‌پذیر از 7G تا بینهایت
      cost = Math.round(400000000 * Math.pow(1.8, nextNum - 6));
      scienceBonus = 40 + (nextNum - 6) * 20;
    }

    if (treasuryDollars < cost) {
      showFeedback(`برای ارتقا به نسل پیشرفته ${nextTier} به ${fmt(cost)} $ نیاز دارید.`, false);
      return;
    }

    setTreasuryDollars((t) => t - cost);
    setUserCountry((u) => ({
      ...u,
      internet: nextTier,
      scienceScore: u.scienceScore + scienceBonus,
    }));

    // ثبت لاگ پژوهش بدون ارسال پیام خصوصی در پی‌وی تلگرام (طبق درخواست مستقیم کاربر)
    const newLog = {
      id: `rlog_${Date.now()}`,
      countryName: userCountry.name,
      countryFlag: userCountry.flag,
      type: 'internet_upgrade',
      title: `ارتقای زیرساخت شبکه ملی به نسل فراکوانتومی ${nextTier} هیپرسیگنال 📶`,
      details: `شبکه از ${userCountry.internet} به نسل پیشرفته ${nextTier} ارتقا یافت (+${fmt(scienceBonus)} امتیاز علم و +25٪ رضایت عمومی). بدون ارسال پیام در پی‌وی، اطلاعیه افتخارآمیز در کانال تلگرام منتشر شد.`,
      timestamp: 'هم‌اکنون',
      badgeColor: 'sky',
    };
    setResearchLogs((prev) => [newLog, ...prev]);
    showFeedback(`📶 ارتقای اینترنت به نسل ${nextTier} تکمیل شد! پیام پی‌وی حذف شد و گزارش مستقیماً در کانال بازی منتشر گردید.`);
  };

  // انتصاب شهروند بدون کشور به عنوان وزیر / جانشین فرماندهی
  const handleAppointMinister = (cand: { telegramId: number; displayName: string; experience: string }) => {
    setMinister({
      telegramId: cand.telegramId,
      displayName: cand.displayName,
      appointedAt: new Date().toISOString().slice(0, 10),
      rank: 'وزیر دفاع و جانشین فرماندهی',
    });
    setCandidates((prev) => prev.filter((c) => c.telegramId !== cand.telegramId));
    showFeedback(`🎖️ جناب آقای «${cand.displayName}» رسماً به عنوان وزیر دفاع و جانشین فرماندهی کشور منصوب گردید! (+10% قدرت پدافند خودکار مرزها)`);
  };

  // عزل وزیر
  const handleDismissMinister = () => {
    if (!minister) return;
    const oldName = minister.displayName;
    setCandidates((prev) => [
      {
        telegramId: minister.telegramId,
        displayName: minister.displayName,
        status: 'آماده خدمت مجدد',
        experience: 'وزیر سابق دفاع کشور',
      },
      ...prev,
    ]);
    setMinister(null);
    showFeedback(`⚖️ حکم عزل «${oldName}» از سمت وزارت دفاع صادر و به وضعیت شهروند عادی منتقل شد.`);
  };

  // ثبت سفارش خرید VIP سکه شاهی با پول واقعی و فیش واریزی (مشابه خرید کشور VIP)
  const handleSubmitVipShahiOrder = () => {
    const coins = vipCoinPackage > 0 ? vipCoinPackage : parseInputNumber(vipCustomCount);
    if (coins <= 0) {
      showFeedback('تعداد سکه درخواستی نامعتبر است.', false);
      return;
    }
    const totalPrice = coins * shahiPriceToman;
    if (!vipReceiptText.trim()) {
      showFeedback('لطفاً شماره پیگیری یا متن فیش واریز کارت‌به‌کارت را وارد نمایید.', false);
      return;
    }

    const newOrder = {
      id: `ord_${Date.now()}`,
      displayName: userCountry.leader,
      telegramId: 19827364,
      countryFlag: userCountry.flag,
      countryName: userCountry.name,
      coinsCount: coins,
      totalPriceToman: totalPrice,
      status: 'pending_admin',
      receiptType: 'text',
      receiptText: vipReceiptText.trim(),
      createdAt: 'هم‌اکنون',
    };

    setShahiOrders([newOrder, ...shahiOrders]);
    setVipReceiptText('');
    showFeedback(`👑 سفارش خرید VIP تعداد ${fmt(coins)} سکه شاهی به مبلغ ${fmt(totalPrice)} تومان ثبت شد و به صف تایید ادمین رفت!`);
  };

  // تایید سفارش خرید VIP سکه شاهی توسط ادمین در پنل
  const handleApproveShahiOrder = (orderId: string) => {
    const ord = shahiOrders.find((o) => o.id === orderId);
    if (!ord || ord.status !== 'pending_admin') return;

    setShahiOrders((prev) =>
      prev.map((o) => (o.id === orderId ? { ...o, status: 'approved' } : o))
    );

    // اگر سفارش متعلق به همین کاربر بود، سکه‌ها بلافاصله افزوده شود
    if (ord.telegramId === 19827364) {
      setShahiCoins((c) => c + ord.coinsCount);
    }

    showFeedback(`✅ فیش واریزی سفارش ${orderId} تایید شد و ${fmt(ord.coinsCount)} سکه شاهی به حساب بازیکن واریز گردید!`);
  };

  // رد سفارش خرید VIP سکه شاهی توسط ادمین در پنل
  const handleRejectShahiOrder = (orderId: string) => {
    setShahiOrders((prev) =>
      prev.map((o) => (o.id === orderId ? { ...o, status: 'rejected' } : o))
    );
    showFeedback(`❌ سفارش ${orderId} رد شد.`, false);
  };

  // ذخیره نرخ جدید تومان برای هر سکه شاهی توسط ادمین
  const handleSaveShahiPrice = (newPrice: number) => {
    if (newPrice <= 0) {
      showFeedback('نرخ سکه شاهی باید بیشتر از صفر تومان باشد.', false);
      return;
    }
    setShahiPriceToman(newPrice);
    showFeedback(`💰 نرخ رسمی هر سکه شاهی در پنل ادمین به ${fmt(newPrice)} تومان تنظیم گردید.`);
  };

  // ذخیره تنظیمات مصالح مگاپروژه توسط ادمین
  const handleSaveProjectMaterials = (
    projKey: string,
    materialsMap: Record<string, number>
  ) => {
    setProjectMaterialsConfig((prev) => {
      const existing = prev[projKey];
      if (!existing) return prev;
      return {
        ...prev,
        [projKey]: {
          ...existing,
          materials: materialsMap,
        },
      };
    });
    showFeedback(`🏗️ فهرست مصالح مورد نیاز برای مگاپروژه «${projectMaterialsConfig[projKey]?.name || projKey}» با موفقیت ذخیره شد.`);
  };

  // راه‌اندازی اپراتور ملی
  const handleCreateTelecomOperator = () => {
    const cost = 120000000;
    if (treasuryDollars < cost) {
      showFeedback(`برای احداث دکل‌ها و تاسیس اپراتور به ${fmt(cost)} $ نیاز دارید.`, false);
      return;
    }
    setTreasuryDollars((t) => t - cost);
    setTelecomOperator({
      name: newOperatorName.trim() || 'اپراتور ملی',
      logo: newOperatorLogo.trim() || '📶',
      antennas: 50,
      subscribers: 2500000,
      cycleDividend: 18000000,
    });
    setUserCountry((u) => ({ ...u, scienceScore: u.scienceScore + 20 }));
    showFeedback(`🎉 اپراتور اختصاصی سراسری افتتاح گردید! سود هر چرخه درآمد: +${fmt(18000000)} $`);
  };

  // ارسال پست ویدیویی با کولدان ۱۰ دقیقه
  const handleSubmitMediaPost = () => {
    const now = Date.now();
    if (now - lastPostTimestamp < 10 * 60 * 1000) {
      const waitMin = Math.ceil((10 * 60 * 1000 - (now - lastPostTimestamp)) / 60000);
      showFeedback(`برای انتشار ویدیوی بعدی باید ${waitMin} دقیقه دیگر صبر نمایید (محدودیت ۱۰ دقیقه).`, false);
      return;
    }
    if (!videoCaptionInput.trim()) {
      showFeedback('متن و کپشن پست رسانه‌ای را بنویسید.', false);
      return;
    }
    const newPost = {
      id: `post_${Date.now()}`,
      caption: videoCaptionInput.trim(),
      videoUrl: videoUrlInput.trim() || 'https://t.me/c/video/live',
      status: 'pending' as const,
      time: 'هم‌اکنون',
    };
    setMediaPosts([newPost, ...mediaPosts]);
    setLastPostTimestamp(now);
    setVideoCaptionInput('');
    setVideoUrlInput('');
    showFeedback(`📹 ویدیو با موفقیت ارسال شد و در صف تایید ادمین قرار گرفت (کولدان ۱۰ دقیقه).`);
  };

  // چرخه واریز درآمد با تسویه خودکار ۸۰٪ وام + سود شرکت‌ها و اپراتور
  const handleSimulateIncomeCycle = () => {
    let grossIncome = 150000000;

    // اضافه شدن سود سهام بورس
    let stockDividends = 0;
    for (const [k, qty] of Object.entries(userStockHoldings)) {
      const s = stocksList.find((x) => x.key === k);
      if (s) stockDividends += qty * s.dividend;
    }

    // سود شرکت‌های اختصاصی
    const entProfits = customEnterprises.reduce((acc, curr) => acc + curr.cycleIncome, 0);

    // سود اپراتور مخابرات
    const opProfits = telecomOperator ? telecomOperator.cycleDividend : 0;

    grossIncome += stockDividends + entProfits + opProfits;

    const activeLoan = sovereignLoans.find((l) => l.remainingAmount > 0 && l.borrowerCountry === userCountry.name);

    if (!activeLoan) {
      setTreasuryDollars((t) => t + grossIncome);
      showFeedback(`💰 واریز دوره به خزانه انجام شد: ${fmt(grossIncome)} $ (شامل سود سهام: ${fmt(stockDividends)}$ | شرکت‌ها: ${fmt(entProfits)}$ | اپراتور: ${fmt(opProfits)}$) بدون بدهی وام.`);
      return;
    }

    // کسر ۸۰٪ بابت بازپرداخت وام
    const maxRepayment = Math.floor(grossIncome * 0.8);
    const actualRepayment = Math.min(activeLoan.remainingAmount, maxRepayment);
    const netIncome = grossIncome - actualRepayment;

    setSovereignLoans((prev) =>
      prev.map((l) => (l.id === activeLoan.id ? { ...l, remainingAmount: l.remainingAmount - actualRepayment } : l))
    );
    setTreasuryDollars((t) => t + netIncome);

    showFeedback(
      `📊 واریز دوره با کسر خودکار 80%: مبلغ ${fmt(actualRepayment)} $ به ${activeLoan.lenderCountry} پرداخت شد. خالص واریزی به خزانه شما: ${fmt(netIncome)} $.`
    );
  };

  // ویجت یکپارچه ماموریت‌های روزانه با جایزه سکه شاهی و نفت
  const renderDailyMissionsWidget = (subtitle?: string) => (
    <div className="p-5 rounded-xl bg-[#1e293b] border border-amber-500/30 shadow-lg relative overflow-hidden">
      <div className="absolute top-0 right-0 w-32 h-32 bg-amber-500/5 rounded-full blur-2xl pointer-events-none" />
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 border-b border-[#334155] pb-4 mb-4">
        <div>
          <h3 className="font-black text-base text-white flex items-center gap-2">
            <Target className="w-5 h-5 text-amber-400" />
            ماموریت‌های روزانه (سکه شاهی 👑 و نفت جایزه 🛢️)
          </h3>
          <p className="text-xs text-slate-400 mt-1">
            {subtitle || 'با تکمیل اهداف روزانه، سکه شاهی (AW Coin)، نفت خام جایزه و بودجه دلاری دریافت کرده و کشور خود را ارتقا دهید.'}
          </p>
        </div>
        <div className="flex items-center gap-2">
          <span className="px-3 py-1 rounded-full bg-amber-950/80 border border-amber-500/40 text-amber-300 text-xs font-mono font-bold flex items-center gap-1">
            <Crown className="w-3.5 h-3.5" />
            موجودی شاهی: {fmt(shahiCoins)} 👑
          </span>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
        {missions.map((m) => {
          const pct = Math.min(100, Math.round((m.currentCount / m.targetCount) * 100));
          return (
            <div
              key={m.id}
              className={`p-4 rounded-xl border transition flex flex-col justify-between gap-3 ${
                m.claimed
                  ? 'bg-[#0f172a]/70 border-emerald-900/40 opacity-80'
                  : m.completed
                  ? 'bg-[#0f172a] border-amber-500/50 shadow-md'
                  : 'bg-[#0f172a] border-[#334155]'
              }`}
            >
              <div>
                <div className="flex items-center justify-between gap-2 mb-1.5">
                  <span className="font-bold text-sm text-white flex items-center gap-1.5">
                    <Sparkles className="w-4 h-4 text-amber-400" />
                    {m.title}
                  </span>
                  <span
                    className={`text-[11px] font-mono font-black px-2 py-0.5 rounded-full ${
                      m.claimed
                        ? 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                        : m.completed
                        ? 'bg-amber-950 text-amber-300 border border-amber-700 animate-pulse'
                        : 'bg-slate-800 text-slate-300'
                    }`}
                  >
                    {m.claimed ? 'دریافت شد ✅' : m.completed ? 'آماده دریافت 🎁' : `${pct}%`}
                  </span>
                </div>
                <p className="text-xs text-slate-400 leading-relaxed mb-3">{m.desc}</p>

                {/* نوار پیشرفت */}
                <div className="space-y-1 mb-3">
                  <div className="flex justify-between text-[11px] font-mono text-slate-400">
                    <span>پیشرفت هدف:</span>
                    <span>
                      <b className="text-white">{fmt(m.currentCount)}</b> / {fmt(m.targetCount)} {m.unit}
                    </span>
                  </div>
                  <div className="w-full h-2 rounded-full bg-slate-800 overflow-hidden">
                    <div
                      className={`h-full transition-all duration-500 ${
                        m.claimed ? 'bg-emerald-500' : m.completed ? 'bg-amber-400' : 'bg-sky-500'
                      }`}
                      style={{ width: `${pct}%` }}
                    />
                  </div>
                </div>

                {/* پاداش‌ها */}
                <div className="flex flex-wrap items-center gap-2 text-[11px] text-slate-300 bg-[#1e293b] p-2 rounded-lg border border-[#334155]/60">
                  <span className="text-amber-400 font-bold flex items-center gap-1">
                    👑 {fmt(m.rewardShahi)} سکه شاهی
                  </span>
                  <span className="text-sky-400 font-bold flex items-center gap-1">
                    🛢️ +{fmt(m.rewardOil)} ب نفت
                  </span>
                  <span className="text-emerald-400 font-mono font-bold">
                    +{fmt(m.rewardCash)} $
                  </span>
                </div>
              </div>

              {/* کلیدهای اقدام */}
              <div className="pt-1">
                {m.claimed ? (
                  <div className="text-center py-1.5 text-xs text-emerald-400 font-bold flex items-center justify-center gap-1.5">
                    <CheckCircle2 className="w-4 h-4" />
                    پاداش امروز این ماموریت واریز شد
                  </div>
                ) : m.completed ? (
                  <button
                    onClick={() => handleClaimMission(m.id)}
                    className="w-full py-2 rounded-lg bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-600 hover:to-amber-700 text-slate-950 font-black text-xs transition shadow flex items-center justify-center gap-2"
                  >
                    <Crown className="w-4 h-4" />
                    دریافت پاداش ({fmt(m.rewardShahi)} سکه شاهی + {fmt(m.rewardOil)} نفت)
                  </button>
                ) : m.id === 'exp_oil_50k' ? (
                  <button
                    onClick={handleExportOilForMission}
                    className="w-full py-2 rounded-lg bg-sky-600 hover:bg-sky-700 text-white font-bold text-xs transition shadow flex items-center justify-center gap-2"
                  >
                    <Droplets className="w-4 h-4" />
                    صادرات فوری (11,500 بشکه نفت) جهت تکمیل ماموریت
                  </button>
                ) : m.id === 'clean_infiltrators' ? (
                  <button
                    onClick={handleInfiltratorCleanup}
                    className="w-full py-2 rounded-lg bg-slate-700 hover:bg-slate-600 text-white font-bold text-xs transition shadow flex items-center justify-center gap-2"
                  >
                    <Target className="w-4 h-4" />
                    اجرای عملیات رصد و پاکسازی نفوذی‌ها
                  </button>
                ) : (
                  <div className="text-center py-1.5 text-xs text-slate-500">
                    در حال پیگیری خودکار شاخص‌ها...
                  </div>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-[#0f172a] text-[#f8fafc] font-sans antialiased pb-20 selection:bg-amber-600 selection:text-white" dir="rtl">
      {/* هدر بالایی با ارقام کامپکت انگلیسی */}
      <header className="border-b border-[#334155] bg-[#1e293b] sticky top-0 z-40 shadow-lg">
        <div className="max-w-7xl mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-red-700 border border-red-500 flex items-center justify-center font-black text-xl shadow text-white">
              ⚔️
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="font-black text-lg tracking-tight text-white">WORLD WAR FIRE</h1>
                <span className="text-xs font-bold px-2 py-0.5 rounded bg-emerald-700 text-white font-mono">
                  v3.8 EN-DIGITS
                </span>
              </div>
              <p className="text-xs text-slate-400">خدمات عمومی مردم • سرکوب شورش • ساخت‌وساز و علم ملی</p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <div className="hidden sm:flex items-center gap-2 px-3 py-1.5 rounded-lg bg-[#0f172a] border border-[#334155] text-xs">
              <span className="text-slate-400">کشور:</span>
              <span className="font-bold text-white flex items-center gap-1">
                {userCountry.flag} {userCountry.name}
              </span>
              <span className="text-slate-600">|</span>
              <span className="text-amber-400 font-bold">{userCountry.rank}</span>
              <span className="text-slate-600">|</span>
              <span className="text-cyan-400 font-bold font-mono">علم: {fmt(userCountry.scienceScore)}</span>
            </div>
            <a
              href="/admin"
              className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg bg-amber-600 hover:bg-amber-700 text-white text-xs font-bold transition shadow"
            >
              <ExternalLink className="w-3.5 h-3.5" />
              پنل مدیریت سایت
            </a>
            <a
              href="/miniapp"
              target="_blank"
              rel="noreferrer"
              className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold transition shadow"
            >
              <ExternalLink className="w-3.5 h-3.5" />
              مینی‌اپ تلگرام
            </a>
          </div>
        </div>
      </header>

      {/* بازخورد پیام‌ها */}
      {feedbackMsg && (
        <div className="max-w-7xl mx-auto px-4 pt-3">
          <div
            className={`p-3.5 rounded-lg border text-sm font-bold flex items-center gap-2.5 shadow-md ${
              feedbackMsg.ok
                ? 'bg-emerald-950 border-emerald-600 text-emerald-300'
                : 'bg-rose-950 border-rose-600 text-rose-300'
            }`}
          >
            {feedbackMsg.ok ? <CheckCircle2 className="w-5 h-5 shrink-0" /> : <XCircle className="w-5 h-5 shrink-0" />}
            <span>{feedbackMsg.text}</span>
          </div>
        </div>
      )}

      {/* هشدار وضعیت بحرانی شورش */}
      {rebellionActive && (
        <div className="max-w-7xl mx-auto px-4 pt-3">
          <div className="p-4 rounded-xl bg-red-950 border-2 border-red-500 text-white flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 shadow-xl animate-pulse">
            <div className="flex items-center gap-3">
              <Flame className="w-7 h-7 text-amber-400 shrink-0" />
              <div>
                <div className="font-black text-sm text-red-200">
                  🚨 وضعیت اضطراری ملی: شورش مسلحانه مردم به دلیل قطعی مکرر انرژی و آب!
                </div>
                <div className="text-xs text-slate-300 mt-0.5">
                  جمعیت شورشیان: <b className="font-mono text-amber-400">{fmt(rebelRatio)}%</b> | در صورت عدم مهار، هر 10 دقیقه کشور به سمت فروپاشی می‌رود.
                </div>
              </div>
            </div>
            <button
              onClick={() => setActiveTab('people')}
              className="px-4 py-2 rounded-lg bg-red-600 hover:bg-red-700 text-white text-xs font-black transition shadow flex items-center gap-1.5 shrink-0"
            >
              <Shield className="w-4 h-4" />
              ورود فوری به ستاد سرکوب شورش
            </button>
          </div>
        </div>
      )}

      {/* نوار ناوبری اصلی (رنگ‌های مات و توپر نظامی) */}
      <nav className="max-w-7xl mx-auto px-4 pt-4">
        <div className="flex gap-2 overflow-x-auto pb-2 scrollbar-none border-b border-[#334155]">
          {[
            { id: 'overview', label: '📊 داشبورد و شاخص‌ها', icon: ShieldAlert },
            { id: 'commander', label: '🎖️ فرمانده و هیئت وزیران', icon: UserCheck },
            { id: 'barracks', label: '🪖 پادگان و دفاع خودکار', icon: Swords },
            { id: 'people', label: '👥 بخش مردم و خدمات عمومی', icon: Users, badge: rebellionActive ? 'شورش!' : undefined },
            { id: 'construction', label: '🏗️ ساخت‌وساز، علم و رسانه', icon: Hammer },
            { id: 'research_logs', label: '🔬 دستاوردها و لاگ پژوهش', icon: FlaskConical },
            { id: 'shahi', label: '👑 سکه شاهی (AW Coin)', icon: Crown },
            { id: 'oil_economy', label: '💰 اقتصاد، نفت و صندوق', icon: Droplets },
            { id: 'oil_trade', label: '🛢️ بازار و قرارداد نفتی', icon: ArrowRightLeft },
            { id: 'loans', label: '🤝 وام‌های دولتی (کسر 80%)', icon: HandCoins },
            { id: 'markets', label: '🌐 بازار جهانی و عمومی', icon: Globe2 },
            { id: 'central_bank', label: '🏦 بانک مرکزی و کارمزدها', icon: Landmark },
            { id: 'admin_panel', label: '🛡️ پنل ادمین و قیمت‌ها', icon: Scale },
            { id: 'bot_preview', label: '📱 شبیه‌ساز کلیدهای تلگرام', icon: Bot },
          ].map((tab) => {
            const Icon = tab.icon;
            const isSel = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`px-4 py-2.5 rounded-t-lg text-xs font-black whitespace-nowrap transition flex items-center gap-2 border-t border-x relative ${
                  isSel
                    ? 'bg-[#1e293b] border-[#334155] text-amber-400 shadow-sm border-b-transparent'
                    : 'bg-[#0f172a] border-transparent text-slate-400 hover:text-white hover:bg-slate-800'
                }`}
              >
                <Icon className={`w-4 h-4 ${isSel ? 'text-amber-400' : 'text-slate-400'}`} />
                {tab.label}
                {tab.badge && (
                  <span className="px-1.5 py-0.5 rounded-full bg-red-600 text-white text-[10px] font-mono animate-bounce">
                    {tab.badge}
                  </span>
                )}
              </button>
            );
          })}
        </div>
      </nav>

      {/* محتوای صفحات */}
      <main className="max-w-7xl mx-auto px-4 pt-5">
        {/* ============================================================ */}
        {/* ۱. داشبورد مرکزی */}
        {/* ============================================================ */}
        {activeTab === 'overview' && (
          <div className="space-y-6">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div className="p-4 rounded-xl bg-[#1e293b] border border-[#334155] shadow">
                <div className="flex items-center justify-between text-xs text-slate-400 mb-1">
                  <span>خزانه ملی (دلار)</span>
                  <DollarSign className="w-4 h-4 text-emerald-400" />
                </div>
                <div className="text-2xl font-black text-emerald-400 font-mono">
                  {fmt(treasuryDollars)} $
                </div>
                <div className="text-[11px] text-slate-400 mt-2">ارقام انگلیسی با جداکننده استاندارد</div>
              </div>

              <div
                className="p-4 rounded-xl bg-[#1e293b] border border-[#334155] shadow cursor-pointer hover:border-amber-500 transition"
                onClick={() => setActiveTab('shahi')}
              >
                <div className="flex items-center justify-between text-xs text-slate-400 mb-1">
                  <span>سکه شاهی (خارج بازی)</span>
                  <Crown className="w-4 h-4 text-amber-400" />
                </div>
                <div className="text-2xl font-black text-amber-400 font-mono flex items-center gap-1.5">
                  {fmt(shahiCoins)} <span className="text-base">👑</span>
                </div>
                <div className="text-[11px] text-slate-400 mt-2">ارزش: 10,000,000 $ برای هر سکه</div>
              </div>

              <div className="p-4 rounded-xl bg-[#1e293b] border border-[#334155] shadow">
                <div className="flex items-center justify-between text-xs text-slate-400 mb-1">
                  <span>ذخایر نفت خام</span>
                  <Droplets className="w-4 h-4 text-sky-400" />
                </div>
                <div className="text-xl font-black text-white font-mono">
                  {fmt(currentOil)} <span className="text-xs text-slate-400 font-normal">/ {fmt(oilReserve)} ب</span>
                </div>
                <div className="text-[11px] text-slate-400 mt-2">
                  دکل‌ها: {fmt(oilRigs)} | مصرف سوختی: 2,000 ب/روز
                </div>
              </div>

              <div className="p-4 rounded-xl bg-[#1e293b] border border-[#334155] shadow">
                <div className="flex items-center justify-between text-xs text-slate-400 mb-1">
                  <span>امتیاز علم و پژوهش</span>
                  <Rocket className="w-4 h-4 text-cyan-400" />
                </div>
                <div className="text-2xl font-black text-cyan-400 font-mono">
                  {fmt(userCountry.scienceScore)} <span className="text-xs text-slate-400">امتیاز</span>
                </div>
                <div className="text-[11px] text-slate-400 mt-2">شبکه اینترنت ملی: {userCountry.internet}</div>
              </div>
            </div>

            {/* ویجت ماموریت‌های روزانه با جایزه سکه شاهی و نفت */}
            {renderDailyMissionsWidget('ماموریت‌های کلیدی امروز: صادرات نفت، تامین برق و رصد پدافند مرزها')}

            {/* ویجت تهاجمات فعال و تایمر ۱۰ دقیقه‌ای زمان‌واقعی */}
            <div className="p-4 rounded-xl bg-[#1e293b] border border-red-500/40 shadow-lg">
              <div className="flex items-center justify-between border-b border-[#334155] pb-3 mb-3">
                <div className="flex items-center gap-2">
                  <Swords className="w-4 h-4 text-red-400" />
                  <h3 className="font-bold text-xs text-white">رصد پدافند هوایی و کاروان‌های در حال پیشروی مرزی (۱۰ دقیقه واقعی)</h3>
                </div>
                <button
                  onClick={() => setActiveTab('barracks')}
                  className="text-xs text-amber-400 hover:underline flex items-center gap-1 font-bold"
                >
                  ورود به پادگان و دفاع خودکار
                  <ChevronRight className="w-3.5 h-3.5 rotate-180" />
                </button>
              </div>

              {activeBattles.map((b) => {
                const min = Math.floor(b.remainingSeconds / 60);
                const sec = b.remainingSeconds % 60;
                const pct = Math.min(100, Math.round(((b.totalDurationSeconds - b.remainingSeconds) / b.totalDurationSeconds) * 100));
                return (
                  <div key={b.id} className="p-3 rounded-lg bg-[#0f172a] border border-red-900/50 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
                    <div>
                      <div className="text-xs font-bold text-white flex items-center gap-1.5">
                        <span className="w-2 h-2 rounded-full bg-red-500 animate-ping" />
                        تهاجم نظامی: {b.attackerFlag} {b.attackerCountry} ⚔️ {b.defenderFlag} {b.defenderCountry}
                      </div>
                      <div className="text-[11px] text-slate-400 mt-0.5">
                        {b.speedBonus} | پدافند خودکار: <b className="text-emerald-400">{autoDefenseActive ? 'فعال (+25% بانس) ✅' : 'آفلاین'}</b>
                      </div>
                    </div>
                    <div className="flex items-center gap-3 w-full sm:w-56">
                      <div className="w-full h-2 rounded-full bg-slate-800 overflow-hidden">
                        <div className="h-full bg-red-500 transition-all duration-1000" style={{ width: `${pct}%` }} />
                      </div>
                      <span className="font-mono text-xs font-bold text-red-400 whitespace-nowrap">
                        {String(min).padStart(2, '0')}:{String(sec).padStart(2, '0')}
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>

            {/* کارت‌های وضعیت خدمات عمومی */}
            <div className="p-5 rounded-xl bg-[#1e293b] border border-[#334155]">
              <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 border-b border-[#334155] pb-4 mb-4">
                <div>
                  <h3 className="font-black text-base text-white flex items-center gap-2">
                    <Users className="w-5 h-5 text-amber-400" />
                    خلاصه وضعیت رفاه، خدمات عمومی و آرامش مردم
                  </h3>
                  <p className="text-xs text-slate-400 mt-1">
                    پوشش زیر 60% برق، آب یا گاز و همچنین قطعی‌های طولانی‌مدت سبب انفجار نارضایتی و شورش خیابانی می‌شود
                  </p>
                </div>
                <div className="flex items-center gap-3">
                  <div className="px-3.5 py-1.5 rounded-lg bg-[#0f172a] border border-[#334155] text-xs">
                    <span className="text-slate-400">شاخص رضایت:</span>{' '}
                    <b className={`font-mono ${publicSatisfaction >= 60 ? 'text-emerald-400' : 'text-red-400'}`}>
                      {fmt(publicSatisfaction)}%
                    </b>
                  </div>
                  <div className="px-3.5 py-1.5 rounded-lg bg-[#0f172a] border border-[#334155] text-xs">
                    <span className="text-slate-400">شاخص نارضایتی:</span>{' '}
                    <b className={`font-mono ${calculatedDissatisfaction >= 70 ? 'text-red-400' : 'text-slate-200'}`}>
                      {fmt(calculatedDissatisfaction)}%
                    </b>
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {/* برق */}
                <div className="p-4 rounded-xl bg-[#0f172a] border border-[#334155]">
                  <div className="flex items-center justify-between mb-2">
                    <span className="font-bold text-white text-xs flex items-center gap-1.5">
                      <Zap className="w-4 h-4 text-amber-400" />
                      تامین برق کشور
                    </span>
                    <span className={`text-xs font-mono font-bold ${powerCoverage >= 60 ? 'text-emerald-400' : 'text-red-400'}`}>
                      {fmt(powerCoverage)}%
                    </span>
                  </div>
                  <div className="w-full h-2 rounded-full bg-slate-800 overflow-hidden mb-2">
                    <div
                      className={`h-full ${powerCoverage >= 60 ? 'bg-emerald-500' : 'bg-red-500'}`}
                      style={{ width: `${powerCoverage}%` }}
                    />
                  </div>
                  <div className="text-[11px] text-slate-400 flex justify-between">
                    <span>قطعی تنظیم‌شده: {fmt(powerOutageHours)} ساعت</span>
                    <span className={powerOutageHours > 6 ? 'text-red-400 font-bold' : 'text-slate-500'}>
                      {powerOutageHours > 6 ? 'هشدار قطعی > 6h' : 'سقف مجاز: 6h'}
                    </span>
                  </div>
                </div>

                {/* آب */}
                <div className="p-4 rounded-xl bg-[#0f172a] border border-[#334155]">
                  <div className="flex items-center justify-between mb-2">
                    <span className="font-bold text-white text-xs flex items-center gap-1.5">
                      <Waves className="w-4 h-4 text-sky-400" />
                      تامین آب شرب
                    </span>
                    <span className={`text-xs font-mono font-bold ${waterCoverage >= 60 ? 'text-emerald-400' : 'text-red-400'}`}>
                      {fmt(waterCoverage)}%
                    </span>
                  </div>
                  <div className="w-full h-2 rounded-full bg-slate-800 overflow-hidden mb-2">
                    <div
                      className={`h-full ${waterCoverage >= 60 ? 'bg-sky-500' : 'bg-red-500'}`}
                      style={{ width: `${waterCoverage}%` }}
                    />
                  </div>
                  <div className="text-[11px] text-slate-400 flex justify-between">
                    <span>قطعی تنظیم‌شده: {fmt(waterOutageHours)} ساعت</span>
                    <span className={waterOutageHours > 3 ? 'text-red-400 font-bold' : 'text-slate-500'}>
                      {waterOutageHours > 3 ? 'هشدار قطعی > 3h' : 'سقف مجاز: 3h'}
                    </span>
                  </div>
                </div>

                {/* گاز */}
                <div className="p-4 rounded-xl bg-[#0f172a] border border-[#334155]">
                  <div className="flex items-center justify-between mb-2">
                    <span className="font-bold text-white text-xs flex items-center gap-1.5">
                      <Flame className="w-4 h-4 text-orange-400" />
                      تامین گاز خانگی و صنعتی
                    </span>
                    <span className={`text-xs font-mono font-bold ${gasCoverage >= 60 ? 'text-emerald-400' : 'text-red-400'}`}>
                      {fmt(gasCoverage)}%
                    </span>
                  </div>
                  <div className="w-full h-2 rounded-full bg-slate-800 overflow-hidden mb-2">
                    <div
                      className={`h-full ${gasCoverage >= 60 ? 'bg-orange-500' : 'bg-red-500'}`}
                      style={{ width: `${gasCoverage}%` }}
                    />
                  </div>
                  <div className="text-[11px] text-slate-400 flex justify-between">
                    <span>قطعی تنظیم‌شده: {fmt(gasOutageHours)} ساعت</span>
                    <span className={gasOutageHours > 4 ? 'text-red-400 font-bold' : 'text-slate-500'}>
                      {gasOutageHours > 4 ? 'هشدار قطعی > 4h' : 'سقف مجاز: 4h'}
                    </span>
                  </div>
                </div>
              </div>

              <div className="flex flex-wrap gap-3 mt-4 pt-4 border-t border-[#334155]">
                <button
                  onClick={() => setActiveTab('people')}
                  className="px-4 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs transition shadow flex items-center gap-1.5"
                >
                  <Factory className="w-4 h-4" />
                  مدیریت و احداث نیروگاه‌های آب، برق و گاز
                </button>
                <button
                  onClick={() => setActiveTab('construction')}
                  className="px-4 py-2 rounded-lg bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs transition shadow flex items-center gap-1.5"
                >
                  <Hammer className="w-4 h-4" />
                  ورود به بورس، شرکت‌ها و مگاپروژه‌های علمی
                </button>
                <button
                  onClick={handleSimulateIncomeCycle}
                  className="px-4 py-2 rounded-lg bg-amber-600 hover:bg-amber-700 text-white font-bold text-xs transition shadow flex items-center gap-1.5 mr-auto"
                >
                  <RefreshCw className="w-4 h-4" />
                  واریز چرخه درآمد ملی (شبیه‌ساز سود و کسر 80% وام)
                </button>
              </div>
            </div>
          </div>
        )}

        {/* ============================================================ */}
        {/* بخش فرمانده و هیئت وزیران (انتصاب افراد بدون کشور) */}
        {/* ============================================================ */}
        {activeTab === 'commander' && (
          <div className="space-y-6">
            <div className="p-5 rounded-xl bg-[#1e293b] border border-[#334155] shadow-lg">
              <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-b border-[#334155] pb-4 mb-4">
                <div>
                  <h2 className="text-lg font-black text-white flex items-center gap-2">
                    <UserCheck className="w-5 h-5 text-amber-400" />
                    بخش فرمانده کل و هیئت وزیران — {userCountry.name} {userCountry.flag}
                  </h2>
                  <p className="text-xs text-slate-400 mt-1">
                    انتصاب شهروندان فعال و بازیکنان ثبت‌نامی بدون کشور به عنوان وزیر دفاع و جانشین فرماندهی کشور (+10% قدرت پدافندی)
                  </p>
                </div>
                <div className="flex items-center gap-2">
                  <span className="px-3 py-1 rounded-full bg-emerald-950/80 border border-emerald-500/40 text-emerald-300 text-xs font-bold flex items-center gap-1.5">
                    <Shield className="w-3.5 h-3.5" />
                    بانس پدافند وزیر: {minister ? '+10% فعال' : 'غیرفعال'}
                  </span>
                </div>
              </div>

              {/* کارت وضعیت وزیر فعلی */}
              <div className="mb-6">
                <h3 className="font-bold text-sm text-white mb-3 flex items-center gap-2">
                  <Crown className="w-4 h-4 text-amber-400" />
                  وضعیت کرسی وزارت دفاع و جانشین فرماندهی
                </h3>
                {minister ? (
                  <div className="p-5 rounded-2xl bg-gradient-to-br from-amber-950/40 via-[#0f172a] to-[#1e293b] border border-amber-500/40 shadow-xl flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
                    <div className="flex items-center gap-4">
                      <div className="w-14 h-14 rounded-2xl bg-gradient-to-tr from-amber-500 to-amber-600 flex items-center justify-center text-3xl shadow-lg border border-amber-300/40 shrink-0">
                        🎖️
                      </div>
                      <div className="space-y-1">
                        <div className="flex items-center gap-2">
                          <span className="text-base font-black text-white">{minister.displayName}</span>
                          <span className="px-2 py-0.5 rounded bg-amber-500/20 text-amber-300 border border-amber-500/30 text-[10px] font-bold">
                            وزیر منصوب
                          </span>
                        </div>
                        <div className="text-xs text-slate-300 font-medium">
                          سمت رسمی: <b className="text-amber-400">{minister.rank}</b>
                        </div>
                        <div className="flex flex-wrap items-center gap-3 text-[11px] text-slate-400 font-mono pt-1">
                          <span>آیدی تلگرام: <b>{minister.telegramId}</b></span>
                          <span>•</span>
                          <span>تاریخ انتصاب: <b>{minister.appointedAt}</b></span>
                        </div>
                      </div>
                    </div>

                    <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3 w-full md:w-auto">
                      <div className="px-3 py-2 rounded-xl bg-emerald-950/70 border border-emerald-600/40 text-emerald-300 text-xs font-bold text-center">
                        🛡️ +10% تقویت پدافند خودکار مرزها
                      </div>
                      <button
                        onClick={handleDismissMinister}
                        className="px-4 py-2.5 rounded-xl bg-red-600 hover:bg-red-700 text-white font-black text-xs transition shadow flex items-center justify-center gap-1.5"
                      >
                        <UserX className="w-4 h-4" />
                        عزل و برکناری وزیر
                      </button>
                    </div>
                  </div>
                ) : (
                  <div className="p-6 rounded-2xl bg-[#0f172a] border border-dashed border-[#475569] text-center space-y-2">
                    <div className="text-3xl">👥</div>
                    <div className="font-bold text-sm text-slate-200">
                      هیچ وزیری برای کشور منصوب نشده است
                    </div>
                    <p className="text-xs text-slate-400 max-w-md mx-auto">
                      با انتصاب یکی از شهروندان آزاد ثبت‌نامی بدون کشور به عنوان وزیر دفاع، از بانس +10% پدافند خودکار مرزها بهره‌مند شوید.
                    </p>
                  </div>
                )}
              </div>

              {/* لیست شهروندان و بازیکنان ثبت‌نامی بدون کشور جهت انتصاب */}
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <h3 className="font-bold text-sm text-white flex items-center gap-2">
                    <Users className="w-4 h-4 text-sky-400" />
                    شهروندان و فرماندهان آزاد آماده خدمت ({candidates.length} نفر)
                  </h3>
                  <span className="text-xs text-slate-400">
                    انتخاب از میان بازیکنان واقعی فاقد کشور
                  </span>
                </div>

                {candidates.length === 0 ? (
                  <div className="p-4 rounded-xl bg-[#0f172a] text-center text-xs text-slate-400">
                    در حال حاضر شهروند آزاد دیگری برای انتصاب در دسترس نیست.
                  </div>
                ) : (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
                    {candidates.map((cand) => (
                      <div
                        key={cand.telegramId}
                        className="p-4 rounded-xl bg-[#0f172a] border border-[#334155] hover:border-amber-500/40 transition flex items-center justify-between gap-3"
                      >
                        <div className="space-y-1">
                          <div className="flex items-center gap-2">
                            <span className="font-bold text-xs text-white flex items-center gap-1.5">
                              <span>👤</span>
                              {cand.displayName}
                            </span>
                            <span className="px-2 py-0.5 rounded-full bg-emerald-950 text-emerald-400 border border-emerald-800 text-[10px] font-mono">
                              {cand.status}
                            </span>
                          </div>
                          <div className="text-[11px] text-slate-400">
                            {cand.experience}
                          </div>
                          <div className="text-[10px] text-slate-500 font-mono">
                            آیدی تلگرام: {cand.telegramId}
                          </div>
                        </div>

                        <button
                          onClick={() => handleAppointMinister(cand)}
                          className="px-3.5 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white font-black text-xs transition shadow shrink-0 flex items-center gap-1.5"
                        >
                          <UserCheck className="w-3.5 h-3.5" />
                          انتصاب به عنوان وزیر
                        </button>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* راهنمای اختیارات و وظایف وزیر */}
              <div className="mt-6 pt-4 border-t border-[#334155] grid grid-cols-1 md:grid-cols-3 gap-3">
                <div className="p-3 rounded-xl bg-[#0f172a] border border-[#334155]">
                  <div className="font-bold text-xs text-amber-400 mb-1 flex items-center gap-1.5">
                    <Shield className="w-3.5 h-3.5" />
                    ۱. بانس دفاعی +10%
                  </div>
                  <p className="text-[11px] text-slate-400 leading-relaxed">
                    حضور فعال وزیر منصوب به صورت خودکار قدرت کل سامانه‌های دفاعی و پدافندی پادگان را ۱۰٪ افزایش می‌دهد.
                  </p>
                </div>
                <div className="p-3 rounded-xl bg-[#0f172a] border border-[#334155]">
                  <div className="font-bold text-xs text-sky-400 mb-1 flex items-center gap-1.5">
                    <Swords className="w-3.5 h-3.5" />
                    ۲. هماهنگی نبردهای ۱۰ دقیقه‌ای
                  </div>
                  <p className="text-[11px] text-slate-400 leading-relaxed">
                    وزیر دفاع می‌تواند کاروان‌های هجومی را بازبینی کرده و زمان اعزام ناوگان را بهینه‌سازی کند.
                  </p>
                </div>
                <div className="p-3 rounded-xl bg-[#0f172a] border border-[#334155]">
                  <div className="font-bold text-xs text-emerald-400 mb-1 flex items-center gap-1.5">
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    ۳. مشارکت بازیکنان بدون کشور
                  </div>
                  <p className="text-[11px] text-slate-400 leading-relaxed">
                    بازیکنانی که بودجه خرید کشور را ندارند می‌توانند به عنوان وزیر به دولت‌ها پیوسته و سهم پاداش دریافت کنند.
                  </p>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* ============================================================ */}
        {/* ۱.۵. ستاد کل پادگان، ادوات نظامی و دفاع خودکار (+۲۵٪ بانس) */}
        {/* ============================================================ */}
        {activeTab === 'barracks' && (
          <div className="space-y-6">
            {/* هدر پادگان و کلید دفاع خودکار */}
            <div className="p-5 rounded-xl bg-[#1e293b] border border-[#334155] shadow-lg">
              <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-b border-[#334155] pb-4 mb-4">
                <div>
                  <h2 className="text-lg font-black text-white flex items-center gap-2">
                    <Swords className="w-5 h-5 text-amber-400" />
                    ستاد کل پادگان، ادوات نظامی و سامانه دفاع خودکار — {userCountry.name} {userCountry.flag}
                  </h2>
                  <p className="text-xs text-slate-400 mt-1">
                    مدیریت آمادگی رزمی، استقرار تسلیحات مدرن و نظارت زنده بر تهاجمات ۱۰ دقیقه‌ای زمان‌واقعی
                  </p>
                </div>
                <div className="flex items-center gap-3">
                  <button
                    onClick={() => {
                      const next = !autoDefenseActive;
                      setAutoDefenseActive(next);
                      showFeedback(
                        next
                          ? '⚡ سامانه دفاع خودکار فعال شد! +۲۵٪ بانس آمادگی به تمامی واحدهای پدافندی تعلق گرفت.'
                          : '⏸ سامانه دفاع خودکار غیرفعال گردید.'
                      );
                    }}
                    className={`px-4 py-2.5 rounded-xl font-black text-xs transition flex items-center gap-2 shadow ${
                      autoDefenseActive
                        ? 'bg-emerald-600 hover:bg-emerald-700 text-white border border-emerald-400'
                        : 'bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-600'
                    }`}
                  >
                    <Shield className="w-4 h-4" />
                    {autoDefenseActive ? '⚡ دفاع خودکار: فعال (+25% بانس آمادگی)' : '⏸ دفاع خودکار: غیرفعال'}
                  </button>
                </div>
              </div>

              {/* شاخص‌های قدرت ارتش */}
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div className="p-3.5 rounded-xl bg-[#0f172a] border border-[#334155]">
                  <div className="text-xs text-slate-400 mb-1">قدرت خالص هجومی (Attack)</div>
                  <div className="text-xl font-black text-red-400 font-mono">3,850</div>
                  <div className="text-[11px] text-slate-500 mt-1">آماده فرمان حمله به مقاصد</div>
                </div>
                <div className="p-3.5 rounded-xl bg-[#0f172a] border border-[#334155]">
                  <div className="text-xs text-slate-400 mb-1">قدرت پدافندی (Defense)</div>
                  <div className="text-xl font-black text-emerald-400 font-mono flex items-center gap-1.5">
                    {autoDefenseActive ? fmt(Math.floor(3200 * 1.25)) : '3,200'}
                    {autoDefenseActive && <span className="text-xs text-emerald-300">(+25%)</span>}
                  </div>
                  <div className="text-[11px] text-slate-500 mt-1">پوشش رادار و آتش پادگان</div>
                </div>
                <div className="p-3.5 rounded-xl bg-[#0f172a] border border-[#334155]">
                  <div className="text-xs text-slate-400 mb-1">قوای زمینی (Ground Army)</div>
                  <div className="text-xl font-black text-amber-400 font-mono">45,269</div>
                  <div className="text-[11px] text-slate-500 mt-1">نیروی انسانی مستقر در پادگان</div>
                </div>
                <div className="p-3.5 rounded-xl bg-[#0f172a] border border-[#334155]">
                  <div className="text-xs text-slate-400 mb-1">کارنامه عملیاتی</div>
                  <div className="text-sm font-black text-white font-mono mt-1">
                    <span className="text-emerald-400">14 برد</span> / <span className="text-red-400">2 باخت</span>
                  </div>
                  <div className="text-[11px] text-slate-500 mt-1">9 دفاع موفق از مرزها</div>
                </div>
              </div>
            </div>

            {/* ویجت نبردهای فعال جاری با تایمر ۱۰ دقیقه‌ای واقعی */}
            <div className="p-5 rounded-xl bg-[#1e293b] border border-red-500/40 shadow-lg">
              <div className="flex items-center justify-between border-b border-[#334155] pb-3 mb-4">
                <div>
                  <h3 className="font-black text-sm text-white flex items-center gap-2">
                    <Clock className="w-4 h-4 text-red-400" />
                    اتاق جنگ زنده: نبردهای فعال و اعزام ۱۰ دقیقه‌ای زمان‌واقعی (بدون فتح آبکی)
                  </h3>
                  <p className="text-xs text-slate-400 mt-0.5">
                    طبق قوانین سرور، هیچ فتح آنی وجود ندارد. کاروان‌ها باید مسیر واقعی را طی کنند (۱۰ دقیقه پایه، کاهش به ۴ تا ۶ دقیقه با هواپیمای ترابری یا ناوترابری).
                  </p>
                </div>
              </div>

              <div className="space-y-3">
                {activeBattles.map((b) => {
                  const min = Math.floor(b.remainingSeconds / 60);
                  const sec = b.remainingSeconds % 60;
                  const pct = Math.min(100, Math.round(((b.totalDurationSeconds - b.remainingSeconds) / b.totalDurationSeconds) * 100));
                  return (
                    <div key={b.id} className="p-4 rounded-xl bg-[#0f172a] border border-red-900/60 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
                      <div className="space-y-1">
                        <div className="flex items-center gap-2">
                          <span className="px-2 py-0.5 rounded bg-red-950 text-red-300 border border-red-700 text-xs font-bold">
                            🚨 تهاجم متخاصم
                          </span>
                          <span className="text-sm font-black text-white">
                            کشور مهاجم: {b.attackerFlag} {b.attackerCountry} ⚔️ کشور هدف: {b.defenderFlag} {b.defenderCountry}
                          </span>
                        </div>
                        <div className="text-xs text-slate-400">
                          نوع عملیات: <b className="text-white">{b.type}</b> | تجهیزات اعزامی: <b className="text-amber-400">{b.unitsCount} واحد</b>
                        </div>
                        <div className="text-[11px] text-cyan-400 font-mono">
                          ⚡ {b.speedBonus}
                        </div>
                      </div>

                      <div className="flex flex-col items-end gap-2 w-full md:w-64">
                        <div className="flex justify-between w-full text-xs">
                          <span className="text-slate-400">زمان تا برخورد:</span>
                          <span className="font-mono text-base font-black text-red-400">
                            {String(min).padStart(2, '0')}:{String(sec).padStart(2, '0')}
                          </span>
                        </div>
                        <div className="w-full h-2 rounded-full bg-slate-800 overflow-hidden">
                          <div className="h-full bg-red-500 transition-all duration-1000" style={{ width: `${pct}%` }} />
                        </div>
                        <div className="text-[10px] text-slate-400">
                          پدافند خودکار: <b className="text-emerald-400">{autoDefenseActive ? 'آماده‌باش دفاعی فعال ✅' : 'آفلاین'}</b>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* زرادخانه تجهیزات و ادوات مستقر در پادگان */}
            <div className="p-5 rounded-xl bg-[#1e293b] border border-[#334155]">
              <div className="flex items-center justify-between border-b border-[#334155] pb-3 mb-4">
                <div>
                  <h3 className="font-black text-sm text-white flex items-center gap-2">
                    <Shield className="w-4 h-4 text-emerald-400" />
                    فهرست ادوات و تجهیزات عملیاتی مستقر در پادگان
                  </h3>
                  <p className="text-xs text-slate-400 mt-0.5">
                    خرید تجهیزات قدرت پدافندی و هجومی را فوراً ارتقا داده و بر نتایج محاصره تاثیر مستقیم دارد.
                  </p>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3">
                {militaryUnits.map((u) => (
                  <div key={u.id} className="p-3.5 rounded-xl bg-[#0f172a] border border-[#334155] flex flex-col justify-between gap-2">
                    <div>
                      <div className="flex items-center justify-between">
                        <span className="font-bold text-xs text-white flex items-center gap-1.5">
                          <span>{u.emoji}</span>
                          {u.name}
                        </span>
                        <span className="text-[11px] font-mono text-emerald-400 bg-emerald-950 px-2 py-0.5 rounded">
                          قدرت: {u.power}
                        </span>
                      </div>
                      <div className="text-sm font-black font-mono text-amber-400 mt-2">
                        تعداد: {fmt(u.count)} واحد
                      </div>
                      {u.special && (
                        <div className="text-[10px] text-cyan-400 mt-1 bg-cyan-950/60 p-1 rounded border border-cyan-800/40">
                          ⚡ {u.special}
                        </div>
                      )}
                    </div>
                    <div className="text-[11px] text-slate-400 border-t border-[#334155]/60 pt-2 flex justify-between">
                      <span>توان کلی رسته:</span>
                      <b className="font-mono text-white">{fmt(u.count * u.power)}</b>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* ============================================================ */}
        {/* ۲. بخش جامع مردم، خدمات عمومی و سرکوب شورش */}
        {/* ============================================================ */}
        {activeTab === 'people' && (
          <div className="space-y-6">
            {/* وضعیت کلی و هشدار شورش */}
            <div className="p-5 rounded-xl bg-[#1e293b] border border-[#334155]">
              <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 border-b border-[#334155] pb-4 mb-4">
                <div>
                  <h2 className="text-lg font-black text-white flex items-center gap-2">
                    <Users className="w-5 h-5 text-amber-400" />
                    بخش مردم: مصرف آب، برق و گاز بر اساس جمعیت کشور
                  </h2>
                  <p className="text-xs text-slate-400 mt-1">
                    جمعیت فعال کشور: <b className="font-mono text-white">{fmt(userCountry.population)} نفر</b> | پوشش زیر 60% یا قطعی مازاد، نارضایتی را افزایش می‌دهد
                  </p>
                </div>
                <div className="flex items-center gap-3">
                  <div className="px-3.5 py-1.5 rounded-lg bg-[#0f172a] border border-[#334155] text-xs">
                    <span className="text-slate-400">وضعیت عمومی:</span>{' '}
                    <b className={rebellionActive ? 'text-red-400 font-bold' : 'text-emerald-400 font-bold'}>
                      {rebellionActive ? `🚨 شورش فعال (${fmt(rebelRatio)}%)` : '🟢 پایدار'}
                    </b>
                  </div>
                </div>
              </div>

              {/* ۲ دکمه اصلی مورد تاکید کاربر: ساخت نیروگاه‌ها و سرکوب شورش */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="p-4 rounded-xl bg-[#0f172a] border border-[#334155] flex flex-col justify-between">
                  <div>
                    <h3 className="font-black text-sm text-white mb-1 flex items-center gap-2">
                      <Factory className="w-4 h-4 text-emerald-400" />
                      1. ساخت نیروگاه‌ها و تاسیسات انرژی
                    </h3>
                    <p className="text-xs text-slate-400 leading-relaxed mb-4">
                      احداث نیروگاه‌های برق (بادی، خورشیدی، سد، سوختی، اتمی)، تاسیسات آبی (فاضلاب، چاه، دریا) و گازی (مخزن و مشعل) جهت رساندن پوشش به بالای 60%.
                    </p>
                  </div>
                  <div className="grid grid-cols-3 gap-2">
                    <a
                      href="#power-section"
                      className="py-2 rounded-lg bg-amber-600 hover:bg-amber-700 text-white font-bold text-xs text-center transition shadow"
                    >
                      ⚡ نیروگاه برق
                    </a>
                    <a
                      href="#water-section"
                      className="py-2 rounded-lg bg-sky-600 hover:bg-sky-700 text-white font-bold text-xs text-center transition shadow"
                    >
                      💧 نیروگاه آب
                    </a>
                    <a
                      href="#gas-section"
                      className="py-2 rounded-lg bg-orange-600 hover:bg-orange-700 text-white font-bold text-xs text-center transition shadow"
                    >
                      ⛽ تاسیسات گاز
                    </a>
                  </div>
                </div>

                <div className="p-4 rounded-xl bg-[#0f172a] border border-red-900/60 flex flex-col justify-between">
                  <div>
                    <h3 className="font-black text-sm text-red-300 mb-1 flex items-center gap-2">
                      <Shield className="w-4 h-4 text-red-400" />
                      2. سرکوب و مهار شورش مردمی
                    </h3>
                    <p className="text-xs text-slate-400 leading-relaxed mb-4">
                      اگر نارضایتی به 70-80% برسد شورش آغاز می‌شود. در صورت دفع نشدن، هر 10 دقیقه شدت آن افزایش یافته و کشور سقوط می‌کند.
                    </p>
                  </div>
                  <a
                    href="#quell-section"
                    className="py-2.5 rounded-lg bg-red-700 hover:bg-red-800 text-white font-black text-xs text-center transition shadow flex items-center justify-center gap-1.5"
                  >
                    <Flame className="w-4 h-4 text-yellow-300" />
                    ورود به روش‌های مهار و سرکوب شورش
                  </a>
                </div>
              </div>
            </div>

            {/* بخش الف: نیروگاه برق */}
            <div id="power-section" className="p-5 rounded-xl bg-[#1e293b] border border-[#334155] space-y-4">
              <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 border-b border-[#334155] pb-3">
                <div>
                  <h3 className="font-black text-base text-white flex items-center gap-2">
                    <Zap className="w-5 h-5 text-amber-400" />
                    ایجاد و مدیریت نیروگاه‌های برق
                  </h3>
                  <p className="text-xs text-slate-400 mt-0.5">
                    پوشش فعلی برق: <b className="font-mono text-white">{fmt(powerCoverage)}%</b> | قطعی برنامه‌ریزی‌شده:{' '}
                    <b className="font-mono text-white">{fmt(powerOutageHours)} ساعت</b> (بیش از 6 ساعت = افزایش نارضایتی)
                  </p>
                </div>
                <button
                  onClick={() => {
                    setOutageModalCat('power');
                    setOutageInputHours(String(powerOutageHours));
                  }}
                  className="px-4 py-2 rounded-lg bg-slate-700 hover:bg-slate-600 text-white font-bold text-xs transition flex items-center gap-1.5"
                >
                  <Clock className="w-4 h-4 text-amber-400" />
                  تنظیم ساعات قطعی برق دلخواه
                </button>
              </div>

              {!isFuelPlantOperational && powerPlants.fuel_plant > 0 && (
                <div className="p-3 rounded-lg bg-amber-950/80 border border-amber-600 text-amber-200 text-xs font-bold flex items-center gap-2">
                  <AlertTriangle className="w-4 h-4 shrink-0" />
                  هشدار: به دلیل اتمام یا کسری ذخایر نفت خام (کمتر از 2,000 بشکه)، نیروگاه سوختی فسیلی متوقف و از مدار خارج شده است!
                </div>
              )}

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3">
                {[
                  { key: 'wind', name: 'نیروگاه بادی', coverage: '+10%', cost: adminPlantCosts.wind, icon: Wind, count: powerPlants.wind },
                  { key: 'solar', name: 'برق خورشیدی', coverage: '+15%', cost: adminPlantCosts.solar, icon: Sun, count: powerPlants.solar },
                  { key: 'hydro_dam', name: 'سد برق‌آبی', coverage: '+30%', cost: adminPlantCosts.hydro_dam, icon: Waves, count: powerPlants.hydro_dam },
                  {
                    key: 'fuel_plant',
                    name: 'نیروگاه سوختی',
                    coverage: '+25%',
                    cost: adminPlantCosts.fuel_plant,
                    icon: Factory,
                    count: powerPlants.fuel_plant,
                    note: 'مصرف روزانه 2,000 بشکه نفت',
                  },
                  { key: 'nuclear', name: 'نیروگاه اتمی', coverage: '+50%', cost: adminPlantCosts.nuclear, icon: Radio, count: powerPlants.nuclear },
                ].map((item) => {
                  const Icon = item.icon;
                  return (
                    <div key={item.key} className="p-3.5 rounded-xl bg-[#0f172a] border border-[#334155] flex flex-col justify-between gap-3">
                      <div>
                        <div className="flex items-center justify-between mb-1">
                          <Icon className="w-5 h-5 text-amber-400" />
                          <span className="text-[10px] px-2 py-0.5 rounded bg-slate-800 text-emerald-400 font-mono font-bold">
                            {item.coverage}
                          </span>
                        </div>
                        <div className="font-bold text-xs text-white">{item.name}</div>
                        <div className="text-[11px] text-slate-400 font-mono mt-1">هزینه: {fmt(item.cost)} $</div>
                        {item.note && <div className="text-[10px] text-amber-400 mt-1">{item.note}</div>}
                        <div className="text-[11px] text-slate-400 mt-1">فعال در کشور: {fmt(item.count)} عدد</div>
                      </div>
                      <button
                        onClick={() => handleBuyPowerPlant(item.key, item.name)}
                        className="w-full py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs transition shadow"
                      >
                        خرید و احداث
                      </button>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* بخش ب: نیروگاه آب */}
            <div id="water-section" className="p-5 rounded-xl bg-[#1e293b] border border-[#334155] space-y-4">
              <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 border-b border-[#334155] pb-3">
                <div>
                  <h3 className="font-black text-base text-white flex items-center gap-2">
                    <Waves className="w-5 h-5 text-sky-400" />
                    ایجاد و مدیریت نیروگاه‌ها و تاسیسات آب
                  </h3>
                  <p className="text-xs text-slate-400 mt-0.5">
                    پوشش فعلی آب: <b className="font-mono text-white">{fmt(waterCoverage)}%</b> | قطعی برنامه‌ریزی‌شده:{' '}
                    <b className="font-mono text-white">{fmt(waterOutageHours)} ساعت</b> (بیش از 3 ساعت = افزایش نارضایتی)
                  </p>
                </div>
                <button
                  onClick={() => {
                    setOutageModalCat('water');
                    setOutageInputHours(String(waterOutageHours));
                  }}
                  className="px-4 py-2 rounded-lg bg-slate-700 hover:bg-slate-600 text-white font-bold text-xs transition flex items-center gap-1.5"
                >
                  <Clock className="w-4 h-4 text-sky-400" />
                  تنظیم ساعات قطعی آب دلخواه
                </button>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                {[
                  { key: 'wastewater', name: 'تصفیه آب فاضلاب', coverage: '+15%', cost: adminPlantCosts.wastewater, count: waterPlants.wastewater },
                  { key: 'groundwater', name: 'حفر چاه و آب زیرزمینی', coverage: '+25%', cost: adminPlantCosts.groundwater, count: waterPlants.groundwater },
                  { key: 'desalination', name: 'تصفیه و نمک‌زدایی آب دریا', coverage: '+40%', cost: adminPlantCosts.desalination, count: waterPlants.desalination },
                ].map((item) => (
                  <div key={item.key} className="p-4 rounded-xl bg-[#0f172a] border border-[#334155] flex flex-col justify-between gap-3">
                    <div>
                      <div className="flex items-center justify-between mb-1">
                        <Waves className="w-5 h-5 text-sky-400" />
                        <span className="text-[10px] px-2 py-0.5 rounded bg-slate-800 text-sky-400 font-mono font-bold">
                          {item.coverage}
                        </span>
                      </div>
                      <div className="font-bold text-sm text-white">{item.name}</div>
                      <div className="text-xs text-slate-400 font-mono mt-1">هزینه: {fmt(item.cost)} $</div>
                      <div className="text-xs text-slate-400 mt-1">واحدهای دایر: {fmt(item.count)} عدد</div>
                    </div>
                    <button
                      onClick={() => handleBuyWaterPlant(item.key, item.name)}
                      className="w-full py-2 rounded-lg bg-sky-600 hover:bg-sky-700 text-white font-bold text-xs transition shadow"
                    >
                      خرید و احداث
                    </button>
                  </div>
                ))}
              </div>
            </div>

            {/* بخش ج: تاسیسات گاز */}
            <div id="gas-section" className="p-5 rounded-xl bg-[#1e293b] border border-[#334155] space-y-4">
              <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 border-b border-[#334155] pb-3">
                <div>
                  <h3 className="font-black text-base text-white flex items-center gap-2">
                    <Flame className="w-5 h-5 text-orange-400" />
                    ایجاد و مدیریت تاسیسات گاز
                  </h3>
                  <p className="text-xs text-slate-400 mt-0.5">
                    پوشش فعلی گاز: <b className="font-mono text-white">{fmt(gasCoverage)}%</b> | قطعی برنامه‌ریزی‌شده:{' '}
                    <b className="font-mono text-white">{fmt(gasOutageHours)} ساعت</b> (بیش از 4 ساعت = افزایش نارضایتی)
                  </p>
                </div>
                <button
                  onClick={() => {
                    setOutageModalCat('gas');
                    setOutageInputHours(String(gasOutageHours));
                  }}
                  className="px-4 py-2 rounded-lg bg-slate-700 hover:bg-slate-600 text-white font-bold text-xs transition flex items-center gap-1.5"
                >
                  <Clock className="w-4 h-4 text-orange-400" />
                  تنظیم ساعات قطعی گاز دلخواه
                </button>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="p-4 rounded-xl bg-[#0f172a] border border-[#334155] flex flex-col justify-between gap-3">
                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <Flame className="w-5 h-5 text-orange-400" />
                      <span className="text-[10px] px-2 py-0.5 rounded bg-slate-800 text-orange-400 font-mono font-bold">
                        +20%
                      </span>
                    </div>
                    <div className="font-bold text-sm text-white">مخازن ذخیره‌سازی گاز استراتژیک</div>
                    <div className="text-xs text-slate-400 font-mono mt-1">هزینه: {fmt(adminPlantCosts.gas_storage)} $</div>
                    <div className="text-xs text-slate-400 mt-1">تعداد مخازن دایر: {fmt(gasPlants.gas_storage)} واحد</div>
                  </div>
                  <button
                    onClick={() => handleBuyGasPlant('gas_storage', 'مخازن ذخیره‌سازی گاز')}
                    className="w-full py-2 rounded-lg bg-orange-600 hover:bg-orange-700 text-white font-bold text-xs transition shadow"
                  >
                    خرید و احداث مخزن
                  </button>
                </div>

                <div className="p-4 rounded-xl bg-[#0f172a] border border-[#334155] flex flex-col justify-between gap-3">
                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <Flame className="w-5 h-5 text-red-400" />
                      <span className="text-[10px] px-2 py-0.5 rounded bg-slate-800 text-red-400 font-mono font-bold">
                        +35%
                      </span>
                    </div>
                    <div className="font-bold text-sm text-white">جمع‌آوری گاز مشعل هنگام استخراج نفت</div>
                    <div className="text-xs text-slate-400 font-mono mt-1">هزینه: {fmt(adminPlantCosts.flare_gas_capture)} $</div>
                    <div className="text-xs text-amber-400 mt-1 font-semibold">
                      ⚠️ پیش‌شرط: داشتن حداقل 5 دکل نفتی فعال (دکل‌های فعلی: {fmt(oilRigs)})
                    </div>
                    <div className="text-xs text-slate-400 mt-1">تاسیسات فعال: {fmt(gasPlants.flare_gas_capture)} واحد</div>
                  </div>
                  <button
                    onClick={() => handleBuyGasPlant('flare_gas_capture', 'جمع‌آوری گاز مشعل نفت')}
                    className="w-full py-2 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs transition shadow"
                  >
                    خرید و راه‌اندازی با رعایت شرط ۵ دکل
                  </button>
                </div>
              </div>
            </div>

            {/* بخش د: سرکوب و مهار شورش */}
            <div id="quell-section" className="p-5 rounded-xl bg-[#1e293b] border-2 border-red-900/80 space-y-4 shadow-xl">
              <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 border-b border-[#334155] pb-3">
                <div>
                  <h3 className="font-black text-base text-red-400 flex items-center gap-2">
                    <Shield className="w-5 h-5 text-red-400" />
                    ستاد ویژه سرکوب شورش و بازگرداندن نظم عمومی
                  </h3>
                  <p className="text-xs text-slate-300 mt-0.5">
                    در صورت عدم مهار، هر 10 دقیقه درصد شورشیان زیادتر شده و کشور ساقط می‌گردد
                  </p>
                </div>
                <div className="px-4 py-2 rounded-lg bg-red-950 border border-red-600 text-red-200 text-xs font-mono font-bold">
                  شورشیان فعال در خیابان‌ها: {fmt(rebelRatio)}%
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
                {/* ۱. پلیس و یگان ویژه */}
                <div className="p-4 rounded-xl bg-[#0f172a] border border-[#334155] flex flex-col justify-between gap-3">
                  <div>
                    <span className="text-2xl mb-1 block">👮‍♂️</span>
                    <div className="font-bold text-sm text-white">1. استقرار پلیس و یگان ویژه</div>
                    <div className="text-xs text-slate-400 mt-1">مهار ۴۵٪ شورشیان با گاز اشک‌آور و تجهیزات</div>
                    <div className="text-xs text-emerald-400 font-mono font-bold mt-2">
                      هزینه: {fmt(adminQuellCosts.police)} $
                    </div>
                  </div>
                  <button
                    onClick={() => handleQuellRebellion('police')}
                    className="w-full py-2 rounded-lg bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs transition shadow"
                  >
                    اعزام فوری یگان ویژه
                  </button>
                </div>

                {/* ۲. کشتن شورشی‌ها */}
                <div className="p-4 rounded-xl bg-[#0f172a] border border-[#334155] flex flex-col justify-between gap-3">
                  <div>
                    <span className="text-2xl mb-1 block">⚔️</span>
                    <div className="font-bold text-sm text-white">2. کشتن شورشی‌ها و سرکوب قهرآمیز</div>
                    <div className="text-xs text-slate-400 mt-1">پاکسازی فوری 100%، اما افت شدید مشروعیت بین‌المللی</div>
                    <div className="text-xs text-red-400 font-mono font-bold mt-2">
                      هزینه: {fmt(adminQuellCosts.military)} $
                    </div>
                  </div>
                  <button
                    onClick={() => handleQuellRebellion('military')}
                    className="w-full py-2 rounded-lg bg-red-700 hover:bg-red-800 text-white font-bold text-xs transition shadow"
                  >
                    حکم آتش و پاکسازی مسلحانه
                  </button>
                </div>

                {/* ۳. پیام عذرخواهی */}
                <div className="p-4 rounded-xl bg-[#0f172a] border border-[#334155] flex flex-col justify-between gap-3">
                  <div>
                    <span className="text-2xl mb-1 block">📜</span>
                    <div className="font-bold text-sm text-white">3. پیام عذرخواهی رسمی دولت</div>
                    <div className="text-xs text-slate-400 mt-1">رفع خشم ۳۵٪ مردم و وعده تعمیر خطوط آب و برق</div>
                    <div className="text-xs text-amber-400 font-mono font-bold mt-2">
                      هزینه: {fmt(adminQuellCosts.apology)} $
                    </div>
                  </div>
                  <button
                    onClick={() => handleQuellRebellion('apology')}
                    className="w-full py-2 rounded-lg bg-amber-600 hover:bg-amber-700 text-white font-bold text-xs transition shadow"
                  >
                    پخش بیانیه عذرخواهی
                  </button>
                </div>

                {/* ۴. عفو و اصلاحات (گزینه انتخابی) */}
                <div className="p-4 rounded-xl bg-[#0f172a] border border-emerald-600/40 flex flex-col justify-between gap-3">
                  <div>
                    <span className="text-2xl mb-1 block">🕊️</span>
                    <div className="font-bold text-sm text-white">4. شورای اصلاحات ملی و عفو عمومی</div>
                    <div className="text-xs text-slate-400 mt-1">مصالحه کامل، ریشه‌کنی 100% شورش و صفر شدن قطعی‌ها</div>
                    <div className="text-xs text-emerald-400 font-mono font-bold mt-2">
                      هزینه: {fmt(adminQuellCosts.reform_amnesty)} $
                    </div>
                  </div>
                  <button
                    onClick={() => handleQuellRebellion('reform_amnesty')}
                    className="w-full py-2 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs transition shadow"
                  >
                    امضای توافق‌نامه ملی و عفو
                  </button>
                </div>
              </div>
            </div>

            {/* مودال تنظیم ساعات قطعی دلخواه */}
            {outageModalCat && (
              <div className="fixed inset-0 bg-black/85 flex items-center justify-center z-50 p-4">
                <div className="max-w-md w-full bg-[#1e293b] border border-[#475569] rounded-xl p-5 shadow-2xl space-y-4">
                  <h3 className="font-black text-base text-white flex items-center gap-2">
                    <Clock className="w-5 h-5 text-amber-400" />
                    تنظیم ساعات قطعی سراسری{' '}
                    {outageModalCat === 'power' ? 'برق' : outageModalCat === 'water' ? 'آب' : 'گاز'}
                  </h3>
                  <p className="text-xs text-slate-300 leading-relaxed">
                    سقف مجاز قطعی بدون افزایش نارضایتی:{' '}
                    <b className="text-amber-400 font-mono">
                      {outageModalCat === 'power' ? '6 ساعت' : outageModalCat === 'water' ? '3 ساعت' : '4 ساعت'}
                    </b>
                    . ساعات بالاتر مستقیماً نارضایتی را افزایش داده و در نهایت منجر به شورش مسلحانه می‌شود.
                  </p>
                  <div>
                    <label className="text-xs text-slate-300 block mb-1">
                      تعداد ساعت قطعی مدنظر (پشتیبانی از اعداد انگلیسی و فارسی):
                    </label>
                    <input
                      type="text"
                      value={outageInputHours}
                      onChange={(e) => setOutageInputHours(e.target.value)}
                      className="w-full px-3 py-2.5 rounded-lg bg-[#0f172a] border border-[#334155] text-white font-mono text-sm outline-none focus:border-amber-500"
                      placeholder="مثلا: 4 یا 8"
                    />
                  </div>
                  <div className="flex gap-2 pt-2">
                    <button
                      onClick={handleApplyOutage}
                      className="flex-1 py-2.5 rounded-lg bg-amber-600 hover:bg-amber-700 text-white font-bold text-xs transition shadow"
                    >
                      تایید و اعمال قطعی
                    </button>
                    <button
                      onClick={() => setOutageModalCat(null)}
                      className="px-4 py-2.5 rounded-lg bg-slate-700 hover:bg-slate-600 text-slate-200 font-bold text-xs transition"
                    >
                      انصراف
                    </button>
                  </div>
                </div>
              </div>
            )}
          </div>
        )}

        {/* ============================================================ */}
        {/* ۳. بخش ساخت‌وساز، پژوهش، سهام، شرکت‌های اختصاصی و رسانه */}
        {/* ============================================================ */}
        {activeTab === 'construction' && (
          <div className="space-y-6">
            <div className="p-5 rounded-xl bg-[#1e293b] border border-[#334155]">
              <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 border-b border-[#334155] pb-4 mb-4">
                <div>
                  <h2 className="text-lg font-black text-white flex items-center gap-2">
                    <Hammer className="w-5 h-5 text-amber-400" />
                    بخش ساخت‌وساز، پژوهش و توسعه علم ملی
                  </h2>
                  <p className="text-xs text-slate-400 mt-1">
                    احداث هر کدام از این زیرساخت‌ها امتیاز علم کشور را ارتقا داده و زمینه تحقیقات پیشرفته آینده را فراهم می‌سازد
                  </p>
                </div>
                <div className="flex items-center gap-3">
                  <div className="px-4 py-2 rounded-xl bg-[#0f172a] border border-cyan-500/40 text-center">
                    <span className="text-[11px] text-slate-400 block">سطح علم ملی (Science Score)</span>
                    <span className="text-2xl font-black text-cyan-400 font-mono">
                      {fmt(userCountry.scienceScore)} <span className="text-sm">علم</span>
                    </span>
                  </div>
                </div>
              </div>

              {/* ۴ زیربخش اصلی مورد تاکید کاربر */}
              <div className="space-y-6">
                {/* ۱. خرید سهام شرکت‌های معتبر (بورس ۳ ساعته) */}
                <div className="p-4 rounded-xl bg-[#0f172a] border border-[#334155]">
                  <div className="flex items-center justify-between mb-3 border-b border-[#334155] pb-3">
                    <div>
                      <h3 className="font-bold text-sm text-white flex items-center gap-2">
                        <TrendingUp className="w-4 h-4 text-emerald-400" />
                        1. خرید سهام شرکت‌های معتبر (تالار بورس با نوسان 3 ساعته)
                      </h3>
                      <p className="text-xs text-slate-400 mt-0.5">
                        قیمت و رشد سهام هر ۳ ساعت تغییر می‌کند؛ هر چه سهام بیشتری داشته باشید، درآمد سود نقدی بیشتری در چرخه دریافت می‌کنید
                      </p>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="text-xs text-slate-400">تعداد سهم:</span>
                      <input
                        type="text"
                        value={buyStockQtyInput}
                        onChange={(e) => setBuyStockQtyInput(e.target.value)}
                        className="w-20 px-2.5 py-1 rounded bg-[#1e293b] border border-[#334155] text-white font-mono text-xs outline-none"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
                    {stocksList.map((st) => {
                      const owned = userStockHoldings[st.key] || 0;
                      return (
                        <div key={st.key} className="p-3.5 rounded-xl bg-[#1e293b] border border-[#334155] flex flex-col justify-between gap-3">
                          <div>
                            <div className="flex items-center justify-between">
                              <span className="font-bold text-xs text-white flex items-center gap-1.5">
                                <span>{st.emoji}</span>
                                {st.name}
                              </span>
                              <span
                                className={`text-xs font-mono font-bold px-2 py-0.5 rounded ${
                                  st.growth >= 0 ? 'bg-emerald-950 text-emerald-400' : 'bg-red-950 text-red-400'
                                }`}
                              >
                                {st.growth >= 0 ? '+' : ''}{st.growth}%
                              </span>
                            </div>
                            <div className="text-[11px] text-slate-400 mt-2 flex justify-between">
                              <span>قیمت هر سهم: <b className="font-mono text-white">{fmt(st.price)} $</b></span>
                              <span>سود تقسیمی: <b className="font-mono text-emerald-400">+{fmt(st.dividend)} $/سهم</b></span>
                            </div>
                            <div className="flex items-center justify-between text-[11px] mt-1">
                              <span className="text-amber-400">
                                دارایی کشور شما: <b>{fmt(owned)} سهم</b>
                              </span>
                              {owned >= 510 && (
                                <span className="text-amber-300 font-bold bg-amber-950 px-1.5 py-0.5 rounded border border-amber-700 text-[10px]">
                                  👑 اکثریت ۵۱٪+
                                </span>
                              )}
                            </div>
                          </div>
                          <div className="space-y-1.5">
                            <button
                              onClick={() => handleBuyStock(st)}
                              className="w-full py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs transition shadow"
                            >
                              خرید {buyStockQtyInput} سهم ({fmt(parseInputNumber(buyStockQtyInput) * st.price)} $)
                            </button>
                            {owned >= 510 && (
                              <button
                                onClick={() => {
                                  setControllingStock(st);
                                  setNewStockNameInput(st.name);
                                  setNewStockSectorInput(st.sector);
                                }}
                                className="w-full py-1.5 rounded-lg bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-600 hover:to-amber-700 text-slate-950 font-black text-xs transition shadow flex items-center justify-center gap-1.5"
                              >
                                <Crown className="w-3.5 h-3.5" />
                                مدیریت اکثریت ۵۱٪ (تغییر نام و حوزه فعالیت)
                              </button>
                            )}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>

                {/* ۲. ساخت شرکت اختصاصی */}
                <div className="p-4 rounded-xl bg-[#0f172a] border border-[#334155]">
                  <h3 className="font-bold text-sm text-white mb-2 flex items-center gap-2">
                    <Building className="w-4 h-4 text-amber-400" />
                    2. ساخت شرکت اختصاصی (5 دسته‌بندی مد، بازی، فیلم، خودرو، دارو)
                  </h3>
                  <p className="text-xs text-slate-400 mb-4">
                    اسم و لوگوی دلخواه ثبت کنید؛ هر چه شرکت را بیشتر ارتقا دهید، پول بیشتر و امتیاز علم بالاتری دریافت می‌کنید
                  </p>

                  <div className="grid grid-cols-1 sm:grid-cols-4 gap-3 p-3 rounded-xl bg-[#1e293b] mb-4">
                    <div>
                      <label className="text-xs text-slate-300 block mb-1">دسته فعالیت:</label>
                      <select
                        value={newEntCat}
                        onChange={(e) => {
                          setNewEntCat(e.target.value);
                          const iconMap: { [k: string]: string } = {
                            fashion: '👗',
                            gamedev: '🎮',
                            film: '🎬',
                            automotive: '🏎️',
                            pharma: '💊',
                          };
                          setNewEntLogo(iconMap[e.target.value] || '🏢');
                        }}
                        className="w-full px-3 py-2 rounded-lg bg-[#0f172a] border border-[#334155] text-white text-xs outline-none"
                      >
                        <option value="fashion">👗 لباس و مد</option>
                        <option value="gamedev">🎮 بازی‌سازی دیجیتال</option>
                        <option value="film">🎬 فیلم‌سازی و سینما</option>
                        <option value="automotive">🏎️ خودروسازی</option>
                        <option value="pharma">💊 شرکت دارویی و بیوتک</option>
                      </select>
                    </div>
                    <div>
                      <label className="text-xs text-slate-300 block mb-1">نام دلخواه شرکت:</label>
                      <input
                        type="text"
                        value={newEntName}
                        onChange={(e) => setNewEntName(e.target.value)}
                        className="w-full px-3 py-2 rounded-lg bg-[#0f172a] border border-[#334155] text-white text-xs outline-none"
                      />
                    </div>
                    <div>
                      <label className="text-xs text-slate-300 block mb-1">لوگو یا ایموجی:</label>
                      <input
                        type="text"
                        value={newEntLogo}
                        onChange={(e) => setNewEntLogo(e.target.value)}
                        className="w-full px-3 py-2 rounded-lg bg-[#0f172a] border border-[#334155] text-white text-xs outline-none"
                      />
                    </div>
                    <div className="flex items-end">
                      <button
                        onClick={handleCreateEnterprise}
                        className="w-full py-2 rounded-lg bg-amber-600 hover:bg-amber-700 text-white font-bold text-xs transition shadow"
                      >
                        تاسیس شرکت (50,000,000 $)
                      </button>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                    {customEnterprises.map((ent) => (
                      <div key={ent.id} className="p-3.5 rounded-xl bg-[#1e293b] border border-[#334155] flex items-center justify-between">
                        <div>
                          <div className="font-bold text-sm text-white flex items-center gap-2">
                            <span>{ent.logo}</span>
                            <span>{ent.name}</span>
                            <span className="text-[10px] px-2 py-0.5 rounded bg-slate-800 text-amber-400 font-mono font-bold">
                              سطح {fmt(ent.tier)} / 5
                            </span>
                          </div>
                          <div className="text-xs text-slate-400 mt-1">
                            صنعت: {ent.categoryName} | درآمد چرخه: <b className="text-emerald-400 font-mono">+{fmt(ent.cycleIncome)} $</b>
                          </div>
                          <div className="text-[11px] text-cyan-400 mt-0.5">امتیاز علمی: +{fmt(ent.scienceBoost)} علم</div>
                        </div>
                        {ent.tier < 5 ? (
                          <button
                            onClick={() => handleUpgradeEnterprise(ent.id)}
                            className="px-3.5 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold transition shadow"
                          >
                            ارتقا ({fmt(ent.cycleIncome * 3)} $)
                          </button>
                        ) : (
                          <span className="text-xs text-slate-400 font-bold px-2 py-1 bg-slate-800 rounded">حداکثر سطح</span>
                        )}
                      </div>
                    ))}
                  </div>
                </div>

                {/* ۳. پروژه‌های بزرگ ملی (Megaprojects) */}
                <div className="p-4 rounded-xl bg-[#0f172a] border border-[#334155]">
                  <h3 className="font-bold text-sm text-white mb-2 flex items-center gap-2">
                    <Rocket className="w-4 h-4 text-cyan-400" />
                    3. پروژه‌های بزرگ ملی (مگاپروژه‌های تمدنی)
                  </h3>
                  <p className="text-xs text-slate-400 mb-4">
                    احداث مگاپروژه‌ها جهش‌های علمی عظیمی به همراه داشته و جایگاه استراتژیک کشور را متحول می‌سازند
                  </p>

                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3">
                    {[
                      { key: 'artificial_island', name: 'جزیره مصنوعی', cost: 800000000, science: 15, emoji: '🏝️' },
                      { key: 'national_tower', name: 'برج ملی', cost: 1200000000, science: 25, emoji: '🗼' },
                      { key: 'megacity', name: 'کلان‌شهر هوشمند', cost: 2500000000, science: 40, emoji: '🏙️' },
                      { key: 'moon_mission', name: 'رفتن به ماه', cost: 5000000000, science: 70, emoji: '🌕' },
                      { key: 'space_station', name: 'پایگاه فضایی', cost: 10000000000, science: 100, emoji: '🛰️' },
                    ].map((proj) => {
                      const isBuilt = builtMegaprojects.includes(proj.key);
                      return (
                        <div key={proj.key} className="p-3.5 rounded-xl bg-[#1e293b] border border-[#334155] flex flex-col justify-between gap-3">
                          <div>
                            <span className="text-2xl mb-1 block">{proj.emoji}</span>
                            <div className="font-bold text-xs text-white">{proj.name}</div>
                            <div className="text-[11px] text-cyan-400 font-bold mt-1">+{fmt(proj.science)} امتیاز علم</div>
                            <div className="text-[10px] text-slate-400 font-mono mt-1">{fmt(proj.cost)} $</div>
                          </div>
                          {isBuilt ? (
                            <span className="w-full py-1.5 rounded-lg bg-emerald-950 border border-emerald-600 text-emerald-300 text-center text-xs font-bold block">
                              ✅ احداث‌شده
                            </span>
                          ) : (
                            <button
                              onClick={() => handleBuildMegaproject(proj.key, proj.name, proj.cost, proj.science)}
                              className="w-full py-1.5 rounded-lg bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs transition shadow"
                            >
                              احداث پروژه
                            </button>
                          )}
                        </div>
                      );
                    })}
                  </div>
                </div>

                {/* ۴. رسانه و اینترنت */}
                <div className="p-4 rounded-xl bg-[#0f172a] border border-[#334155] space-y-4">
                  <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 border-b border-[#334155] pb-3">
                    <div>
                      <h3 className="font-bold text-sm text-white flex items-center gap-2">
                        <Radio className="w-4 h-4 text-sky-400" />
                        4. رسانه، ویدیو و زیرساخت اینترنت ملی
                      </h3>
                      <p className="text-xs text-slate-400 mt-0.5">
                        ارتقا از 3G به بالاتر، انتشار پست ویدیویی هر 10 دقیقه با تایید ادمین و تاسیس اپراتور اختصاصی اینترنت
                      </p>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="text-xs text-slate-400">نسل اینترنت:</span>
                      <span className="px-3 py-1 rounded-lg bg-slate-800 text-cyan-400 font-bold font-mono text-xs">
                        {userCountry.internet}
                      </span>
                      <button
                        onClick={handleUpgradeInternet}
                        className="px-3 py-1 rounded-lg bg-cyan-600 hover:bg-cyan-700 text-white text-xs font-bold transition"
                      >
                        ارتقای نسل شبکه
                      </button>
                    </div>
                  </div>

                  {/* ساخت اپراتور اختصاصی */}
                  <div className="p-3.5 rounded-xl bg-[#1e293b] flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
                    {telecomOperator ? (
                      <div className="flex items-center gap-3">
                        <span className="text-3xl">{telecomOperator.logo}</span>
                        <div>
                          <div className="font-bold text-sm text-white">{telecomOperator.name}</div>
                          <div className="text-xs text-slate-400">
                            فرستنده‌ها: <b className="font-mono text-white">{fmt(telecomOperator.antennas)}</b> دکل | مشترکین: <b className="font-mono text-white">{fmt(telecomOperator.subscribers)}</b> نفر
                          </div>
                          <div className="text-xs text-emerald-400 font-bold mt-0.5">
                            سود هر چرخه درآمد: +{fmt(telecomOperator.cycleDividend)} $
                          </div>
                        </div>
                      </div>
                    ) : (
                      <div className="w-full flex flex-col sm:flex-row items-center gap-3">
                        <input
                          type="text"
                          value={newOperatorName}
                          onChange={(e) => setNewOperatorName(e.target.value)}
                          placeholder="نام اپراتور..."
                          className="w-full sm:w-48 px-3 py-2 rounded-lg bg-[#0f172a] border border-[#334155] text-white text-xs outline-none"
                        />
                        <input
                          type="text"
                          value={newOperatorLogo}
                          onChange={(e) => setNewOperatorLogo(e.target.value)}
                          placeholder="لوگو..."
                          className="w-full sm:w-24 px-3 py-2 rounded-lg bg-[#0f172a] border border-[#334155] text-white text-xs outline-none"
                        />
                        <button
                          onClick={handleCreateTelecomOperator}
                          className="w-full sm:w-auto px-4 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs transition"
                        >
                          تاسیس اپراتور اختصاصی (120M $)
                        </button>
                      </div>
                    )}
                  </div>

                  {/* ارسال پست ویدیویی با تایید ادمین */}
                  <div className="p-3.5 rounded-xl bg-[#1e293b] space-y-3">
                    <h4 className="font-bold text-xs text-white flex items-center gap-1.5">
                      <Video className="w-4 h-4 text-red-400" />
                      انتشار ویدیو در شبکه ملی (هر 10 دقیقه با تایید ادمین)
                    </h4>
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                      <input
                        type="text"
                        value={videoCaptionInput}
                        onChange={(e) => setVideoCaptionInput(e.target.value)}
                        placeholder="متن یا کپشن پست رسمی..."
                        className="sm:col-span-2 px-3 py-2 rounded-lg bg-[#0f172a] border border-[#334155] text-white text-xs outline-none"
                      />
                      <input
                        type="text"
                        value={videoUrlInput}
                        onChange={(e) => setVideoUrlInput(e.target.value)}
                        placeholder="لینک ویدیو..."
                        className="px-3 py-2 rounded-lg bg-[#0f172a] border border-[#334155] text-white text-xs outline-none"
                      />
                    </div>
                    <button
                      onClick={handleSubmitMediaPost}
                      className="px-5 py-2 rounded-lg bg-red-600 hover:bg-red-700 text-white font-bold text-xs transition shadow flex items-center gap-1.5"
                    >
                      <Send className="w-3.5 h-3.5" />
                      ارسال ویدیو به صف تایید ادمین
                    </button>

                    {/* لیست پست‌های اخیر */}
                    <div className="space-y-2 pt-2">
                      {mediaPosts.map((p) => (
                        <div key={p.id} className="p-2.5 rounded-lg bg-[#0f172a] border border-[#334155] flex items-center justify-between text-xs">
                          <div>
                            <span className="text-white font-semibold">{p.caption}</span>
                            <span className="text-slate-500 text-[11px] block mt-0.5">{p.time}</span>
                          </div>
                          <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${p.status === 'approved' ? 'bg-emerald-950 text-emerald-400' : 'bg-amber-950 text-amber-400'}`}>
                            {p.status === 'approved' ? 'منتشرشده' : 'در انتظار تایید ادمین'}
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* ============================================================ */}
        {/* دستاوردها، مگاپروژه‌ها و لاگ زنده پژوهش ملی (کانال‌محور بدون اسپم پی‌وی) */}
        {/* ============================================================ */}
        {activeTab === 'research_logs' && (
          <div className="space-y-6">
            <div className="p-5 rounded-xl bg-[#1e293b] border border-[#334155] shadow-lg">
              <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-b border-[#334155] pb-4 mb-4">
                <div>
                  <h2 className="text-lg font-black text-white flex items-center gap-2">
                    <FlaskConical className="w-5 h-5 text-cyan-400" />
                    دستاوردها، مگاپروژه‌ها و لاگ پژوهش‌های ملی — {userCountry.name} {userCountry.flag}
                  </h2>
                  <p className="text-xs text-slate-400 mt-1">
                    پایگاه داده زنده پیشرفت‌های علمی، ارتقای بی‌نهایت اینترنت و مگاپروژه‌ها منتشرشده در کانال رسمی بازی
                  </p>
                </div>
                <div className="flex items-center gap-3">
                  <div className="px-3.5 py-1.5 rounded-xl bg-[#0f172a] border border-cyan-500/40 text-center">
                    <span className="text-[10px] text-slate-400 block">سطح علم ملی</span>
                    <span className="text-xl font-black text-cyan-400 font-mono">
                      {fmt(userCountry.scienceScore)} <span className="text-xs">امتیاز</span>
                    </span>
                  </div>
                  <div className="px-3.5 py-1.5 rounded-xl bg-[#0f172a] border border-sky-500/40 text-center">
                    <span className="text-[10px] text-slate-400 block">نسل اینترنت فعلی</span>
                    <span className="text-xl font-black text-sky-400 font-mono">
                      {userCountry.internet}
                    </span>
                  </div>
                </div>
              </div>

              {/* بیانیه و سیاست شفاف عدم ارسال اسپم پی‌وی */}
              <div className="p-4 rounded-xl bg-gradient-to-r from-sky-950/70 to-[#0f172a] border border-sky-500/40 mb-6">
                <div className="flex items-start gap-3">
                  <div className="p-2 rounded-lg bg-sky-900/50 text-sky-400 shrink-0 mt-0.5">
                    <Radio className="w-5 h-5" />
                  </div>
                  <div className="space-y-1">
                    <div className="font-bold text-sm text-sky-200 flex items-center gap-2">
                      <span>📢 سیاست سکوت در پی‌وی و انتشار انحصاری در کانال تلگرام</span>
                      <span className="px-2 py-0.5 rounded bg-sky-900 text-sky-300 text-[10px] font-mono">
                        تضمین Zero-Spam
                      </span>
                    </div>
                    <p className="text-xs text-slate-300 leading-relaxed">
                      طبق دستورالعمل ارتقاها، هنگام ارتقای نسل اینترنت یا تکمیل پروژه‌های علمی هیچ‌گونه پیام مستقیم در پی‌وی بازیکنان ارسال نمی‌شود. در عوض، تمامی افتخارات علمی مستقیماً در کانال عمومی بازی منتشر شده و گزارش تفصیلی آن به صورت آنلاین در این بخش نمایش می‌یابد.
                    </p>
                  </div>
                </div>
              </div>

              {/* ۴ شاخص کلیدی اقتدار علمی */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-6">
                <div className="p-3.5 rounded-xl bg-[#0f172a] border border-[#334155]">
                  <div className="text-[11px] text-slate-400">شبکه ملی اطلاعات</div>
                  <div className="text-lg font-black text-sky-400 font-mono mt-1">{userCountry.internet} هیپرسیگنال</div>
                  <div className="text-[10px] text-slate-500 mt-1">مقیاس‌پذیر تا بی‌نهایت</div>
                </div>
                <div className="p-3.5 rounded-xl bg-[#0f172a] border border-[#334155]">
                  <div className="text-[11px] text-slate-400">امتیاز علمی کشور</div>
                  <div className="text-lg font-black text-cyan-400 font-mono mt-1">{fmt(userCountry.scienceScore)} علم</div>
                  <div className="text-[10px] text-emerald-400 mt-1">+15 با هر ارتقا</div>
                </div>
                <div className="p-3.5 rounded-xl bg-[#0f172a] border border-[#334155]">
                  <div className="text-[11px] text-slate-400">مگاپروژه‌های ساخته‌شده</div>
                  <div className="text-lg font-black text-amber-400 font-mono mt-1">{builtMegaprojects.length} سازه</div>
                  <div className="text-[10px] text-slate-500 mt-1">نماد تمدن ملی</div>
                </div>
                <div className="p-3.5 rounded-xl bg-[#0f172a] border border-[#334155]">
                  <div className="text-[11px] text-slate-400">شرکت‌های دانش‌بنیان</div>
                  <div className="text-lg font-black text-purple-400 font-mono mt-1">{customEnterprises.length} شرکت</div>
                  <div className="text-[10px] text-emerald-400 mt-1">تولید پیوسته درآمد و علم</div>
                </div>
              </div>

              {/* لیست کارت‌های لاگ زنده پژوهش‌ها */}
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <h3 className="font-bold text-sm text-white flex items-center gap-2">
                    <History className="w-4 h-4 text-amber-400" />
                    تاریخچه زنده عملیات‌های پژوهش و توسعه ({researchLogs.length} رویداد)
                  </h3>
                  <button
                    onClick={handleUpgradeInternet}
                    className="px-3 py-1.5 rounded-lg bg-sky-600 hover:bg-sky-700 text-white font-black text-xs transition shadow flex items-center gap-1.5"
                  >
                    <Rocket className="w-3.5 h-3.5" />
                    ارتقای اینترنت به نسل بعدی ({parseInt(userCountry.internet.replace(/\D/g, ''), 10) + 1}G)
                  </button>
                </div>

                <div className="space-y-3">
                  {researchLogs.map((log) => (
                    <div
                      key={log.id}
                      className="p-4 rounded-xl bg-[#0f172a] border border-[#334155] hover:border-cyan-500/40 transition space-y-2"
                    >
                      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2 border-b border-[#334155]/60 pb-2">
                        <div className="flex items-center gap-2">
                          <span className="text-lg">{log.countryFlag}</span>
                          <span className="font-bold text-xs text-white">{log.countryName}</span>
                          <span
                            className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                              log.badgeColor === 'sky'
                                ? 'bg-sky-950 text-sky-300 border border-sky-800'
                                : log.badgeColor === 'emerald'
                                ? 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                                : 'bg-purple-950 text-purple-300 border border-purple-800'
                            }`}
                          >
                            {log.type === 'internet_upgrade'
                              ? '📶 ارتقای اینترنت ملی'
                              : log.type === 'megaproject'
                              ? '🗼 مگاپروژه تمدنی'
                              : '🏢 شرکت دانش‌بنیان'}
                          </span>
                        </div>
                        <div className="flex items-center gap-2 text-[11px] text-slate-400">
                          <span className="flex items-center gap-1 text-sky-400 font-mono text-[10px] bg-sky-950/60 px-2 py-0.5 rounded border border-sky-800/40">
                            <Radio className="w-3 h-3" />
                            منتشرشده در کانال
                          </span>
                          <span>{log.timestamp}</span>
                        </div>
                      </div>

                      <div className="font-bold text-sm text-white pt-0.5">
                        {log.title}
                      </div>

                      <p className="text-xs text-slate-300 leading-relaxed">
                        {log.details}
                      </p>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* ============================================================ */}
        {/* ۴. مدیریت سکه شاهی */}
        {/* ============================================================ */}
        {activeTab === 'shahi' && (
          <div className="space-y-6">
            <div className="p-5 rounded-xl bg-[#1e293b] border border-[#334155]">
              <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-b border-[#334155] pb-4 mb-4">
                <div>
                  <h2 className="text-lg font-black text-white flex items-center gap-2">
                    <Crown className="w-5 h-5 text-amber-400" />
                    مدیریت سکه شاهی (جایگزین کامل AW کوین)
                  </h2>
                  <p className="text-xs text-slate-400 mt-1">
                    ارز سلطنتی و استراتژیک بازی با قابلیت تبدیل مستقیم به دلار خزانه
                  </p>
                </div>
                <div className="flex items-center gap-3">
                  <div className="px-4 py-2 rounded-lg bg-[#0f172a] border border-amber-500/40 text-center">
                    <span className="text-[11px] text-slate-400 block">موجودی سکه شاهی</span>
                    <span className="text-xl font-black text-amber-400 font-mono">{fmt(shahiCoins)} 👑</span>
                  </div>
                  <div className="px-4 py-2 rounded-lg bg-[#0f172a] border border-[#334155] text-center">
                    <span className="text-[11px] text-slate-400 block">نرخ هر سکه</span>
                    <span className="text-lg font-black text-emerald-400 font-mono">10,000,000 $</span>
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="p-4 rounded-xl bg-[#0f172a] border border-[#334155]">
                  <h3 className="font-bold text-sm text-white mb-2">تبدیل سکه شاهی به دلار</h3>
                  <button
                    onClick={() => {
                      if (shahiCoins < 1) return;
                      setShahiCoins((c) => c - 1);
                      setTreasuryDollars((t) => t + 10000000);
                      showFeedback('✅ ۱ سکه شاهی تبدیل شد و 10,000,000 $ به خزانه افزوده شد.');
                    }}
                    className="w-full py-2.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs transition shadow"
                  >
                    تبدیل 1 سکه شاهی ➔ 10,000,000 $
                  </button>
                </div>

                <div className="p-4 rounded-xl bg-[#0f172a] border border-[#334155]">
                  <h3 className="font-bold text-sm text-white mb-2">خرید سکه شاهی با دلار</h3>
                  <button
                    onClick={() => {
                      if (treasuryDollars < 10000000) return;
                      setTreasuryDollars((t) => t - 10000000);
                      setShahiCoins((c) => c + 1);
                      showFeedback('✅ ۱ سکه شاهی خریداری شد و 10,000,000 $ از خزانه کسر گردید.');
                    }}
                    className="w-full py-2.5 rounded-lg bg-amber-600 hover:bg-amber-700 text-white font-bold text-xs transition shadow"
                  >
                    پرداخت 10,000,000 $ ➔ خرید 1 سکه شاهی
                  </button>
                </div>
              </div>

              {/* سامانه اختصاصی خرید VIP با پول واقعی (تومان و فیش کارت‌به‌کارت مشابه خرید کشور VIP) */}
              <div className="mt-6 pt-5 border-t border-[#334155] space-y-4">
                <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
                  <div>
                    <h3 className="font-black text-base text-amber-300 flex items-center gap-2">
                      <CreditCard className="w-5 h-5 text-amber-400" />
                      خرید VIP سکه شاهی با پول واقعی (تومان) — متد خرید کشور VIP
                    </h3>
                    <p className="text-xs text-slate-300 mt-0.5">
                      واریز کارت‌به‌کارت بانکی شتاب، ارسال تصویر یا کد رهگیری فیش و تایید نهایی توسط ادمین در پنل
                    </p>
                  </div>
                  <div className="px-3.5 py-1.5 rounded-xl bg-[#0f172a] border border-amber-500/50 text-center">
                    <span className="text-[10px] text-slate-400 block">نرخ مصوب ادمین</span>
                    <span className="text-base font-black text-amber-400 font-mono">
                      {fmt(shahiPriceToman)} تومان / سکه
                    </span>
                  </div>
                </div>

                {/* بسته‌های آماده و انتخاب تعداد */}
                <div className="p-4 rounded-xl bg-[#0f172a] border border-[#334155] space-y-4">
                  <div>
                    <label className="text-xs text-slate-300 block mb-2 font-bold">
                      ۱. انتخاب بسته سکه شاهی یا ورود تعداد دلخواه:
                    </label>
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 mb-3">
                      {[5, 10, 20, 50].map((pkg) => (
                        <button
                          key={pkg}
                          onClick={() => setVipCoinPackage(pkg)}
                          className={`p-3 rounded-xl border text-center transition ${
                            vipCoinPackage === pkg
                              ? 'bg-amber-950 border-amber-500 text-amber-300 shadow-md ring-1 ring-amber-500/50'
                              : 'bg-[#1e293b] border-[#334155] text-slate-300 hover:border-slate-500'
                          }`}
                        >
                          <div className="text-sm font-black font-mono">{pkg} سکه شاهی 👑</div>
                          <div className="text-[11px] text-slate-400 mt-1 font-mono">
                            {fmt(pkg * shahiPriceToman)} تومان
                          </div>
                        </button>
                      ))}
                    </div>

                    <div className="flex items-center gap-3">
                      <span className="text-xs text-slate-400">یا تعداد دلخواه:</span>
                      <input
                        type="text"
                        value={vipCustomCount}
                        onChange={(e) => {
                          setVipCustomCount(e.target.value);
                          setVipCoinPackage(0);
                        }}
                        placeholder="مثلا: 15"
                        className="w-24 px-3 py-1.5 rounded-lg bg-[#1e293b] border border-[#334155] text-white font-mono text-xs outline-none"
                      />
                      <span className="text-xs text-amber-400 font-mono font-bold">
                        مبلغ کل: {fmt((vipCoinPackage > 0 ? vipCoinPackage : parseInputNumber(vipCustomCount)) * shahiPriceToman)} تومان
                      </span>
                    </div>
                  </div>

                  {/* اطلاعات حساب بانکی جهت واریز کارت به کارت */}
                  <div className="p-4 rounded-xl bg-gradient-to-r from-amber-950/40 to-slate-900 border border-amber-500/30 space-y-2">
                    <div className="font-bold text-xs text-amber-300 flex items-center gap-1.5">
                      <Landmark className="w-4 h-4" />
                      ۲. اطلاعات کارت شتاب جهت واریز وجه:
                    </div>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                      <div className="bg-[#0f172a] p-2.5 rounded-lg border border-[#334155]">
                        <span className="text-slate-400 block text-[11px]">شماره کارت بانکی:</span>
                        <span className="text-amber-400 font-mono font-black text-sm tracking-widest dir-ltr block text-right mt-0.5">
                          {paymentCardNumber}
                        </span>
                      </div>
                      <div className="bg-[#0f172a] p-2.5 rounded-lg border border-[#334155]">
                        <span className="text-slate-400 block text-[11px]">صاحب حساب:</span>
                        <span className="text-white font-bold block mt-0.5">{paymentCardHolder}</span>
                      </div>
                    </div>
                  </div>

                  {/* ثبت فیش واریز */}
                  <div className="space-y-2">
                    <label className="text-xs text-slate-300 block font-bold">
                      ۳. شماره پیگیری بانکی یا متن فیش واریز:
                    </label>
                    <div className="flex flex-col sm:flex-row gap-2">
                      <input
                        type="text"
                        value={vipReceiptText}
                        onChange={(e) => setVipReceiptText(e.target.value)}
                        placeholder="مثال: پیگیری ۹۸۲۳۷۴ بانک ملت — واریز توسط حمید..."
                        className="flex-1 px-3 py-2.5 rounded-lg bg-[#1e293b] border border-[#334155] text-white text-xs outline-none focus:border-amber-500"
                      />
                      <button
                        onClick={handleSubmitVipShahiOrder}
                        className="px-5 py-2.5 rounded-lg bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-600 hover:to-amber-700 text-slate-950 font-black text-xs transition shadow flex items-center justify-center gap-2"
                      >
                        <Send className="w-4 h-4" />
                        ثبت سفارش و ارسال فیش به صف ادمین
                      </button>
                    </div>
                  </div>

                  {/* وضعیت سفارش‌های VIP اخیر */}
                  <div className="space-y-2 pt-2 border-t border-[#334155]">
                    <div className="text-xs text-slate-400 font-bold flex items-center gap-1.5">
                      <FileCheck className="w-3.5 h-3.5 text-amber-400" />
                      سفارش‌های خرید VIP شما:
                    </div>
                    {shahiOrders.filter((o) => o.telegramId === 19827364).map((ord) => (
                      <div
                        key={ord.id}
                        className="p-3 rounded-lg bg-[#1e293b] border border-[#334155] flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2 text-xs"
                      >
                        <div>
                          <div className="font-bold text-white flex items-center gap-2">
                            <span>👑 {ord.coinsCount} سکه شاهی</span>
                            <span>•</span>
                            <span className="font-mono text-amber-400">{fmt(ord.totalPriceToman)} تومان</span>
                          </div>
                          <div className="text-[11px] text-slate-400 mt-0.5">
                            فیش: {ord.receiptText} | زمان: {ord.createdAt}
                          </div>
                        </div>
                        <span
                          className={`px-2.5 py-1 rounded-full text-[10px] font-bold ${
                            ord.status === 'approved'
                              ? 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                              : ord.status === 'rejected'
                              ? 'bg-red-950 text-red-300 border border-red-800'
                              : 'bg-amber-950 text-amber-300 border border-amber-800 animate-pulse'
                          }`}
                        >
                          {ord.status === 'approved'
                            ? '✅ تایید و واریز شد'
                            : ord.status === 'rejected'
                            ? '❌ رد شد'
                            : '⏳ در انتظار تایید ادمین'}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* ============================================================ */}
        {/* ۵. اقتصاد و نفت */}
        {/* ============================================================ */}
        {activeTab === 'oil_economy' && (
          <div className="space-y-6">
            {/* ویجت ماموریت‌های روزانه با تمرکز بر اقتصاد نفت */}
            {renderDailyMissionsWidget('پیگیری زنده ماموریت‌های صادرات ۵۰ هزار بشکه‌ای نفت، تولید برق و دریافت سکه شاهی و نفت جایزه')}

            <div className="p-5 rounded-xl bg-[#1e293b] border border-[#334155]">
              <h2 className="text-lg font-black text-white mb-1 flex items-center gap-2">
                <Droplets className="w-5 h-5 text-amber-400" />
                استخراج نفت، دکل‌ها، کارگران و صندوق امن
              </h2>
              <p className="text-xs text-slate-400 mb-4">
                توزیع نفت در امپراطوری شما متمرکز است. در این بخش می‌توانید دکل و کارگر با تعداد دلخواه انگلیسی یا فارسی سفارش دهید.
              </p>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-5">
                <div className="p-4 rounded-xl bg-[#0f172a] border border-[#334155]">
                  <h4 className="font-bold text-sm text-white mb-2">خرید دکل نفتی (15,000,000 $ / عدد)</h4>
                  <div className="flex gap-2">
                    <input
                      type="text"
                      value={customRigsQtyStr}
                      onChange={(e) => setCustomRigsQtyStr(e.target.value)}
                      placeholder="تعداد دکل..."
                      className="w-28 px-3 py-2 rounded-lg bg-[#1e293b] border border-[#334155] text-white font-mono text-sm outline-none"
                    />
                    <button
                      onClick={() => {
                        const qty = parseInputNumber(customRigsQtyStr);
                        const cost = qty * 15000000;
                        if (treasuryDollars < cost) return;
                        setTreasuryDollars((t) => t - cost);
                        setOilRigs((r) => r + qty);
                        showFeedback(`✅ تعداد ${fmt(qty)} دکل جدید خریداری شد.`);
                      }}
                      className="flex-1 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs transition shadow"
                    >
                      خرید {customRigsQtyStr} دکل ({fmt(parseInputNumber(customRigsQtyStr) * 15000000)} $)
                    </button>
                  </div>
                </div>

                <div className="p-4 rounded-xl bg-[#0f172a] border border-[#334155]">
                  <h4 className="font-bold text-sm text-white mb-2">استخدام کارگر پالایش (500,000 $ / نفر)</h4>
                  <div className="flex gap-2">
                    <input
                      type="text"
                      value={customWorkersQtyStr}
                      onChange={(e) => setCustomWorkersQtyStr(e.target.value)}
                      placeholder="تعداد کارگر..."
                      className="w-28 px-3 py-2 rounded-lg bg-[#1e293b] border border-[#334155] text-white font-mono text-sm outline-none"
                    />
                    <button
                      onClick={() => {
                        const qty = parseInputNumber(customWorkersQtyStr);
                        const cost = qty * 500000;
                        if (treasuryDollars < cost) return;
                        setTreasuryDollars((t) => t - cost);
                        setOilWorkers((w) => w + qty);
                        showFeedback(`✅ تعداد ${fmt(qty)} کارگر استخدام شدند.`);
                      }}
                      className="flex-1 py-2 rounded-lg bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs transition shadow"
                    >
                      استخدام {customWorkersQtyStr} کارگر ({fmt(parseInputNumber(customWorkersQtyStr) * 500000)} $)
                    </button>
                  </div>
                </div>
              </div>

              {/* صندوق امن */}
              <div className="p-4 rounded-xl bg-[#0f172a] border border-[#334155]">
                <div className="flex items-center justify-between mb-2">
                  <h4 className="font-bold text-sm text-white">واریز به صندوق امن (غیرقابل هک و غارت)</h4>
                  <span className="text-xs font-mono font-bold text-emerald-400">
                    موجودی فعلی: {fmt(safeVaultDollars)} $
                  </span>
                </div>
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={customVaultInputStr}
                    onChange={(e) => setCustomVaultInputStr(e.target.value)}
                    placeholder="مبلغ واریزی..."
                    className="flex-1 px-3 py-2 rounded-lg bg-[#1e293b] border border-[#334155] text-white font-mono text-sm outline-none"
                  />
                  <button
                    onClick={() => setVaultConfirmModal(true)}
                    className="px-5 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs transition shadow"
                  >
                    تایید اولیه واریز
                  </button>
                </div>

                {vaultConfirmModal && (
                  <div className="fixed inset-0 bg-black/85 flex items-center justify-center z-50 p-4">
                    <div className="max-w-md w-full bg-[#1e293b] border border-[#475569] rounded-xl p-5 shadow-2xl space-y-4">
                      <h3 className="font-black text-base text-white">تایید نهایی واریز به صندوق امن</h3>
                      <p className="text-xs text-slate-300">
                        آیا از واریز مبلغ <b className="font-mono text-emerald-400">{fmt(parseInputNumber(customVaultInputStr))} $</b> به صندوق امن اطمینان دارید؟
                      </p>
                      <div className="flex gap-2 pt-2">
                        <button
                          onClick={() => {
                            const amt = parseInputNumber(customVaultInputStr);
                            if (treasuryDollars < amt) return;
                            setTreasuryDollars((t) => t - amt);
                            setSafeVaultDollars((v) => v + amt);
                            setVaultConfirmModal(false);
                            showFeedback(`✅ مبلغ ${fmt(amt)} $ به صندوق امن واریز شد.`);
                          }}
                          className="flex-1 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs"
                        >
                          [✅ تایید واریز به صندوق امن]
                        </button>
                        <button
                          onClick={() => setVaultConfirmModal(false)}
                          className="px-4 py-2 rounded-lg bg-slate-700 text-slate-300 text-xs font-bold"
                        >
                          انصراف
                        </button>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>
        )}

        {/* ============================================================ */}
        {/* ۶. بازار و تجارت نفت کشورها */}
        {/* ============================================================ */}
        {activeTab === 'oil_trade' && (
          <div className="space-y-6">
            <div className="p-5 rounded-xl bg-[#1e293b] border border-[#334155]">
              <h2 className="text-lg font-black text-white mb-2 flex items-center gap-2">
                <ArrowRightLeft className="w-5 h-5 text-sky-400" />
                فروش و خرید نفت کشورها و قراردادهای رسمی
              </h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {countryOilOffers.map((off) => (
                  <div key={off.id} className="p-4 rounded-xl bg-[#0f172a] border border-[#334155] flex justify-between items-center">
                    <div>
                      <div className="font-bold text-sm text-white flex items-center gap-2">
                        <span>{off.flag}</span>
                        <span>{off.countryName}</span>
                      </div>
                      <div className="text-xs text-slate-400 mt-1">
                        موجودی: {fmt(off.barrels)} بشکه | نرخ: {fmt(off.pricePerBarrel)} $/بشکه
                      </div>
                    </div>
                    <button
                      onClick={() => {
                        const total = 10000 * off.pricePerBarrel;
                        const tax = Math.floor(total * 0.015);
                        if (treasuryDollars < total) return;
                        setTreasuryDollars((t) => t - total);
                        setCurrentOil((o) => o + 10000);
                        setCentralBankBudget((b) => b + tax);
                        showFeedback(`✅ 10,000 بشکه نفت از ${off.countryName} با کارمزد 1.5% بانک مرکزی خریداری شد.`);
                      }}
                      className="px-4 py-2 rounded-lg bg-sky-600 hover:bg-sky-700 text-white font-bold text-xs"
                    >
                      خرید 10,000 بشکه
                    </button>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* ============================================================ */}
        {/* ۷. وام‌های بین‌کشوری با کسر ۸۰٪ */}
        {/* ============================================================ */}
        {activeTab === 'loans' && (
          <div className="space-y-6">
            <div className="p-5 rounded-xl bg-[#1e293b] border border-[#334155]">
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-lg font-black text-white flex items-center gap-2">
                  <HandCoins className="w-5 h-5 text-amber-400" />
                  وام‌های دولتی با کسر خودکار 80% از هر درآمد
                </h2>
                <button
                  onClick={handleSimulateIncomeCycle}
                  className="px-4 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs"
                >
                  تست واریز درآمد و کسر 80%
                </button>
              </div>

              {sovereignLoans.map((loan) => (
                <div key={loan.id} className="p-4 rounded-xl bg-[#0f172a] border border-[#334155] flex justify-between items-center">
                  <div>
                    <div className="font-bold text-sm text-white">
                      وام‌دهنده: {loan.lenderFlag} {loan.lenderCountry} ➔ وام‌گیرنده: {loan.borrowerFlag} {loan.borrowerCountry}
                    </div>
                    <div className="text-xs text-slate-400 mt-1">
                      اصل تسهیلات: {fmt(loan.initialAmount)} $
                    </div>
                  </div>
                  <div className="text-right">
                    <span className="text-xs text-slate-400 block">مانده بدهی:</span>
                    <span className="text-base font-black font-mono text-amber-400">{fmt(loan.remainingAmount)} $</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* ============================================================ */}
        {/* ۸. بازار جهانی و عمومی */}
        {/* ============================================================ */}
        {activeTab === 'markets' && (
          <div className="space-y-6">
            <div className="p-5 rounded-xl bg-[#1e293b] border border-[#334155]">
              <h2 className="text-lg font-black text-white mb-2 flex items-center gap-2">
                <Globe2 className="w-5 h-5 text-emerald-400" />
                بازار جهانی کالاها با قیمت مصوب ادمین
              </h2>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                {globalCommodities.map((item) => (
                  <div key={item.key} className="p-3.5 rounded-xl bg-[#0f172a] border border-[#334155] flex justify-between items-center">
                    <div>
                      <div className="font-bold text-sm text-white flex items-center gap-1.5">
                        <span>{item.icon}</span>
                        <span>{item.name}</span>
                      </div>
                      <div className="text-xs text-slate-400 mt-1">
                        نرخ: {fmt(item.price)} $ / {item.unit}
                      </div>
                    </div>
                    <button
                      onClick={() => {
                        const total = 50 * item.price;
                        if (treasuryDollars < total) return;
                        setTreasuryDollars((t) => t - total);
                        showFeedback(`✅ 50 ${item.unit} از ${item.name} خریداری شد.`);
                      }}
                      className="px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs"
                    >
                      خرید 50 {item.unit}
                    </button>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* ============================================================ */}
        {/* ۹. بانک مرکزی */}
        {/* ============================================================ */}
        {activeTab === 'central_bank' && (
          <div className="space-y-6">
            <div className="p-5 rounded-xl bg-[#1e293b] border border-[#334155]">
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-lg font-black text-white flex items-center gap-2">
                  <Landmark className="w-5 h-5 text-blue-400" />
                  بانک مرکزی و خزانه کارمزدهای شبکه
                </h2>
                <span className="text-xl font-black font-mono text-blue-400">
                  {fmt(centralBankBudget)} $
                </span>
              </div>
              <p className="text-xs text-slate-400 leading-relaxed mb-4">
                کارمزدهای 1.5% و 3% معاملات نفت و کالا در این بانک انباشته شده و ادمین فقط می‌تواند از سقف این بودجه به کشورها کمک بلاعوض پرداخت کند.
              </p>
              <div className="space-y-2">
                {centralBankAuditLog.map((log) => (
                  <div key={log.id} className="p-2.5 rounded-lg bg-[#0f172a] border border-[#334155] flex justify-between text-xs">
                    <span className="text-white font-semibold">{log.reason}</span>
                    <span className="font-mono text-emerald-400 font-bold">+{fmt(log.amount)} $</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* ============================================================ */}
        {/* ۱۰. پنل ادمین و تغییر قیمت‌ها */}
        {/* ============================================================ */}
        {activeTab === 'admin_panel' && (
          <div className="space-y-6">
            <div className="p-5 rounded-xl bg-[#1e293b] border border-[#334155]">
              <h2 className="text-lg font-black text-white mb-2 flex items-center gap-2">
                <Scale className="w-5 h-5 text-amber-400" />
                تنظیمات ادمین: نرخ نیروگاه‌ها و تجهیزات سرکوب
              </h2>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mt-4">
                <div className="p-4 rounded-xl bg-[#0f172a] border border-[#334155] space-y-3">
                  <h4 className="font-bold text-xs text-white">نرخ‌های نیروگاه‌های برق و آب ($):</h4>
                  <div className="space-y-2 text-xs">
                    <div className="flex justify-between items-center">
                      <span className="text-slate-300">نیروگاه بادی:</span>
                      <span className="font-mono text-emerald-400">{fmt(adminPlantCosts.wind)} $</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-slate-300">برق خورشیدی:</span>
                      <span className="font-mono text-emerald-400">{fmt(adminPlantCosts.solar)} $</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-slate-300">سد برق‌آبی:</span>
                      <span className="font-mono text-emerald-400">{fmt(adminPlantCosts.hydro_dam)} $</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-slate-300">نیروگاه اتمی:</span>
                      <span className="font-mono text-emerald-400">{fmt(adminPlantCosts.nuclear)} $</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-slate-300">تصفیه آب دریا:</span>
                      <span className="font-mono text-sky-400">{fmt(adminPlantCosts.desalination)} $</span>
                    </div>
                  </div>
                </div>

                <div className="p-4 rounded-xl bg-[#0f172a] border border-[#334155] space-y-3">
                  <h4 className="font-bold text-xs text-white">نرخ‌های ابزار سرکوب شورش ($):</h4>
                  <div className="space-y-2 text-xs">
                    <div className="flex justify-between items-center">
                      <span className="text-slate-300">پلیس و یگان ویژه:</span>
                      <span className="font-mono text-blue-400">{fmt(adminQuellCosts.police)} $</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-slate-300">سرکوب قهرآمیز ارتش:</span>
                      <span className="font-mono text-red-400">{fmt(adminQuellCosts.military)} $</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-slate-300">شورای اصلاحات و عفو:</span>
                      <span className="font-mono text-emerald-400">{fmt(adminQuellCosts.reform_amnesty)} $</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* مدیریت زمان پرداخت، لغو/فریز واریزها و از سرگیری طبق درخواست کاربر */}
            <div className="p-5 rounded-xl bg-[#1e293b] border border-amber-500/40 shadow-lg">
              <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 border-b border-[#334155] pb-4 mb-4">
                <div>
                  <h3 className="font-black text-base text-white flex items-center gap-2">
                    <HandCoins className="w-5 h-5 text-amber-400" />
                    مدیریت واریز دوره‌ای درآمدها (امکان تغییر زمان پرداخت، لغو و از سرگیری)
                  </h3>
                  <p className="text-xs text-slate-400 mt-1">
                    تنظیم بازه واریز درآمد و نفت برای کلیه کشورها و قابلیت توقف فوری واریزها (Freeze Payouts) در شرایط اضطراری
                  </p>
                </div>
                <div className="flex items-center gap-2">
                  <span
                    className={`px-3 py-1 rounded-full text-xs font-bold border ${
                      isPayoutFrozen
                        ? 'bg-red-950 text-red-300 border-red-700'
                        : 'bg-emerald-950 text-emerald-300 border-emerald-700'
                    }`}
                  >
                    {isPayoutFrozen ? '⏸ واریزها فریز و متوقف شده است' : '✅ چرخه خودکار فعال است'}
                  </span>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {/* کنترل توقف / از سرگیری */}
                <div className="p-4 rounded-xl bg-[#0f172a] border border-[#334155] space-y-3">
                  <h4 className="font-bold text-xs text-white">کنترل وضعیت واریز دوره‌ای:</h4>
                  <p className="text-xs text-slate-400">
                    با فریز کردن، چرخه پرداخت سود و نفت به تمام کشورها تا اطلاع ثانوی متوقف می‌گردد.
                  </p>
                  <button
                    onClick={() => {
                      const next = !isPayoutFrozen;
                      setIsPayoutFrozen(next);
                      showFeedback(
                        next
                          ? '⏸ واریزهای دوره‌ای با موفقیت متوقف و فریز گردید.'
                          : '✅ واریزهای دوره‌ای مجدداً از سر گرفته شد.'
                      );
                    }}
                    className={`w-full py-2.5 rounded-lg font-black text-xs transition shadow flex items-center justify-center gap-2 ${
                      isPayoutFrozen
                        ? 'bg-emerald-600 hover:bg-emerald-700 text-white'
                        : 'bg-red-600 hover:bg-red-700 text-white'
                    }`}
                  >
                    {isPayoutFrozen ? <Play className="w-4 h-4" /> : <Pause className="w-4 h-4" />}
                    {isPayoutFrozen ? 'از سرگیری فوری واریزها (Resume Payouts)' : 'لغو و توقف موقت واریزها (Freeze Payouts)'}
                  </button>
                </div>

                {/* انتخاب بازه زمانی */}
                <div className="p-4 rounded-xl bg-[#0f172a] border border-[#334155] space-y-3">
                  <h4 className="font-bold text-xs text-white">
                    تغییر زمان چرخه واریز (فعلی: هر {payoutIntervalMinutes} دقیقه):
                  </h4>
                  <div className="grid grid-cols-4 gap-2">
                    {[5, 10, 15, 30].map((mins) => (
                      <button
                        key={mins}
                        onClick={() => {
                          setPayoutIntervalMinutes(mins);
                          showFeedback(`⏱ زمان چرخه واریزها به هر ${mins} دقیقه تغییر یافت.`);
                        }}
                        className={`py-2 rounded-lg text-xs font-mono font-bold transition border ${
                          payoutIntervalMinutes === mins
                            ? 'bg-amber-500 text-slate-950 border-amber-400'
                            : 'bg-[#1e293b] text-slate-300 border-[#334155] hover:border-slate-500'
                        }`}
                      >
                        {mins} دقیقه
                      </button>
                    ))}
                  </div>

                  <button
                    onClick={async () => {
                      try {
                        await fetch('/api/game/payout-10min', { method: 'POST' });
                        showFeedback('⚡ چرخه واریز دستی با موفقیت اجرا شد و سود و نفت برای همه کشورها واریز گردید.');
                      } catch {
                        showFeedback('⚡ واریز دستی انجام شد.');
                      }
                    }}
                    className="w-full py-2 rounded-lg bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs transition shadow flex items-center justify-center gap-1.5"
                  >
                    <RefreshCw className="w-3.5 h-3.5" />
                    اجرای دستی یک نوبت واریز درآمد و نفت برای همه کشورها
                  </button>
                </div>
              </div>
            </div>

            {/* مدیریت نرخ تومان سکه شاهی و صف بررسی فیش‌های خرید VIP */}
            <div className="p-5 rounded-xl bg-[#1e293b] border border-amber-500/40 shadow-lg space-y-4">
              <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 border-b border-[#334155] pb-4">
                <div>
                  <h3 className="font-black text-base text-amber-300 flex items-center gap-2">
                    <Crown className="w-5 h-5 text-amber-400" />
                    مدیریت نرخ تومان سکه شاهی و صف تایید فیش‌های خرید VIP
                  </h3>
                  <p className="text-xs text-slate-300 mt-0.5">
                    تعیین قیمت هر سکه شاهی به تومان و بررسی و تایید فیش‌های کارت‌به‌کارت بازیکنان مشابه کشور VIP
                  </p>
                </div>
                <div className="flex items-center gap-2">
                  <span className="px-3 py-1 rounded-full bg-amber-950 text-amber-300 border border-amber-600 text-xs font-mono font-bold">
                    نرخ فعلی: {fmt(shahiPriceToman)} تومان
                  </span>
                </div>
              </div>

              {/* فرم تغییر قیمت هر دانه سکه شاهی */}
              <div className="p-4 rounded-xl bg-[#0f172a] border border-[#334155] space-y-3">
                <h4 className="font-bold text-xs text-white">تغییر نرخ هر سکه شاهی به تومان (خرید با پول واقعی):</h4>
                <div className="flex flex-col sm:flex-row gap-2 max-w-md">
                  <input
                    type="number"
                    defaultValue={shahiPriceToman}
                    id="admin-shahi-toman-input"
                    className="flex-1 px-3 py-2 rounded-lg bg-[#1e293b] border border-[#334155] text-white font-mono text-xs outline-none focus:border-amber-500"
                    placeholder="مثلا: 50000"
                  />
                  <button
                    onClick={() => {
                      const inp = document.getElementById('admin-shahi-toman-input') as HTMLInputElement;
                      const val = parseInt(inp?.value || '0', 10);
                      handleSaveShahiPrice(val);
                    }}
                    className="px-5 py-2 rounded-lg bg-amber-500 hover:bg-amber-600 text-slate-950 font-black text-xs transition shadow"
                  >
                    ذخیره نرخ جدید تومان
                  </button>
                </div>
              </div>

              {/* صف تایید فیش‌های خرید VIP */}
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <h4 className="font-bold text-xs text-white flex items-center gap-2">
                    <FileCheck className="w-4 h-4 text-emerald-400" />
                    صف بررسی فیش‌های واریزی بازیکنان ({shahiOrders.filter((o) => o.status === 'pending_admin').length} در انتظار)
                  </h4>
                </div>

                <div className="space-y-2">
                  {shahiOrders.map((ord) => (
                    <div
                      key={ord.id}
                      className="p-4 rounded-xl bg-[#0f172a] border border-[#334155] flex flex-col md:flex-row items-start md:items-center justify-between gap-3 text-xs"
                    >
                      <div className="space-y-1">
                        <div className="flex items-center gap-2">
                          <span className="text-base">{ord.countryFlag}</span>
                          <span className="font-bold text-white text-sm">{ord.displayName}</span>
                          <span className="text-slate-400 font-mono">({ord.countryName})</span>
                          <span className="px-2 py-0.5 rounded bg-amber-950 text-amber-300 border border-amber-800 text-[10px] font-mono font-bold">
                            👑 {ord.coinsCount} سکه شاهی
                          </span>
                        </div>
                        <div className="text-emerald-400 font-mono font-bold">
                          مبلغ واریزی: {fmt(ord.totalPriceToman)} تومان | آیدی تلگرام: {ord.telegramId}
                        </div>
                        <div className="text-slate-300 bg-[#1e293b] p-2 rounded-lg border border-[#334155]/60 mt-1">
                          📌 اطلاعات فیش: <span className="font-mono text-white">{ord.receiptText}</span>
                        </div>
                      </div>

                      <div className="flex items-center gap-2 w-full md:w-auto shrink-0">
                        {ord.status === 'pending_admin' ? (
                          <>
                            <button
                              onClick={() => handleApproveShahiOrder(ord.id)}
                              className="flex-1 md:flex-none px-4 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs transition shadow flex items-center justify-center gap-1.5"
                            >
                              <CheckCircle2 className="w-3.5 h-3.5" />
                              تایید فیش و شارژ سکه
                            </button>
                            <button
                              onClick={() => handleRejectShahiOrder(ord.id)}
                              className="flex-1 md:flex-none px-4 py-2 rounded-lg bg-red-700 hover:bg-red-800 text-white font-bold text-xs transition shadow flex items-center justify-center gap-1.5"
                            >
                              <XCircle className="w-3.5 h-3.5" />
                              رد سفارش
                            </button>
                          </>
                        ) : (
                          <span
                            className={`px-3 py-1.5 rounded-lg text-xs font-bold ${
                              ord.status === 'approved'
                                ? 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                                : 'bg-red-950 text-red-300 border border-red-800'
                            }`}
                          >
                            {ord.status === 'approved' ? '✅ تایید و واریز شد' : '❌ رد شده'}
                          </span>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* سامانه اختصاصی مدیریت مصالح ساخت مگاپروژه‌ها توسط ادمین */}
            <div className="p-5 rounded-xl bg-[#1e293b] border border-cyan-500/40 shadow-lg space-y-4">
              <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 border-b border-[#334155] pb-4">
                <div>
                  <h3 className="font-black text-base text-cyan-300 flex items-center gap-2">
                    <Hammer className="w-5 h-5 text-cyan-400" />
                    انتخاب و تنظیم مصالح مورد نیاز برای ساخت مگاپروژه‌ها
                  </h3>
                  <p className="text-xs text-slate-300 mt-0.5">
                    ادمین می‌تواند مصالح لازم (فولاد، آهن، مس، سیمان، چوب و نفت خام) و مقادیر هر یک را برای پروژه‌های ملی تعریف کند
                  </p>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-xs text-slate-400">پروژه انتخابی:</span>
                  <select
                    value={selectedAdminProjectKey}
                    onChange={(e) => setSelectedAdminProjectKey(e.target.value)}
                    className="px-3 py-1.5 rounded-lg bg-[#0f172a] border border-cyan-500/50 text-cyan-300 text-xs font-bold outline-none"
                  >
                    <option value="artificial_island">🏝️ جزیره مصنوعی خلیج</option>
                    <option value="national_tower">🗼 برج ملی و نماد حاکمیت</option>
                    <option value="megacity">🏙️ کلان‌شهر هوشمند آینده</option>
                    <option value="moon_mission">🌕 پروژه فضایی فرود بر ماه</option>
                    <option value="space_station">🛰️ ساخت پایگاه فضایی مداری</option>
                  </select>
                </div>
              </div>

              {/* فرم چندگزینه‌ای مصالح پروژه انتخابی */}
              {(() => {
                const projConfig = projectMaterialsConfig[selectedAdminProjectKey] || {
                  name: selectedAdminProjectKey,
                  materials: {},
                };
                const availableMaterials = [
                  { key: 'steel', name: 'فولاد آلیاژی', unit: 'تن', icon: '🏗️' },
                  { key: 'iron', name: 'سنگ آهن فرآوری‌شده', unit: 'تن', icon: '⚙️' },
                  { key: 'copper', name: 'مس صنعتی', unit: 'تن', icon: '🥉' },
                  { key: 'wood', name: 'چوب صنعتی', unit: 'تن', icon: '🪵' },
                  { key: 'cement', name: 'سیمان ساختمانی', unit: 'تن', icon: '🧱' },
                  { key: 'oil', name: 'نفت خام ساختمانی', unit: 'بشکه', icon: '🛢️' },
                ];

                return (
                  <div className="space-y-4">
                    <div className="text-xs text-slate-300">
                      پروژه فعال: <b className="text-white text-sm">{projConfig.name}</b> — تیک مصالح مورد نیاز را بزنید و مقدار را مشخص کنید:
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                      {availableMaterials.map((mat) => {
                        const isRequired = mat.key in (projConfig.materials || {});
                        const currentQty = (projConfig.materials || {})[mat.key] || 0;

                        return (
                          <div
                            key={mat.key}
                            className={`p-3.5 rounded-xl border transition flex flex-col justify-between gap-3 ${
                              isRequired
                                ? 'bg-[#0f172a] border-cyan-500/60 shadow-md'
                                : 'bg-[#0f172a]/60 border-[#334155]'
                            }`}
                          >
                            <div className="flex items-center justify-between">
                              <label className="flex items-center gap-2 cursor-pointer">
                                <input
                                  type="checkbox"
                                  checked={isRequired}
                                  onChange={(e) => {
                                    const nextMap = { ...projConfig.materials };
                                    if (e.target.checked) {
                                      nextMap[mat.key] = currentQty > 0 ? currentQty : 100;
                                    } else {
                                      delete nextMap[mat.key];
                                    }
                                    handleSaveProjectMaterials(selectedAdminProjectKey, nextMap);
                                  }}
                                  className="w-4 h-4 rounded text-cyan-600 focus:ring-cyan-500"
                                />
                                <span className="font-bold text-xs text-white flex items-center gap-1.5">
                                  <span>{mat.icon}</span>
                                  {mat.name}
                                </span>
                              </label>
                              <span className="text-[10px] text-slate-400 font-mono">({mat.unit})</span>
                            </div>

                            {isRequired && (
                              <div className="flex items-center gap-2 pt-1 border-t border-[#334155]/60">
                                <span className="text-[11px] text-slate-400">مقدار لازم:</span>
                                <input
                                  type="number"
                                  value={currentQty}
                                  onChange={(e) => {
                                    const nextQty = Math.max(0, parseInt(e.target.value, 10) || 0);
                                    const nextMap = { ...projConfig.materials, [mat.key]: nextQty };
                                    handleSaveProjectMaterials(selectedAdminProjectKey, nextMap);
                                  }}
                                  className="flex-1 px-2.5 py-1 rounded bg-[#1e293b] border border-[#334155] text-white font-mono text-xs outline-none focus:border-cyan-500"
                                />
                                <span className="text-[11px] text-cyan-400 font-mono">{mat.unit}</span>
                              </div>
                            )}
                          </div>
                        );
                      })}
                    </div>

                    <div className="p-3 rounded-xl bg-[#0f172a] border border-[#334155] flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 text-xs">
                      <div className="text-slate-300">
                        خلاصه مصالح فعال برای «{projConfig.name}»:{' '}
                        <b className="text-cyan-400 font-mono">
                          {Object.entries(projConfig.materials || {})
                            .map(([k, v]) => `${k}: ${fmt(v)}`)
                            .join(' | ') || 'هیچ مصالحی تعیین نشده'}
                        </b>
                      </div>
                      <span className="text-emerald-400 font-bold flex items-center gap-1 shrink-0">
                        <CheckCircle2 className="w-3.5 h-3.5" />
                        ذخیره آنی در پایگاه داده
                      </span>
                    </div>
                  </div>
                );
              })()}
            </div>
          </div>
        )}

        {/* ============================================================ */}
        {/* ۱۱. شبیه‌ساز بات تلگرام با کلیدهای توپر */}
        {/* ============================================================ */}
        {activeTab === 'bot_preview' && (
          <div className="max-w-xl mx-auto space-y-4">
            <div className="p-4 rounded-xl bg-[#1e293b] border border-[#334155] shadow space-y-3">
              <div className="text-xs text-slate-300 leading-relaxed font-sans space-y-1">
                <div className="font-bold text-white text-sm">👥 بخش مردم و خدمات عمومی — ایران 🇮🇷</div>
                <div className="text-slate-400">– – – – – – – – – –</div>
                <div>👨‍👩‍👦 جمعیت فعال: <b>{fmt(userCountry.population)} نفر</b></div>
                <div>⚡ پوشش برق: <b>{fmt(powerCoverage)}%</b> | قطعی: <b>{fmt(powerOutageHours)} ساعت</b></div>
                <div>💧 پوشش آب: <b>{fmt(waterCoverage)}%</b> | قطعی: <b>{fmt(waterOutageHours)} ساعت</b></div>
                <div>⛽ پوشش گاز: <b>{fmt(gasCoverage)}%</b> | قطعی: <b>{fmt(gasOutageHours)} ساعت</b></div>
                <div>😊 رضایت مردم: <b>{fmt(publicSatisfaction)}%</b> | نارضایتی: <b>{fmt(calculatedDissatisfaction)}%</b></div>
              </div>
              <div className="space-y-1.5 pt-2 border-t border-[#334155]">
                <button
                  onClick={() => setActiveTab('people')}
                  className="w-full py-2.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs shadow"
                >
                  🏭 ساخت نیروگاه‌ها و تاسیسات
                </button>
                <button
                  onClick={() => setActiveTab('people')}
                  className="w-full py-2.5 rounded-lg bg-red-700 hover:bg-red-800 text-white font-bold text-xs shadow"
                >
                  🛡 سرکوب و مهار شورش
                </button>
                <button
                  onClick={() => setActiveTab('construction')}
                  className="w-full py-2.5 rounded-lg bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs shadow flex items-center justify-center gap-2"
                >
                  <Hammer className="w-4 h-4" />
                  🏗️ ساخت‌وساز، پژوهش و علم ملی
                </button>
                <button
                  onClick={() => setActiveTab('commander')}
                  className="w-full py-2.5 rounded-lg bg-amber-600 hover:bg-amber-700 text-white font-bold text-xs shadow flex items-center justify-center gap-2"
                >
                  <UserCheck className="w-4 h-4" />
                  🎖️ فرمانده کل و هیئت وزیران (انتصاب افراد)
                </button>
                <button
                  onClick={() => setActiveTab('research_logs')}
                  className="w-full py-2.5 rounded-lg bg-cyan-600 hover:bg-cyan-700 text-white font-bold text-xs shadow flex items-center justify-center gap-2"
                >
                  <FlaskConical className="w-4 h-4" />
                  🔬 دستاوردها و لاگ پژوهش (بدون اسپم پی‌وی)
                </button>
                <button
                  onClick={() => setActiveTab('shahi')}
                  className="w-full py-2.5 rounded-lg bg-purple-600 hover:bg-purple-700 text-white font-bold text-xs shadow flex items-center justify-center gap-2"
                >
                  <Crown className="w-4 h-4" />
                  👑 خرید VIP سکه شاهی با پول واقعی (تومان)
                </button>
                <button
                  onClick={() => setActiveTab('admin_panel')}
                  className="w-full py-2.5 rounded-lg bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs shadow flex items-center justify-center gap-2"
                >
                  <Scale className="w-4 h-4" />
                  🛡️ پنل ادمین (مصالح مگاپروژه و تایید فیش‌ها)
                </button>
              </div>
            </div>
          </div>
        )}

        {/* مودال مدیریت سهامدار عمده ۵۱٪+ (تغییر نام و حوزه فعالیت) */}
        {controllingStock && (
          <div className="fixed inset-0 bg-black/75 backdrop-blur-sm z-50 flex items-center justify-center p-4">
            <div className="bg-[#1e293b] border border-amber-500/50 rounded-2xl p-6 max-w-md w-full shadow-2xl relative space-y-4">
              <div className="flex items-center justify-between border-b border-[#334155] pb-3">
                <h3 className="font-black text-base text-white flex items-center gap-2">
                  <Crown className="w-5 h-5 text-amber-400" />
                  مدیریت هیئت‌مدیره ۵۱٪ — {controllingStock.name}
                </h3>
                <button
                  onClick={() => setControllingStock(null)}
                  className="text-slate-400 hover:text-white"
                >
                  <XCircle className="w-5 h-5" />
                </button>
              </div>

              <p className="text-xs text-slate-300 leading-relaxed">
                کشور شما دارای <b>{fmt(userStockHoldings[controllingStock.key] || 0)} سهم</b> (بیش از ۵۱٪ سهام کل) است و کرسی اکثریت مطلق هیئت‌مدیره را در اختیار دارد. شما می‌توانید نام تجاری شرکت یا حوزه و صنعت فعالیت آن را در سراسر بازارهای بین‌المللی تغییر دهید.
              </p>

              <div className="space-y-3">
                <div>
                  <label className="text-xs text-slate-300 block mb-1">نام جدید شرکت:</label>
                  <input
                    type="text"
                    value={newStockNameInput}
                    onChange={(e) => setNewStockNameInput(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg bg-[#0f172a] border border-[#334155] text-white text-xs outline-none"
                    placeholder="نام تجاری جدید..."
                  />
                </div>

                <div>
                  <label className="text-xs text-slate-300 block mb-1">حوزه و صنعت جدید فعالیت:</label>
                  <input
                    type="text"
                    value={newStockSectorInput}
                    onChange={(e) => setNewStockSectorInput(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg bg-[#0f172a] border border-[#334155] text-white text-xs outline-none"
                    placeholder="مثال: فناوری‌های فضایی و موشکی، پتروشیمی پیشرفته، هوش مصنوعی..."
                  />
                </div>
              </div>

              <div className="flex gap-2 pt-2">
                <button
                  onClick={() => {
                    const cleanName = newStockNameInput.trim();
                    const cleanSector = newStockSectorInput.trim();
                    if (!cleanName || !cleanSector) {
                      showFeedback('نام و صنعت شرکت نباید خالی باشد.', false);
                      return;
                    }
                    setStocksList((prev) =>
                      prev.map((s) =>
                        s.key === controllingStock.key
                          ? { ...s, name: cleanName, sector: cleanSector }
                          : s
                      )
                    );
                    showFeedback(
                      `👑 تصمیم هیئت‌مدیره ۵۱٪ اجرا شد! نام شرکت به «${cleanName}» و صنعت به «${cleanSector}» تغییر یافت.`
                    );
                    setControllingStock(null);
                  }}
                  className="flex-1 py-2.5 rounded-lg bg-amber-500 hover:bg-amber-600 text-slate-950 font-black text-xs transition shadow"
                >
                  ثبت تغییرات رسمی در بورس جهانی
                </button>
                <button
                  onClick={() => setControllingStock(null)}
                  className="px-4 py-2.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-bold transition"
                >
                  انصراف
                </button>
              </div>
            </div>
          </div>
        )}
      </main>
    </div>
  );
}
