'use strict';
const test = require('node:test');
const assert = require('node:assert');
const { parseIdList } = require('../src/config');
const { esc, toLatinDigits, parseNonNegInt } = require('../src/utils/text');
const { requiresPayment, canSeeCountry } = require('../src/services/selectionService');
const { CHANNEL_CATEGORIES, publishToChannel } = require('../src/services/notificationService');
const { config } = require('../src/config');
const { requestActions } = require('../src/bot/keyboards/admin');

test('parseIdList: شناسه مدیران درست پارس می‌شود', () => {
  assert.deepStrictEqual(parseIdList('123, 456;789 123'), [123, 456, 789]);
  assert.deepStrictEqual(parseIdList('abc,,-5,0'), []);
  assert.deepStrictEqual(parseIdList(''), []);
  assert.deepStrictEqual(parseIdList(undefined), []);
});

test('esc: کاراکترهای HTML escape می‌شوند', () => {
  assert.strictEqual(esc('<b>&</b>'), '&lt;b&gt;&amp;&lt;/b&gt;');
});

test('parseNonNegInt: ارقام فارسی و جداکننده', () => {
  assert.strictEqual(toLatinDigits('۱۲۳'), '123');
  assert.strictEqual(parseNonNegInt('۱۵۰٬۰۰۰'), 150000);
  assert.strictEqual(parseNonNegInt('12a'), null);
  assert.strictEqual(parseNonNegInt('-5'), null);
  assert.strictEqual(parseNonNegInt('0'), 0);
});

test('requiresPayment و canSeeCountry', () => {
  assert.strictEqual(requiresPayment({ selectionType: 'free', price: 0 }), false);
  assert.strictEqual(requiresPayment({ selectionType: 'premium', price: 100 }), true);
  assert.strictEqual(requiresPayment({ selectionType: 'exclusive', price: 0 }), false);
  assert.strictEqual(requiresPayment({ selectionType: 'exclusive', price: 5 }), true);
  assert.strictEqual(canSeeCountry({ isActive: true, selectionType: 'free', allowedUserIds: [] }, 1), true);
  assert.strictEqual(canSeeCountry({ isActive: true, selectionType: 'exclusive', allowedUserIds: [2] }, 1), false);
  assert.strictEqual(canSeeCountry({ isActive: true, selectionType: 'exclusive', allowedUserIds: [1] }, 1), true);
  assert.strictEqual(canSeeCountry({ isActive: false, selectionType: 'free', allowedUserIds: [] }, 1), false);
});

test('انتشار در کانال: فقط دسته‌های مجاز بازی', async () => {
  assert.ok(CHANNEL_CATEGORIES.includes('statement'));
  assert.ok(CHANNEL_CATEGORIES.includes('economic_report'));
  await assert.rejects(() => publishToChannel({}, 'spam', 'x'), /نامعتبر/);
});

test('برند پیش‌فرض WORLD WAR FIRE است و ALPHA WAR در پیش‌فرض‌ها نیست', () => {
  assert.strictEqual(config.brandDefaults.channelName, 'WORLD WAR FIRE');
  assert.strictEqual(config.brandDefaults.gameName, 'WORLD WAR FIRE | جنگ جهانی سوم');
  assert.ok(!JSON.stringify(config.brandDefaults).includes('ALPHA'));
});

test('دکمه‌های درخواست: بدون پرداخت تأییدشده، تخصیص نشان داده نمی‌شود', () => {
  const flat = (kb) => JSON.stringify(kb.reply_markup.inline_keyboard);
  const base = { id: 'a'.repeat(20), isOpen: true, status: 'pending' };
  assert.ok(!flat(requestActions({ ...base, paymentStatus: 'submitted' })).includes(':assign'));
  assert.ok(!flat(requestActions({ ...base, paymentStatus: 'awaiting' })).includes(':assign'));
  assert.ok(flat(requestActions({ ...base, paymentStatus: 'approved' })).includes(':assign'));
  assert.ok(flat(requestActions({ ...base, paymentStatus: 'not_required' })).includes(':assign'));
  assert.ok(flat(requestActions({ ...base, paymentStatus: 'submitted' })).includes(':payok'));
});
