'use strict';
// تست رفتار ربات از طریق Telegraf با حمل‌ونقل ساختگی (بدون اتصال به تلگرام) روی Firestore شبیه‌سازی‌شده
const test = require('node:test');
const assert = require('node:assert');
process.env.BOT_TOKEN = '123456:TESTTOKEN';
process.env.ADMIN_IDS = '900';
process.env.ADMIN_PASSWORD = 'correct-horse';
const { FakeFirestore } = require('./fakeFirestore');
const { setDb } = require('../src/db/firestore');
const { Telegram } = require('telegraf');
const { createBot } = require('../src/bot');
const seasonService = require('../src/services/seasonService');
const countryService = require('../src/services/countryService');
const settings = require('../src/services/settingsService');
const userService = require('../src/services/userService');
const ownership = require('../src/services/ownershipService');

let uid = 0;
async function env() {
  setDb(new FakeFirestore());
  settings._clearCache();
  userService._clearCache();
  ownership.invalidateOwnershipCache();
  await seasonService.ensureDefaultSeason();
  const bot = createBot();
  const calls = [];
  bot.botInfo = { id: 1, is_bot: true, username: 'wwf_bot', first_name: 'WWF' };
  // Telegraf برای هر آپدیت یک نمونه Telegram جدید می‌سازد؛ پس حمل‌ونقل را روی prototype جایگزین می‌کنیم
  Telegram.prototype.callApi = async function callApi(method, payload) {
    calls.push({ method, payload });
    if (method === 'sendMessage' || method === 'sendPhoto') return { message_id: ++uid, chat: { id: payload.chat_id } };
    return true;
  };
  const chat = (id) => ({ id, type: 'private' });
  const from = (id) => ({ id, is_bot: false, first_name: `کاربر${id}`, username: `u${id}` });
  const text = (id, t) => bot.handleUpdate({ update_id: ++uid, message: { message_id: ++uid, from: from(id), chat: chat(id), date: 1, text: t, ...(t.startsWith('/') ? { entities: [{ type: 'bot_command', offset: 0, length: t.split(' ')[0].length }] } : {}) } });
  const photo = (id) => bot.handleUpdate({ update_id: ++uid, message: { message_id: ++uid, from: from(id), chat: chat(id), date: 1, photo: [{ file_id: 'small', width: 1, height: 1 }, { file_id: 'FILE123', width: 9, height: 9 }] } });
  const cb = (id, data) => bot.handleUpdate({ update_id: ++uid, callback_query: { id: String(++uid), from: from(id), chat_instance: 'x', data, message: { message_id: ++uid, chat: chat(id), date: 1, text: 'x' } } });
  const sentTo = (id) => calls.filter((c) => (c.method === 'sendMessage' || c.method === 'sendPhoto') && c.payload.chat_id === id);
  const btns = (c) => ((c.payload.reply_markup && c.payload.reply_markup.inline_keyboard) || []).flat();
  const findBtn = (id, prefix) => { for (const c of [...calls].reverse()) { if (c.payload.chat_id === id) { const b = btns(c).find((x) => x.callback_data && x.callback_data.startsWith(prefix)); if (b) return b.callback_data; } } return null; };
  return { bot, calls, text, photo, cb, sentTo, findBtn };
}

test('/start: منوی اصلی با برند WORLD WAR FIRE و دکمه انتخاب کشور', async () => {
  const e = await env();
  await e.text(1, '/start');
  const msgs = e.sentTo(1);
  const welcome = msgs.find((m) => m.payload.text && m.payload.text.includes('WORLD WAR FIRE'));
  assert.ok(welcome);
  assert.ok(!JSON.stringify(e.calls).includes('ALPHA'));
  assert.ok(e.findBtn(1, 'cl:0'));
  assert.ok(!msgs.some((m) => m.payload.text && m.payload.text.includes('/admin'))); // کاربر عادی پیام مدیریتی نمی‌بیند
});

test('کاربر عادی به /admin و دکمه‌های مدیریتی دسترسی ندارد', async () => {
  const e = await env();
  await e.text(1, '/admin');
  assert.strictEqual(e.sentTo(1).length, 0);
  await e.cb(1, 'ad:rql');
  const alert = e.calls.find((c) => c.method === 'answerCallbackQuery' && c.payload.show_alert);
  assert.ok(alert && alert.payload.text.includes('دسترسی'));
  await e.text(900, '/admin');
  assert.ok(e.sentTo(900).some((m) => m.payload.text.includes('پنل مدیریت')));
});

test('جریان کشور رایگان: انتخاب → درخواست → اعلان مدیر → تخصیص → اطلاع بازیکن', async () => {
  const e = await env();
  const c = await countryService.create({ name: 'ایران', flag: '🇮🇷' });
  await e.text(1, '/start');
  await e.cb(1, 'cl:0');
  assert.ok(e.findBtn(1, `cs:${c.id}`));
  await e.cb(1, `cs:${c.id}`);
  await e.cb(1, `cc:${c.id}`);
  const adminMsg = e.sentTo(900).find((m) => m.payload.text && m.payload.text.includes('درخواست انتخاب کشور'));
  assert.ok(adminMsg);
  const assignCb = btnData(adminMsg, ':assign');
  await e.cb(900, assignCb);
  const season = await seasonService.getActiveSeason();
  assert.strictEqual((await ownership.getActiveOwnership(1, season.id)).country.name, 'ایران');
  assert.ok(e.sentTo(1).some((m) => m.payload.text && m.payload.text.includes('تبریک')));
  // کشور اشغال‌شده در فهرست نفر بعد نیست
  await e.text(2, '/start');
  await e.cb(2, 'cl:0');
  assert.ok(!e.findBtn(2, `cs:${c.id}`));
});
function btnData(m, suffix) { return m.payload.reply_markup.inline_keyboard.flat().find((b) => b.callback_data.endsWith(suffix)).callback_data; }

test('جریان کشور ویژه: رسید عکس → تأیید پرداخت → تخصیص؛ بدون کارت پرداخت مسدود است', async () => {
  const e = await env();
  const c = await countryService.create({ name: 'آمریکا', flag: '🇺🇸', selectionType: 'premium', price: 150000 });
  await e.text(5, '/start');
  await e.cb(5, `cc:${c.id}`);
  assert.ok(e.calls.some((x) => JSON.stringify(x.payload).includes('هنوز توسط مدیر تنظیم نشده')));
  await settings.set('paymentCardNumber', '6037997000000000');
  await e.cb(5, `cc:${c.id}`);
  assert.ok(e.calls.some((x) => JSON.stringify(x.payload).includes('6037997000000000')));
  await e.photo(5);
  const adminPhoto = e.sentTo(900).find((m) => m.method === 'sendPhoto');
  assert.ok(adminPhoto && adminPhoto.payload.photo === 'FILE123');
  // تخصیص پیش از تأیید پرداخت وجود ندارد
  assert.ok(!adminPhoto.payload.reply_markup.inline_keyboard.flat().some((b) => b.callback_data.endsWith(':assign')));
  await e.cb(900, btnData(adminPhoto, ':payok'));
  assert.ok(e.sentTo(5).some((m) => m.payload.text && m.payload.text.includes('پرداخت شما تأیید شد')));
  const req = (await require('../src/services/selectionService').listOpenRequests())[0];
  await e.cb(900, `ad:rqa:${req.id}:assign`);
  const season = await seasonService.getActiveSeason();
  assert.ok(await ownership.getActiveOwnership(5, season.id));
});

test('رد درخواست با دلیل از طریق پنل تلگرام', async () => {
  const e = await env();
  const c = await countryService.create({ name: 'ترکیه', flag: '🇹🇷' });
  await e.text(7, '/start');
  await e.cb(7, `cc:${c.id}`);
  const req = (await require('../src/services/selectionService').listOpenRequests())[0];
  await e.cb(900, `ad:rqa:${req.id}:no`);
  await e.text(900, 'اطلاعات ناقص');
  assert.ok(e.sentTo(7).some((m) => m.payload.text && m.payload.text.includes('رد شد') && m.payload.text.includes('اطلاعات ناقص')));
  assert.strictEqual((await userService.getById(900)).flowName, null);
  assert.strictEqual((await require('../src/services/selectionService').listOpenRequests()).length, 0);
});

test('دکمه‌های منوی بخش‌های آینده و سکه', async () => {
  const e = await env();
  await e.text(8, '/start');
  await e.text(8, '🪙 سکه');
  assert.ok(e.sentTo(8).some((m) => m.payload.text.includes('به‌روزرسانی‌های آینده')));
  await e.text(8, '📊 وضعیت کشور من');
  assert.ok(e.sentTo(8).some((m) => m.payload.text.includes('هنوز کشوری ندارید')));
});

test('کاربر مسدود پاسخ بازی نمی‌گیرد', async () => {
  const e = await env();
  await e.text(9, '/start');
  await require('../src/services/userService').ban(9, 'تست');
  const before = e.sentTo(9).length;
  await e.text(9, '/start');
  const after = e.sentTo(9);
  assert.strictEqual(after.length, before + 1);
  assert.ok(after[after.length - 1].payload.text.includes('مسدود'));
});
