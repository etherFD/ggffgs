'use strict';
const test = require('node:test');
const assert = require('node:assert');
process.env.BOT_TOKEN = '123456:TESTTOKEN';
process.env.ADMIN_IDS = '1';
process.env.ADMIN_PASSWORD = 'correct-horse';
const { FakeFirestore } = require('./fakeFirestore');
const { setDb } = require('../src/db/firestore');
const { config } = require('../src/config');
const { createWebApp } = require('../src/web/server');
const userService = require('../src/services/userService');
const seasonService = require('../src/services/seasonService');
const selection = require('../src/services/selectionService');

const sent = [];
const updates = [];
const fakeBot = {
  telegram: {
    sendMessage: async (id, text) => { sent.push({ id, text }); return {}; },
    getWebhookInfo: async () => ({ url: 'https://example.run.app/telegram/secret', pending_update_count: 0 }),
    setWebhook: async (url, opts) => { fakeBot._wh = { url, opts }; return true; },
  },
  handleUpdate: async (u) => { updates.push(u); },
};

async function start() {
  setDb(new FakeFirestore());
  require('../src/services/settingsService')._clearCache();
  await seasonService.ensureDefaultSeason();
  const app = createWebApp({ bot: fakeBot });
  const server = await new Promise((r) => { const s = app.listen(0, '127.0.0.1', () => r(s)); });
  const base = `http://127.0.0.1:${server.address().port}`;
  const call = async (method, path, body, token) => {
    const r = await fetch(base + path, { method, headers: { 'Content-Type': 'application/json', ...(token ? { Authorization: `Bearer ${token}` } : {}) }, body: body === undefined ? undefined : JSON.stringify(body) });
    let json = null; try { json = await r.json(); } catch (_) {}
    return { status: r.status, json };
  };
  return { server, call, base };
}

test('داشبورد: ورود، احراز هویت و جریان کامل درخواست کشور', async () => {
  const { server, call, base } = await start();
  try {
    // صفحه داشبورد و سلامت
    const page = await fetch(base + '/');
    assert.strictEqual(page.status, 200);
    assert.ok((await page.text()).includes('WORLD WAR FIRE'));
    assert.strictEqual((await call('GET', '/health')).json.ok, true);

    // بدون توکن / رمز اشتباه
    assert.strictEqual((await call('GET', '/api/overview')).status, 401);
    assert.strictEqual((await call('GET', '/api/overview', undefined, 'fake.token')).status, 401);
    assert.strictEqual((await call('POST', '/api/login', { password: 'bad' })).status, 401);
    const ok = await call('POST', '/api/login', { password: 'correct-horse' });
    assert.strictEqual(ok.status, 200);
    const t = ok.json.token;

    // کشور اولیه و ساخت کشور
    assert.strictEqual((await call('POST', '/api/countries/seed', {}, t)).json.created, 12);
    const made = await call('POST', '/api/countries', { name: 'تست', flag: '🇹🇪', selectionType: 'free' }, t);
    assert.strictEqual(made.status, 200);
    const bad = await call('POST', '/api/countries', { name: '', selectionType: 'x' }, t);
    assert.strictEqual(bad.status, 400);

    // بازیکن درخواست می‌دهد
    const user = await userService.touchUser({ id: 555, first_name: 'علی', username: 'ali' });
    const { request } = await selection.createRequest({ user, countryId: made.json.id });
    const reqs = await call('GET', '/api/requests', undefined, t);
    assert.strictEqual(reqs.json.length, 1);
    assert.ok(!JSON.stringify(reqs.json).includes('fileId'));

    // تأیید و تخصیص از داشبورد
    const as = await call('POST', `/api/requests/${request.id}/assign`, {}, t);
    assert.strictEqual(as.status, 200);
    assert.ok(sent.some((m) => m.id === 555 && m.text.includes('تبریک')));
    assert.strictEqual((await call('POST', `/api/requests/${request.id}/assign`, {}, t)).status, 400); // دوباره ممکن نیست

    const countries = await call('GET', '/api/countries', undefined, t);
    assert.strictEqual(countries.json.find((c) => c.id === made.json.id).owner.gameId, user.gameId);
    const players = await call('GET', '/api/players?q=علی', undefined, t);
    assert.strictEqual(players.json[0].country.name, 'تست');

    // مسدودسازی و تنظیمات
    assert.strictEqual((await call('POST', '/api/players/555/ban', { reason: 'تست' }, t)).status, 200);
    assert.strictEqual((await call('POST', '/api/players/1/ban', {}, t)).status, 400); // ادمین
    assert.strictEqual((await call('PUT', '/api/settings', { key: 'channelName', value: 'کانال من' }, t)).status, 200);
    assert.strictEqual((await call('GET', '/api/overview', undefined, t)).json.brand.channelName, 'کانال من');

    // حسابرسی با منبع web
    const audit = await call('GET', '/api/audit', undefined, t);
    assert.ok(audit.json.length >= 4 && audit.json.every((a) => a.via === 'web'));

    // وب‌هوک
    assert.strictEqual((await call('POST', '/api/webhook', { baseUrl: 'http://insecure.example' }, t)).status, 400);
    const wh = await call('POST', '/api/webhook', { baseUrl: 'https://example.run.app/' }, t);
    assert.strictEqual(wh.status, 200);
    assert.ok(fakeBot._wh.url.endsWith(`/telegram/${config.webhookPath}`));
    assert.strictEqual(fakeBot._wh.opts.secret_token, config.webhookSecret);
    assert.ok(!JSON.stringify((await call('GET', '/api/webhook', undefined, t)).json).includes('secret'));
  } finally { server.close(); }
});

test('وب‌هوک تلگرام: فقط با توکن مخفی درست پردازش می‌شود', async () => {
  const { server, base } = await start();
  try {
    updates.length = 0;
    const url = `${base}/telegram/${config.webhookPath}`;
    const post = (headers) => fetch(url, { method: 'POST', headers: { 'Content-Type': 'application/json', ...headers }, body: JSON.stringify({ update_id: 1 }) });
    assert.strictEqual((await post({})).status, 401);
    assert.strictEqual((await post({ 'x-telegram-bot-api-secret-token': 'wrong' })).status, 401);
    assert.strictEqual((await fetch(`${base}/telegram/wrongpath`, { method: 'POST' })).status, 404);
    assert.strictEqual((await post({ 'x-telegram-bot-api-secret-token': config.webhookSecret })).status, 200);
    assert.strictEqual(updates.length, 1);
  } finally { server.close(); }
});

test('قفل ورود پس از ۵ تلاش ناموفق', async () => {
  const { server, call } = await start();
  try {
    let last;
    for (let i = 0; i < 6; i++) last = await call('POST', '/api/login', { password: 'x' + i });
    assert.strictEqual(last.status, 429);
    assert.strictEqual((await call('POST', '/api/login', { password: 'correct-horse' })).status, 429);
  } finally { server.close(); }
});
