'use strict';
const test = require('node:test');
const assert = require('node:assert');
process.env.ADMIN_IDS = '1';
const { FakeFirestore } = require('./fakeFirestore');
const { setDb, col } = require('../src/db/firestore');

function freshDb() {
  setDb(new FakeFirestore());
  require('../src/services/settingsService')._clearCache();
  require('../src/services/userService')._clearCache();
  require('../src/services/ownershipService').invalidateOwnershipCache();
}
const userService = require('../src/services/userService');
const countryService = require('../src/services/countryService');
const seasonService = require('../src/services/seasonService');
const selection = require('../src/services/selectionService');
const ownership = require('../src/services/ownershipService');
const actions = require('../src/services/adminActions');

const fakeTelegram = () => { const sent = []; return { sent, sendMessage: async (id, text) => { sent.push({ id, text }); return { message_id: 1 }; } }; };
const from = (id, name = `u${id}`) => ({ id, first_name: name, username: name });

async function setup() {
  freshDb();
  await seasonService.ensureDefaultSeason();
  const season = await seasonService.getActiveSeason();
  const a = await userService.touchUser(from(101));
  const b = await userService.touchUser(from(102));
  const free = await countryService.create({ name: 'آزاد', flag: '🏳️' });
  const prem = await countryService.create({ name: 'ویژه', selectionType: 'premium', price: 5000 });
  return { season, a, b, free, prem };
}

test('کاربر جدید شناسه بازی یکتا و پیوسته می‌گیرد، حتی با ورود هم‌زمان', async () => {
  freshDb();
  const users = await Promise.all([201, 202, 203, 204].map((i) => userService.touchUser(from(i))));
  const ids = users.map((u) => u.gameId).sort();
  assert.deepStrictEqual(ids, [1001, 1002, 1003, 1004]);
  const again = await userService.touchUser(from(201));
  assert.strictEqual(again.gameId, users[0].gameId);
});

test('فقط یک سیزن فعال می‌تواند وجود داشته باشد', async () => {
  freshDb();
  const s1 = await seasonService.ensureDefaultSeason();
  assert.strictEqual(s1.number, 1);
  await assert.rejects(() => seasonService.createSeason({ name: 'x' }), /سیزن فعال/);
  const results = await Promise.allSettled([seasonService.createSeason({ name: 'a' }), seasonService.createSeason({ name: 'b' })]);
  assert.ok(results.every((r) => r.status === 'rejected'));
});

test('seed کشورها قابل اجرای مجدد است', async () => {
  freshDb();
  const r1 = await countryService.seedDefaults();
  const r2 = await countryService.seedDefaults();
  assert.strictEqual(r1.created, r1.total);
  assert.strictEqual(r2.created, 0);
});

test('انتخاب رایگان: ثبت درخواست، تأیید و تخصیص؛ تأیید دوباره ممکن نیست', async () => {
  const { season, a, free } = await setup();
  const { request, paid } = await selection.createRequest({ user: a, countryId: free.id });
  assert.strictEqual(paid, false);
  await assert.rejects(() => selection.createRequest({ user: a, countryId: free.id }), /درخواست باز/);
  const done = await selection.approveAndAssign({ requestId: request.id, adminTelegramId: 1 });
  assert.strictEqual(done.status, 'approved');
  const own = await ownership.getActiveOwnership(a.telegramId, season.id);
  assert.strictEqual(own.country.name, 'آزاد');
  await assert.rejects(() => selection.approveAndAssign({ requestId: request.id, adminTelegramId: 1 }), /قابل تخصیص نیست/);
  assert.strictEqual((await ownership.ownedCountryIds(season.id)).length, 1);
  assert.strictEqual(await selection.getOpenRequest(a.telegramId), null);
});

test('تخصیص هم‌زمان یک کشور به دو بازیکن: فقط یکی موفق می‌شود', async () => {
  const { season, a, b, free } = await setup();
  const ra = (await selection.createRequest({ user: a, countryId: free.id })).request;
  const rb = (await selection.createRequest({ user: b, countryId: free.id })).request;
  const res = await Promise.allSettled([
    selection.approveAndAssign({ requestId: ra.id, adminTelegramId: 1 }),
    selection.approveAndAssign({ requestId: rb.id, adminTelegramId: 1 }),
  ]);
  assert.strictEqual(res.filter((r) => r.status === 'fulfilled').length, 1);
  assert.strictEqual((await ownership.ownedCountryIds(season.id)).length, 1);
  const loser = res.find((r) => r.status === 'rejected');
  assert.match(loser.reason.message, /قبلاً به بازیکن دیگری/);
});

test('کشور ویژه: بدون تأیید پرداخت تخصیص ممکن نیست؛ رسید فقط یک بار؛ جریان کامل', async () => {
  const { season, b, prem } = await setup();
  const { request, paid } = await selection.createRequest({ user: b, countryId: prem.id });
  assert.strictEqual(paid, true);
  assert.strictEqual(request.price, 5000);
  await assert.rejects(() => selection.approveAndAssign({ requestId: request.id, adminTelegramId: 1 }));
  await assert.rejects(() => selection.approvePayment({ requestId: request.id, adminTelegramId: 1 }), /در انتظار بررسی/);
  const receipt = { type: 'text', text: 'tx-123' };
  await selection.submitReceipt({ requestId: request.id, userTelegramId: b.telegramId, receipt });
  await assert.rejects(() => selection.submitReceipt({ requestId: request.id, userTelegramId: b.telegramId, receipt }));
  await assert.rejects(() => selection.approveAndAssign({ requestId: request.id, adminTelegramId: 1 })); // رسید ≠ تأیید پرداخت
  await selection.approvePayment({ requestId: request.id, adminTelegramId: 1 });
  await assert.rejects(() => selection.approvePayment({ requestId: request.id, adminTelegramId: 1 })); // دوبار تأیید
  await selection.approveAndAssign({ requestId: request.id, adminTelegramId: 1 });
  assert.ok(await ownership.getActiveOwnership(b.telegramId, season.id));
  assert.strictEqual((await selection.getPayment(request.id)).status, 'approved');
});

test('رسید توسط بازیکن دیگر پذیرفته نمی‌شود', async () => {
  const { a, b, prem } = await setup();
  const { request } = await selection.createRequest({ user: b, countryId: prem.id });
  await assert.rejects(() => selection.submitReceipt({ requestId: request.id, userTelegramId: a.telegramId, receipt: { type: 'text', text: 'x' } }));
});

test('رد پرداخت/لغو، قفل را آزاد می‌کند و بازیکن می‌تواند دوباره درخواست دهد', async () => {
  const { b, prem, free } = await setup();
  const { request } = await selection.createRequest({ user: b, countryId: prem.id });
  await selection.submitReceipt({ requestId: request.id, userTelegramId: b.telegramId, receipt: { type: 'text', text: 'tx' } });
  await selection.rejectPayment({ requestId: request.id, adminTelegramId: 1, note: 'نامعتبر' });
  const r2 = await selection.createRequest({ user: b, countryId: free.id });
  await selection.cancelByUser({ requestId: r2.request.id, userTelegramId: b.telegramId });
  await selection.createRequest({ user: b, countryId: free.id });
});

test('کشور اختصاصی فقط برای کاربران مجاز', async () => {
  const { a, b } = await setup();
  const ex = await countryService.create({ name: 'اختصاصی', selectionType: 'exclusive', allowedUserIds: [a.telegramId] });
  await assert.rejects(() => selection.createRequest({ user: b, countryId: ex.id }), /در دسترس نیست/);
  const r = await selection.createRequest({ user: a, countryId: ex.id });
  assert.strictEqual(r.paid, false);
});

test('کاربر مسدود درخواست نمی‌دهد و تخصیص به او رد می‌شود', async () => {
  const { season, b, free } = await setup();
  const tg = fakeTelegram();
  await actions.banPlayer(tg, b.telegramId, 'تست', 1, 'web');
  const banned = await userService.getById(b.telegramId);
  await assert.rejects(() => selection.createRequest({ user: banned, countryId: free.id }), /مسدود/);
  await assert.rejects(() => ownership.assignCountry({ userTelegramId: b.telegramId, countryId: free.id, seasonId: season.id }), /مسدود/);
  await assert.rejects(() => actions.banPlayer(tg, 1, 'x', 1), /مدیران/);
});

test('تخصیص دستی درخواست باز را می‌بندد؛ آزادسازی مالکیت را برمی‌دارد', async () => {
  const { season, a, free } = await setup();
  const tg = fakeTelegram();
  await selection.createRequest({ user: a, countryId: free.id });
  await actions.manualAssign(tg, free.id, String(a.gameId), 1, 'web');
  assert.strictEqual(await selection.getOpenRequest(a.telegramId), null);
  assert.ok(await ownership.getActiveOwnership(a.telegramId, season.id));
  await assert.rejects(() => actions.updateCountry(1, free.id, { isActive: false }), /آزاد کنید/);
  await actions.releaseCountry(tg, free.id, 1, 'web');
  assert.strictEqual(await ownership.getActiveOwnership(a.telegramId, season.id), null);
  await actions.updateCountry(1, free.id, { isActive: false });
  assert.ok(tg.sent.length >= 2); // اطلاع به بازیکن
});

test('تنظیمات: اعتبارسنجی، شماره کارت در حسابرسی ثبت نمی‌شود', async () => {
  freshDb();
  const tg = fakeTelegram();
  await assert.rejects(() => actions.setSetting(tg, 'paymentCardNumber', '123', 1), /معتبر/);
  await actions.setSetting(tg, 'paymentCardNumber', '۶۲۷۳ ۵۳۳۱ ۲۳۴۵ ۶۷۸۹', 1, 'web');
  const view = await actions.getSettingsView();
  assert.strictEqual(view.paymentCardNumber.value, '6273533123456789');
  const logs = await require('../src/services/auditService').recent();
  assert.ok(!JSON.stringify(logs).includes('6273533123456789'));
  assert.strictEqual(view.channelName.value, 'WORLD WAR FIRE');
  assert.strictEqual(view.countryCooldownHours.value, 24);
  await assert.rejects(() => actions.setSetting(tg, 'channelId', 'bad id', 1), /قالب/);
  await assert.rejects(() => actions.setSetting(tg, 'nope', 'x', 1), /نامعتبر/);
});

test('اطلاعیه سراسری فقط برای بازیکنان فعال ارسال می‌شود', async () => {
  const { a, b } = await setup();
  const tg = fakeTelegram();
  await actions.banPlayer(tg, b.telegramId, null, 1);
  tg.sent.length = 0;
  const r = await actions.broadcast(tg, 'سلام', 1, 'web');
  assert.strictEqual(r.ok, 1);
  assert.strictEqual(tg.sent[0].id, a.telegramId);
  assert.strictEqual(r.channel, 'skipped'); // کانال تنظیم نشده
});
