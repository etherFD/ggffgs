'use strict';
const test = require('node:test');
const assert = require('node:assert');
process.env.ADMIN_IDS = '1';

const { FakeFirestore } = require('./fakeFirestore');
const { setDb, col } = require('../src/db/firestore');

function freshDb() {
  setDb(new FakeFirestore());
  require('../src/services/settingsService')._clearCache();
  require('../src/services/userService')._clearCache();
  require('../src/services/ownershipService').invalidateOwnershipCache();
}

const userService = require('../src/services/userService');
const countryService = require('../src/services/countryService');
const seasonService = require('../src/services/seasonService');
const gameService = require('../src/services/gameService');
const straitService = require('../src/services/straitService');
const unService = require('../src/services/unService');
const tutorialService = require('../src/services/tutorialService');
const adminActions = require('../src/services/adminActions');
const settings = require('../src/services/settingsService');
const warService = require('../src/services/warService');

const from = (id, name = `u${id}`) => ({ id, first_name: name, username: name });

async function setupGame() {
  freshDb();
  await seasonService.ensureDefaultSeason();
  const season = await seasonService.getActiveSeason();
  const user1 = await userService.touchUser(from(101));
  const user2 = await userService.touchUser(from(102));

  const country1 = await countryService.create({ name: 'ایران', flag: '🇮🇷' });
  const country2 = await countryService.create({ name: 'عراق', flag: '🇮🇶' });

  await gameService.getCountryState(country1.id, season.id);
  await gameService.getCountryState(country2.id, season.id);

  return { season, user1, user2, country1, country2 };
}

test('۱. ساخت شرکت و مگاپروژه با کسر اتمیک بودجه و مصالح (شامل نفت خام)', async () => {
  const { season, country1 } = await setupGame();

  await gameService.updateCountryState(country1.id, season.id, {
    treasury: 1000000000,
    oil: 5000,
    inventory: {
      steel: 500,
      iron: 400,
      copper: 200,
      wood: 300,
      cement: 300,
    },
  });

  const entRes = await gameService.createCustomEnterprise(country1.id, season.id, {
    category: 'tech',
    name: 'صنایع الکترونیک البرز',
    logo: '⚡',
  });

  assert.strictEqual(entRes.enterprise.name, 'صنایع الکترونیک البرز');
  assert.strictEqual(entRes.enterprise.tier, 1);
  assert.ok(entRes.enterprise.cycleIncome > 0);

  const stateAfterEnt = await gameService.getCountryState(country1.id, season.id);
  assert.strictEqual(stateAfterEnt.inventory.copper, 100);
  assert.strictEqual(stateAfterEnt.inventory.steel, 400);

  const megaRes = await gameService.buildMegaproject(country1.id, season.id, 'mega_refinery');
  assert.strictEqual(megaRes.project.name, 'پالایشگاه فوق‌پیشرفته و زنجیره پتروشیمی ملی');

  const stateAfterMega = await gameService.getCountryState(country1.id, season.id);
  assert.ok(stateAfterMega.megaprojects.includes('mega_refinery'));
  assert.strictEqual(stateAfterMega.oil, 4500);
  assert.strictEqual(stateAfterMega.inventory.steel, 280);
  assert.strictEqual(stateAfterMega.inventory.cement, 160);

  await assert.rejects(
    () => gameService.buildMegaproject(country1.id, season.id, 'mega_refinery'),
    /پیش‌تر در کشور احداث شده است/
  );
});

test('۲. اعتبارسنجی و کسر قطعی تجهیزات و نفت در لحظه صدور نهایی فرمان حمله', async () => {
  const { season, country1 } = await setupGame();

  await gameService.updateCountryState(country1.id, season.id, {
    oil: 2000,
    groundUnits: { tank: 50, infantry: 1000 },
    airUnits: { f16: 10 },
  });

  const selectedUnits = [
    { id: 'tank', name: 'تانک', count: 10, category: 'tank' },
    { id: 'f16', name: 'جنگنده F-16', count: 2, category: 'fighter' },
  ];

  const deductRes = await gameService.validateAndDeductAttackUnits(country1.id, season.id, selectedUnits);
  assert.ok(deductRes.operationOil > 0);

  const stateAfter = await gameService.getCountryState(country1.id, season.id);
  assert.strictEqual(stateAfter.groundUnits.tank, 40);
  assert.strictEqual(stateAfter.airUnits.f16, 8);

  await assert.rejects(
    () => gameService.validateAndDeductAttackUnits(country1.id, season.id, [
      { id: 'tank', name: 'تانک', count: 100, category: 'tank' },
    ]),
    /کافی نیست/
  );
});

test('۳. ماموریت‌های روزانه با پیشرفت خودکار و واریز آنی بدون تکرار', async () => {
  const { season, user1, country1 } = await setupGame();

  const stateBefore = await gameService.getCountryState(country1.id, season.id);
  const initialTreasury = stateBefore.treasury;
  const initialShahi = stateBefore.shahiCoins || 0;

  const claimRes = await gameService.recordMissionProgressAndAutoClaim(
    user1.telegramId,
    country1.id,
    season.id,
    'military_readiness',
    1
  );

  assert.ok(claimRes);
  assert.strictEqual(claimRes.completed, true);
  assert.strictEqual(claimRes.claimed, true);

  const stateAfter = await gameService.getCountryState(country1.id, season.id);
  assert.strictEqual(stateAfter.treasury, initialTreasury + claimRes.rewardCash);
  assert.strictEqual(stateAfter.shahiCoins, initialShahi + claimRes.rewardShahi);

  const secondTry = await gameService.recordMissionProgressAndAutoClaim(
    user1.telegramId,
    country1.id,
    season.id,
    'military_readiness',
    1
  );
  assert.strictEqual(secondTry, null);

  const stateFinal = await gameService.getCountryState(country1.id, season.id);
  assert.strictEqual(stateFinal.treasury, stateAfter.treasury);
});

test('۴. آموزش تعاملی ۱۰ مرحله‌ای، پیشرفت معتبر و پاداش شروع بازی', async () => {
  const { season, user1, country1 } = await setupGame();

  const initialTut = await tutorialService.getPlayerTutorial(user1.telegramId);
  assert.strictEqual(initialTut.completedSteps.length, 0);

  const s1 = await tutorialService.completeTutorialStep(user1.telegramId, country1.id, season.id, 1);
  assert.strictEqual(s1.valid, true);

  const tutRef = col('user_tutorials').doc(String(user1.telegramId));
  await tutRef.update({
    completedSteps: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10],
  });

  const stateBeforeReward = await gameService.getCountryState(country1.id, season.id);
  const rewardRes = await tutorialService.claimTutorialReward(user1.telegramId, country1.id, season.id);

  assert.strictEqual(rewardRes.cashReward, 100000000);
  assert.strictEqual(rewardRes.shahiReward, 5);

  const stateAfterReward = await gameService.getCountryState(country1.id, season.id);
  assert.strictEqual(stateAfterReward.treasury, stateBeforeReward.treasury + 100000000);
  assert.strictEqual(stateAfterReward.shahiCoins, (stateBeforeReward.shahiCoins || 0) + 5);

  await assert.rejects(
    () => tutorialService.claimTutorialReward(user1.telegramId, country1.id, season.id),
    /قبلاً دریافت شده است/
  );
});

test('۵. تنگه‌های استراتژیک، محاسبه توان دریایی و شرط حداقل ۲ برابری مدافع', async () => {
  const { season, country1, country2 } = await setupGame();

  await gameService.updateCountryState(country1.id, season.id, {
    treasury: 1000000000,
    navalUnits: { warship: 5 },
  });

  const claimRes = await straitService.claimStrait({
    countryId: country1.id,
    seasonId: season.id,
    straitId: 'hormuz',
  });
  assert.strictEqual(claimRes.strait.ownerCountryId, String(country1.id));

  await gameService.updateCountryState(country2.id, season.id, {
    treasury: 1000000000,
    navalUnits: { warship: 5 },
  });

  await assert.rejects(
    () => straitService.claimStrait({
      countryId: country2.id,
      seasonId: season.id,
      straitId: 'hormuz',
    }),
    /حداقل ۲ برابر/
  );

  await gameService.updateCountryState(country2.id, season.id, {
    navalUnits: { warship: 12 },
  });

  const conquestRes = await straitService.claimStrait({
    countryId: country2.id,
    seasonId: season.id,
    straitId: 'hormuz',
  });
  assert.strictEqual(conquestRes.conquered, true);
  assert.strictEqual(conquestRes.strait.ownerCountryId, String(country2.id));
});

test('۶. درخت غنی‌سازی هسته‌ای و مسدودیت ارتقا تا زمان اخذ مجوز سازمان ملل', async () => {
  const { season, country1 } = await setupGame();

  await gameService.updateCountryState(country1.id, season.id, {
    treasury: 2000000000,
  });

  await assert.rejects(
    () => gameService.upgradeNuclearTier(country1.id, season.id, 20),
    /مجوز رسمی سازمان ملل/
  );

  const session = await unService.createVoteSession({
    seasonId: season.id,
    initiatorCountryId: country1.id,
    type: 'nuclear_license',
    title: 'مجوز غنی‌سازی ۲۰٪',
    description: 'درخواست مجوز',
    metadata: { targetTier: 20 },
  });

  await unService.castVote({ voteId: session.id, countryId: country1.id, choice: 'yes', userId: 101 });
  await unService.resolveSession(session.id);

  const upRes = await gameService.upgradeNuclearTier(country1.id, season.id, 20);
  assert.strictEqual(upRes.tier, 20);

  const stateAfter = await gameService.getCountryState(country1.id, season.id);
  assert.strictEqual(stateAfter.nuclearTier, 20);
});

test('۷. اعلان جنگ غیرمجاز، مجمع عمومی سازمان ملل، محکومیت و تحریم ۱ ساعته با مصونیت متقابل', async () => {
  const { season, country1, country2, user1 } = await setupGame();

  const warRes = await warService.declareWar({
    attackerCountryId: country1.id,
    defenderCountryId: country2.id,
    seasonId: season.id,
    type: 'unauthorized',
    reason: 'تهاجم مرزی فوری',
    userId: user1.telegramId,
  });

  assert.strictEqual(warRes.status, 'un_investigation');
  assert.ok(warRes.unVoteSessionId);

  await unService.castVote({ voteId: warRes.unVoteSessionId, countryId: country2.id, choice: 'yes', userId: 102 });
  await unService.resolveSession(warRes.unVoteSessionId);

  const sanctionStatus = await unService.checkCountrySanction(country1.id, season.id);
  assert.strictEqual(sanctionStatus.isSanctioned, true);
  assert.ok(sanctionStatus.remainingMinutes > 0);

  await assert.rejects(
    () => warService.declareWar({
      attackerCountryId: country1.id,
      defenderCountryId: country2.id,
      seasonId: season.id,
      type: 'authorized',
      reason: 'تلاش مجدد برای جنگ',
      userId: user1.telegramId,
    }),
    /آتش‌بس و تحریم نظامی/
  );

  await assert.rejects(
    () => warService.declareWar({
      attackerCountryId: country2.id,
      defenderCountryId: country1.id,
      seasonId: season.id,
      type: 'authorized',
      reason: 'ضدحمله به کشور متجاوز',
      userId: 102,
    }),
    /مصونیت و آتش‌بس سازمان ملل/
  );
});

test('۸. کنترل‌های مدیریتی انجماد واریزها، فاصله چرخه‌ها و ریست کامل دارایی‌های بازیکن', async () => {
  const { season, country1 } = await setupGame();

  const freeze1 = await adminActions.togglePayoutFreeze(1, true, 'test');
  assert.strictEqual(freeze1.frozen, true);
  assert.strictEqual(await settings.isPayoutsFrozen(), true);

  const freeze2 = await adminActions.togglePayoutFreeze(1, false, 'test');
  assert.strictEqual(freeze2.frozen, false);
  assert.strictEqual(await settings.isPayoutsFrozen(), false);

  const intervalRes = await adminActions.setPayoutIntervalMinutes(1, 15, 'test');
  assert.strictEqual(intervalRes.intervalMinutes, 15);
  assert.strictEqual(await settings.getPayoutInterval(), 15);

  await gameService.updateCountryState(country1.id, season.id, {
    treasury: 9999999999,
    shahiCoins: 50,
    megaprojects: ['mega_refinery'],
    inventory: { steel: 500 },
  });

  const resetRes = await adminActions.resetPlayerAssets(null, country1.id, 'تخلف تجاری در بازی', 1, 'test');
  assert.strictEqual(resetRes.country.id, country1.id);

  const stateAfterReset = await gameService.getCountryState(country1.id, season.id);
  assert.strictEqual(stateAfterReset.treasury, 400000000);
  assert.strictEqual(stateAfterReset.shahiCoins, 0);
  assert.deepStrictEqual(stateAfterReset.megaprojects, []);
  assert.deepStrictEqual(stateAfterReset.inventory, {});
});
