'use strict';
// پیاده‌سازی درون‌حافظه‌ای حداقلی از API فایراستور برای تست منطق سرویس‌ها.
// تراکنش‌ها سریالی اجرا می‌شوند (معادل ایزولاسیون serializable) و قانون
// «همه خواندن‌ها قبل از نوشتن‌ها» مثل فایراستور واقعی اعمال می‌شود.
const clone = (v) => structuredClone(v);

class Snap {
  constructor(ref, data) { this.ref = ref; this.id = ref.id; this._d = data; this.exists = data !== undefined; }
  data() { return this._d === undefined ? undefined : clone(this._d); }
}

class DocRef {
  constructor(db, colName, id) { this.db = db; this.colName = colName; this.id = id; }
  _store() { return this.db._col(this.colName); }
  async get() { return new Snap(this, this._store().get(this.id)); }
  async set(data, opts) { this._apply({ op: 'set', ref: this, data, opts }); }
  async create(data) { this._apply({ op: 'create', ref: this, data }); }
  async update(data) { this._apply({ op: 'update', ref: this, data }); }
  async delete() { this._apply({ op: 'delete', ref: this }); }
  _apply(o) { this.db._applyOp(o); }
}

class Query {
  constructor(db, colName, filters = [], order = null, lim = null) { this.db = db; this.colName = colName; this.filters = filters; this.order = order; this.lim = lim; }
  where(f, op, v) { return new Query(this.db, this.colName, [...this.filters, [f, op, v]], this.order, this.lim); }
  orderBy(f, dir = 'asc') { return new Query(this.db, this.colName, this.filters, [f, dir], this.lim); }
  limit(n) { return new Query(this.db, this.colName, this.filters, this.order, n); }
  async get() {
    let rows = [...this.db._col(this.colName).entries()].filter(([, d]) => this.filters.every(([f, op, v]) => {
      const x = d[f];
      if (op === '==') return x === v || (x instanceof Date && v instanceof Date && +x === +v);
      if (op === 'in') return v.includes(x);
      if (op === 'array-contains') return Array.isArray(x) && x.includes(v);
      throw new Error(`op ${op} not supported in fake`);
    }));
    if (this.order) {
      const [f, dir] = this.order;
      rows.sort(([, a], [, b]) => (a[f] > b[f] ? 1 : a[f] < b[f] ? -1 : 0) * (dir === 'desc' ? -1 : 1));
    }
    if (this.lim != null) rows = rows.slice(0, this.lim);
    const docs = rows.map(([id, d]) => new Snap(new DocRef(this.db, this.colName, id), d));
    return { docs, empty: docs.length === 0, size: docs.length };
  }
}

class Col extends Query {
  constructor(db, name) { super(db, name); }
  doc(id) { return new DocRef(this.db, this.colName, id || `auto${(++this.db._auto).toString().padStart(15, '0')}x`); }
  async add(data) { const r = this.doc(); await r.create(data); return r; }
}

class Tx {
  constructor() { this.ops = []; }
  async get(ref) {
    if (this.ops.length) throw new Error('FAKE: همه خواندن‌ها باید قبل از نوشتن‌ها باشند (قانون فایراستور)');
    return ref.get();
  }
  set(ref, data, opts) { this.ops.push({ op: 'set', ref, data, opts }); }
  create(ref, data) { this.ops.push({ op: 'create', ref, data }); }
  update(ref, data) { this.ops.push({ op: 'update', ref, data }); }
  delete(ref) { this.ops.push({ op: 'delete', ref }); }
}

class FakeFirestore {
  constructor() { this.data = new Map(); this._auto = 0; this._lock = Promise.resolve(); }
  _col(n) { if (!this.data.has(n)) this.data.set(n, new Map()); return this.data.get(n); }
  collection(n) { return new Col(this, n); }
  _applyOp({ op, ref, data, opts }) {
    const s = ref._store();
    const has = s.has(ref.id);
    if (op === 'create') { if (has) { const e = new Error('ALREADY_EXISTS'); e.code = 6; throw e; } s.set(ref.id, clone(data)); }
    else if (op === 'set') s.set(ref.id, opts && opts.merge ? { ...(s.get(ref.id) || {}), ...clone(data) } : clone(data));
    else if (op === 'update') { if (!has) { const e = new Error('NOT_FOUND'); e.code = 5; throw e; } s.set(ref.id, { ...s.get(ref.id), ...clone(data) }); }
    else if (op === 'delete') s.delete(ref.id);
  }
  runTransaction(fn) {
    const run = async () => {
      const tx = new Tx();
      const result = await fn(tx);
      // اعتبارسنجی همه عملیات پیش از اعمال (اتمیک)
      const snapshot = new Map([...this.data.entries()].map(([k, v]) => [k, new Map(v)]));
      try { for (const o of tx.ops) this._applyOp(o); } catch (e) { this.data = snapshot; throw e; }
      return result;
    };
    const p = this._lock.then(run);
    this._lock = p.catch(() => {});
    return p;
  }
}
module.exports = { FakeFirestore };
