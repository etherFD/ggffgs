'use strict';
// ارسال یا ویرایش پیام HTML (در صورت ناموفق بودن ویرایش، پیام جدید ارسال می‌شود)
async function render(ctx, text, keyboard) {
  const extra = { parse_mode: 'HTML', disable_web_page_preview: true, ...(keyboard || {}) };
  if (ctx.callbackQuery && ctx.callbackQuery.message && !ctx.callbackQuery.message.photo) {
    try {
      await ctx.editMessageText(text, extra);
      return;
    } catch (err) {
      if (err && /message is not modified/i.test(err.description || err.message || '')) return;
    }
  }
  await ctx.reply(text, extra);
}

async function answer(ctx, text, alert = false) {
  if (ctx.callbackQuery) await ctx.answerCbQuery(text, { show_alert: alert }).catch(() => {});
}

module.exports = { render, answer };
