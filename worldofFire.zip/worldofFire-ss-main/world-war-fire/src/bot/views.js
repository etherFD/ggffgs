'use strict';
const { esc, fmtNum, fmtDate, shortId } = require('../utils/text');

const TYPE_FA = { free: 'رایگان', premium: 'ویژه 💎', exclusive: 'اختصاصی 🔒' };
const REQ_STATUS_FA = {
  pending: 'در انتظار بررسی',
  processing: 'در حال پردازش',
  approved: 'تأییدشده',
  rejected: 'ردشده',
  cancelled: 'لغوشده',
};
const PAY_STATUS_FA = {
  not_required: 'نیاز ندارد',
  awaiting: 'منتظر ارسال رسید',
  submitted: 'در انتظار بررسی پرداخت',
  approved: 'تأییدشده',
  rejected: 'ردشده',
};
const GOV_FA = {
  republic: 'جمهوری', monarchy: 'پادشاهی', dictatorship: 'دیکتاتوری', parliamentary: 'جمهوری پارلمانی',
  constitutional: 'پادشاهی مشروطه', military: 'حکومت نظامی', federal: 'حکومت فدرال', fascism: 'فاشیسم',
};
const RELIGION_FA = {
  islam: 'اسلام', christianity: 'مسیحیت', judaism: 'یهودیت', zoroastrian: 'زرتشتی', buddhism: 'بودایی', none: 'بدون دین رسمی',
};

// کارت درخواست انتخاب کشور (برای مدیر). req باید user و country را populate کرده باشد یا فیلدهای ذخیره‌شده را داشته باشد
function requestCardText(req, country, user) {
  const c = country || req.country;
  const u = user || req.user;
  const lines = [
    `📋 <b>درخواست انتخاب کشور</b> #${shortId(req.id)}`,
    '',
    `👤 بازیکن: ${esc(req.displayName)}${req.username ? ` (@${esc(req.username)})` : ''}`,
    `🆔 Telegram ID: <code>${req.userId}</code>${u && u.gameId ? ` | شناسه بازی: <code>${u.gameId}</code>` : ''}`,
    `🌍 کشور: ${esc(c?.flag || '')} ${esc(c?.name || '—')}`,
    `🏷 نوع انتخاب: ${TYPE_FA[req.selectionType] || req.selectionType}`,
  ];
  if (req.paymentStatus !== 'not_required') {
    lines.push(`💰 مبلغ: ${fmtNum(req.price)} تومان`);
    lines.push(`💳 وضعیت پرداخت: ${PAY_STATUS_FA[req.paymentStatus] || req.paymentStatus}`);
  }
  lines.push(`📌 وضعیت درخواست: ${REQ_STATUS_FA[req.status] || req.status}`);
  lines.push(`🕒 ثبت: ${fmtDate(req.createdAt)}`);
  if (req.adminNote) lines.push(`📝 توضیح مدیر: ${esc(req.adminNote)}`);
  return lines.join('\n');
}

function countryCardText(c, extra = '') {
  const lines = [
    `${esc(c.flag)} <b>${esc(c.name)}</b>`,
    `👤 رهبر: ${esc(c.leaderName)}`,
    `🏛 حکومت: ${GOV_FA[c.governmentType] || esc(c.governmentType)}`,
    `🕊 دین رسمی: ${RELIGION_FA[c.religion] || esc(c.religion)}`,
    `👥 جمعیت: ${fmtNum(c.population)}`,
    `🏷 نوع انتخاب: ${TYPE_FA[c.selectionType]}`,
  ];
  if (c.selectionType === 'premium' || c.price > 0) lines.push(`💰 قیمت: ${fmtNum(c.price)} تومان`);
  if (extra) lines.push('', extra);
  return lines.join('\n');
}

module.exports = { TYPE_FA, REQ_STATUS_FA, PAY_STATUS_FA, GOV_FA, RELIGION_FA, requestCardText, countryCardText };
