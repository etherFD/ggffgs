'use strict';
// مرحله‌های گفتگو (دریافت متن/تصویر از کاربر)؛ وضعیت در Firestore ذخیره می‌شود
const userService = require('../services/userService');

const registry = new Map();
const registerFlow = (name, fn) => registry.set(name, fn);

function flowMiddleware() {
  return async (ctx, next) => {
    const user = ctx.state.user;
    if (!user || !user.flowName || !ctx.message) return next();

    // پشتیبانی از انصراف سریع
    if (ctx.message?.text === '/cancel') {
      await userService.clearFlow(user.telegramId);
      return ctx.reply('❌ عملیات لغو شد.');
    }

    let fn = registry.get(user.flowName);
    let matchResult = null;

    if (!fn) {
      for (const [key, handler] of registry.entries()) {
        if (key instanceof RegExp) {
          const match = user.flowName.match(key);
          if (match) {
            fn = handler;
            matchResult = match;
            break;
          }
        }
      }
    }

    if (!fn || (user.flowName.startsWith('adm:') && !ctx.state.isAdmin)) {
      await userService.clearFlow(user.telegramId);
      return next();
    }

    if (matchResult) {
      return fn(ctx, matchResult, user.flowData || {}, user);
    }
    return fn(ctx, user.flowData || {}, user);
  };
}
module.exports = { registerFlow, flowMiddleware };

