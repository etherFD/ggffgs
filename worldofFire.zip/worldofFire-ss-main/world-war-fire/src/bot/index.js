'use strict';
const { Telegraf } = require('telegraf');
const { config } = require('../config');
const logger = require('../utils/logger');
const rateLimit = require('./middleware/rateLimit');
const userMiddleware = require('./middleware/user');
const { flowMiddleware } = require('./flows');

function createBot() {
  const bot = new Telegraf(config.botToken, { handlerTimeout: 25000 });
  bot.use(rateLimit());
  bot.use(userMiddleware);

  const start = require('../handlers/start');
  const empire = require('../handlers/empire');
  const people = require('../handlers/people');
  const registration = require('../handlers/registration');
  bot.use(flowMiddleware());
  bot.use(start.composer);
  bot.use(people.composer);
  bot.use(empire.composer);
  bot.use(registration.composer);
  const admin = require('../handlers/admin');
  bot.use(admin.composer);

  bot.catch(async (err, ctx) => {
    if (!err) return;
    const errText = String(err.message || '').toLowerCase();
    // نادیده‌گرفتن هشدارهای طبیعی کلاینت تلگرام مانند کلیک مجدد کاربر روی یک دکمه یا منقضی شدن کوئری
    if (errText.includes('message is not modified') || errText.includes('query is too old') || errText.includes('message to edit not found')) {
      if (ctx && ctx.callbackQuery) await ctx.answerCbQuery().catch(() => {});
      return;
    }

    if (err.userFacing) {
      if (ctx && ctx.callbackQuery) await ctx.answerCbQuery(String(err.message).slice(0, 190), { show_alert: true }).catch(() => {});
      else if (ctx && typeof ctx.reply === 'function') await ctx.reply(`⚠️ ${err.message}`).catch(() => {});
      return;
    }

    const updateId = ctx && ctx.update ? ctx.update.update_id : 'unknown';
    const updateType = ctx && ctx.update ? Object.keys(ctx.update).filter((k) => k !== 'update_id').join(',') : 'none';
    const cbData = ctx && ctx.callbackQuery ? ctx.callbackQuery.data : null;
    const msgText = ctx && ctx.message && ctx.message.text ? ctx.message.text : null;
    const detail = cbData ? ` | دکمه: ${cbData}` : msgText ? ` | پیام: ${msgText.slice(0, 30)}` : '';
    logger.error(`خطا در پردازش آپدیت ${updateId} [${updateType}${detail}]:`, err && err.stack ? err.stack : err);
    const msg = '❌ خطایی رخ داد. لطفاً دوباره تلاش کنید.';
    if (ctx && ctx.callbackQuery) await ctx.answerCbQuery(msg, { show_alert: true }).catch(() => {});
    else if (ctx && typeof ctx.reply === 'function') await ctx.reply(msg).catch(() => {});
  });
  return bot;
}
module.exports = { createBot };
