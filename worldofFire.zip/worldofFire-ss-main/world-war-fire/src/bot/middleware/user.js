const logger = require('../../utils/logger');
const { config } = require('../../config');
const userService = require('../../services/userService');
const settings = require('../../services/settingsService');
const { LABEL_VALUES } = require('../keyboards/labels');

function extractChatTarget(raw) {
  if (!raw) return null;
  const s = String(raw).trim();
  if (/^-?\d+$/.test(s)) return Number(s);
  if (s.startsWith('@')) return s;
  const m = s.match(/(?:t\.me|telegram\.me)\/([A-Za-z0-9_]+)/i);
  if (m && m[1] && !m[1].startsWith('+') && m[1] !== 'joinchat') {
    return `@${m[1]}`;
  }
  return null;
}

function ensureReturnButton(extra) {
  const finalExtra = (extra && typeof extra === 'object') ? { ...extra } : {};
  if (finalExtra.reply_markup && finalExtra.reply_markup.remove_keyboard) {
    return finalExtra;
  }
  const defaultReturnBtn = [{ text: '🔙 بازگشت به منوی اصلی', callback_data: 'menu:home' }];

  if (!finalExtra.reply_markup) {
    finalExtra.reply_markup = { inline_keyboard: [defaultReturnBtn] };
  } else if (finalExtra.reply_markup && Array.isArray(finalExtra.reply_markup.inline_keyboard)) {
    const ik = [...finalExtra.reply_markup.inline_keyboard];
    const hasBack = ik.some((r) =>
      Array.isArray(r) &&
      r.some((b) =>
        b &&
        ((b.callback_data && (b.callback_data.includes('home') || b.callback_data.includes('back') || b.callback_data.includes('ad:home'))) ||
        (b.text && (b.text.includes('بازگشت') || b.text.includes('منو'))))
      )
    );
    if (!hasBack) {
      ik.push(defaultReturnBtn);
      finalExtra.reply_markup = { ...finalExtra.reply_markup, inline_keyboard: ik };
    }
  }
  return finalExtra;
}

// بارگذاری/ساخت کاربر، تشخیص مدیر (فقط با شناسه عددی از تنظیمات امن)، بررسی مسدودی و وضعیت فعال/خاموش بودن ربات
module.exports = async function userMiddleware(ctx, next) {
  if (!ctx.from || ctx.from.is_bot) return undefined;
  // Most game actions stay private, but voting buttons are posted in a channel.
  // Allow only this specific callback from a channel post; all other group/channel
  // updates remain ignored.
  const callbackData = (ctx.callbackQuery && ctx.callbackQuery.data) || '';
  const isChannelWarVote = /^war:side:[A-Za-z0-9_-]+:(neutral|attacker|defender)$/.test(callbackData);
  const isChannelUNVote = /^un:vote:[A-Za-z0-9_-]+:(yes|no|abstain)$/.test(callbackData);
  if (ctx.chat && ctx.chat.type !== 'private' && !isChannelWarVote && !isChannelUNVote) return undefined;

  const user = await userService.touchUser(ctx.from);
  ctx.state.user = user;
  ctx.state.isAdmin = config.adminIds.includes(ctx.from.id);

  // بررسی وضعیت روشن/خاموش بودن ربات توسط ادمین
  const botDisabled = await settings.isBotDisabled();
  ctx.state.botDisabled = botDisabled;

  if (botDisabled) {
    const shutdownMsg = [
      '🔴 <b>ربات اصلی بازی خاموش است</b>',
      '– – – – – – – – – –',
      '⛔ تمام بخش‌های بازی موقتاً قفل شده‌اند.',
      ctx.state.isAdmin ? 'برای روشن‌کردن بازی، از داشبورد ربات ادمین اختصاصی استفاده کنید.' : 'پس از راه‌اندازی مجدد، دوباره تلاش کنید.',
    ].join('\n');
    const replyExtra = { parse_mode: 'HTML', reply_markup: { remove_keyboard: true } };
    if (ctx.callbackQuery) {
      await ctx.answerCbQuery('🔴 ربات اصلی بازی خاموش است.', { show_alert: true }).catch(() => {});
      await ctx.reply(shutdownMsg, replyExtra).catch(() => {});
    } else {
      await ctx.reply(shutdownMsg, replyExtra).catch(() => {});
    }
    return undefined;
  }

  // بررسی عضویت اجباری هم در کانال و هم در گروه رسمی بازی برای بازیکنان
  if (!ctx.state.isAdmin) {
    const isMembershipCheckAction = callbackData === 'menu:check_membership';
    const links = await settings.getRequiredLinks();

    let channelOk = true;
    let groupOk = true;

    const channelTarget = extractChatTarget(links.channelId);
    if (channelTarget) {
      try {
        const m = await ctx.telegram.getChatMember(channelTarget, ctx.from.id);
        channelOk = ['creator', 'administrator', 'member', 'restricted'].includes(m?.status);
      } catch (err) {
        const errMsg = String(err?.message || '').toLowerCase();
        if (errMsg.includes('user not found') || errMsg.includes('participant') || errMsg.includes('member')) {
          channelOk = false;
        } else {
          // اگر دسترسی به کانال برای ربات امکان‌پذیر نباشد بازیکنان را بلاک نمی‌کنیم
          logger.warn(`بررسی عضویت کانال (${channelTarget}): عدم دسترسی یا خطای تلگرام (${errMsg})`);
          channelOk = true;
        }
      }
    }

    const groupTarget = extractChatTarget(links.groupId);
    if (groupTarget) {
      try {
        const gm = await ctx.telegram.getChatMember(groupTarget, ctx.from.id);
        groupOk = ['creator', 'administrator', 'member', 'restricted'].includes(gm?.status);
      } catch (err) {
        const errMsg = String(err?.message || '').toLowerCase();
        if (errMsg.includes('user not found') || errMsg.includes('participant') || errMsg.includes('member')) {
          groupOk = false;
        } else {
          // اگر ربات در گروه عضو یا ادمین نباشد، بازی برای تمام بازیکنان قفل نشود
          logger.warn(`بررسی عضویت گروه (${groupTarget}): عدم دسترسی یا خطای تلگرام (${errMsg})`);
          groupOk = true;
        }
      }
    }

    if (!channelOk || !groupOk) {
      if (ctx.callbackQuery) {
        await ctx.answerCbQuery(
          isMembershipCheckAction ? '⚠️ شما هنوز در کانال یا گروه رسمی عضو نشده‌اید!' : '⚠️ لطفاً ابتدا در کانال و گروه رسمی بازی عضو شوید.',
          { show_alert: true }
        ).catch(() => {});
      }
      const missingText = [
        '🔒 <b>عضویت اجباری در کانال و گروه رسمی بازی</b>',
        '– – – – – – – – – –',
        'برای دسترسی به کشور، امپراطوری من، انتصاب در دولت و شرکت در نبردها، عضویت همزمان در <b>کانال رسمی</b> و <b>ابرگروه بازی</b> برای کلیه بازیکنان و وزرا الزامی است.',
        '',
        `📢 کانال رسمی: ${channelOk ? '✅ عضو شده‌اید' : '❌ هنوز عضو نشده‌اید'}`,
        `👥 ابرگروه رسمی: ${groupOk ? '✅ عضو شده‌اید' : '❌ هنوز عضو نشده‌اید'}`,
        '',
        '👇 لطفاً در هر دو بخش عضو شوید و سپس دکمه «تایید و بررسی عضویت» را لمس کنید:',
      ].join('\n');

      const gateKb = {
        parse_mode: 'HTML',
        reply_markup: {
          inline_keyboard: [
            [{ text: '📢 عضویت در کانال رسمی', url: links.channelLink || 'https://t.me/worldwarfire_ch' }],
            [{ text: '👥 عضویت در گروه رسمی', url: links.groupLink || 'https://t.me/worldwarfire_gp' }],
            [{ text: '🔄 تایید و بررسی عضویت', callback_data: 'menu:check_membership' }],
          ],
        },
      };

      if (ctx.callbackQuery) {
        await ctx.editMessageText(missingText, gateKb).catch(async () => {
          await ctx.reply(missingText, gateKb).catch(() => {});
        });
      } else {
        await ctx.reply(missingText, gateKb).catch(() => {});
      }
      return undefined;
    }

    if (isMembershipCheckAction) {
      await ctx.answerCbQuery('🎉 عضویت شما در کانال و گروه با موفقیت تایید شد!', { show_alert: true }).catch(() => {});
      const { mainMenu } = require('../keyboards/main');
      await ctx.reply('✅ <b>خوش آمدید!</b>\nعضویت شما در کانال و گروه رسمی تایید شد. اکنون می‌توانید کشور خود را فرماندهی کنید.', mainMenu());
      return undefined;
    }
  }

  // تضمین وجود دکمه بازگشت برای تمام پیام‌های ربات
  const origReply = ctx.reply.bind(ctx);
  ctx.reply = (messageText, extra) => {
    return origReply(messageText, ensureReturnButton(extra)).catch((err) => {
      if (err?.message?.includes('message is not modified')) return true;
      throw err;
    });
  };

  const origReplyWithPhoto = ctx.replyWithPhoto ? ctx.replyWithPhoto.bind(ctx) : null;
  if (origReplyWithPhoto) {
    ctx.replyWithPhoto = (photo, extra) => {
      return origReplyWithPhoto(photo, ensureReturnButton(extra)).catch((err) => {
        if (err?.message?.includes('message is not modified')) return true;
        throw err;
      });
    };
  }

  const origEditMessageText = ctx.editMessageText ? ctx.editMessageText.bind(ctx) : null;
  if (origEditMessageText) {
    ctx.editMessageText = (messageText, extra) => {
      return origEditMessageText(messageText, ensureReturnButton(extra)).catch((err) => {
        if (err?.message?.includes('message is not modified')) return true;
        throw err;
      });
    };
  }

  if (user.status === 'banned' && !ctx.state.isAdmin) {
    const msg = '⛔ حساب شما مسدود شده است.' + (user.banReason ? `\nدلیل: ${user.banReason}` : '');
    if (ctx.callbackQuery) await ctx.answerCbQuery(msg.slice(0, 190), { show_alert: true }).catch(() => {});
    else await ctx.reply(msg).catch(() => {});
    return undefined;
  }

  // دستورات و دکمه‌های منو، مرحله جاری گفتگو را لغو می‌کنند
  const text = ctx.message && ctx.message.text;
  if (user.flowName && text && (text.startsWith('/') || LABEL_VALUES.has(text))) {
    await userService.clearFlow(user.telegramId);
    user.flowName = null;
    user.flowData = null;
  }

  // حذف قطعی پنل کیبورد پایین در صورت لمس هر یک از دکمه‌های کیبورد قدیمی
  if (text && !user.flowName) {
    const legacyKeys = [
      'حمله 🇦', 'اقتصاد و نفت 💰', 'اعلام جنگ ⚔️', 'دفاع 🛡️', 'مردم 👥',
      'توسعه کشور ⚙️', 'فرمانده 🧑‍✈️', 'استان‌های من 🗺️', 'پادگان 🪖',
      'رزمایش 🪖', 'نقشه‌ی جهان 🗺️', 'اتحاد من 🤝', 'تحقیقات 🔬',
      'شرکت‌ها 🏢', 'نیروی سایبری 💻', 'جاسوسی 🕵️‍♂️', 'تجارت 🤝',
      'بازار جهانی 🌐', 'اکتشاف نفت 🛢️', 'برنامه هسته‌ای ☢️', 'مذاکره 🗣️',
      'دیپلماسی 🕊️', 'تنگه‌ها 🚢', 'پایگاه نظامی 🪖', 'تورم 📉',
      'گروهک‌ها 🕶️', 'بازار و سرمایه 💹', 'ساخت و ساز و پروژه‌ها 🏗️',
      'کشورداری و موارد دیگر 🏛️', 'پاکسازی نفوذی‌ها 🧹', '/clean', '/fix'
    ];
    if (legacyKeys.includes(text)) {
      // ارسال دستور حذف کیبورد به کلاینت تلگرام جهت پاکسازی کش
      await origReply('🧹 پنل کیبورد پایین پاکسازی شد.', {
        reply_markup: { remove_keyboard: true, selective: false },
      }).catch(() => {});
    }
  }

  return next();
};
