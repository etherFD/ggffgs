'use strict';
const hits = new Map();

// محدودیت نرخ ساده: حداکثر max درخواست در windowMs برای هر کاربر
function rateLimit({ windowMs = 10000, max = 14 } = {}) {
  setInterval(() => {
    const now = Date.now();
    for (const [id, arr] of hits) {
      if (!arr.some((t) => now - t < windowMs)) hits.delete(id);
    }
  }, 60000).unref();

  return async (ctx, next) => {
    const id = ctx.from && ctx.from.id;
    if (!id) return next();
    const now = Date.now();
    const arr = (hits.get(id) || []).filter((t) => now - t < windowMs);
    arr.push(now);
    hits.set(id, arr);
    if (arr.length > max) {
      if (ctx.callbackQuery) ctx.answerCbQuery('⏳ لطفاً کمی آهسته‌تر').catch(() => {});
      return undefined;
    }
    return next();
  };
}
module.exports = rateLimit;
