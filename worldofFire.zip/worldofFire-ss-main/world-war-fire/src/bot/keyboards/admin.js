'use strict';
const { Markup } = require('telegraf');

function adminHome(botDisabled = false) {
  const rows = [
    [Markup.button.callback('📥 درخواست‌های کشور', 'ad:rql')],
    [Markup.button.callback('⚖️ مشاهده شکایات کاربران', 'ad:cmpl')],
    [Markup.button.callback('📢 ارسال اطلاعیه همگانی', 'ad:bc:prompt')],
    [Markup.button.callback('✉️ پیام اختصاصی به یک بازیکن/کشور', 'ad:dm:prompt')],
    [
      Markup.button.callback(
        botDisabled ? '🟢 روشن کردن ربات (خروج از تعمیرات)' : '🔴 خاموش کردن ربات (حالت تعمیرات)',
        botDisabled ? 'ad:bot:toggle:enable' : 'ad:bot:toggle:disable'
      ),
    ],
    [Markup.button.callback('🎮 بازگشت به حالت بازی', 'ad:backtoplayer'), Markup.button.callback('🔙 بازگشت به منوی اصلی', 'menu:home')],
  ];
  return Markup.inlineKeyboard(rows);
}
const backHome = () => Markup.inlineKeyboard([
  [Markup.button.callback('🏠 پنل مدیریت', 'ad:home'), Markup.button.callback('🔙 بازگشت به منوی اصلی', 'menu:home')]
]);

function requestActions(req) {
  const id = String(req.id);
  const rows = [];
  if (req.isOpen) {
    if (req.paymentStatus === 'submitted') {
      rows.push([Markup.button.callback('✅ تأیید پرداخت', `ad:rqa:${id}:payok`), Markup.button.callback('❌ رد پرداخت', `ad:rqa:${id}:payno`)]);
      rows.push([Markup.button.callback('🧾 مشاهده رسید', `ad:rqa:${id}:rcpt`)]);
    } else if (req.status === 'pending' && ['not_required', 'approved'].includes(req.paymentStatus)) {
      rows.push([Markup.button.callback('🏁 تأیید و تخصیص کشور', `ad:rqa:${id}:assign`), Markup.button.callback('❌ رد درخواست', `ad:rqa:${id}:no`)]);
    } else if (req.status === 'pending') {
      rows.push([Markup.button.callback('❌ رد درخواست', `ad:rqa:${id}:no`)]);
    }
  }
  rows.push([Markup.button.callback('📥 فهرست درخواست‌ها', 'ad:rql'), Markup.button.callback('🏠 پنل', 'ad:home')]);
  return Markup.inlineKeyboard(rows);
}
module.exports = { adminHome, backHome, requestActions };
