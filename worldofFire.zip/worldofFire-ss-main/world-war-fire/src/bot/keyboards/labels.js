'use strict';
const LABELS = Object.freeze({
  status: '📊 وضعیت کشور من',
  empire: '👑 امپراطوری من',
  mission: '🎯 مأموریت روزانه',
  account: '👤 حساب من',
  shield: '😴 سپر خواب (۸ ساعت)',
  world: '🌍 کشورهای جهان',
  complaints: '⚖️ شکایات',
  leaderboard: '🏅 لیدربرد',
  coin: '👑 سکه شاهی',
  tutorial: '📚 آموزش بازی',
  support: '🛟 پشتیبانی',
  adminPanel: '👑 پنل مدیریت',
  playerMode: '🎮 بازگشت به حالت بازی',
  back: '🔙 بازگشت به منوی اصلی',
});
const LABEL_VALUES = new Set(Object.values(LABELS));
module.exports = { LABELS, LABEL_VALUES };
