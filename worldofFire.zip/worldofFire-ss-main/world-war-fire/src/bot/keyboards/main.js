'use strict';
const { Markup } = require('telegraf');
const { LABELS: L } = require('./labels');
const { config } = require('../../config');

// دستور حذف کامل پنل کیبورد پایین چت (جهت پاکسازی پنل ثابت زیر کادر چت تلگرام)
function removeKeyboard() {
  return { reply_markup: { remove_keyboard: true } };
}

const cb = (text, data, style = 'primary') => ({ text, callback_data: data, style });

// منوی اصلی بازی به صورت کلیدهای اینلاین کاملاً رنگی (از حالت شیشه‌ای درآمده)
function mainInlineMenu(isAdmin = false) {
  const rows = [
    [
      cb('📊 وضعیت کشور من', 'menu:status', 'primary'),
      cb('👑 امپراطوری من', 'menu:empire', 'success'),
    ],
    [
      cb('🎖️ فرمانده کل و هیئت وزیران', 'menu:commander', 'primary'),
      cb('💬 گروه چت و گفتگوی بازیکنان', 'menu:chat', 'success'),
    ],
    [
      cb('🎯 ماموریت روزانه', 'menu:mission', 'success'),
      cb('👤 حساب من', 'menu:account', 'primary'),
    ],
    [
      cb('🛡️ سپر خواب', 'menu:shield', 'primary'),
      cb('🗺️ نقشه‌ی جهان', 'menu:world', 'primary'),
    ],
    [
      cb('⚖️ شکایات و پشتیبانی', 'menu:complaints', 'danger'),
      cb('🏆 لیدربرد جهان', 'menu:leaderboard', 'primary'),
    ],
    [
      cb('👑 سکه شاهی', 'menu:coin', 'success'),
      cb('📚 راهنمای بازی', 'menu:tutorial', 'primary'),
    ],
  ];

  return { reply_markup: { inline_keyboard: rows } };
}

// جهت سازگاری با توابع قبلی، mainMenu پنل پایین را حذف می‌کند تا صفحه باز نشود
function mainMenu() {
  return removeKeyboard();
}

// کیبورد لیدربورد جهانی کاملاً رنگی (بدون حالت شیشه‌ای)
function leaderboardKeyboard() {
  return {
    reply_markup: {
      inline_keyboard: [
        [cb('🏆 برترین‌های جهان (کل)', 'lb:overall', 'primary')],
        [cb('📊 جدول قدرت جهانی', 'lb:military', 'primary')],
        [cb('🛢️ قدرت‌های نفتی', 'lb:oil', 'success')],
        [cb('💵 قدرت‌های اقتصادی', 'lb:economy', 'success')],
        [cb('☢️ قدرت‌های اتمی', 'lb:nuclear', 'danger')],
        [cb('👑 برترین‌های سکه شاهی', 'lb:coin', 'success')],
        [cb('🏆 تالار افتخارات سیزن', 'lb:hall', 'primary')],
        [cb('🔙 بازگشت به منوی اصلی', 'menu:home', 'danger')],
      ],
    },
  };
}

module.exports = {
  mainMenu,
  removeKeyboard,
  mainInlineMenu,
  leaderboardKeyboard,
};
