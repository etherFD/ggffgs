'use strict';
// خطایی که پیام آن مستقیماً به کاربر نمایش داده می‌شود
class GameError extends Error {
  constructor(message) {
    super(message);
    this.name = 'GameError';
    this.userFacing = true;
  }
}
module.exports = { GameError };
