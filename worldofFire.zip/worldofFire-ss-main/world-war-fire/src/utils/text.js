'use strict';

function esc(value) {
  return String(value ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;');
}

function fmtNum(n) {
  return Number(n || 0).toLocaleString('en-US');
}

function fmtDate(d) {
  if (!d) return '—';
  return new Date(d).toLocaleString('fa-IR', { timeZone: 'Asia/Tehran' });
}

function displayNameOf(from) {
  const name = [from.first_name, from.last_name].filter(Boolean).join(' ').trim();
  return name || from.username || String(from.id);
}

function shortId(id) {
  return String(id).slice(-6);
}

// تبدیل ارقام فارسی/عربی به لاتین
function toLatinDigits(str) {
  return String(str ?? '')
    .replace(/[۰-۹]/g, (d) => String(d.charCodeAt(0) - 0x06f0))
    .replace(/[٠-٩]/g, (d) => String(d.charCodeAt(0) - 0x0660));
}

// عدد صحیح نامنفی یا null
function parseNonNegInt(str) {
  const s = toLatinDigits(str).replace(/[,٬\s]/g, '');
  if (!/^\d{1,15}$/.test(s)) return null;
  const n = Number(s);
  return Number.isSafeInteger(n) ? n : null;
}

module.exports = { esc, fmtNum, fmtDate, displayNameOf, shortId, toLatinDigits, parseNonNegInt };
