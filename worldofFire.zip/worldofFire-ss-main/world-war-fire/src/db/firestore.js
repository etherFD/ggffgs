'use strict';
const { config } = require('../config');

let _db = null;

function parseServiceAccount(raw) {
  let text = raw.trim();
  if (!text.startsWith('{') && !text.includes('"type"')) text = Buffer.from(text, 'base64').toString('utf8');
  if (!text.startsWith('{')) text = '{' + text;
  if (!text.endsWith('}')) text = text + '}';
  const sa = JSON.parse(text);
  if (sa.private_key) sa.private_key = sa.private_key.replace(/\\n/g, '\n');
  return sa;
}

function initDb() {
  if (_db) return _db;
  const { Firestore } = require('@google-cloud/firestore');
  const opts = { ignoreUndefinedProperties: true };
  if (config.firebaseServiceAccount) {
    const sa = parseServiceAccount(config.firebaseServiceAccount);
    opts.projectId = sa.project_id;
    opts.credentials = { client_email: sa.client_email, private_key: sa.private_key };
  } else if (config.projectId) {
    opts.projectId = config.projectId;
  }
  if (config.firestoreDatabaseId && !config.firestoreDatabaseId.includes('://') && config.firestoreDatabaseId !== '(default)') {
    opts.databaseId = config.firestoreDatabaseId;
  }
  _db = new Firestore(opts);
  return _db;
}

const db = () => _db || initDb();
const setDb = (x) => { _db = x; }; // برای تست
const col = (name) => db().collection(name);

// تبدیل Timestamp فایراستور به Date
function convert(v) {
  if (v && typeof v === 'object') {
    if (v instanceof Date) return v;
    if (typeof v.toDate === 'function') return v.toDate();
    if (Array.isArray(v)) return v.map(convert);
    const out = {};
    for (const k of Object.keys(v)) out[k] = convert(v[k]);
    return out;
  }
  return v;
}
const snap = (d) => (d && d.exists ? { id: d.id, ...convert(d.data()) } : null);
const docs = (qs) => qs.docs.map(snap);

module.exports = { db, setDb, initDb, col, snap, docs };
