'use strict';
// اسناد «قفل» در مجموعه locks، یکتایی و عدم تداخل را تضمین می‌کنند
// (همگام‌سازی در حافظه + ذخیره در فایراستور با انقضای خودکار TTL)

const activeLocks = new Map();

/**
 * دریافت قفل توزیع‌شده با TTL
 * @param {string} key
 * @param {number} ttlMs
 * @returns {Promise<boolean>}
 */
async function acquireLock(key, ttlMs = 10000) {
  if (!key) return true;
  const now = Date.now();
  const existing = activeLocks.get(key);
  if (existing && existing.expiresAt > now) {
    return false;
  }
  const expiresAt = now + Math.max(1000, Number(ttlMs) || 10000);
  activeLocks.set(key, { expiresAt });

  try {
    const { col } = require('./firestore');
    const safeDocId = String(key).replace(/[\/\s#?\[\]]/g, '_');
    await col('locks').doc(safeDocId).set({ key, expiresAt, acquiredAt: now }, { merge: true });
  } catch (_) {
    // در صورت عدم دسترسی موقت به فایراستور، قفل حافظه‌ای سیستم فعال است
  }

  return true;
}

/**
 * آزادسازی قفل
 * @param {string} key
 * @returns {Promise<void>}
 */
async function releaseLock(key) {
  if (!key) return;
  activeLocks.delete(key);
  try {
    const { col } = require('./firestore');
    const safeDocId = String(key).replace(/[\/\s#?\[\]]/g, '_');
    await col('locks').doc(safeDocId).delete().catch(() => {});
  } catch (_) {}
}

module.exports = {
  activeSeason: 'active_season',
  reqLock: (seasonId, userId) => `req_${seasonId}_${userId}`, // یک درخواست باز برای هر بازیکن در هر سیزن
  ownCountry: (seasonId, countryId) => `own_c_${seasonId}_${countryId}`, // یک مالک برای هر کشور
  ownUser: (seasonId, userId) => `own_u_${seasonId}_${userId}`, // یک کشور برای هر بازیکن
  acquireLock,
  releaseLock,
};

