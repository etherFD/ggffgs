'use strict';
const { config, assertConfig } = require('./config');
const logger = require('./utils/logger');
const { initDb } = require('./db/firestore');
const { ensureDefaultSeason } = require('./services/seasonService');
const { setWebhook } = require('./services/webhookService');
const { createBot } = require('./bot');
const { createWebApp } = require('./web/server');

async function main() {
  assertConfig();
  initDb();
  const bot = createBot();

  // آماده‌سازی در پس‌زمینه تا سرور سریع بالا بیاید؛ درخواست‌ها منتظر ready می‌مانند
  const ready = (async () => {
    bot.botInfo = await bot.telegram.getMe();
    await ensureDefaultSeason();
    logger.info(`ربات @${bot.botInfo.username} و Firestore آماده‌اند.`);
    // ربات ادمین مستقل از همان ابتدا پولینگ را فعال می‌کند تا /start و داشبوردش منتظر اولین اعلان نمانند.
    await require('./services/adminBotService').initAdminBot(bot.telegram).catch((e) => logger.warn('راه‌اندازی ربات ادمین مستقل ناموفق بود:', e.message));
    if (config.publicUrl) {
      try {
        const url = await setWebhook(bot.telegram, config.publicUrl);
        logger.info(`وب‌هوک ثبت شد: ${new URL(url).host}`);
      } catch (e) {
        logger.warn('ثبت خودکار وب‌هوک ناموفق بود (از داشبورد انجام دهید):', e.message);
      }
    }
  })();
  ready.catch((e) => logger.error('راه‌اندازی ناموفق بود:', e.message));

  const app = createWebApp({ bot, ready });
  const server = app.listen(config.port, '0.0.0.0', () => logger.info(`سرور روی پورت ${config.port} فعال شد.`));

  const shutdown = (sig) => { logger.info(`${sig} دریافت شد؛ خاموش‌سازی...`); server.close(() => process.exit(0)); setTimeout(() => process.exit(0), 8000).unref(); };
  process.once('SIGTERM', () => shutdown('SIGTERM'));
  process.once('SIGINT', () => shutdown('SIGINT'));
}

process.on('unhandledRejection', (e) => logger.error('unhandledRejection:', e && e.message ? e.message : e));
main().catch((err) => { logger.error('راه‌اندازی ناموفق بود:', err.message); process.exit(1); });
