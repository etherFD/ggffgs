'use strict';
const { Composer, Markup } = require('telegraf');
const { LABELS: L } = require('../bot/keyboards/labels');
const { mainMenu } = require('../bot/keyboards/main');
const { requestActions } = require('../bot/keyboards/admin');
const { render, answer } = require('../bot/ui');
const { TYPE_FA, requestCardText, countryCardText, PAY_STATUS_FA, REQ_STATUS_FA } = require('../bot/views');
const { registerFlow } = require('../bot/flows');
const { esc, fmtNum } = require('../utils/text');
const settings = require('../services/settingsService');
const countryService = require('../services/countryService');
const userService = require('../services/userService');
const { getActiveSeason } = require('../services/seasonService');
const ownership = require('../services/ownershipService');
const selection = require('../services/selectionService');
const { notifyAdmins } = require('../services/notificationService');

const composer = new Composer();
const PAGE = 8;
const ID = '([A-Za-z0-9_-]{3,40})';
const TYPE_ICON = { free: '🆓', premium: '💎', exclusive: '🔒' };

async function paymentInfoText(request, country) {
  const card = await settings.get('paymentCardNumber', '');
  const holder = await settings.get('paymentCardHolder', '');
  const note = await settings.get('paymentNote', '');
  return [
    `💎 <b>انتخاب ویژه: ${esc(country.flag)} ${esc(country.name)}</b>`, '',
    `💰 مبلغ قابل پرداخت: <b>${fmtNum(request.price)} تومان</b>`,
    `💳 شماره کارت: <code>${esc(card)}</code>`,
    holder ? `👤 به نام: ${esc(holder)}` : '',
    note ? `📝 ${esc(note)}` : '', '',
    '📸 پس از پرداخت، <b>تصویر رسید</b> یا <b>اطلاعات تراکنش (متن)</b> را همین‌جا بفرستید.',
    'ℹ️ ارسال رسید به معنی تأیید پرداخت نیست؛ مدیر پرداخت را بررسی می‌کند و سپس کشور را تخصیص می‌دهد.',
  ].filter(Boolean).join('\n');
}

async function showOpenRequest(ctx, req) {
  const c = req.country;
  const lines = [
    '📌 <b>شما یک درخواست باز دارید</b>', '',
    `🌍 کشور: ${esc(c.flag)} ${esc(c.name)}`,
    `🏷 نوع: ${TYPE_FA[req.selectionType]}`,
    `📋 وضعیت درخواست: ${REQ_STATUS_FA[req.status]}`,
  ];
  if (req.paymentStatus !== 'not_required') lines.push(`💳 وضعیت پرداخت: ${PAY_STATUS_FA[req.paymentStatus]}`);
  const rows = [];
  if (req.paymentStatus === 'awaiting') rows.push([Markup.button.callback('🧾 ارسال رسید', `cr:${req.id}`)]);
  if (req.status === 'pending' && ['not_required', 'awaiting'].includes(req.paymentStatus)) rows.push([Markup.button.callback('🗑 لغو درخواست', `cx:${req.id}`)]);
  await render(ctx, lines.join('\n'), rows.length ? Markup.inlineKeyboard(rows) : undefined);
}

async function showPicker(ctx, page = 0) {
  const user = ctx.state.user;
  const season = await getActiveSeason();
  if (!season) return render(ctx, '⏳ در حال حاضر سیزن فعالی وجود ندارد. بعداً دوباره تلاش کنید.');
  const own = await ownership.getActiveOwnership(user.telegramId, season.id);
  if (own) return render(ctx, `✅ شما در این سیزن کشور ${esc(own.country.flag)} <b>${esc(own.country.name)}</b> را دارید.`);
  const open = await selection.getOpenRequest(user.telegramId);
  if (open) return showOpenRequest(ctx, open);

  const owned = new Set(await ownership.ownedCountryIds(season.id));
  const all = (await countryService.list()).filter((c) => !owned.has(c.id) && selection.canSeeCountry(c, user.telegramId));
  if (!all.length) return render(ctx, '😕 در حال حاضر کشور آزادی برای انتخاب وجود ندارد.');
  const maxPage = Math.max(0, Math.ceil(all.length / PAGE) - 1);
  page = Math.min(Math.max(0, page), maxPage);
  const rows = all.slice(page * PAGE, page * PAGE + PAGE).map((c) => [Markup.button.callback(`${c.flag} ${c.name} ${TYPE_ICON[c.selectionType]}`, `cs:${c.id}`)]);
  const nav = [];
  if (page > 0) nav.push(Markup.button.callback('◀️ قبلی', `cl:${page - 1}`));
  if (page < maxPage) nav.push(Markup.button.callback('بعدی ▶️', `cl:${page + 1}`));
  if (nav.length) rows.push(nav);
  return render(ctx, [
    '🌍 <b>انتخاب کشور</b>', `(صفحه ${fmtNum(page + 1)} از ${fmtNum(maxPage + 1)})`, '',
    '🆓 رایگان (با تأیید مدیر)   💎 ویژه (پرداختی)   🔒 اختصاصی', 'یک کشور را انتخاب کنید:',
  ].join('\n'), Markup.inlineKeyboard(rows));
}

composer.action(/^cl:(\d+)$/, async (ctx) => { await answer(ctx); await showPicker(ctx, Number(ctx.match[1])); });

composer.action(new RegExp(`^cs:${ID}$`), async (ctx) => {
  await answer(ctx);
  const season = await getActiveSeason();
  const c = await countryService.get(ctx.match[1]);
  if (!season || !c || !selection.canSeeCountry(c, ctx.state.user.telegramId)) return render(ctx, '❌ این کشور در دسترس نیست.');
  if (await ownership.getOwnerOfCountry(c.id, season.id)) return render(ctx, '❌ این کشور قبلاً انتخاب شده است.');
  const extra = selection.requiresPayment(c)
    ? '💎 پس از تأیید، اطلاعات پرداخت نمایش داده می‌شود.'
    : '🆓 درخواست شما پس از ثبت، برای تأیید مدیر ارسال می‌شود.';
  await render(ctx, countryCardText(c, extra), Markup.inlineKeyboard([
    [Markup.button.callback('✅ ثبت درخواست این کشور', `cc:${c.id}`)],
    [Markup.button.callback('🔙 بازگشت', 'cl:0')],
  ]));
});

composer.action(new RegExp(`^cc:${ID}$`), async (ctx) => {
  await answer(ctx);
  const user = ctx.state.user;
  const c = await countryService.get(ctx.match[1]);
  if (c && selection.requiresPayment(c) && !(await settings.get('paymentCardNumber', ''))) {
    return render(ctx, '⚠️ اطلاعات پرداخت هنوز توسط مدیر تنظیم نشده است. لطفاً بعداً تلاش کنید یا کشور رایگان انتخاب کنید.');
  }
  const { request, country, paid } = await selection.createRequest({ user, countryId: ctx.match[1] });
  if (paid) {
    await userService.setFlow(user.telegramId, 'receipt', { requestId: request.id });
    return render(ctx, await paymentInfoText(request, country), Markup.inlineKeyboard([[Markup.button.callback('🗑 لغو درخواست', `cx:${request.id}`)]]));
  }
  await render(ctx, `✅ درخواست انتخاب ${esc(country.flag)} <b>${esc(country.name)}</b> ثبت شد.\nمنتظر تأیید مدیر باشید؛ نتیجه از طریق همین ربات اطلاع داده می‌شود.`);
  await notifyAdmins(ctx.telegram, requestCardText(request, country, user), requestActions(request));
});

composer.action(new RegExp(`^cr:${ID}$`), async (ctx) => {
  await answer(ctx);
  const open = await selection.getOpenRequest(ctx.state.user.telegramId);
  if (!open || open.id !== ctx.match[1] || open.paymentStatus !== 'awaiting') return render(ctx, 'ℹ️ این درخواست منتظر رسید نیست.');
  await userService.setFlow(ctx.state.user.telegramId, 'receipt', { requestId: open.id });
  await render(ctx, await paymentInfoText(open, open.country));
});

composer.action(new RegExp(`^cx:${ID}$`), async (ctx) => {
  await answer(ctx);
  await selection.cancelByUser({ requestId: ctx.match[1], userTelegramId: ctx.state.user.telegramId });
  await userService.clearFlow(ctx.state.user.telegramId);
  await render(ctx, '🗑 درخواست شما لغو شد. هر زمان خواستید دوباره کشور انتخاب کنید.', Markup.inlineKeyboard([[Markup.button.callback('🌍 انتخاب کشور', 'cl:0')]]));
});

// دریافت رسید پرداخت (عکس یا متن)
registerFlow('receipt', async (ctx, data, user) => {
  const msg = ctx.message;
  let receipt;
  if (msg.photo && msg.photo.length) {
    receipt = { type: 'photo', fileId: msg.photo[msg.photo.length - 1].file_id, text: (msg.caption || '').slice(0, 500) || null };
  } else if (msg.text) {
    const t = msg.text.trim();
    if (t.length < 4 || t.length > 1000) return ctx.reply('⚠️ متن رسید باید بین ۴ تا ۱۰۰۰ کاراکتر باشد. یا تصویر رسید را بفرستید.');
    receipt = { type: 'text', fileId: null, text: t };
  } else {
    return ctx.reply('⚠️ فقط تصویر رسید یا متن اطلاعات تراکنش پذیرفته می‌شود.');
  }
  const request = await selection.submitReceipt({ requestId: data.requestId, userTelegramId: user.telegramId, receipt });
  await userService.clearFlow(user.telegramId);
  await ctx.reply('✅ رسید شما ثبت شد و در وضعیت «در انتظار بررسی پرداخت» قرار گرفت. نتیجه از همین ربات اطلاع داده می‌شود.', mainMenu());
  const country = await countryService.get(request.countryId);
  let card = requestCardText(request, country, user);
  if (receipt.type === 'text') card += `\n\n🧾 اطلاعات تراکنش:\n${esc(receipt.text)}`;
  else if (receipt.text) card += `\n\n🧾 توضیح بازیکن:\n${esc(receipt.text)}`;
  await notifyAdmins(ctx.telegram, card, requestActions(request), receipt.type === 'photo' ? receipt.fileId : null);
});

composer.hears(L.world, async (ctx) => {
  const user = ctx.state.user;
  const season = await getActiveSeason();
  const own = season ? await ownership.getActiveOwnership(user.telegramId, season.id) : null;
  if (!own) return showPicker(ctx, 0);
  const owned = new Set(await ownership.ownedCountryIds(season.id));
  const countries = (await countryService.list()).filter((c) => c.isActive).slice(0, 60);
  const lines = ['🌍 <b>کشورهای جهان</b>', '(🟢 آزاد   🔴 تحت مالکیت بازیکن)', ''];
  for (const c of countries) lines.push(`${owned.has(c.id) ? '🔴' : '🟢'} ${esc(c.flag)} ${esc(c.name)}`);
  lines.push('', '🔍 جست‌وجو، پرچم و اطلاعات تفصیلی کشورها در مراحل بعد اضافه می‌شود.');
  await ctx.reply(lines.join('\n'), { parse_mode: 'HTML' });
});

module.exports = { composer, showPicker };
