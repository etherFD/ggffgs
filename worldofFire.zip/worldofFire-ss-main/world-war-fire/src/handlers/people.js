'use strict';

/**
 * هندلر بخش مردم، خدمات عمومی (برق، آب، گاز)، قطعی‌ها، شورش و ساخت‌وساز/پژوهش
 */

const { Composer, Markup } = require('telegraf');
const { esc, fmtNum, parseNonNegInt } = require('../utils/text');
const { getActiveSeason } = require('../services/seasonService');
const { getActiveOwnership } = require('../services/ownershipService');
const countryService = require('../services/countryService');
const userService = require('../services/userService');
const gameService = require('../services/gameService');
const peopleService = require('../services/peopleService');
const constructionService = require('../services/constructionService');
const notifications = require('../services/notificationService');
const { registerFlow } = require('../bot/flows');

const composer = new Composer();

async function requireCountry(ctx) {
  const season = await getActiveSeason();
  if (!season) {
    await ctx.reply('⚠️ در حال حاضر سیزن فعالی وجود ندارد.');
    return null;
  }
  const user = ctx.state.user;
  if (!user) {
    await ctx.reply('⚠️ ابتدا در ربات ثبت نام کنید.');
    return null;
  }
  const own = await getActiveOwnership(user.telegramId || ctx.from.id, season.id);
  if (own) {
    ctx.state.isLeader = true;
    ctx.state.isMinister = false;
    ctx.state.ministerRole = null;
    const country = await countryService.get(own.countryId);
    return { season, user, own: { ...own, country }, isLeader: true };
  }

  // بررسی سمت وزارتی کاربر در این سیزن
  const ministerService = require('../services/ministerService');
  const ministerRecord = await ministerService.findMinisterRole(user.telegramId || ctx.from.id, season.id);
  if (ministerRecord) {
    const country = await countryService.get(ministerRecord.countryId);
    ctx.state.isLeader = false;
    ctx.state.isMinister = true;
    ctx.state.ministerRole = ministerRecord.role;
    return {
      season,
      user,
      own: { countryId: ministerRecord.countryId, country, isMinister: true, ministerRole: ministerRecord.role },
      isLeader: false,
      isMinister: true,
      role: ministerRecord.role,
    };
  }

  await ctx.reply('⚠️ شما هنوز هدایت هیچ کشوری را برعهده نگرفته‌اید.');
  return null;
}

// =============================================================
// ۱. منوی اصلی بخش مردم و خدمات عمومی
// =============================================================
composer.action('emp:people', async (ctx) => {
  await ctx.answerCbQuery().catch(() => {});
  await showPeoplePanel(ctx, true);
});
composer.hears(['مردم 👥', 'مردم', 'خدمات عمومی', 'نیروگاه ها'], async (ctx) => {
  await showPeoplePanel(ctx, false);
});

async function showPeoplePanel(ctx, isEdit = false) {
  const data = await requireCountry(ctx);
  if (!data) return;
  const { season, own } = data;

  const utils = await gameService.getCountryUtilities(own.countryId, season.id);
  const flag = countryService.getDynamicFlag(own.country, utils.state);

  // وضعیت شورش
  let rebellionText = '🟢 آرام و باثبات';
  if (utils.rebellionActive) {
    rebellionText = `🚨 <b>شورش فعال! (${fmtNum(utils.rebelRatio)}٪ شورشی)</b>`;
  } else if (utils.dissatisfaction >= 70) {
    rebellionText = '⚠️ <b>در آستانه انفجار و شورش عمومی!</b>';
  }

  const pBar = utils.powerCoverage >= 60 ? '🟢' : '🔴';
  const wBar = utils.waterCoverage >= 60 ? '🟢' : '🔴';
  const gBar = utils.gasCoverage >= 60 ? '🟢' : '🔴';

  const lines = [
    `👥 <b>بخش مردم و خدمات عمومی — ${esc(own.country.name)} ${flag}</b>`,
    '– – – – – – – – – –',
    `👨‍👩‍👦 جمعیت فعال کشور: <b>${fmtNum(utils.population)} نفر</b>`,
    `😊 شاخص رضایت مردم: <b>${fmtNum(utils.satisfaction)}%</b> | نارضایتی: <b>${fmtNum(utils.dissatisfaction)}%</b>`,
    `🚨 وضعیت شورش: ${rebellionText}`,
    '',
    '📊 <b>وضعیت خدمات عمومی و تامین نیازها (حداقل ۶۰٪ جهت رضایت):</b>',
    `${pBar} ⚡ پوشش برق: <b>${fmtNum(utils.powerCoverage)}%</b> (قطعی فعلی: ${fmtNum(utils.powerOutage)} ساعت)`,
    `${wBar} 💧 پوشش آب: <b>${fmtNum(utils.waterCoverage)}%</b> (قطعی فعلی: ${fmtNum(utils.waterOutage)} ساعت)`,
    `${gBar} ⛽ پوشش گاز: <b>${fmtNum(utils.gasCoverage)}%</b> (قطعی فعلی: ${fmtNum(utils.gasOutage)} ساعت)`,
    '',
    '💡 <i>نکته: قطعی برق بالای ۶ ساعت، آب بالای ۳ ساعت و گاز بالای ۴ ساعت باعث اوج‌گیری نارضایتی مردم خواهد شد.</i>',
  ];

  const kb = Markup.inlineKeyboard([
    [
      Markup.button.callback('🏭 ساخت نیروگاه‌ها و تاسیسات', 'people:plants_menu'),
      Markup.button.callback('🛡 سرکوب و مهار شورش', 'people:quell_menu'),
    ],
    [Markup.button.callback('🔙 بازگشت به امپراطوری', 'emp:home')],
  ]);

  if (isEdit && ctx.callbackQuery) {
    await ctx.editMessageText(lines.join('\n'), { parse_mode: 'HTML', ...kb }).catch(() => {
      ctx.reply(lines.join('\n'), { parse_mode: 'HTML', ...kb });
    });
  } else {
    await ctx.reply(lines.join('\n'), { parse_mode: 'HTML', ...kb });
  }
}

// منوی ساخت نیروگاه‌ها
composer.action('people:plants_menu', async (ctx) => {
  await ctx.answerCbQuery().catch(() => {});
  const data = await requireCountry(ctx);
  if (!data) return;

  const lines = [
    '🏭 <b>مدیریت و احداث زیرساخت‌های نیروگاهی کشور</b>',
    '– – – – – – – – – –',
    'نوع انرژی و تاسیسات مورد نظر را جهت ساخت یا مدیریت قطعی انتخاب فرمایید:',
  ];

  const kb = Markup.inlineKeyboard([
    [Markup.button.callback('⚡ ایجاد نیروگاه برق', 'people:cat:power')],
    [Markup.button.callback('💧 ایجاد نیروگاه آب', 'people:cat:water')],
    [Markup.button.callback('⛽ ایجاد نیروگاه گاز', 'people:cat:gas')],
    [Markup.button.callback('🔙 بازگشت به بخش مردم', 'emp:people')],
  ]);

  await ctx.editMessageText(lines.join('\n'), { parse_mode: 'HTML', ...kb }).catch(() => {});
});

// زیرمنوی برق
composer.action('people:cat:power', async (ctx) => {
  await ctx.answerCbQuery().catch(() => {});
  const data = await requireCountry(ctx);
  if (!data) return;
  const { season, own } = data;
  const utils = await gameService.getCountryUtilities(own.countryId, season.id);

  const lines = [
    '⚡ <b>سامانه ملی شبکه توزیع برق</b>',
    '– – – – – – – – – –',
    `📊 درصد پوشش فعلی برق: <b>${fmtNum(utils.powerCoverage)}%</b>`,
    `⏱ ساعت قطعی برنامه‌ریزی‌شده: <b>${fmtNum(utils.powerOutage)} ساعت</b> (بیش از ۶ ساعت = افزایش نارضایتی)`,
    `💵 موجودی خزانه کشور: <b>${fmtNum(utils.state.treasury || 0)}$</b>`,
    `🛢 موجودی نفت خام: <b>${fmtNum(utils.state.oil || 0)} بشکه</b>`,
    '',
    'جهت مدیریت خاموشی یا احداث نیروگاه جدید کلیک فرمایید:',
  ];

  const kb = Markup.inlineKeyboard([
    [Markup.button.callback('🔌 قطع برق دلخواه (تنظیم ساعت)', 'people:outage:power')],
    [Markup.button.callback('💨 نیروگاه بادی (+۱۰٪ | ۲۵M$)', 'people:buy:power:wind')],
    [Markup.button.callback('☀️ برق خورشیدی (+۱۵٪ | ۴۰M$)', 'people:buy:power:solar')],
    [Markup.button.callback('🌊 سد برق‌آبی (+۳۰٪ | ۱۲۰M$)', 'people:buy:power:hydro_dam')],
    [Markup.button.callback('🏭 نیروگاه سوختی (+۲۵٪ | ۷۰M$ | روزانه ۲۰۰۰ بشکه نفت)', 'people:buy:power:fuel_plant')],
    [Markup.button.callback('☢️ نیروگاه اتمی (+۵۰٪ | ۳۵۰M$)', 'people:buy:power:nuclear')],
    [Markup.button.callback('🔙 بازگشت به منوی نیروگاه‌ها', 'people:plants_menu')],
  ]);

  await ctx.editMessageText(lines.join('\n'), { parse_mode: 'HTML', ...kb }).catch(() => {});
});

// زیرمنوی آب
composer.action('people:cat:water', async (ctx) => {
  await ctx.answerCbQuery().catch(() => {});
  const data = await requireCountry(ctx);
  if (!data) return;
  const { season, own } = data;
  const utils = await gameService.getCountryUtilities(own.countryId, season.id);

  const lines = [
    '💧 <b>سامانه آب و فاضلاب ملی</b>',
    '– – – – – – – – – –',
    `📊 درصد پوشش فعلی آب: <b>${fmtNum(utils.waterCoverage)}%</b>`,
    `⏱ ساعت قطعی برنامه‌ریزی‌شده: <b>${fmtNum(utils.waterOutage)} ساعت</b> (بیش از ۳ ساعت = افزایش نارضایتی)`,
    `💵 موجودی خزانه کشور: <b>${fmtNum(utils.state.treasury || 0)}$</b>`,
    '',
    'جهت اعمال قطعی یا احداث تاسیسات آبی جدید انتخاب نمایید:',
  ];

  const kb = Markup.inlineKeyboard([
    [Markup.button.callback('🚰 قطع آب دلخواه (تنظیم ساعت)', 'people:outage:water')],
    [Markup.button.callback('♻️ تصفیه آب فاضلاب (+۱۵٪ | ۳۰M$)', 'people:buy:water:wastewater')],
    [Markup.button.callback('🚰 چاه عمیق و آب زیرزمینی (+۲۵٪ | ۵۰M$)', 'people:buy:water:groundwater')],
    [Markup.button.callback('🌊 تصفیه آب دریا (+۴۰٪ | ۱۵۰M$)', 'people:buy:water:desalination')],
    [Markup.button.callback('🔙 بازگشت به منوی نیروگاه‌ها', 'people:plants_menu')],
  ]);

  await ctx.editMessageText(lines.join('\n'), { parse_mode: 'HTML', ...kb }).catch(() => {});
});

// زیرمنوی گاز
composer.action('people:cat:gas', async (ctx) => {
  await ctx.answerCbQuery().catch(() => {});
  const data = await requireCountry(ctx);
  if (!data) return;
  const { season, own } = data;
  const utils = await gameService.getCountryUtilities(own.countryId, season.id);

  const lines = [
    '⛽ <b>شبکه سراسری خطوط گاز کشور</b>',
    '– – – – – – – – – –',
    `📊 درصد پوشش فعلی گاز: <b>${fmtNum(utils.gasCoverage)}%</b>`,
    `⏱ ساعت قطعی برنامه‌ریزی‌شده: <b>${fmtNum(utils.gasOutage)} ساعت</b> (بیش از ۴ ساعت = افزایش نارضایتی)`,
    `💵 موجودی خزانه کشور: <b>${fmtNum(utils.state.treasury || 0)}$</b>`,
    `🛢 تعداد دکل‌های فعال: <b>${fmtNum(utils.state.oilRigs || 0)} دکل</b>`,
    '',
    'جهت اعمال قطعی یا احداث تاسیسات گازی انتخاب نمایید:',
  ];

  const kb = Markup.inlineKeyboard([
    [Markup.button.callback('🔥 قطع گاز دلخواه (تنظیم ساعت)', 'people:outage:gas')],
    [Markup.button.callback('⛽ مخازن ذخیره‌سازی گاز (+۲۰٪ | ۴۵M$)', 'people:buy:gas:gas_storage')],
    [Markup.button.callback('🔥 جمع‌آوری گاز مشعل نفت (+۳۵٪ | ۸۵M$ | نیازمند ۵ دکل)', 'people:buy:gas:flare_gas_capture')],
    [Markup.button.callback('🔙 بازگشت به منوی نیروگاه‌ها', 'people:plants_menu')],
  ]);

  await ctx.editMessageText(lines.join('\n'), { parse_mode: 'HTML', ...kb }).catch(() => {});
});

// خرید نیروگاه
composer.action(/^people:buy:([a-z]+):([a-z_]+)$/, async (ctx) => {
  await ctx.answerCbQuery().catch(() => {});
  const [category, plantKey] = [ctx.match[1], ctx.match[2]];
  const data = await requireCountry(ctx);
  if (!data) return;

  try {
    const res = await gameService.buyUtilityPlant(data.own.countryId, data.season.id, category, plantKey);
    await ctx.reply([
      `🎉 <b>احداث موفق تاسیسات: ${res.plant.emoji} ${res.plant.name}</b>`,
      '– – – – – – – – – –',
      `➕ افزایش پوشش شبکه: <b>+${fmtNum(res.plant.coverage)}%</b>`,
      `💰 هزینه پرداخت‌شده: <b>${fmtNum(res.cost)}$</b>`,
      `🏦 موجودی باقیمانده خزانه: <b>${fmtNum(res.remainingTreasury)}$</b>`,
      `تعداد کل فعال از این نوع: <b>${fmtNum(res.count)} واحد</b>`,
    ].join('\n'), {
      parse_mode: 'HTML',
      ...Markup.inlineKeyboard([[Markup.button.callback('🔙 بازگشت به خدمات عمومی', 'emp:people')]]),
    });
  } catch (err) {
    await ctx.reply(`❌ خطا: ${esc(err.message)}`);
  }
});

// تنظیم قطعی دلخواه
composer.action(/^people:outage:([a-z]+)$/, async (ctx) => {
  await ctx.answerCbQuery().catch(() => {});
  const category = ctx.match[1];
  const catNames = { power: 'برق', water: 'آب', gas: 'گاز' };
  const limits = { power: 6, water: 3, gas: 4 };

  await userService.setFlow(ctx.from.id, `game:outage:${category}`);
  await ctx.reply([
    `⏱ <b>تنظیم ساعات قطعی سراسری ${catNames[category]}</b>`,
    '– – – – – – – – – –',
    `سقف مجاز قطعی بدون شورش: <b>${limits[category]} ساعت</b>`,
    'اگر ساعت قطعی فراتر از سقف مجاز باشد، نارضایتی مردم تصاعدی بالا خواهد رفت.',
    '',
    'لطفاً <b>تعداد ساعات قطعی</b> مورد نظر را به انگلیسی یا فارسی ارسال نمایید:',
    '<i>(مثال: 4 یا 8 یا 12)</i>',
    'جهت انصراف: /cancel',
  ].join('\n'), { parse_mode: 'HTML' });
});

for (const cat of ['power', 'water', 'gas']) {
  registerFlow(`game:outage:${cat}`, async (ctx) => {
    const hours = parseNonNegInt(ctx.message?.text);
    if (hours === null) return ctx.reply('⚠️ لطفاً یک عدد معتبر ارسال کنید. لغو: /cancel');

    const data = await requireCountry(ctx);
    if (!data) return;

    try {
      const res = await gameService.setUtilityOutage(data.own.countryId, data.season.id, cat, hours);
      await userService.clearFlow(ctx.from.id);

      const catNames = { power: 'برق', water: 'آب', gas: 'گاز' };
      const lines = [
        `✅ <b>ساعات قطعی ${catNames[cat]} با موفقیت تنظیم شد</b>`,
        '– – – – – – – – – –',
        `⏱ میزان قطعی اعمال‌شده: <b>${fmtNum(res.hours)} ساعت</b>`,
        `📉 جریمه افت رضایت: <b>-${fmtNum(res.penalty)}%</b>`,
        `😊 شاخص رضایت جدید مردم: <b>${fmtNum(res.newSatisfaction)}%</b>`,
        `😡 شاخص نارضایتی عمومی: <b>${fmtNum(res.dissatisfaction)}%</b>`,
      ];

      if (res.rebellionTriggered) {
        lines.push('', '🚨 <b>هشدار امنیتی: مردم در اثر قطعی مکرر به خیابان‌ها ریخته و شورش کردند!</b>');
      }

      await ctx.reply(lines.join('\n'), {
        parse_mode: 'HTML',
        ...Markup.inlineKeyboard([
          [Markup.button.callback('🛡 سرکوب شورش', 'people:quell_menu')],
          [Markup.button.callback('🔙 بخش مردم', 'emp:people')],
        ]),
      });
    } catch (err) {
      await ctx.reply(`❌ خطا: ${esc(err.message)}`);
    }
  });
}

// منوی سرکوب شورش
composer.action('people:quell_menu', async (ctx) => {
  await ctx.answerCbQuery().catch(() => {});
  const data = await requireCountry(ctx);
  if (!data) return;
  const { season, own } = data;

  const utils = await gameService.getCountryUtilities(own.countryId, season.id);
  const lines = [
    '🛡 <b>ستاد ویژه مقابله با بحران و مهار شورش‌های مردمی</b>',
    '– – – – – – – – – –',
    `😡 شاخص نارضایتی عمومی: <b>${fmtNum(utils.dissatisfaction)}%</b>`,
    `🚨 جمعیت شورشیان در خیابان: <b>${fmtNum(utils.rebelRatio)}%</b>`,
    `💵 موجودی خزانه دولت: <b>${fmtNum(utils.state.treasury || 0)}$</b>`,
    '',
    '⚠️ در صورت دفع نشدن شورش، هر ۱۰ دقیقه درصد شورشیان افزایش یافته و کشور به سمت سقوط کامل پیش می‌رود.',
    '',
    'یک شیوه مهار و سرکوب را انتخاب فرمایید:',
  ];

  const kb = Markup.inlineKeyboard([
    [Markup.button.callback('👮 ۱. استقرار پلیس و یگان ویژه (۳۵M$)', 'people:quell:police')],
    [Markup.button.callback('⚔️ ۲. کشتن شورشی‌ها و سرکوب قهرآمیز ارتش (۶۰M$)', 'people:quell:military')],
    [Markup.button.callback('📜 ۳. پیام عذرخواهی رسمی دولت (۵M$)', 'people:quell:apology')],
    [Markup.button.callback('🕊 ۴. تشکیل شورای اصلاحات ملی و عفو عمومی (۵۰M$)', 'people:quell:reform_amnesty')],
    [Markup.button.callback('🔙 بازگشت به بخش مردم', 'emp:people')],
  ]);

  await ctx.editMessageText(lines.join('\n'), { parse_mode: 'HTML', ...kb }).catch(() => {});
});

// اجرای سرکوب شورش
composer.action(/^people:quell:([a-z_]+)$/, async (ctx) => {
  await ctx.answerCbQuery().catch(() => {});
  const method = ctx.match[1];
  const data = await requireCountry(ctx);
  if (!data) return;

  try {
    const res = await gameService.quellRebellion(data.own.countryId, data.season.id, method);
    await ctx.reply([
      `⚖️ <b>حکم مهار بحران اجرا شد: ${esc(res.title)}</b>`,
      '– – – – – – – – – –',
      `💬 نتیجه میدانی: ${esc(res.resultMsg)}`,
      `💰 هزینه عملیاتی: <b>${fmtNum(res.cost)}$</b>`,
      `🏦 موجودی باقیمانده خزانه: <b>${fmtNum(res.remainingTreasury)}$</b>`,
      `😊 رضایت عمومی جدید: <b>${fmtNum(res.newSatisfaction)}%</b>`,
      res.rebellionActive ? '⚠️ شورش هنوز کاملاً خاموش نشده است.' : '✅ وضعیت خیابان‌ها به طور کامل آرام و شورش خاموش شد.',
    ].join('\n'), {
      parse_mode: 'HTML',
      ...Markup.inlineKeyboard([[Markup.button.callback('🔙 بازگشت به بخش مردم', 'emp:people')]]),
    });
  } catch (err) {
    await ctx.reply(`❌ خطا: ${esc(err.message)}`);
  }
});

// =============================================================
// ۲. بخش ساخت‌وساز، پژوهش، بورس، شرکت‌های اختصاصی و رسانه
// =============================================================
composer.action(['emp:construction', 'emp:research', 'emp:companies'], async (ctx) => {
  await ctx.answerCbQuery().catch(() => {});
  await showConstructionPanel(ctx, true);
});
composer.hears(['ساخت و ساز 🏗️', 'پژوهش', 'تحقیقات 🔬', 'شرکت‌ها 🏢', 'ساخت و ساز و پروژه‌ها 🏗️'], async (ctx) => {
  await showConstructionPanel(ctx, false);
});

async function showConstructionPanel(ctx, isEdit = false) {
  const data = await requireCountry(ctx);
  if (!data) return;
  const { season, own } = data;

  if (ctx.state.isMinister && ctx.state.ministerRole === 'war') {
    return ctx.reply('⛔ عدم دسترسی: به عنوان وزیر جنگ، اختیارات شما منحصر به امور نظامی و سایبری است و مدیریت ساخت‌وساز و پروژه‌ها در حیطه وزیر اقتصاد است.');
  }

  const state = await gameService.getCountryState(own.countryId, season.id);
  const flag = countryService.getDynamicFlag(own.country, state);

  const lines = [
    `🏗 <b>ساخت‌وساز، پژوهش و توسعه علم ملی — ${esc(own.country.name)} ${flag}</b>`,
    '– – – – – – – – – –',
    `🔬 امتیاز علم و پژوهش کشور (Science Level): <b>${fmtNum(state.scienceScore || 10)} امتیاز</b>`,
    `📶 نسل شبکه اینترنت ملی: <b>${state.internet || '3G'}</b>`,
    `💵 موجودی خزانه: <b>${fmtNum(state.treasury || 0)}$</b>`,
    '',
    '<i>هر کدام از پروژه‌ها و شرکت‌ها امتیاز علم کشور را ارتقا داده و زمینه تحقیقات پیشرفته آینده را فراهم می‌کنند.</i>',
  ];

  const kb = Markup.inlineKeyboard([
    [Markup.button.callback('📈 ۱. خرید سهام شرکت‌های معتبر (بورس ۳ ساعته)', 'const:stocks')],
    [Markup.button.callback('🏢 ۲. ساخت شرکت اختصاصی (۵ صنعت)', 'const:enterprises')],
    [Markup.button.callback('🗼 ۳. پروژه‌های بزرگ ملی (مگاپروژه‌ها)', 'const:megaprojects')],
    [Markup.button.callback('📡 ۴. رسانه، ویدیو و اینترنت ملی', 'const:media_telecom')],
    [Markup.button.callback('🔙 بازگشت به امپراطوری', 'emp:home')],
  ]);

  if (isEdit && ctx.callbackQuery) {
    await ctx.editMessageText(lines.join('\n'), { parse_mode: 'HTML', ...kb }).catch(() => {});
  } else {
    await ctx.reply(lines.join('\n'), { parse_mode: 'HTML', ...kb });
  }
}

// الف) بورس سهام
composer.action('const:stocks', async (ctx) => {
  await ctx.answerCbQuery().catch(() => {});
  const data = await requireCountry(ctx);
  if (!data) return;
  const { season, own } = data;

  const market = await gameService.getStockMarket(season.id);
  const state = await gameService.getCountryState(own.countryId, season.id);
  const shares = state.stockShares || {};

  const lines = [
    '📈 <b>تالار بورس سهام بین‌المللی</b>',
    '– – – – – – – – – –',
    'قیمت سهام و درصد سود/زیان هر ۳ ساعت یک‌بار بروزرسانی می‌شود.',
    `💵 بودجه خزانه: <b>${fmtNum(state.treasury || 0)}$</b>`,
    '',
  ];

  const rows = [];
  for (const [k, s] of Object.entries(market || {})) {
    if (!s) continue;
    const owned = shares[k] || 0;
    const sign = (s.growth || 0) >= 0 ? '+' : '';
    const isMajority = owned >= 510;
    lines.push(`${s.emoji || '📈'} <b>${s.name}</b> (${s.sector || 'بورس'})`);
    lines.push(`   قیمت: <b>${fmtNum(s.price)}$</b> | نوسان: <b>${sign}${s.growth}%</b> | دارایی شما: <b>${fmtNum(owned)} سهم</b> (از ۱۰۰۰) ${isMajority ? '👑 <b>(مالک اکثریت ۵۱٪+)</b>' : ''}`);
    const btnRow = [Markup.button.callback(`خرید سهام ${s.name}`, `const:buy_stock:${k}`)];
    if (isMajority) {
      btnRow.push(Markup.button.callback('👑 مدیریت ۵۱٪+', `const:ctrl:${k}`));
    }
    rows.push(btnRow);
  }
  rows.push([Markup.button.callback('🔙 بازگشت به ساخت‌وساز', 'emp:construction')]);

  await ctx.editMessageText(lines.join('\n'), { parse_mode: 'HTML', ...Markup.inlineKeyboard(rows) }).catch(() => {});
});

// کنترل و هدایت ۵۱٪ سهامدار عمده
composer.action(/^const:ctrl:([a-z_]+)$/, async (ctx) => {
  await ctx.answerCbQuery().catch(() => {});
  const stockKey = ctx.match[1];
  const data = await requireCountry(ctx);
  if (!data) return;
  const { season, own } = data;

  const market = await gameService.getStockMarket(season.id);
  const stock = market[stockKey];
  const state = await gameService.getCountryState(own.countryId, season.id);
  const owned = (state.stockShares || {})[stockKey] || 0;
  const pct = Math.min(100, Math.floor((owned / 1000) * 100));

  if (pct < 51) {
    return ctx.reply(`⚠️ شما دارای ${owned} سهم (${pct}٪) هستید. اختیارات اکثریت فقط برای مالکان ۵۱٪ و بالاتر فعال است.`);
  }

  const text = [
    `👑 <b>مرکز مدیریت سهامدار عمده — ${stock.emoji} ${esc(stock.name)}</b>`,
    '– – – – – – – – – –',
    `حوزه فعالیت فعلی: <b>${esc(stock.sector)}</b>`,
    `مالکیت رسمی شما: <b>${fmtNum(owned)} سهم از ۱۰۰۰ (${pct}٪)</b>`,
    '',
    'به عنوان سهامدار عمده و صاحب کرسی ریاست، شما از اختیارات زیر برخوردارید:',
    '۱. تغییر نام شرکت در کل بازارهای جهانی',
    '۲. تغییر حوزه صنعت و ماموریت تجاری شرکت',
  ].join('\n');

  await ctx.editMessageText(text, {
    parse_mode: 'HTML',
    reply_markup: Markup.inlineKeyboard([
      [Markup.button.callback('✏️ تغییر نام شرکت', `const:rename:${stockKey}`)],
      [Markup.button.callback('🔄 تغییر زمینه فعالیت و صنعت', `const:sector:${stockKey}`)],
      [Markup.button.callback('🔙 بازگشت به تالار بورس', 'const:stocks')],
    ]).reply_markup,
  }).catch(() => {});
});

// تغییر نام شرکت با اکثریت ۵۱٪
composer.action(/^const:rename:([a-z_]+)$/, async (ctx) => {
  await ctx.answerCbQuery().catch(() => {});
  const stockKey = ctx.match[1];
  await userService.setFlow(ctx.from.id, `game:stock_rename:${stockKey}`);
  await ctx.reply([
    '✏️ <b>تغییر نام رسمی شرکت بین‌المللی</b>',
    '– – – – – – – – – –',
    'لطفاً <b>نام جدید شرکت</b> را ارسال فرمایید (حداکثر ۵۰ کاراکتر):',
    'جهت انصراف: /cancel',
  ].join('\n'), { parse_mode: 'HTML' });
});

registerFlow(/^game:stock_rename:([a-z_]+)$/, async (ctx, match) => {
  const stockKey = match[1];
  const newName = String(ctx.message?.text || '').trim();
  if (!newName || newName.length < 2 || newName.length > 50) {
    return ctx.reply('⚠️ نام شرکت باید بین ۲ تا ۵۰ کاراکتر باشد. لغو: /cancel');
  }

  const data = await requireCountry(ctx);
  if (!data) return;

  try {
    const res = await constructionService.controlStockEnterprise(
      data.own.countryId,
      data.season.id,
      stockKey,
      { newName },
      gameService
    );
    await userService.clearFlow(ctx.from.id);

    // اعلام عمومی در کانال رسمی
    const chanAlert = [
      '🏢 <b>تصمیم هیئت‌مدیره اکثریت بورس جهانی!</b>',
      '– – – – – – – – – –',
      `کشور <b>${data.own.country.flag} ${esc(data.own.country.name)}</b> به عنوان سهامدار ۵۱٪+، نام شرکت را رسماً به <b>«${esc(newName)}»</b> تغییر داد.`,
    ].join('\n');
    await notifications.publishToChannel(ctx.telegram, 'announcement', chanAlert).catch(() => {});

    await ctx.reply(`🎉 <b>نام شرکت با موفقیت به «${esc(newName)}» تغییر یافت!</b>`, {
      parse_mode: 'HTML',
      ...Markup.inlineKeyboard([[Markup.button.callback('📈 تالار بورس', 'const:stocks')]]),
    });
  } catch (err) {
    await ctx.reply(`❌ خطا: ${esc(err.message)}`);
  }
});

// تغییر زمینه صنعت شرکت با اکثریت ۵۱٪
composer.action(/^const:sector:([a-z_]+)$/, async (ctx) => {
  await ctx.answerCbQuery().catch(() => {});
  const stockKey = ctx.match[1];
  await userService.setFlow(ctx.from.id, `game:stock_sector:${stockKey}`);
  await ctx.reply([
    '🔄 <b>تغییر صنعت و ماموریت تجاری شرکت</b>',
    '– – – – – – – – – –',
    'لطفاً <b>نام صنعت جدید</b> را ارسال فرمایید:',
    '<i>(مثال: فناوری‌های فضایی و موشکی، پتروشیمی پیشرفته، انرژی‌های پاک، هوش مصنوعی)</i>',
    'جهت انصراف: /cancel',
  ].join('\n'), { parse_mode: 'HTML' });
});

registerFlow(/^game:stock_sector:([a-z_]+)$/, async (ctx, match) => {
  const stockKey = match[1];
  const newSector = String(ctx.message?.text || '').trim();
  if (!newSector || newSector.length < 2 || newSector.length > 40) {
    return ctx.reply('⚠️ عنوان صنعت باید بین ۲ تا ۴۰ کاراکتر باشد. لغو: /cancel');
  }

  const data = await requireCountry(ctx);
  if (!data) return;

  try {
    const res = await constructionService.controlStockEnterprise(
      data.own.countryId,
      data.season.id,
      stockKey,
      { newSector },
      gameService
    );
    await userService.clearFlow(ctx.from.id);

    // اعلام عمومی در کانال رسمی
    const chanAlert = [
      '🌐 <b>تغییر ماموریت صنعتی شرکت در بورس جهانی!</b>',
      '– – – – – – – – – –',
      `کشور <b>${data.own.country.flag} ${esc(data.own.country.name)}</b> به عنوان مالک اکثریت سهام، صنعت شرکت <b>${res.stock.name}</b> را به <b>«${esc(newSector)}»</b> تغییر داد.`,
    ].join('\n');
    await notifications.publishToChannel(ctx.telegram, 'announcement', chanAlert).catch(() => {});

    await ctx.reply(`🎉 <b>صنعت شرکت با موفقیت به «${esc(newSector)}» تغییر یافت!</b>`, {
      parse_mode: 'HTML',
      ...Markup.inlineKeyboard([[Markup.button.callback('📈 تالار بورس', 'const:stocks')]]),
    });
  } catch (err) {
    await ctx.reply(`❌ خطا: ${esc(err.message)}`);
  }
});

// خرید سهم با تعداد دلخواه
composer.action(/^const:buy_stock:([a-z_]+)$/, async (ctx) => {
  await ctx.answerCbQuery().catch(() => {});
  const stockKey = ctx.match[1];
  await userService.setFlow(ctx.from.id, `game:stock_buy:${stockKey}`);
  await ctx.reply([
    '📊 <b>خرید سهام شرکت در بورس</b>',
    '– – – – – – – – – –',
    'لطفاً <b>تعداد سهم</b> مورد نظر برای خرید را به صورت عدد ارسال فرمایید:',
    '<i>(مثال: 10 یا 100 یا 500)</i>',
    'جهت انصراف: /cancel',
  ].join('\n'), { parse_mode: 'HTML' });
});

registerFlow(/^game:stock_buy:([a-z_]+)$/, async (ctx, match) => {
  const stockKey = match[1];
  const qty = parseNonNegInt(ctx.message?.text);
  if (!qty || qty <= 0) return ctx.reply('⚠️ لطفاً یک تعداد سهم معتبر ارسال کنید. لغو: /cancel');

  const data = await requireCountry(ctx);
  if (!data) return;

  try {
    const res = await gameService.buyStockShares(data.own.countryId, data.season.id, stockKey, qty);
    await userService.clearFlow(ctx.from.id);
    await ctx.reply([
      `✅ <b>تعداد ${fmtNum(res.qty)} سهم از شرکت «${esc(res.stock.name)}» خریداری شد!</b>`,
      '– – – – – – – – – –',
      `💰 کل مبلغ پرداختی: <b>${fmtNum(res.totalCost)}$</b>`,
      `📈 مجموع سهام شما در این شرکت: <b>${fmtNum(res.totalShares)} سهم</b>`,
      `🔬 امتیاز علمی کسب‌شده: <b>+${fmtNum(res.scienceGain)} علم</b>`,
      `🏦 موجودی باقیمانده خزانه: <b>${fmtNum(res.remainingTreasury)}$</b>`,
    ].join('\n'), {
      parse_mode: 'HTML',
      ...Markup.inlineKeyboard([[Markup.button.callback('📈 تالار بورس', 'const:stocks')]]),
    });
  } catch (err) {
    await ctx.reply(`❌ خطا: ${esc(err.message)}`);
  }
});

// ب) شرکت‌های اختصاصی
composer.action('const:enterprises', async (ctx) => {
  await ctx.answerCbQuery().catch(() => {});
  const data = await requireCountry(ctx);
  if (!data) return;
  const { season, own } = data;

  const state = await gameService.getCountryState(own.countryId, season.id);
  const enterprises = state.customEnterprises || [];

  const lines = [
    '🏢 <b>شرکت‌های اختصاصی و بنگاه‌های اقتصادی کشور</b>',
    '– – – – – – – – – –',
    `تعداد شرکت‌های ثبت‌شده: <b>${fmtNum(enterprises.length)} شرکت</b>`,
    '',
  ];

  const rows = [];
  if (enterprises.length > 0) {
    lines.push('📋 <b>شرکت‌های فعال شما:</b>');
    for (const ent of enterprises) {
      lines.push(`${ent.logo} <b>${esc(ent.name)}</b> (صنعت: ${esc(ent.categoryName)} | سطح ${fmtNum(ent.tier)})`);
      lines.push(`   درآمد هر چرخه: <b>+${fmtNum(ent.cycleIncome)}$</b> | امتیاز علم: <b>+${fmtNum(ent.scienceScore)}</b>`);
      if (ent.tier < 5) {
        rows.push([Markup.button.callback(`⬆️ ارتقای ${ent.name} به سطح ${ent.tier + 1}`, `const:up_ent:${ent.id}`)]);
      }
    }
    lines.push('');
  }

  lines.push('➕ جهت تاسیس شرکت جدید یکی از ۵ صنعت زیر را انتخاب نمایید:');
  const cats = gameService.ENTERPRISE_CATEGORIES || require('../services/constructionService').ENTERPRISE_CATEGORIES || {};
  for (const [ck, c] of Object.entries(cats || {})) {
    if (!c) continue;
    const btnLabel = `${c.emoji || '🏢'} ${c.shortName || c.name} (${fmtNum(c.baseCost || 0)}$)`;
    rows.push([Markup.button.callback(btnLabel, `const:new_ent:${ck}`)]);
  }
  rows.push([Markup.button.callback('🔙 بازگشت به ساخت‌وساز', 'emp:construction')]);

  await ctx.editMessageText(lines.join('\n'), { parse_mode: 'HTML', ...Markup.inlineKeyboard(rows) }).catch(() => {});
});

// ایجاد شرکت جدید: نمایش مشخصات کامل، هزینه و مصالح موردنیاز
composer.action(/^const:new_ent:([a-z0-9_]+)$/, async (ctx) => {
  await ctx.answerCbQuery().catch(() => {});
  const cat = ctx.match[1];
  const catDef = gameService.ENTERPRISE_CATEGORIES[cat];
  if (!catDef) return ctx.reply('صنعت مورد نظر یافت نشد.');

  await userService.setFlow(ctx.from.id, `game:ent_name:${cat}`);

  const matLines = Object.entries(catDef.materials || catDef.requiredMaterials || {})
    .map(([m, qty]) => {
      const matNames = { steel: 'فولاد 🏗️', iron: 'آهن ⛏️', copper: 'مس 🪙', wood: 'چوب 🪵', cement: 'سیمان 🧱', oil: 'نفت خام 🛢️' };
      return `• ${matNames[m] || m}: <b>${fmtNum(qty)} واحد</b>`;
    }).join('\n');

  await ctx.reply([
    `🏢 <b>تاسیس شرکت جدید: ${catDef.name}</b>`,
    '– – – – – – – – – –',
    `📖 شرح: <i>${catDef.desc || 'سرمایه‌گذاری راهبردی در خطوط تولید ملی'}</i>`,
    `💰 هزینه تاسیس: <b>${fmtNum(catDef.baseCost)}$</b>`,
    `💵 درآمد دوره‌ای پایه: <b>+${fmtNum(catDef.baseIncome)}$</b>`,
    '',
    '📦 <b>مصالح و مواد اولیه مورد نیاز از بازار جهانی:</b>',
    matLines || 'بدون نیاز به مصالح اولیه',
    '– – – – – – – – – –',
    '✍️ لطفاً <b>نام اختصاصی شرکت</b> خود را ارسال فرمایید:',
    '<i>(مثال: صنایع الکترونیک البرز، داروسازی سینا، پتروشیمی خلیج)</i>',
    '',
    'جهت انصراف: /cancel',
  ].join('\n'), { parse_mode: 'HTML' });
});

registerFlow(/^game:ent_name:([a-z0-9_]+)$/, async (ctx, match) => {
  const cat = match[1];
  const name = String(ctx.message?.text || '').trim();
  if (!name || name.length < 2) return ctx.reply('⚠️ نام شرکت باید حداقل ۲ حرف باشد. لغو: /cancel');

  await userService.setFlow(ctx.from.id, `game:ent_logo:${cat}`, { name });
  await ctx.reply([
    `✅ نام شرکت: <b>${esc(name)}</b>`,
    'حال لطفاً <b>یک ایموجی یا آیکون دلخواه</b> به عنوان لوگوی شرکت ارسال کنید:',
    '<i>(مثال: 🚀 یا 💎 یا 🏎 یا 📱 یا ⚡)</i>',
  ].join('\n'), { parse_mode: 'HTML' });
});

registerFlow(/^game:ent_logo:([a-z0-9_]+)$/, async (ctx, match, data) => {
  const cat = match[1];
  const logo = String(ctx.message?.text || '🏢').trim().slice(0, 5);
  const name = data?.name || 'شرکت ملی';

  const userCountryData = await requireCountry(ctx);
  if (!userCountryData) return;

  try {
    const res = await gameService.createCustomEnterprise(userCountryData.own.countryId, userCountryData.season.id, {
      category: cat,
      name,
      logo,
    });
    await userService.clearFlow(ctx.from.id);
    await ctx.reply([
      `🎉 <b>شرکت «${res.enterprise.logo} ${esc(res.enterprise.name)}» با موفقیت ثبت و راه‌اندازی شد!</b>`,
      '– – – – – – – – – –',
      `💼 صنعت: <b>${esc(res.enterprise.categoryName)}</b>`,
      `💰 هزینه تاسیس: <b>${fmtNum(res.cost)}$</b>`,
      `💵 درآمد دوره‌ای تضمین‌شده: <b>+${fmtNum(res.enterprise.cycleIncome)}$</b>`,
      `🔬 امتیاز علمی افزوده شده: <b>+${fmtNum(res.enterprise.scienceScore)} علم</b>`,
      `🏦 موجودی باقیمانده خزانه: <b>${fmtNum(res.remainingTreasury)}$</b>`,
    ].join('\n'), {
      parse_mode: 'HTML',
      ...Markup.inlineKeyboard([[Markup.button.callback('🏢 فهرست شرکت‌ها', 'const:enterprises')]]),
    });
  } catch (err) {
    await ctx.reply(`❌ خطا در ثبت شرکت: ${esc(err.message)}`);
  }
});

// ارتقای شرکت
composer.action(/^const:up_ent:([a-z0-9_]+)$/, async (ctx) => {
  await ctx.answerCbQuery().catch(() => {});
  const entId = ctx.match[1];
  const data = await requireCountry(ctx);
  if (!data) return;

  try {
    const res = await gameService.upgradeEnterprise(data.own.countryId, data.season.id, entId);
    await ctx.reply([
      `⬆️ <b>شرکت «${res.enterprise.logo} ${esc(res.enterprise.name)}» به سطح ${fmtNum(res.enterprise.tier)} ارتقا یافت!</b>`,
      '– – – – – – – – – –',
      `💰 هزینه ارتقا: <b>${fmtNum(res.upgradeCost)}$</b>`,
      `💵 درآمد دوره‌ای جدید: <b>+${fmtNum(res.enterprise.cycleIncome)}$</b>`,
      `🔬 امتیاز علم ملی: <b>+10 علم</b>`,
      `🏦 موجودی باقیمانده خزانه: <b>${fmtNum(res.remainingTreasury)}$</b>`,
    ].join('\n'), {
      parse_mode: 'HTML',
      ...Markup.inlineKeyboard([[Markup.button.callback('🏢 فهرست شرکت‌ها', 'const:enterprises')]]),
    });
  } catch (err) {
    await ctx.reply(`❌ خطا: ${esc(err.message)}`);
  }
});

// ج) پروژه‌های بزرگ ملی (Megaprojects) با نام‌های کوتاه در دکمه‌ها و پیش‌نمایش مصالح
composer.action('const:megaprojects', async (ctx) => {
  await ctx.answerCbQuery().catch(() => {});
  const data = await requireCountry(ctx);
  if (!data) return;
  const { season, own } = data;

  const state = await gameService.getCountryState(own.countryId, season.id);
  const built = state.megaprojects || [];

  const lines = [
    '🗼 <b>پروژه‌های بزرگ و افتخارات تمدنی ملی</b>',
    '– – – – – – – – – –',
    'احداث این پروژه‌ها امتیاز علم و فناوری کشور را به طور چشمگیری افزایش می‌دهد:',
    `💵 بودجه خزانه: <b>${fmtNum(state.treasury || 0)}$</b>`,
    '',
  ];

  const rows = [];
  const projs = gameService.MEGAPROJECTS || require('../services/constructionService').DEFAULT_MEGAPROJECTS || {};
  for (const [pk, p] of Object.entries(projs || {})) {
    if (!p) continue;
    const isBuilt = built.includes(pk);
    lines.push(`${p.emoji || '🏗'} <b>${p.name}</b> ${isBuilt ? '✅ (احداث شده)' : ''}`);
    lines.push(`   هزینه: <b>${fmtNum(p.cost)}$</b> | جهش علم: <b>+${fmtNum(p.science)} امتیاز</b>`);
    lines.push(`   توضیح: <i>${p.desc}</i>`);
    if (!isBuilt) {
      const btnText = `${p.emoji || '🏗'} احداث ${p.shortName || p.name} (${fmtNum(p.cost)}$)`;
      rows.push([Markup.button.callback(btnText, `const:do_mega:${pk}`)]);
    }
  }
  rows.push([Markup.button.callback('🔙 بازگشت به ساخت‌وساز', 'emp:construction')]);

  await ctx.editMessageText(lines.join('\n'), { parse_mode: 'HTML', ...Markup.inlineKeyboard(rows) }).catch(() => {});
});

// پیش‌نمایش و تایید احداث مگاپروژه
composer.action(/^const:do_mega:([a-z_]+)$/, async (ctx) => {
  await ctx.answerCbQuery().catch(() => {});
  const pk = ctx.match[1];
  const data = await requireCountry(ctx);
  if (!data) return;

  const allProjs = gameService.MEGAPROJECTS || require('../services/constructionService').DEFAULT_MEGAPROJECTS || {};
  const proj = allProjs[pk];
  if (!proj) return ctx.reply('پروژه مورد نظر یافت نشد.');

  const matNames = { steel: 'فولاد 🏗️', iron: 'آهن ⛏️', copper: 'مس 🪙', wood: 'چوب 🪵', cement: 'سیمان 🧱', oil: 'نفت خام 🛢️' };
  const matLines = Object.entries(proj.materials || proj.requiredMaterials || {})
    .map(([m, qty]) => `• ${matNames[m] || m}: <b>${fmtNum(qty)} واحد</b>`)
    .join('\n');

  const text = [
    `🗼 <b>پیش‌نمایش احداث پروژه ملی: ${proj.name} ${proj.emoji}</b>`,
    '– – – – – – – – – –',
    `📖 شرح پروژه: <i>${proj.desc}</i>`,
    `💰 هزینه مالی احداث: <b>${fmtNum(proj.cost)}$</b>`,
    `🔬 ارتقای علم و فناوری ملی: <b>+${fmtNum(proj.science)} امتیاز</b>`,
    '',
    '📦 <b>مصالح ساختمانی و منابع مورد نیاز (از انبار کشور):</b>',
    matLines,
    '',
    '⚠️ در زمان تایید، بودجه و مصالح به صورت اتمیک از حساب کشور کسر خواهد شد.',
  ].join('\n');

  const kb = Markup.inlineKeyboard([
    [Markup.button.callback('✅ تایید نهایی و شروع احداث پروژه', `const:mega_confirm:${pk}`)],
    [Markup.button.callback('🔙 بازگشت به پروژه‌ها', 'const:megaprojects')],
  ]);

  await ctx.editMessageText(text, { parse_mode: 'HTML', reply_markup: kb.reply_markup }).catch(() => {});
});

// احداث قطعی مگاپروژه با قفل همزمانی
composer.action(/^const:mega_confirm:([a-z_]+)$/, async (ctx) => {
  await ctx.answerCbQuery().catch(() => {});
  const pk = ctx.match[1];
  const data = await requireCountry(ctx);
  if (!data) return;

  try {
    const res = await gameService.buildMegaproject(data.own.countryId, data.season.id, pk);
    await ctx.reply([
      `🎉 <b>افتخار ملی: مگاپروژه «${res.project.emoji} ${res.project.name}» با موفقیت افتتاح شد!</b>`,
      '– – – – – – – – – –',
      `🔬 جهش علم و فناوری: <b>+${fmtNum(res.project.science)} امتیاز علم</b> (سطح جدید: ${fmtNum(res.newScience)})`,
      `💰 بودجه مصرفی: <b>${fmtNum(res.project.cost)}$</b>`,
      `🏦 موجودی باقیمانده خزانه: <b>${fmtNum(res.remainingTreasury)}$</b>`,
    ].join('\n'), {
      parse_mode: 'HTML',
      ...Markup.inlineKeyboard([[Markup.button.callback('🗼 مگاپروژه‌ها', 'const:megaprojects')]]),
    });
  } catch (err) {
    await ctx.reply(`❌ خطا در احداث مگاپروژه: ${esc(err.message)}`, {
      ...Markup.inlineKeyboard([[Markup.button.callback('🔙 بازگشت به پروژه‌ها', 'const:megaprojects')]]),
    });
  }
});

// د) رسانه و اینترنت
composer.action('const:media_telecom', async (ctx) => {
  await ctx.answerCbQuery().catch(() => {});
  const data = await requireCountry(ctx);
  if (!data) return;
  const { season, own } = data;

  const state = await gameService.getCountryState(own.countryId, season.id);
  const operator = state.telecomOperator;

  const lines = [
    '📡 <b>زیرساخت ارتباطات، رسانه و اینترنت ملی</b>',
    '– – – – – – – – – –',
    `📶 نسل فعلی اینترنت کشور: <b>${state.internet || '3G'}</b>`,
    `🏢 اپراتور ملی اختصاصی: <b>${operator ? `${operator.logo} ${esc(operator.name)}` : 'هنوز ثبت نشده'}</b>`,
  ];

  if (operator) {
    lines.push(`   مشترکین فعال: <b>${fmtNum(operator.subscribers)} نفر</b> | درآمد هر چرخه: <b>+${fmtNum(operator.cycleDividend)}$</b>`);
  }

  lines.push('');
  lines.push('امکانات رسانه‌ای و مخابراتی قابل ارتقا:');

  const rows = [
    [Markup.button.callback(`📶 ارتقای نسل اینترنت (${state.internet || '3G'} ➔ پیشرفته‌تر)`, 'const:up_internet')],
    [Markup.button.callback('📹 انتشار پست ویدیویی رسانه‌ای (هر ۱۰ دقیقه)', 'const:post_video')],
  ];

  if (!operator) {
    rows.push([Markup.button.callback('📱 ساخت اپراتور اینترنت اختصاصی (۱۲۰M$)', 'const:create_operator')]);
  }

  rows.push([Markup.button.callback('🔙 بازگشت به ساخت‌وساز', 'emp:construction')]);

  await ctx.editMessageText(lines.join('\n'), { parse_mode: 'HTML', ...Markup.inlineKeyboard(rows) }).catch(() => {});
});

// ارتقای نسل اینترنت
composer.action('const:up_internet', async (ctx) => {
  await ctx.answerCbQuery().catch(() => {});
  const data = await requireCountry(ctx);
  if (!data) return;

  try {
    const res = await gameService.upgradeInternet(data.own.countryId, data.season.id);
    await ctx.reply([
      `📶 <b>اینترنت کشور با موفقیت به ${res.nextInfo.name} ارتقا یافت!</b>`,
      '– – – – – – – – – –',
      `🔬 امتیاز علمی کسب‌شده: <b>+${fmtNum(res.nextInfo.scienceBonus)} علم</b>`,
      `😊 افزایش رضایت عمومی مردم: <b>+${fmtNum(res.nextInfo.satisfactionBonus)}%</b>`,
      `💰 هزینه ارتقا: <b>${fmtNum(res.cost)}$</b>`,
      `🏦 موجودی باقیمانده خزانه: <b>${fmtNum(res.remainingTreasury)}$</b>`,
    ].join('\n'), {
      parse_mode: 'HTML',
      ...Markup.inlineKeyboard([[Markup.button.callback('📡 رسانه و اینترنت', 'const:media_telecom')]]),
    });
  } catch (err) {
    await ctx.reply(`❌ خطا: ${esc(err.message)}`);
  }
});

// ساخت اپراتور اختصاصی
composer.action('const:create_operator', async (ctx) => {
  await ctx.answerCbQuery().catch(() => {});
  await userService.setFlow(ctx.from.id, 'game:operator:name');
  await ctx.reply([
    '📱 <b>تاسیس و نام‌گذاری اپراتور اختصاصی اینترنت کشور</b>',
    '– – – – – – – – – –',
    'هزینه سرمایه‌گذاری راه‌اندازی دکل‌ها و آنتن‌ها: <b>120,000,000$</b>',
    'سود حاصله در هر چرخه درآمد ملی به خزانه شما واریز خواهد شد.',
    '',
    'لطفاً <b>نام اپراتور</b> خود را ارسال فرمایید:',
    '<i>(مثال: ایرانسل ملی یا پارس تلکام)</i>',
    'جهت انصراف: /cancel',
  ].join('\n'), { parse_mode: 'HTML' });
});

registerFlow('game:operator:name', async (ctx) => {
  const name = String(ctx.message?.text || '').trim();
  if (!name || name.length < 2) return ctx.reply('⚠️ نام اپراتور باید حداقل ۲ نویسه باشد. لغو: /cancel');

  await userService.setFlow(ctx.from.id, 'game:operator:logo', { name });
  await ctx.reply([
    `✅ نام اپراتور: <b>${esc(name)}</b>`,
    'حال لطفاً <b>لوگو یا ایموجی اختصاصی</b> اپراتور را ارسال فرمایید:',
    '<i>(مثال: 📶 یا 🌐 یا ⚡ یا 🛰)</i>',
  ].join('\n'), { parse_mode: 'HTML' });
});

registerFlow('game:operator:logo', async (ctx, data) => {
  const logo = String(ctx.message?.text || '📶').trim().slice(0, 5);
  const name = data?.name || 'اپراتور ملی';

  const userCountryData = await requireCountry(ctx);
  if (!userCountryData) return;

  try {
    const res = await gameService.createTelecomOperator(userCountryData.own.countryId, userCountryData.season.id, {
      name,
      logo,
    });
    await userService.clearFlow(ctx.from.id);
    await ctx.reply([
      `🎉 <b>اپراتور سراسری «${res.telecomOperator.logo} ${esc(res.telecomOperator.name)}» افتتاح گردید!</b>`,
      '– – – – – – – – – –',
      `📡 آنتن‌های اولیه: <b>${fmtNum(res.telecomOperator.antennas)} ایستگاه فرستنده</b>`,
      `👥 مشترکین اولیه: <b>${fmtNum(res.telecomOperator.subscribers)} نفر</b>`,
      `💵 درآمد تضمینی هر چرخه: <b>+${fmtNum(res.telecomOperator.cycleDividend)}$</b>`,
      `💰 بودجه مصرفی: <b>${fmtNum(res.cost)}$</b>`,
      `🏦 موجودی باقیمانده خزانه: <b>${fmtNum(res.remainingTreasury)}$</b>`,
    ].join('\n'), {
      parse_mode: 'HTML',
      ...Markup.inlineKeyboard([[Markup.button.callback('📡 رسانه و اینترنت', 'const:media_telecom')]]),
    });
  } catch (err) {
    await ctx.reply(`❌ خطا: ${esc(err.message)}`);
  }
});

// ارسال پست ویدیویی با تایید ادمین و کولدان ۱۰ دقیقه
composer.action('const:post_video', async (ctx) => {
  await ctx.answerCbQuery().catch(() => {});
  await userService.setFlow(ctx.from.id, 'game:post_video:text');
  await ctx.reply([
    '📹 <b>انتشار محتوای رسانه‌ای و ویدیویی در شبکه ملی</b>',
    '– – – – – – – – – –',
    'هر ۱۰ دقیقه یک‌بار می‌توانید یک پست رسمی ویدیویی جهت تایید ادمین ارسال فرمایید.',
    '',
    'لطفاً <b>متن یا کپشن پست رسانه‌ای</b> خود را ارسال فرمایید:',
    'جهت انصراف: /cancel',
  ].join('\n'), { parse_mode: 'HTML' });
});

registerFlow('game:post_video:text', async (ctx) => {
  const caption = String(ctx.message?.text || '').trim();
  if (!caption) return ctx.reply('⚠️ لطفاً متن پست را ارسال فرمایید. لغو: /cancel');

  await userService.setFlow(ctx.from.id, 'game:post_video:url', { caption });
  await ctx.reply([
    '✅ متن دریافت شد.',
    'اکنون لطفاً <b>لینک ویدیو یا شناسه رسانه</b> را ارسال فرمایید:',
    '<i>(مثال: https://t.me/c/... یا لینک معتبر ویدیو)</i>',
  ].join('\n'), { parse_mode: 'HTML' });
});

registerFlow('game:post_video:url', async (ctx, data) => {
  const videoUrl = String(ctx.message?.text || '').trim();
  const caption = data?.caption || '';

  const userCountryData = await requireCountry(ctx);
  if (!userCountryData) return;

  try {
    const post = await gameService.submitMediaPost(userCountryData.own.countryId, userCountryData.season.id, {
      caption,
      videoUrl,
      userId: ctx.from.id,
    });
    await userService.clearFlow(ctx.from.id);
    await ctx.reply([
      '📨 <b>پست ویدیویی با موفقیت به صف بازبینی ادمین ارسال شد!</b>',
      '– – – – – – – – – –',
      `شناسه پیگیری: <code>${post.id}</code>`,
      'پس از تایید ادمین در کانال رسمی یا بخش رسانه‌ها به نمایش درخواهد آمد.',
      '<i>کولدان ارسال پست بعدی: ۱۰ دقیقه</i>',
    ].join('\n'), {
      parse_mode: 'HTML',
      ...Markup.inlineKeyboard([[Markup.button.callback('📡 رسانه و اینترنت', 'const:media_telecom')]]),
    });
  } catch (err) {
    await ctx.reply(`❌ خطا: ${esc(err.message)}`);
  }
});

module.exports = { composer };
