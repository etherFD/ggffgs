'use strict';
const { Composer, Markup } = require('telegraf');
const { config } = require('../config');
const { col } = require('../db/firestore');
const { LABELS: L } = require('../bot/keyboards/labels');
const { leaderboardKeyboard, mainMenu } = require('../bot/keyboards/main');
const { esc, fmtNum, fmtDate, parseNonNegInt } = require('../utils/text');
const { getActiveSeason } = require('../services/seasonService');
const { getActiveOwnership, releaseOwnership, listActive, getOwnerOfCountry } = require('../services/ownershipService');
const countryService = require('../services/countryService');
const userService = require('../services/userService');
const gameService = require('../services/gameService');
const notifications = require('../services/notificationService');
const weaponService = require('../services/weaponService');
const warService = require('../services/warService');
const adminBotService = require('../services/adminBotService');
const allianceService = require('../services/allianceService');
const tradeService = require('../services/tradeService');
const negotiationService = require('../services/negotiationService');
const straitService = require('../services/straitService');
const cryptoService = require('../services/cryptoService');
const settings = require('../services/settingsService');
const unService = require('../services/unService');
const { registerFlow } = require('../bot/flows');

const composer = new Composer();

async function requireCountry(ctx) {
  const season = await getActiveSeason();
  if (!season) return null;
  const own = await getActiveOwnership(ctx.state.user.telegramId, season.id);
  if (own) {
    ctx.state.isLeader = true;
    ctx.state.isMinister = false;
    ctx.state.ministerRole = null;
    return { season, own, isLeader: true, isMinister: false, role: 'leader' };
  }

  // بررسی عضویت در هیئت وزیران کشور
  const ministerService = require('../services/ministerService');
  const ministerRecord = await ministerService.findMinisterRole(ctx.state.user.telegramId, season.id);
  if (ministerRecord) {
    const country = await countryService.get(ministerRecord.countryId);
    const virtualOwn = {
      countryId: ministerRecord.countryId,
      country,
      seasonId: season.id,
      isMinister: true,
      ministerRole: ministerRecord.role,
      roleTitle: ministerRecord.roleTitle,
    };
    ctx.state.isLeader = false;
    ctx.state.isMinister = true;
    ctx.state.ministerRole = ministerRecord.role;
    return { season, own: virtualOwn, isLeader: false, isMinister: true, role: ministerRecord.role, roleTitle: ministerRecord.roleTitle };
  }

  await ctx.reply('🌍 شما هنوز کشوری ندارید. ابتدا از دکمه «انتخاب کشور» یک کشور برای رهبری انتخاب کنید.', Markup.inlineKeyboard([
    [Markup.button.callback('🌍 انتخاب کشور', 'cl:0')],
  ]));
  return null;
}

const cb = (text, data, style = null) => {
  const b = { text, callback_data: data };
  if (style) b.style = style;
  return b;
};

// کیبورد امپراطوری من با اسامی خلاصه، خوانا و بدون شلوغی متنی
function empireInlineKeyboard() {
  return {
    reply_markup: {
      inline_keyboard: [
        [cb('⚔️ حمله و فتح', 'emp:attack', 'danger'), cb('🛢️ اقتصاد و نفت', 'emp:oil', 'success')],
        [cb('🚨 اعلام جنگ', 'emp:war_declare', 'danger'), cb('🛡️ پدافند و دفاع', 'emp:defense', 'primary')],
        [cb('👥 رفاه مردم', 'emp:people', 'success'), cb('⚙️ توسعه و زیرساخت', 'emp:dev', 'primary')],
        [cb('🎖️ هیئت دولت و وزیران', 'emp:commander', 'primary'), cb('🗺️ استان‌ها و قلمرو', 'emp:provinces', 'success')],
        [cb('🪖 پادگان نظامی', 'emp:barracks', 'primary'), cb('🎖️ رزمایش دفاعی', 'emp:drill', 'danger')],
        [cb('🗺️ نقشه جهان', 'emp:worldmap', 'primary'), cb('🤝 اتحاد و پیمان‌ها', 'emp:alliance', 'success')],
        [cb('🔬 پژوهش و فناوری', 'emp:research', 'primary'), cb('🏢 شرکت‌ها و هلدینگ', 'emp:companies', 'success')],
        [cb('💻 ارتش سایبری', 'emp:cyber', 'primary'), cb('🕵️‍♂️ سرویس اطلاعات', 'emp:spy', 'danger')],
        [cb('🚢 مبادلات تجاری', 'emp:trade', 'success'), cb('🌐 بازار جهانی کالا', 'emp:global_market', 'success')],
        [cb('🛢️ اکتشاف نفت', 'emp:oil_explore', 'success'), cb('☢️ برنامه هسته‌ای', 'emp:nuclear', 'danger')],
        [cb('🗣️ اتاق مذاکرات', 'emp:negotiate', 'success'), cb('🕊️ دیپلماسی', 'emp:diplomacy', 'primary')],
        [cb('🚢 آبراه‌ها و تنگه‌ها', 'emp:straits', 'primary'), cb('🪖 پایگاه نظامی', 'emp:base', 'danger')],
        [cb('💵 مهار تورم', 'emp:inflation', 'primary'), cb('🛑 مهار گروهک‌ها', 'emp:factions', 'danger')],
        [cb('📈 تالار بورس', 'emp:finance', 'success'), cb('🏗️ ساخت‌وساز', 'emp:construction', 'primary')],
        [cb('🏛️ احکام کشورداری', 'emp:governance', 'primary')],
        [cb('🔙 بازگشت به منو', 'menu:home', 'danger')],
      ],
    },
  };
}

// کیبورد نفت و اقتصاد با عناوین خلاصه و خوانا
function oilInlineKeyboard(autoMode = false) {
  return {
    reply_markup: {
      inline_keyboard: [
        [cb('👷 استخدام کارگر', 'oil:worker', 'success'), cb('🛢 احداث دکل نفت', 'oil:rig', 'success')],
        [cb('⛏ استخراج فوری نفت', 'oil:extract', 'success'), cb('🔬 اکتشاف عمیق (۴۵۰M $)', 'emp:oil_explore', 'primary')],
        [cb('💵 فروش نفت به کشورها', 'oil:sell_to_country', 'success'), cb(autoMode ? '🔄 استخراج خودکار (روشن ✅)' : '🔄 استخراج خودکار (خاموش ⏸)', 'oil:auto_toggle', autoMode ? 'success' : 'primary')],
        [cb('⚡ فروش ۵۰٪', 'oil:sell:50', 'primary'), cb('⚡ فروش ۲۵٪', 'oil:sell:25', 'primary')],
        [cb('💰 فروش ۱۰۰٪ موجودی', 'oil:sell:100', 'success')],
        [cb('🌍 قرارداد نفتی', 'oil:contract', 'primary')],
        [cb('🌐 بازار جهانی مصالح', 'oil:global', 'success')],
        [cb('🏪 تالار معاملات', 'oil:market', 'success')],
        [cb('🏦 صندوق امن بانک', 'oil:vault', 'primary')],
        [cb('🤝 وام دولتی', 'oil:loan', 'primary')],
        [cb('🔙 بازگشت به امپراطوری', 'emp:home', 'danger'), cb('🔙 منوی اصلی', 'menu:home', 'primary')],
      ],
    },
  };
}


// -------------------------------------------------------------
// ۱. امپراطوری من
// -------------------------------------------------------------
composer.hears([L.empire, '👑 امپراطوری من', '/empire'], async (ctx) => {
  const data = await requireCountry(ctx);
  if (!data) return;
  const { own, season } = data;
  const state = await gameService.getCountryState(own.countryId, season.id);
  const flag = countryService.getDynamicFlag(own.country, state);

  // پاکسازی قطعی پنل کیبورد پایین صفحه
  await ctx.reply('👑 مرکز فرماندهی امپراطوری آماده است:', { reply_markup: { remove_keyboard: true } }).catch(() => {});

  const text = [
    `👑 <b>امپراطوری ${esc(own.country.name)} ${flag}</b>`,
    '– – – – – – – – – –',
    `👑 رهبر: <b>${esc(ctx.state.user.displayName)}</b>`,
    `💵 سرمایه: <b>${fmtNum(state.treasury)}$</b> | 🛢 نفت: <b>${fmtNum(state.oil || 0)} بشکه</b>`,
    '',
    '👇 فرماندهی و مدیریت بخش‌های مختلف کشور از کلیدهای زیر:',
  ].join('\n');

  await ctx.reply(text, {
    parse_mode: 'HTML',
    ...empireInlineKeyboard(),
  });
});

composer.action('emp:home', async (ctx) => {
  await ctx.answerCbQuery().catch(() => {});
  const data = await requireCountry(ctx);
  if (!data) return;
  const { own, season } = data;
  const state = await gameService.getCountryState(own.countryId, season.id);
  const flag = countryService.getDynamicFlag(own.country, state);

  const text = [
    `👑 <b>امپراطوری ${esc(own.country.name)} ${flag}</b>`,
    '– – – – – – – – – –',
    `👑 رهبر: <b>${esc(ctx.state.user.displayName)}</b>`,
    `💵 سرمایه: <b>${fmtNum(state.treasury)}$</b> | 🛢 نفت: <b>${fmtNum(state.oil || 0)} بشکه</b>`,
    '',
    '👇 بخش مورد نظر خود را انتخاب کنید:',
  ].join('\n');

  await ctx.editMessageText(text, {
    parse_mode: 'HTML',
    reply_markup: empireInlineKeyboard().reply_markup,
  }).catch(() => {});
});

// -------------------------------------------------------------
// ۲. اقتصاد و نفت (کاملاً اینلاین زیر پیام طبق عکس جدید)
// -------------------------------------------------------------
composer.hears('اقتصاد و نفت 💰', async (ctx) => {
  await showOilPanel(ctx);
});
composer.action('emp:oil', async (ctx) => {
  await ctx.answerCbQuery().catch(() => {});
  await showOilPanel(ctx, true);
});

async function showOilPanel(ctx, isEdit = false) {
  const data = await requireCountry(ctx);
  if (!data) return;
  const { season, own } = data;
  const state = await gameService.getCountryState(own.countryId, season.id);
  const country = await countryService.get(own.countryId);
  const oilPrice = gameService.getOilMarketPrice();
  const flag = countryService.getDynamicFlag(own.country, state);
  const capacity = gameService.calculateOilReserveCapacity(state, country || own.country);
  const richness = Math.max(0, Math.min(100, Number(country?.oilRichness ?? state.oilRichness ?? 50)));

  const text = [
    `🛢 <b>بخش اقتصاد و بازار نفت — ${esc(own.country.name)} ${flag}</b>`,
    '– – – – – – – – – –',
    `📈 قیمت جهانی نفت خام: <b>${oilPrice}$</b> (تغییر هر ۲ ساعت)`,
    `🛢 موجودی نفت خام: <b>${fmtNum(state.oil || 0)} / ${fmtNum(capacity.total)} بشکه</b>`,
    `📊 سقف مخزن نفت داخلی: <b>${fmtNum(capacity.total)} بشکه</b> (استخراج بیشتر امکان‌پذیر نیست)`,
    `🔬 درصد نفت‌خیزی تعیین‌شده ادمین: <b>${richness}٪</b>`,
    `🏗 دکل‌های فعال: <b>${fmtNum(state.oilRigs || 0)} دکل</b>`,
    `👷 کارگران نفت: <b>${fmtNum(state.workers || 120)} نفر</b>`,
    `🏦 صندوق امن: <b>${fmtNum(state.safeVault || 0)}$</b>`,
    `💵 سرمایه نقدی: <b>${fmtNum(state.treasury || 0)}$</b>`,
    '',
    '💡 <i>با پرداخت ۴۵۰ میلیون دلار می‌توانید تیم تحقیقاتی اعزام کرده و در صورت کشف منبع، سقف مخزن داخلی کشور را افزایش دهید.</i>',
  ].join('\n');

  const kb = oilInlineKeyboard(Boolean(state.autoMode));
  if (isEdit && ctx.callbackQuery) {
    await ctx.editMessageText(text, { parse_mode: 'HTML', reply_markup: kb.reply_markup }).catch(() => {});
  } else {
    await ctx.reply(text, { parse_mode: 'HTML', ...kb });
  }
}

// استخراج دستی نفت
composer.action('oil:extract', async (ctx) => {
  const data = await requireCountry(ctx);
  if (!data) return;
  const { season, own } = data;
  const res = await gameService.manualExtractOil(own.countryId, season.id);
  await ctx.answerCbQuery(`⛏ ${res.extracted} بشکه نفت جدید استخراج شد!`, { show_alert: true });
  await showOilPanel(ctx, true);
});

// سوئیچ حالت خودکار
composer.action('oil:auto_toggle', async (ctx) => {
  const data = await requireCountry(ctx);
  if (!data) return;
  const { season, own } = data;
  const nextVal = await gameService.toggleAutoMode(own.countryId, season.id);
  await ctx.answerCbQuery(nextVal ? '🔄 حالت خودکار فعال شد.' : '⏸ حالت خودکار خاموش شد.', { show_alert: true });
  await showOilPanel(ctx, true);
});

// خرید کارگر
// خرید کارگر با تعیین تعداد توسط خود بازیکن
composer.action('oil:worker', async (ctx) => {
  await ctx.answerCbQuery().catch(() => {});
  const data = await requireCountry(ctx);
  if (!data) return;
  const state = await gameService.getCountryState(data.own.countryId, data.season.id);

  await userService.setFlow(ctx.from.id, 'game:buy_workers:qty');
  await ctx.reply([
    '👷 <b>استخدام کارگران پالایشگاه نفت</b>',
    '– – – – – – – – – –',
    `تعداد کارگران فعلی شما: <b>${fmtNum(state.workers || 120)} نفر</b>`,
    `💵 موجودی خزانه کشور: <b>${fmtNum(state.treasury || 0)}$</b>`,
    'هزینه هر ۵۰ کارگر = ۲,۰۰۰,۰۰۰ دلار (هر ۱ کارگر = ۴۰,۰۰۰ دلار)',
    '',
    'لطفاً <b>تعداد کارگر</b> مورد نظر برای استخدام را به صورت عدد ارسال نمایید:',
    '<i>(مثال: 50 یا 200 یا 1000)</i>',
    'جهت انصراف: /cancel',
  ].join('\n'), { parse_mode: 'HTML' });
});

registerFlow('game:buy_workers:qty', async (ctx) => {
  const count = parseNonNegInt(ctx.message?.text);
  if (!count || count <= 0) return ctx.reply('⚠️ لطفاً یک رقم عددی معتبر (انگلیسی یا فارسی) ارسال کنید. لغو: /cancel');

  const data = await requireCountry(ctx);
  if (!data) return;
  try {
    const res = await gameService.buyWorker(data.own.countryId, data.season.id, count);
    await userService.clearFlow(ctx.from.id);
    await ctx.reply(`✅ <b>تعداد ${fmtNum(res.count)} کارگر نفتی با هزینه ${fmtNum(res.cost)}$ استخدام شدند!</b>\nموجودی جدید کارگران: <b>${fmtNum(res.currentWorkers)} نفر</b>\nخزانه باقیمانده: <b>${fmtNum(res.remainingTreasury)}$</b>`, {
      parse_mode: 'HTML',
      ...Markup.inlineKeyboard([[Markup.button.callback('💰 بازگشت به اقتصاد و نفت', 'emp:oil')]]),
    });
  } catch (err) {
    await ctx.reply(`❌ خطا: ${esc(err.message)}`);
  }
});

// خرید دکل نفتی با تعیین تعداد توسط خود بازیکن
composer.action('oil:rig', async (ctx) => {
  await ctx.answerCbQuery().catch(() => {});
  const data = await requireCountry(ctx);
  if (!data) return;

  if (ctx.state.isMinister && ctx.state.ministerRole === 'war') {
    return ctx.answerCbQuery('⛔ عدم دسترسی: به عنوان وزیر جنگ شما مجاز به احداث دکل نیستید. امور اقتصادی در اختیار وزیر اقتصاد است.', { show_alert: true });
  }

  const state = await gameService.getCountryState(data.own.countryId, data.season.id);

  await userService.setFlow(ctx.from.id, 'game:buy_rigs:qty');
  await ctx.reply([
    '🛢 <b>احداث دکل‌های نفتی جدید</b>',
    '– – – – – – – – – –',
    `تعداد دکل‌های فعال فعلی: <b>${fmtNum(state.oilRigs || 0)} دکل</b>`,
    `💵 موجودی خزانه کشور: <b>${fmtNum(state.treasury || 0)}$</b>`,
    'هزینه هر ۱ دکل = ۵۰,۰۰۰,۰۰۰ دلار (افزایش توان استخراج و صادرات)',
    '',
    'لطفاً <b>تعداد دکل نفتی</b> مورد نظر را ارسال فرمایید:',
    '<i>(مثال: 1 یا 5 یا 10)</i>',
    'جهت انصراف: /cancel',
  ].join('\n'), { parse_mode: 'HTML' });
});

registerFlow('game:buy_rigs:qty', async (ctx) => {
  const count = parseNonNegInt(ctx.message?.text);
  if (!count || count <= 0) return ctx.reply('⚠️ لطفاً یک عدد معتبر (انگلیسی یا فارسی) ارسال کنید. لغو: /cancel');

  const data = await requireCountry(ctx);
  if (!data) return;
  try {
    const res = await gameService.buyOilRig(data.own.countryId, data.season.id, count);
    await userService.clearFlow(ctx.from.id);
    await ctx.reply(`✅ <b>تعداد ${fmtNum(res.count)} دکل نفتی با هزینه ${fmtNum(res.totalCost)}$ احداث گردید!</b>\nتعداد کل دکل‌ها: <b>${fmtNum(res.currentRigs)} دکل</b>\nخزانه باقیمانده: <b>${fmtNum(res.remainingTreasury)}$</b>`, {
      parse_mode: 'HTML',
      ...Markup.inlineKeyboard([[Markup.button.callback('💰 بازگشت به اقتصاد و نفت', 'emp:oil')]]),
    });
  } catch (err) {
    await ctx.reply(`❌ خطا: ${esc(err.message)}`);
  }
});

// فروش درصدی نفت با ارسال نفت‌کش (واریز بعد از ۱ دقیقه)
composer.action(/^oil:sell:(\d+)$/, async (ctx) => {
  const percent = Number(ctx.match[1]);
  const data = await requireCountry(ctx);
  if (!data) return;
  try {
    const res = await gameService.sellOilMarket(data.own.countryId, data.season.id, percent, ctx.from.id);
    await ctx.answerCbQuery(`🚢 ${res.barrelsSold} بشکه بارگیری شد! نفت‌کش‌ها اعزام شدند و مبلغ ${fmtNum(res.revenue)}$ ظرف ۱ دقیقه دیگر به خزانه واریز می‌شود.`, { show_alert: true });
    await showOilPanel(ctx, true);
  } catch (err) {
    await ctx.answerCbQuery(err.message, { show_alert: true });
  }
});

// صندوق امن: مقدار واریزی دلخواه بازیکن + دکمه تایید نهایی
composer.action('oil:vault', async (ctx) => {
  await ctx.answerCbQuery().catch(() => {});
  const data = await requireCountry(ctx);
  if (!data) return;
  const state = await gameService.getCountryState(data.own.countryId, data.season.id);

  await userService.setFlow(ctx.from.id, 'game:vault:amount');
  await ctx.reply([
    '🏦 <b>صندوق امن ملی (غیرقابل غارت و ضد نفوذ)</b>',
    '– – – – – – – – – –',
    `💰 موجودی فعلی صندوق امن: <b>${fmtNum(state.safeVault || 0)}$</b>`,
    `💵 موجودی خزانه عادی: <b>${fmtNum(state.treasury || 0)}$</b>`,
    '',
    'لطفاً <b>مبلغ مورد نظر برای واریز به صندوق امن</b> را ارسال فرمایید:',
    '<i>(پس از ارسال عدد، پیش‌فاکتور با دکمه تایید نهایی برای شما نمایش داده می‌شود)</i>',
    'جهت انصراف: /cancel',
  ].join('\n'), { parse_mode: 'HTML' });
});

registerFlow('game:vault:amount', async (ctx) => {
  const amount = parseNonNegInt(ctx.message?.text);
  if (!amount || amount <= 0) return ctx.reply('⚠️ لطفاً یک مبلغ عددی معتبر (انگلیسی یا فارسی) ارسال فرمایید. لغو: /cancel');

  const data = await requireCountry(ctx);
  if (!data) return;
  const state = await gameService.getCountryState(data.own.countryId, data.season.id);

  if ((state.treasury || 0) < amount) {
    return ctx.reply(`⚠️ موجودی خزانه شما (${fmtNum(state.treasury || 0)}$) برای واریز این مبلغ کافی نیست. لطفاً مبلغ کمتری بفرستید.`);
  }

  await userService.clearFlow(ctx.from.id);

  const kb = Markup.inlineKeyboard([
    [Markup.button.callback(`✅ تایید واریز ${fmtNum(amount)}$ به صندوق امن`, `oil:vault_confirm:${amount}`)],
    [Markup.button.callback('❌ انصراف و بازگشت', 'emp:oil')],
  ]);

  await ctx.reply([
    '🔐 <b>پیش‌نمایش انتقال به صندوق امن</b>',
    '– – – – – – – – – –',
    `مبلغ انتقالی: <b>${fmtNum(amount)}$</b>`,
    `موجودی صندوق پس از واریز: <b>${fmtNum((state.safeVault || 0) + amount)}$</b>`,
    `موجودی خزانه پس از واریز: <b>${fmtNum((state.treasury || 0) - amount)}$</b>`,
    '',
    'آیا با این انتقال و کسر از خزانه کشور موافقید؟',
  ].join('\n'), { parse_mode: 'HTML', reply_markup: kb.reply_markup });
});

composer.action(/^oil:vault_confirm:(\d+)$/, async (ctx) => {
  await ctx.answerCbQuery().catch(() => {});
  const amount = Number(ctx.match[1]);
  const data = await requireCountry(ctx);
  if (!data) return;
  try {
    const res = await gameService.depositToSafeVault(data.own.countryId, data.season.id, amount);
    await ctx.editMessageText(`✅ <b>مبلغ ${fmtNum(res.amount)}$ با موفقیت به صندوق امن واریز گردید!</b>\nموجودی جدید صندوق: <b>${fmtNum(res.newVault)}$</b>\nخزانه باقیمانده: <b>${fmtNum(res.newTreasury)}$</b>`, {
      parse_mode: 'HTML',
      reply_markup: Markup.inlineKeyboard([[Markup.button.callback('💰 بازگشت به اقتصاد و نفت', 'emp:oil')]]).reply_markup,
    });
  } catch (err) {
    await ctx.reply(`❌ خطا: ${esc(err.message)}`);
  }
});

// -------------------------------------------------------------
// بخش فروش و خرید نفت بین کشورها (با کارمزد ۱.۵٪ به بانک مرکزی)
// -------------------------------------------------------------
composer.action('oil:sell_to_country', async (ctx) => {
  await ctx.answerCbQuery().catch(() => {});
  const data = await requireCountry(ctx);
  if (!data) return;
  const state = await gameService.getCountryState(data.own.countryId, data.season.id);

  const text = [
    '🤝 <b>بازار دادوستد نفت بین کشورها</b>',
    '– – – – – – – – – –',
    `🛢 موجودی نفت آماده فروش شما: <b>${fmtNum(state.oil || 0)} بشکه</b>`,
    `💵 موجودی خزانه کشور: <b>${fmtNum(state.treasury || 0)}$</b>`,
    '💡 <i>کارمزد معاملات نفت بین کشورها ۱.۵٪ بوده و مستقیماً به بانک مرکزی واریز می‌شود.</i>',
    '',
    'گزینه مورد نظر خود را انتخاب نمایید:',
  ].join('\n');

  const kb = Markup.inlineKeyboard([
    [Markup.button.callback('📤 فروش نفت به کشورها (ثبت پیشنهاد)', 'oil:p2p:sell_start')],
    [Markup.button.callback('📥 خرید نفت از کشورها (مشاهده لیست)', 'oil:p2p:buy_list')],
    [Markup.button.callback('🔙 بازگشت به اقتصاد و نفت', 'emp:oil')],
  ]);

  await ctx.editMessageText(text, { parse_mode: 'HTML', reply_markup: kb.reply_markup }).catch(() => {});
});

// ثبت فروش نفت به کشورها
composer.action('oil:p2p:sell_start', async (ctx) => {
  await ctx.answerCbQuery().catch(() => {});
  const data = await requireCountry(ctx);
  if (!data) return;
  const state = await gameService.getCountryState(data.own.countryId, data.season.id);

  if (!state.oil || state.oil <= 0) {
    return ctx.reply('⚠️ شما هیچ بشکه نفتی برای فروش ندارید! ابتدا از دکل‌های نفتی استخراج انجام دهید.');
  }

  await userService.setFlow(ctx.from.id, 'game:oil_p2p:price', { availableOil: state.oil });
  await ctx.reply([
    '📤 <b>ثبت پیشنهاد فروش نفت به کشورها</b>',
    '– – – – – – – – – –',
    `موجودی کل نفت شما: <b>${fmtNum(state.oil)} بشکه</b>`,
    '',
    '<b>مرحله اول:</b> لطفاً <b>قیمت پیشنهادی هر بشکه نفت (دلار)</b> را ارسال کنید:',
    '<i>(مثال: 85 یا 100)</i>',
    'جهت لغو: /cancel',
  ].join('\n'), { parse_mode: 'HTML' });
});

registerFlow('game:oil_p2p:price', async (ctx, data) => {
  const price = Number(String(ctx.message.text || '').replace(/[^0-9]/g, ''));
  if (!price || price <= 0) return ctx.reply('⚠️ لطفاً یک قیمت عددی معتبر برای هر بشکه وارد نمایید. لغو: /cancel');

  await userService.setFlow(ctx.from.id, 'game:oil_p2p:qty', { pricePerBarrel: price, availableOil: data.availableOil });
  await ctx.reply([
    `قیمت هر بشکه: <b>${fmtNum(price)}$</b> تایید شد.`,
    '– – – – – – – – – –',
    `<b>مرحله دوم:</b> چند بشکه نفت را برای فروش می‌گذارید؟ (حداکثر ${fmtNum(data.availableOil)} بشکه):`,
    'جهت لغو: /cancel',
  ].join('\n'), { parse_mode: 'HTML' });
});

registerFlow('game:oil_p2p:qty', async (ctx, data) => {
  const barrels = Number(String(ctx.message.text || '').replace(/[^0-9]/g, ''));
  if (!barrels || barrels <= 0 || barrels > data.availableOil) {
    return ctx.reply(`⚠️ تعداد بشکه باید بین ۱ تا ${fmtNum(data.availableOil)} باشد. لغو: /cancel`);
  }

  const ownData = await requireCountry(ctx);
  if (!ownData) return;

  try {
    const offer = await gameService.postCountryOilOffer({
      countryId: ownData.own.countryId,
      seasonId: ownData.season.id,
      barrels,
      pricePerBarrel: data.pricePerBarrel,
    });

    await userService.clearFlow(ctx.from.id);
    await ctx.reply([
      '🎉 <b>پیشنهاد فروش نفت شما در بازار کشورها ثبت شد!</b>',
      '– – – – – – – – – –',
      `🛢 تعداد: <b>${fmtNum(offer.barrels)} بشکه</b>`,
      `💵 قیمت هر بشکه: <b>${fmtNum(offer.pricePerBarrel)}$</b>`,
      `💰 ارزش کل: <b>${fmtNum(offer.barrels * offer.pricePerBarrel)}$</b>`,
      '💡 به محض خرید توسط کشوری دیگر، وجه منهای ۱.۵٪ کارمزد بانک مرکزی به خزانه شما واریز می‌شود.',
    ].join('\n'), {
      parse_mode: 'HTML',
      ...Markup.inlineKeyboard([[Markup.button.callback('🤝 بازار نفت کشورها', 'oil:sell_to_country')]]),
    });
  } catch (err) {
    await ctx.reply(`❌ خطا: ${esc(err.message)}`);
  }
});

// مشاهده لیست و خرید نفت از کشورها
composer.action('oil:p2p:buy_list', async (ctx) => {
  await ctx.answerCbQuery().catch(() => {});
  const data = await requireCountry(ctx);
  if (!data) return;

  const offers = await gameService.listCountryOilOffers(data.season.id);
  const others = offers.filter((o) => String(o.countryId) !== String(data.own.countryId));

  if (!others.length) {
    return ctx.editMessageText('📭 در حال حاضر هیچ کشور دیگری پیشنهادی برای فروش نفت ثبت نکرده است.', {
      reply_markup: Markup.inlineKeyboard([[Markup.button.callback('🔙 بازگشت', 'oil:sell_to_country')]]).reply_markup,
    }).catch(() => {});
  }

  const rows = [];
  for (const o of others.slice(0, 10)) {
    rows.push([
      Markup.button.callback(
        `${o.countryFlag} ${o.countryName} | ${fmtNum(o.barrels)} بشکه (هر بشکه ${fmtNum(o.pricePerBarrel)}$)`,
        `oil:p2p:buy_pick:${o.id}`
      ),
    ]);
  }
  rows.push([Markup.button.callback('🔙 بازگشت', 'oil:sell_to_country')]);

  await ctx.editMessageText('🛒 <b>فهرست کشورهای فروشنده نفت خام:</b>\nروی کشور مورد نظر کلیک کنید تا تعداد بشکه خرید را مشخص کنید:', {
    parse_mode: 'HTML',
    reply_markup: Markup.inlineKeyboard(rows).reply_markup,
  }).catch(() => {});
});

composer.action(/^oil:p2p:buy_pick:(.+)$/, async (ctx) => {
  await ctx.answerCbQuery().catch(() => {});
  const offerId = ctx.match[1];
  const { col, snap } = require('../db/firestore');
  const docSnap = await col('country_oil_offers').doc(offerId).get();
  if (!docSnap.exists) return ctx.reply('پیشنهاد منقضی شده است.');
  const offer = docSnap.data();

  await userService.setFlow(ctx.from.id, 'game:oil_p2p:buy_qty', { offerId, maxBarrels: offer.barrels, pricePerBarrel: offer.pricePerBarrel });
  await ctx.reply([
    `🛒 <b>خرید نفت از کشور ${offer.countryFlag} ${offer.countryName}</b>`,
    '– – – – – – – – – –',
    `حداکثر موجودی برای فروش: <b>${fmtNum(offer.barrels)} بشکه</b>`,
    `قیمت هر بشکه: <b>${fmtNum(offer.pricePerBarrel)}$</b>`,
    '',
    'لطفاً <b>تعداد بشکه‌ای که می‌خواهید بخرید</b> را ارسال فرمایید:',
    'جهت لغو: /cancel',
  ].join('\n'), { parse_mode: 'HTML' });
});

registerFlow('game:oil_p2p:buy_qty', async (ctx, data) => {
  const reqQty = Number(String(ctx.message.text || '').replace(/[^0-9]/g, ''));
  if (!reqQty || reqQty <= 0 || reqQty > data.maxBarrels) {
    return ctx.reply(`⚠️ لطفاً عددی بین ۱ تا ${fmtNum(data.maxBarrels)} وارد کنید. لغو: /cancel`);
  }

  const ownData = await requireCountry(ctx);
  if (!ownData) return;

  try {
    const res = await gameService.buyCountryOilOffer({
      buyerCountryId: ownData.own.countryId,
      offerId: data.offerId,
      barrelsToBuy: reqQty,
      seasonId: ownData.season.id,
    });

    await userService.clearFlow(ctx.from.id);
    await ctx.reply([
      '🎉 <b>خرید نفت با موفقیت نهایی شد!</b>',
      '– – – – – – – – – –',
      `🛢 تعداد نفت خریداری شده: <b>+${fmtNum(res.reqQty)} بشکه</b>`,
      `💵 کل مبلغ پرداخت‌شده: <b>${fmtNum(res.totalCost)}$</b>`,
      `🏦 کارمزد ۱.۵٪ واریز شده به بانک مرکزی: <b>${fmtNum(res.tax)}$</b>`,
      `💰 مبلغ خالص تحویل‌شده به فروشنده: <b>${fmtNum(res.netSellerPayout)}$</b>`,
    ].join('\n'), {
      parse_mode: 'HTML',
      ...Markup.inlineKeyboard([[Markup.button.callback('🤝 بازار نفت کشورها', 'oil:sell_to_country')]]),
    });
  } catch (err) {
    await ctx.reply(`❌ خطا: ${esc(err.message)}`);
  }
});

// -------------------------------------------------------------
// قراردادهای نفتی دوجانبه بین کشورها
// -------------------------------------------------------------
composer.action('oil:contract', async (ctx) => {
  await ctx.answerCbQuery().catch(() => {});
  const data = await requireCountry(ctx);
  if (!data) return;

  const activeOwnerships = await listActive(data.season.id);
  const others = activeOwnerships.filter((o) => String(o.countryId) !== String(data.own.countryId));

  if (!others.length) {
    return ctx.editMessageText('🌍 کشور دیگری برای عقد قرارداد نفتی وجود ندارد.', {
      reply_markup: Markup.inlineKeyboard([[Markup.button.callback('🔙 بازگشت', 'emp:oil')]]).reply_markup,
    }).catch(() => {});
  }

  const rows = [];
  for (const o of others.slice(0, 10)) {
    const c = await countryService.get(o.countryId);
    if (c) rows.push([Markup.button.callback(`📜 قرارداد با ${c.flag} ${c.name}`, `oil:ct:target:${c.id}`)]);
  }
  rows.push([Markup.button.callback('🔙 بازگشت به نفت', 'emp:oil')]);

  await ctx.editMessageText([
    '📜 <b>سامانه قراردادهای نفتی بلندمدت بین‌الملل</b>',
    '– – – – – – – – – –',
    'کشورها می‌توانند قراردادهای تامین منظم نفت منعقد نمایند.',
    'مثال: <i>ایران روزانه ۵۰ هزار بشکه نفت به ازای ۱۰۰ میلیون دلار به خریدار تحویل دهد.</i>',
    '',
    'کشور طرف قرارداد را انتخاب کنید:',
  ].join('\n'), { parse_mode: 'HTML', reply_markup: Markup.inlineKeyboard(rows).reply_markup }).catch(() => {});
});

composer.action(/^oil:ct:target:(.+)$/, async (ctx) => {
  await ctx.answerCbQuery().catch(() => {});
  const targetId = ctx.match[1];
  const target = await countryService.get(targetId);
  await userService.setFlow(ctx.from.id, 'game:oil_contract:terms', { targetId, targetName: target?.name, flag: target?.flag });
  await ctx.reply([
    `📜 <b>تنظیم مفاد قرارداد با ${target?.flag} ${target?.name}</b>`,
    '– – – – – – – – – –',
    'لطفاً <b>مبلغ روزانه (دلار)</b> و <b>تعداد بشکه روزانه</b> را با فاصله ارسال نمایید:',
    '<i>مثال: 100000000 50000 (یعنی روزانه ۱۰۰ میلیون دلار در ازای ۵۰ هزار بشکه)</i>',
    'جهت لغو: /cancel',
  ].join('\n'), { parse_mode: 'HTML' });
});

registerFlow('game:oil_contract:terms', async (ctx, data) => {
  const parts = ctx.message.text.trim().split(/\s+/);
  const dollars = Number(parts[0]?.replace(/[^0-9]/g, ''));
  const barrels = Number(parts[1]?.replace(/[^0-9]/g, ''));
  if (!dollars || !barrels || dollars <= 0 || barrels <= 0) {
    return ctx.reply('⚠️ لطفاً هر دو رقم (مبلغ دلاری و تعداد بشکه) را با فاصله بفرستید. لغو: /cancel');
  }

  const ownData = await requireCountry(ctx);
  if (!ownData) return;

  try {
    const res = await gameService.createOilContract({
      buyerCountryId: ownData.own.countryId,
      sellerCountryId: data.targetId,
      dailyBarrels: barrels,
      dailyDollars: dollars,
      seasonId: ownData.season.id,
    });

    await userService.clearFlow(ctx.from.id);
    await ctx.reply(`✅ <b>پیشنهاد قرارداد نفتی برای کشور ${data.flag} ${data.targetName} ارسال گردید!</b>\nمفاد: روزانه <b>${fmtNum(dollars)}$</b> بابت <b>${fmtNum(barrels)} بشکه نفت</b>.`, {
      parse_mode: 'HTML',
      ...Markup.inlineKeyboard([[Markup.button.callback('🔙 بازگشت به اقتصاد و نفت', 'emp:oil')]]),
    });
  } catch (err) {
    await ctx.reply(`❌ خطا: ${esc(err.message)}`);
  }
});

// -------------------------------------------------------------
// وام بین کشورها (با بازپرداخت خودکار کسر ۸۰٪ از درآمدهای واریزی)
// -------------------------------------------------------------
composer.action('oil:loan', async (ctx) => {
  await ctx.answerCbQuery().catch(() => {});
  const data = await requireCountry(ctx);
  if (!data) return;

  const loans = await gameService.listLoansForCountry(data.own.countryId, data.season.id);
  const activeDebts = loans.borrowed.filter((l) => l.status === 'active');
  const activeCredits = loans.lent.filter((l) => l.status === 'active');
  const incomingPending = loans.incomingPending || [];
  const outgoingPending = loans.outgoingPending || [];

  const textLines = [
    '🤝 <b>سامانه استقراض و وام حاکمیتی بین کشورها</b>',
    '– – – – – – – – – –',
    'قانون دقیق: برای دریافت وام، <b>ابتدا باید رهبر کشور وام‌دهنده تایید را ثبت کند</b> تا مبلغ از خزانه آن کشور کسر و به حساب شما واریز گردد.',
    '⚡ <b>قانون بازپرداخت ۸۰٪:</b> از هر نوبت درآمد واریزی کشور وام‌گیرنده، ۸۰٪ به صورت خودکار به خزانه کشور وام‌دهنده منتقل می‌شود تا کل بدهی تسویه گردد.',
    '',
  ];

  const rows = [];

  // درخواست‌های وام دریافتی (نیازمند تصمیم رهبر این کشور)
  if (incomingPending.length > 0) {
    textLines.push(`🔔 <b>درخواست‌های وام دریافتی از شما (${fmtNum(incomingPending.length)} فقره):</b>`);
    for (const l of incomingPending) {
      const borrower = await countryService.get(l.borrowerCountryId);
      textLines.push(`• کشور <b>${borrower?.flag || '🏳️'} ${esc(borrower?.name || 'کشور')}</b> مبلغ <b>${fmtNum(l.amount)}$</b> درخواست کرده است.`);
      rows.push([
        Markup.button.callback(`✅ پرداخت وام ${fmtNum(l.amount)}$ به ${borrower?.name || ''}`, `loan:appr:${l.id}`),
        Markup.button.callback(`❌ رد درخواست`, `loan:rejc:${l.id}`),
      ]);
    }
    textLines.push('');
  }

  // درخواست‌های وام ارسالی شما (در انتظار پاسخ)
  if (outgoingPending.length > 0) {
    textLines.push(`⏳ <b>درخواست‌های وام ارسالی شما (${fmtNum(outgoingPending.length)} فقره):</b>`);
    for (const l of outgoingPending) {
      const lender = await countryService.get(l.lenderCountryId);
      textLines.push(`• مبلغ <b>${fmtNum(l.amount)}$</b> از ${lender?.flag || '🏳️'} ${esc(lender?.name || 'کشور')} (در انتظار تایید رهبر آن کشور)`);
      rows.push([
        Markup.button.callback(`🗑 لغو درخواست وام از ${lender?.name || ''}`, `loan:canc:${l.id}`),
      ]);
    }
    textLines.push('');
  }

  textLines.push(
    `🔻 وام‌های دریافتی فعال شما (بدهی جاری): <b>${fmtNum(activeDebts.length)} فقره</b>`,
    `🔺 وام‌های اعطایی شما (مطالبات جاری): <b>${fmtNum(activeCredits.length)} فقره</b>`,
    '',
    '👇 جهت ارسال درخواست وام، یکی از کشورهای دارای خزانه را انتخاب کنید:'
  );

  const activeOwnerships = await listActive(data.season.id);
  const others = activeOwnerships.filter((o) => String(o.countryId) !== String(data.own.countryId));
  for (const o of others.slice(0, 10)) {
    const c = await countryService.get(o.countryId);
    if (c) rows.push([Markup.button.callback(`درخواست وام از: ${c.flag} ${c.name}`, `oil:loan:req:${c.id}`)]);
  }
  rows.push([Markup.button.callback('🔙 بازگشت به اقتصاد و نفت', 'emp:oil')]);

  await ctx.editMessageText(textLines.join('\n'), { parse_mode: 'HTML', reply_markup: Markup.inlineKeyboard(rows).reply_markup }).catch(() => {});
});

composer.action(/^oil:loan:req:(.+)$/, async (ctx) => {
  await ctx.answerCbQuery().catch(() => {});
  const lenderId = ctx.match[1];
  const lender = await countryService.get(lenderId);

  await userService.setFlow(ctx.from.id, 'game:loan:amount', { lenderId, lenderName: lender?.name, flag: lender?.flag });
  await ctx.reply([
    `🤝 <b>درخواست وام از ${lender?.flag} ${lender?.name}</b>`,
    '– – – – – – – – – –',
    'لطفاً <b>مبلغ وام درخواستی (به دلار)</b> را ارسال فرمایید:',
    '⚠️ <i>پس از ارسال، اعلان فوری با کلید تایید برای رهبر آن کشور فرستاده می‌شود و در صورت موافقت ایشان، مبلغ به خزانه شما واریز خواهد شد.</i>',
    'جهت لغو: /cancel',
  ].join('\n'), { parse_mode: 'HTML' });
});

registerFlow('game:loan:amount', async (ctx, data) => {
  const amount = Number(String(ctx.message.text || '').replace(/[^0-9]/g, ''));
  if (!amount || amount <= 0) return ctx.reply('⚠️ لطفاً یک رقم عددی معتبر برای مبلغ وام بفرستید. لغو: /cancel');

  const ownData = await requireCountry(ctx);
  if (!ownData) return;

  try {
    const res = await gameService.requestBilateralLoan({
      borrowerCountryId: ownData.own.countryId,
      lenderCountryId: data.lenderId,
      amount,
      seasonId: ownData.season.id,
      borrowerUserId: ctx.from.id,
    });

    await userService.clearFlow(ctx.from.id);
    await ctx.reply([
      '📨 <b>درخواست وام با موفقیت برای رهبر کشور مقصد ارسال شد!</b>',
      '– – – – – – – – – –',
      `مبلغ درخواستی: <b>+${fmtNum(amount)}$</b>`,
      `طرف حساب وام‌دهنده: <b>${res.lenderCountry?.flag} ${res.lenderCountry?.name}</b>`,
      '⚡ <b>وضعیت:</b> در انتظار بررسی و زدن دکمه تایید توسط رهبر کشور وام‌دهنده.',
      'به محض تایید ایشان، مبلغ فوراً به خزانه شما واریز شده و ۸۰٪ درآمدهای آینده جهت تسویه کسر خواهد شد.',
    ].join('\n'), {
      parse_mode: 'HTML',
      ...Markup.inlineKeyboard([[Markup.button.callback('🤝 سامانه وام', 'oil:loan')]]),
    });

    // ارسال اعلان تعاملی با کلیدهای تایید/رد برای رهبر کشور وام‌دهنده
    try {
      const lenderOwner = await getOwnerOfCountry(data.lenderId, ownData.season.id);
      if (lenderOwner && lenderOwner.userId && ctx.telegram) {
        const lenderMsg = [
          '🤝 <b>درخواست دریافت وام حاکمیتی جدید!</b>',
          '– – – – – – – – – –',
          `کشور <b>${ownData.own.country.flag} ${esc(ownData.own.country.name)}</b> به رهبری <b>${esc(ctx.state.user.displayName)}</b> درخواست دریافت وامی به مبلغ <b>${fmtNum(amount)}$</b> از خزانه کشور شما را دارد.`,
          '',
          '⚡ <b>قانون بازپرداخت ۸۰٪:</b> در صورت تایید شما، ۸۰٪ از هر نوبت درآمد واریزی این کشور مستقیماً به خزانه شما منتقل می‌شود تا بدهی کاملاً تسویه گردد.',
          '',
          'آیا با پرداخت این وام از خزانه موافقت می‌کنید؟',
        ].join('\n');

        await ctx.telegram.sendMessage(Number(lenderOwner.userId), lenderMsg, {
          parse_mode: 'HTML',
          reply_markup: {
            inline_keyboard: [
              [
                Markup.button.callback(`✅ موافقت و پرداخت ${fmtNum(amount)}$`, `loan:appr:${res.loan.id}`),
                Markup.button.callback('❌ رد درخواست وام', `loan:rejc:${res.loan.id}`),
              ],
              [Markup.button.callback('🤝 مشاهده سامانه وام', 'oil:loan')],
            ],
          },
        }).catch(() => {});
      }
    } catch (_) {}
  } catch (err) {
    await ctx.reply(`❌ خطا: ${esc(err.message)}`);
  }
});

// تایید و اعطای قطعی وام توسط کشور وام‌دهنده
composer.action(/^loan:appr:(.+)$/, async (ctx) => {
  await ctx.answerCbQuery().catch(() => {});
  const loanId = ctx.match[1];
  const data = await requireCountry(ctx);
  if (!data) return;

  try {
    const res = await gameService.approveBilateralLoan({
      loanId,
      lenderUserId: ctx.from.id,
      seasonId: data.season.id,
    });

    await ctx.editMessageText([
      '✅ <b>شما با اعطای این وام موافقت کردید!</b>',
      '– – – – – – – – – –',
      `مبلغ <b>${fmtNum(res.amount)}$</b> از خزانه شما کسر و به خزانه کشور <b>${res.borrowerCountry?.flag} ${res.borrowerCountry?.name}</b> واریز شد.`,
      '⚡ از این پس ۸۰٪ از درآمدهای واریزی آن کشور به صورت خودکار به خزانه شما منتقل می‌شود تا تسویه کامل بدهی.',
    ].join('\n'), {
      parse_mode: 'HTML',
      ...Markup.inlineKeyboard([[Markup.button.callback('🤝 سامانه وام', 'oil:loan')]]),
    }).catch(() => {});

    // اطلاع‌رسانی مستقیم به وام‌گیرنده
    if (res.borrowerUserId && ctx.telegram) {
      await ctx.telegram.sendMessage(Number(res.borrowerUserId), [
        '🎉 <b>درخواست وام شما توسط کشور مقصد تایید شد!</b>',
        '– – – – – – – – – –',
        `کشور <b>${res.lenderCountry?.flag} ${res.lenderCountry?.name}</b> با درخواست وام شما موافقت کرد.`,
        `💵 مبلغ <b>+${fmtNum(res.amount)}$</b> هم‌اکنون به موجودی خزانه کشور شما افزوده شد.`,
        '⚡ مطابق قانون، ۸۰٪ از درآمدهای دوره‌ای واریزی بعدی شما تا زمان تسویه بدهی به خزانه این کشور واریز خواهد شد.',
      ].join('\n'), {
        parse_mode: 'HTML',
        ...Markup.inlineKeyboard([
          [Markup.button.callback('👑 مشاهده امپراطوری', 'menu:empire')],
          [Markup.button.callback('🤝 سامانه وام', 'oil:loan')],
        ]),
      }).catch(() => {});
    }
  } catch (err) {
    await ctx.answerCbQuery(err.message, { show_alert: true }).catch(() => {});
    await ctx.reply(`❌ خطا در تایید وام: ${esc(err.message)}`);
  }
});

// رد درخواست وام توسط کشور وام‌دهنده
composer.action(/^loan:rejc:(.+)$/, async (ctx) => {
  await ctx.answerCbQuery().catch(() => {});
  const loanId = ctx.match[1];
  const data = await requireCountry(ctx);
  if (!data) return;

  try {
    const res = await gameService.rejectBilateralLoan({
      loanId,
      lenderUserId: ctx.from.id,
      seasonId: data.season.id,
    });

    await ctx.editMessageText(`❌ شما درخواست وام کشور <b>${res.borrowerCountry?.flag} ${res.borrowerCountry?.name}</b> را رد کردید.`, {
      parse_mode: 'HTML',
      ...Markup.inlineKeyboard([[Markup.button.callback('🤝 سامانه وام', 'oil:loan')]]),
    }).catch(() => {});

    if (res.borrowerUserId && ctx.telegram) {
      await ctx.telegram.sendMessage(Number(res.borrowerUserId), `⚠️ کشور <b>${res.lenderCountry?.flag} ${res.lenderCountry?.name}</b> درخواست وام شما را رد کرد.`, {
        parse_mode: 'HTML',
        ...Markup.inlineKeyboard([[Markup.button.callback('🤝 سامانه وام', 'oil:loan')]]),
      }).catch(() => {});
    }
  } catch (err) {
    await ctx.answerCbQuery(err.message, { show_alert: true }).catch(() => {});
  }
});

// لغو درخواست وام توسط کشور وام‌گیرنده
composer.action(/^loan:canc:(.+)$/, async (ctx) => {
  await ctx.answerCbQuery().catch(() => {});
  const loanId = ctx.match[1];
  try {
    await gameService.cancelBilateralLoan({
      loanId,
      borrowerUserId: ctx.from.id,
    });
    await ctx.answerCbQuery('درخواست وام با موفقیت لغو شد.', { show_alert: true }).catch(() => {});
    await ctx.reply('✅ درخواست وام با موفقیت لغو گردید.', Markup.inlineKeyboard([[Markup.button.callback('🤝 سامانه وام', 'oil:loan')]]));
  } catch (err) {
    await ctx.answerCbQuery(err.message, { show_alert: true }).catch(() => {});
  }
});

// -------------------------------------------------------------
// بازار جهانی (منابع پایه با قیمت ثابت و قابل تغییر توسط ادمین)
// -------------------------------------------------------------
composer.action(['oil:global', 'emp:global_market'], async (ctx) => {
  await ctx.answerCbQuery().catch(() => {});
  const data = await requireCountry(ctx);
  if (!data) return;
  const prices = (await gameService.getGlobalMarketPrices()) || {};
  const state = await gameService.getCountryState(data.own.countryId, data.season.id);

  const text = [
    '🌐 <b>بازار جهانی منابع، مواد اولیه و مصالح استراتژیک</b>',
    '– – – – – – – – – –',
    'قیمت این اقلام ثابت بوده و توسط ادمین تنظیم و بروزرسانی می‌شود:',
    ...Object.entries(prices || {}).map(([k, item]) => `• <b>${item ? item.name : k}:</b> هر ${item ? item.unit : 'واحد'} = <code>${fmtNum(item ? item.price : 0)}$</code>`),
    '',
    `💵 موجودی خزانه کشور شما: <b>${fmtNum(state.treasury || 0)}$</b>`,
    'کالای مورد نظر برای خرید یا فروش را انتخاب فرمایید:',
  ].join('\n');

  const rows = [];
  for (const [k, item] of Object.entries(prices || {})) {
    if (!item) continue;
    rows.push([
      Markup.button.callback(`🛒 خرید ${item.name}`, `oil:gm:buy:${k}`),
      Markup.button.callback(`💰 فروش ${item.name}`, `oil:gm:sell:${k}`),
    ]);
  }
  rows.push([
    Markup.button.callback('🛢️ بازگشت به اقتصاد و نفت', 'emp:oil'),
    Markup.button.callback('👑 بازگشت به امپراطوری', 'menu:empire'),
  ]);

  await ctx.editMessageText(text, { parse_mode: 'HTML', reply_markup: Markup.inlineKeyboard(rows).reply_markup }).catch(() => {});
});


composer.action(/^oil:gm:(buy|sell):(\w+)$/, async (ctx) => {
  await ctx.answerCbQuery().catch(() => {});
  const [action, itemKey] = [ctx.match[1], ctx.match[2]];
  const prices = await gameService.getGlobalMarketPrices();
  const item = prices[itemKey];
  if (!item) return;

  await userService.setFlow(ctx.from.id, 'game:global_market:trade', { action, itemKey, item });
  await ctx.reply([
    `🌐 <b>${action === 'buy' ? 'خرید' : 'فروش'} «${item.name}» در بازار جهانی</b>`,
    '– – – – – – – – – –',
    `قیمت مصوب: <b>${fmtNum(item.price)}$ به ازای هر ${item.unit}</b>`,
    '',
    `لطفاً <b>تعداد ${item.unit}</b> مورد نظر را ارسال فرمایید:`,
    'جهت لغو: /cancel',
  ].join('\n'), { parse_mode: 'HTML' });
});

registerFlow('game:global_market:trade', async (ctx, data) => {
  const qty = parseNonNegInt(ctx.message?.text);
  if (!qty || qty <= 0) return ctx.reply('⚠️ لطفاً یک مقدار عددی معتبر (فارسی یا انگلیسی) وارد نمایید. لغو: /cancel');

  const ownData = await requireCountry(ctx);
  if (!ownData) return;

  try {
    if (data.action === 'buy') {
      const res = await gameService.buyFromGlobalMarket(ownData.own.countryId, ownData.season.id, data.itemKey, qty);
      await userService.clearFlow(ctx.from.id);
      await ctx.reply(`✅ <b>تعداد ${fmtNum(res.qty)} ${data.item.unit} ${data.item.name} با هزینه ${fmtNum(res.totalCost)}$ خریداری شد!</b>\nخزانه باقیمانده: <b>${fmtNum(res.remainingTreasury)}$</b>`, {
        parse_mode: 'HTML',
        ...Markup.inlineKeyboard([[Markup.button.callback('🌐 بازار جهانی', 'oil:global')]]),
      });
    } else {
      const res = await gameService.sellToGlobalMarket(ownData.own.countryId, ownData.season.id, data.itemKey, qty);
      await userService.clearFlow(ctx.from.id);
      await ctx.reply(`✅ <b>تعداد ${fmtNum(res.qty)} ${data.item.unit} ${data.item.name} به مبلغ ${fmtNum(res.revenue)}$ فروخته شد!</b>\nخزانه جدید: <b>${fmtNum(res.newTreasury)}$</b>`, {
        parse_mode: 'HTML',
        ...Markup.inlineKeyboard([[Markup.button.callback('🌐 بازار جهانی', 'oil:global')]]),
      });
    }
  } catch (err) {
    await ctx.reply(`❌ خطا: ${esc(err.message)}`);
  }
});

// بازار عمومی بازیکنان (P2P با کارمزد ۱.۵٪ به بانک مرکزی)
composer.action('oil:market', async (ctx) => {
  await ctx.answerCbQuery().catch(() => {});
  const data = await requireCountry(ctx);
  if (!data) return;

  const offers = await gameService.listPublicMarketOffers(data.season.id);
  const text = [
    '🏪 <b>بازار عمومی و کالای بازیکنان</b>',
    '– – – – – – – – – –',
    'در این بازار کالاها بین بازیکنان با قیمت دلخواه معامله می‌شود.',
    '💡 کارمزد هر تراکنش ۱.۵٪ بوده و به خزانه بانک مرکزی واریز می‌گردد.',
    '',
    `تعداد آگهی‌های فعال فعلی: <b>${offers.length} مورد</b>`,
  ].join('\n');

  const rows = [];
  for (const o of offers.slice(0, 10)) {
    rows.push([
      Markup.button.callback(
        `${o.countryFlag} ${o.countryName} | ${o.itemKey} x${fmtNum(o.quantity)} (واحد ${fmtNum(o.pricePerUnit)}$)`,
        `oil:pub:buy:${o.id}`
      ),
    ]);
  }
  rows.push([Markup.button.callback('🔙 بازگشت به نفت', 'emp:oil')]);

  await ctx.editMessageText(text, { parse_mode: 'HTML', reply_markup: Markup.inlineKeyboard(rows).reply_markup }).catch(() => {});
});

// -------------------------------------------------------------
// ۳. بخش حمله و نبردها (اینلاین کامل زیر پیام)
// -------------------------------------------------------------
// -------------------------------------------------------------
// ۳. بخش حمله و نبردها (سیستم جدید چندمرحله‌ای با انتخاب شیوه، هدف و تجهیزات)
// -------------------------------------------------------------
const userAttackDrafts = new Map();

composer.hears('حمله 🇦', async (ctx) => {
  await showAttackPanel(ctx);
});
composer.action('emp:attack', async (ctx) => {
  await ctx.answerCbQuery().catch(() => {});
  await showAttackPanel(ctx, true);
});

async function showAttackPanel(ctx, isEdit = false) {
  const data = await requireCountry(ctx);
  if (!data) return;
  const { season, own } = data;
  const state = await gameService.getCountryState(own.countryId, season.id);
  const flag = countryService.getDynamicFlag(own.country, state);

  const text = [
    `⚔️ <b>مرکز عملیات نظامی و اتاق جنگ — ${esc(own.country.name)} ${flag}</b>`,
    '– – – – – – – – – –',
    `💥 قدرت تهاجمی پایه: <b>${fmtNum(state.military?.attack || 2124)}</b>`,
    `🛡 قدرت پدافند ملی: <b>${fmtNum(state.military?.defense || 2459)}</b>`,
    `🪖 ارتش و پیاده‌نظام: <b>${fmtNum(state.military?.ground || 74940)}</b>`,
    `🚀 موشک‌های بالستیک: <b>${fmtNum(state.missiles?.fateh110 || 18)}</b>`,
    state.armyAiLevel ? `🤖 سطح هوش مصنوعی ارتش: <b>سطح ${state.armyAiLevel} (+${(state.armyAiLevel - 1) * 10}٪ قدرت کل)</b>` : '',
    '',
    '👇 <b>مرحله اول: شیوه حمله مورد نظر خود را انتخاب کنید:</b>',
  ].filter(Boolean).join('\n');

  const kb = Markup.inlineKeyboard([
    [Markup.button.callback('🪖 حمله زمینی', 'atk:type:ground'), Markup.button.callback('🚢 حمله دریایی', 'atk:type:naval')],
    [Markup.button.callback('✈️ حمله هوایی', 'atk:type:air'), Markup.button.callback('🚀 حمله موشکی', 'atk:type:missile')],
    [Markup.button.callback('🤖 حمله ترکیبی تمام‌عیار', 'atk:type:combined')],
    [Markup.button.callback('🛒 خرید تجهیزات و تسلیحات نظامی', 'atk:shop')],
    [Markup.button.callback('🔙 بازگشت به امپراطوری', 'emp:home'), Markup.button.callback('🔙 بازگشت به منوی اصلی', 'menu:home')],
  ]);

  if (isEdit && ctx.callbackQuery) {
    await ctx.editMessageText(text, { parse_mode: 'HTML', reply_markup: kb.reply_markup }).catch(() => {});
  } else {
    await ctx.reply(text, { parse_mode: 'HTML', ...kb });
  }
}

// مرحله ۲: انتخاب کشور هدف
composer.action(/^atk:type:(\w+)$/, async (ctx) => {
  await ctx.answerCbQuery().catch(() => {});
  const attackType = ctx.match[1];
  const data = await requireCountry(ctx);
  if (!data) return;
  const { season, own } = data;

  const state = await gameService.getCountryState(own.countryId, season.id);
  const shield = gameService.isShielded(state);
  if (shield.shielded && shield.type === 'sleep') {
    return ctx.reply('⚠️ شما دارای سپر خواب هستید و نمی‌توانید حمله کنید. ابتدا سپر خواب را لغو نمایید.', Markup.inlineKeyboard([
      [Markup.button.callback('🔙 بازگشت به منوی اصلی', 'menu:home')],
    ]));
  }

  const attGeo = own.country.geography || countryService.getCountryGeography(own.country.name);
  if (attGeo === 'landlocked' && attackType === 'naval') {
    return ctx.reply('⚠️ کشور شما به دریا و آب‌های آزاد دسترسی ندارد و امکان اجرای عملیات دریایی برای شما فراهم نیست.', Markup.inlineKeyboard([
      [Markup.button.callback('🔙 بازگشت به اتاق جنگ', 'emp:attack')],
    ]));
  }

  const activeOwnerships = await listActive(season.id);
  const targets = activeOwnerships.filter((o) => o.countryId !== own.countryId);

  if (!targets.length) {
    return ctx.reply('🌍 در حال حاضر کشور فعال دیگری در سیزن برای هدف‌گیری وجود ندارد.', Markup.inlineKeyboard([
      [Markup.button.callback('🔙 بازگشت به منوی اصلی', 'menu:home')],
    ]));
  }

  const typeFa = {
    ground: 'زمینی 🪖',
    naval: 'دریایی 🚢',
    air: 'هوایی ✈️',
    missile: 'موشکی 🚀',
    combined: 'ترکیبی تمام‌عیار 🤖',
  }[attackType] || attackType;

  const rows = [];
  for (const t of targets.slice(0, 15)) {
    const c = await countryService.get(t.countryId);
    if (c) {
      const geoIcon = c.geography === 'island' ? '🏝️' : c.geography === 'landlocked' ? '🏔️' : '🌊';
      rows.push([Markup.button.callback(`🎯 هدف: ${c.flag} ${c.name} (${geoIcon})`, `atk:target:${attackType}:${c.id}`)]);
    }
  }
  rows.push([Markup.button.callback('🔙 بازگشت به اتاق جنگ', 'emp:attack'), Markup.button.callback('🔙 بازگشت به منوی اصلی', 'menu:home')]);

  await ctx.editMessageText(`🎯 <b>مرحله دوم: کشور هدف را برای «حمله ${typeFa}» انتخاب کنید:</b>\n(🏝️ = کشور جزیره‌ای | 🏔️ = محصور در خشکی | 🌊 = ساحلی)`, {
    parse_mode: 'HTML',
    reply_markup: Markup.inlineKeyboard(rows).reply_markup,
  }).catch(() => {});
});

// تولید کیبورد اینلاین انتخاب تجهیزات با تعیین تعداد دلخواه
async function buildEquipmentSelectorKeyboard(draft, countryId, seasonId) {
  const allWeapons = await weaponService.list();
  const state = await gameService.getCountryState(countryId, seasonId);

  // فیلتر تجهیزات مرتبط بر اساس شیوه حمله
  const filtered = allWeapons.filter((w) => {
    if (draft.attackType === 'combined') return true;
    if (draft.attackType === 'ground') return ['army', 'tank', 'armored_carrier', 'spy_drone', 'kamikaze_drone', 'army_ai', 'cargo_ship', 'warship', 'aircraft_carrier', 'cargo_plane'].includes(w.category);
    if (draft.attackType === 'naval') return ['aircraft_carrier', 'warship', 'boat', 'submarine', 'nuclear_sub', 'cargo_ship', 'spy_drone', 'army_ai'].includes(w.category);
    if (draft.attackType === 'air') return ['fighter', 'bomber', 'cargo_plane', 'spy_drone', 'kamikaze_drone', 'army_ai'].includes(w.category);
    if (draft.attackType === 'missile') return ['missile', 'nuclear_sub', 'defense', 'army_ai'].includes(w.category);
    return true;
  });

  const rows = [];
  for (const w of filtered) {
    const owned = gameService.getCountryUnitCount(state, w.id);
    const selectedCount = Number(draft.selectedUnitCounts?.[w.id] || 0);
    const indicator = selectedCount > 0 ? '🟢' : '⚪';
    const mainBtn = Markup.button.callback(
      `${indicator} ${w.emoji || '🛡️'} ${w.name.slice(0, 18)} [${selectedCount} / ${owned}]`,
      `atk:toggle:${w.id}`
    );
    const quickAdd = Markup.button.callback('+۵', `atk:add:${w.id}:5`);
    const allAdd = Markup.button.callback('همه', `atk:add:${w.id}:all`);
    const customAdd = Markup.button.callback('✏️ تعداد', `atk:set_qty:${w.id}`);
    rows.push([mainBtn, quickAdd, allAdd, customAdd]);
  }

  rows.push([
    Markup.button.callback('✅ تایید تجهیزات و محاسبه زمان پیشروی', 'atk:step:confirm'),
  ]);
  rows.push([
    Markup.button.callback('🔙 تغییر کشور هدف', `atk:type:${draft.attackType}`),
    Markup.button.callback('🔙 بازگشت به منوی اصلی', 'menu:home'),
  ]);

  return Markup.inlineKeyboard(rows);
}

// انتخاب کشور هدف بدون نمایش اسم استان‌ها (هدایت مستقیم به تجهیزات)
composer.action(/^atk:target:(\w+):(.+)$/, async (ctx) => {
  await ctx.answerCbQuery().catch(() => {});
  const [attackType, targetCountryId] = [ctx.match[1], ctx.match[2]];
  const data = await requireCountry(ctx);
  if (!data) return;
  const { season, own } = data;

  const targetCountry = await countryService.get(targetCountryId);
  if (!targetCountry) return ctx.reply('کشور هدف یافت نشد.');

  const attGeo = own.country.geography || countryService.getCountryGeography(own.country.name);
  const defGeo = targetCountry.geography || countryService.getCountryGeography(targetCountry.name);

  if (defGeo === 'landlocked' && attackType === 'naval') {
    return ctx.reply(`⚠️ کشور ${targetCountry.name} به دریا و آب‌های آزاد دسترسی ندارد و امکان حمله دریایی به آن وجود ندارد!`, Markup.inlineKeyboard([
      [Markup.button.callback('🔙 تغییر شیوه حمله', 'emp:attack')],
      [Markup.button.callback('🔙 بازگشت به منوی اصلی', 'menu:home')],
    ]));
  }

  // بررسی قانون ترانزیت کشورهای محصور در خشکی:
  if (attGeo === 'landlocked') {
    const hasPerm = await warService.checkTransitPermission({
      fromCountryId: own.countryId,
      targetCountryId,
      seasonId: season.id,
    });
    if (!hasPerm) {
      return ctx.editMessageText([
        '🏔️ <b>قانون ژئوپلیتیک: کشور شما محصور در خشکی است!</b>',
        '– – – – – – – – – –',
        `کشور <b>${own.country.flag} ${own.country.name}</b> هیچ مرز دریایی مستقلی ندارد.`,
        `برای لشکرکشی به <b>${targetCountry.flag} ${targetCountry.name}</b>، عبور از خاک یا حریم کشورهای همسایه الزامی است.`,
        '',
        '👇 جهت ارسال درخواست حق ترانزیت و عبور نظامی به همسایگان، کلیک کنید:',
      ].join('\n'), {
        parse_mode: 'HTML',
        ...Markup.inlineKeyboard([
          [Markup.button.callback('📜 ارسال درخواست مجوز عبور نظامی به همسایه', `atk:req_transit:${targetCountry.id}`)],
          [Markup.button.callback('🔙 بازگشت به اتاق جنگ', 'emp:attack')],
        ]),
      }).catch(() => {});
    }
  }

  const defenderState = await gameService.getCountryState(targetCountryId, season.id);
  const provinces = gameService.normalizeProvinces(defenderState.provinces, targetCountry.name);
  if (!provinces.length || defenderState.fallen) return ctx.reply('این کشور سقوط کرده و هدف فعالی نیست.');

  // انتخاب خودکار استان خط مقدم بدون الزام کاربر به درگیر شدن با نام استان‌ها
  const autoTargetProvince = provinces.find((p) => !p.isCapital) || provinces[0];

  const draft = {
    attackType,
    targetCountryId,
    targetName: targetCountry.name,
    targetFlag: targetCountry.flag,
    targetGeo: defGeo,
    selectedUnitCounts: {},
    targetProvinceId: autoTargetProvince.id,
    targetProvince: autoTargetProvince,
  };
  userAttackDrafts.set(ctx.from.id, draft);

  await showEquipmentSelection(ctx, draft, season.id, own.countryId);
});

async function showEquipmentSelection(ctx, draft, seasonId, countryId) {
  const kb = await buildEquipmentSelectorKeyboard(draft, countryId, seasonId);
  const text = [
    `⚔️ <b>انتخاب تجهیزات و قوای نظامی علیه ${draft.targetFlag} ${esc(draft.targetName)}</b>`,
    '– – – – – – – – – –',
    'تعداد دلخواه از هر نوع تجهیزات را مشخص نمایید:',
    '• کلید <b>«+۵»</b> یا <b>«همه»</b> را برای افزودن سریع بزنید، یا با کلید <b>«✏️ تعداد»</b> رقم دلخواه بنویسید.',
    draft.targetGeo === 'island' ? '⚠️ <i>چون کشور مقصد جزیره است، برای انتقال زمینی حتماً ناو تجهیزات‌بر یا هواپیمای ترابری به همراه داشته باشید.</i>' : '',
    '',
    '👇 پس از مشخص‌کردن تجهیزات، «تایید تجهیزات» را لمس کنید:',
  ].filter(Boolean).join('\n');
  await ctx.editMessageText(text, { parse_mode: 'HTML', reply_markup: kb.reply_markup }).catch(() => {});
}

// تغییر وضعیت انتخاب تجهیزات (صفر یا ۱ واحد)
composer.action(/^atk:toggle:(.+)$/, async (ctx) => {
  const unitId = ctx.match[1];
  const draft = userAttackDrafts.get(ctx.from.id);
  if (!draft) return ctx.answerCbQuery('جلسه حمله منقضی شده است.', { show_alert: true });

  const current = Number(draft.selectedUnitCounts?.[unitId] || 0);
  if (current > 0) {
    draft.selectedUnitCounts[unitId] = 0;
    await ctx.answerCbQuery('⚪ حذف شد.');
  } else {
    draft.selectedUnitCounts = draft.selectedUnitCounts || {};
    draft.selectedUnitCounts[unitId] = 1;
    await ctx.answerCbQuery('🟢 ۱ عدد انتخاب شد.');
  }

  const data = await requireCountry(ctx);
  if (!data) return;
  const kb = await buildEquipmentSelectorKeyboard(draft, data.own.countryId, data.season.id);
  await ctx.editMessageReplyMarkup(kb.reply_markup).catch(() => {});
});

// افزایش سریع تعداد تجهیزات (+۵ یا همه)
composer.action(/^atk:add:([^:]+):(5|all)$/, async (ctx) => {
  const [unitId, mode] = [ctx.match[1], ctx.match[2]];
  const draft = userAttackDrafts.get(ctx.from.id);
  if (!draft) return ctx.answerCbQuery('جلسه حمله منقضی شده است.', { show_alert: true });

  const data = await requireCountry(ctx);
  if (!data) return;
  const state = await gameService.getCountryState(data.own.countryId, data.season.id);
  const owned = gameService.getCountryUnitCount(state, unitId);

  draft.selectedUnitCounts = draft.selectedUnitCounts || {};
  const current = Number(draft.selectedUnitCounts[unitId] || 0);

  if (mode === 'all') {
    draft.selectedUnitCounts[unitId] = owned;
    await ctx.answerCbQuery(`🟢 تمام ${owned} عدد انتخاب شد.`);
  } else {
    const nextVal = Math.min(owned, current + 5);
    draft.selectedUnitCounts[unitId] = nextVal;
    await ctx.answerCbQuery(`🟢 تعداد به ${nextVal} افزایش یافت.`);
  }

  const kb = await buildEquipmentSelectorKeyboard(draft, data.own.countryId, data.season.id);
  await ctx.editMessageReplyMarkup(kb.reply_markup).catch(() => {});
});

// وارد کردن تعداد دلخواه برای تجهیزات حمله
composer.action(/^atk:set_qty:(.+)$/, async (ctx) => {
  await ctx.answerCbQuery().catch(() => {});
  const unitId = ctx.match[1];
  const draft = userAttackDrafts.get(ctx.from.id);
  if (!draft) return ctx.reply('جلسه منقضی شده است.');

  const data = await requireCountry(ctx);
  if (!data) return;
  const state = await gameService.getCountryState(data.own.countryId, data.season.id);
  const owned = gameService.getCountryUnitCount(state, unitId);
  const w = await weaponService.get(unitId);

  await userService.setFlow(ctx.from.id, 'game:atk:custom_qty', { unitId, owned, unitName: w?.name });
  await ctx.reply([
    `✏️ <b>تعیین تعداد اعزامی برای «${w?.name}»</b>`,
    '– – – – – – – – – –',
    `حداکثر موجودی در ارتش شما: <b>${owned.toLocaleString()} عدد</b>`,
    '',
    'لطفاً <b>تعداد دلخواه</b> را ارسال کنید:',
    '(جهت انصراف: /cancel)',
  ].join('\n'), { parse_mode: 'HTML' });
});

registerFlow('game:atk:custom_qty', async (ctx, data) => {
  const count = Number(String(ctx.message?.text || '').replace(/[^0-9]/g, ''));
  if (!count || count < 0 || count > data.owned) {
    return ctx.reply(`⚠️ لطفاً عددی بین ۱ تا ${data.owned.toLocaleString()} وارد نمایید. انصراف: /cancel`);
  }

  const draft = userAttackDrafts.get(ctx.from.id);
  if (!draft) return ctx.reply('جلسه حمله منقضی شده است. از اتاق جنگ دوباره اقدام کنید.');

  draft.selectedUnitCounts = draft.selectedUnitCounts || {};
  draft.selectedUnitCounts[data.unitId] = count;

  await userService.clearFlow(ctx.from.id);
  await ctx.reply(`✅ تعداد <b>${count.toLocaleString()} عدد</b> از «${data.unitName}» در کاروان حمله قرار گرفت.`, {
    parse_mode: 'HTML',
    ...Markup.inlineKeyboard([[Markup.button.callback('⚔️ ادامه چیدمان حمله', 'atk:step:confirm')]]),
  });
});

// ارسال درخواست ترانزیت و عبور نظامی به همسایگان
composer.action(/^atk:req_transit:(.+)$/, async (ctx) => {
  await ctx.answerCbQuery().catch(() => {});
  const targetCountryId = ctx.match[1];
  const data = await requireCountry(ctx);
  if (!data) return;

  const activeOwnerships = await listActive(data.season.id);
  const others = activeOwnerships.filter((o) => String(o.countryId) !== String(data.own.countryId) && String(o.countryId) !== String(targetCountryId));

  if (!others.length) {
    return ctx.reply('🌍 همسایه فعالی برای صدور ترانزیت وجود ندارد.');
  }

  const rows = [];
  for (const o of others.slice(0, 8)) {
    const c = await countryService.get(o.countryId);
    if (c) rows.push([Markup.button.callback(`درخواست عبور از: ${c.flag} ${c.name}`, `atk:transit_send:${c.id}:${targetCountryId}`)]);
  }
  rows.push([Markup.button.callback('🔙 بازگشت', 'emp:attack')]);

  await ctx.editMessageText('🏔️ <b>کشور همسایه را جهت درخواست مجوز عبور نظامی انتخاب کنید:</b>', {
    parse_mode: 'HTML',
    reply_markup: Markup.inlineKeyboard(rows).reply_markup,
  }).catch(() => {});
});

composer.action(/^atk:transit_send:([^:]+):(.+)$/, async (ctx) => {
  await ctx.answerCbQuery().catch(() => {});
  const [neighborId, targetCid] = [ctx.match[1], ctx.match[2]];
  const data = await requireCountry(ctx);
  if (!data) return;

  const req = await warService.requestTransit({
    fromCountryId: data.own.countryId,
    transitCountryId: neighborId,
    targetCountryId: targetCid,
    seasonId: data.season.id,
    userId: ctx.from.id,
  });

  const neighborCountry = await countryService.get(neighborId);
  const targetCountry = await countryService.get(targetCid);

  // ارسال پیام فوری به رهبر همسایه
  const activeOwnerships = await listActive(data.season.id);
  const neighOwn = activeOwnerships.find((o) => String(o.countryId) === String(neighborId));
  if (neighOwn) {
    await notifications.safeSend(ctx.telegram, neighOwn.userId, [
      '📜 <b>درخواست اضطراری حق ترانزیت و عبور نظامی!</b>',
      '– – – – – – – – – –',
      `رهبر کشور <b>${data.own.country.flag} ${data.own.country.name}</b> درخواست عبور قوای نظامی از خاک کشور شما برای حمله به <b>${targetCountry?.flag} ${targetCountry?.name}</b> را دارد.`,
      '',
      'آیا مجوز عبور نیروها را صادر می‌کنید؟',
    ].join('\n'), Markup.inlineKeyboard([
      [Markup.button.callback('✅ صدور مجوز عبور', `transit:decide:${req.id}:yes`)],
      [Markup.button.callback('❌ رد درخواست عبور', `transit:decide:${req.id}:no`)],
    ]));
  }

  await ctx.reply(`📨 درخواست مجوز ترانزیت برای رهبر کشور ${neighborCountry?.flag} ${neighborCountry?.name} مخابره شد.\nبه محض تایید، تهاجم نظامی قابل اجرا خواهد بود.`);
});

composer.action(/^transit:decide:([^:]+):(yes|no)$/, async (ctx) => {
  const [reqId, dec] = [ctx.match[1], ctx.match[2]];
  const approved = dec === 'yes';
  try {
    const res = await warService.decideTransit({
      requestId: reqId,
      approved,
      adminOrLeaderId: ctx.from.id,
    });
    await ctx.answerCbQuery(approved ? '✅ مجوز صادر شد.' : '❌ درخواست رد شد.', { show_alert: true });
    await ctx.editMessageText(approved ? '✅ مجوز عبور نیروهای نظامی صادر گردید.' : '❌ درخواست عبور رد شد.').catch(() => {});

    // اطلاع به درخواست‌دهنده
    if (res.requestedByUserId) {
      await notifications.safeSend(ctx.telegram, res.requestedByUserId,
        approved
          ? '🎉 <b>مجوز عبور نظامی صادر شد!</b>\nکشور همسایه با ترانزیت نیروهای شما موافقت کرد. اکنون می‌توانید عملیات نظامی را آغاز نمایید.'
          : '❌ <b>درخواست عبور رد شد!</b>\nکشور همسایه با عبور نیروهای نظامی از مرزهای خود موافقت نکرد.'
      );
    }
  } catch (err) {
    await ctx.answerCbQuery(err.message, { show_alert: true });
  }
});

// مرحله تایید نهایی و محاسبه دقیق زمان پیشروی (۱۰ دقیقه تا ۴ دقیقه با ترابری)
composer.action('atk:step:confirm', async (ctx) => {
  await ctx.answerCbQuery().catch(() => {});
  const draft = userAttackDrafts.get(ctx.from.id);
  if (!draft) {
    return ctx.reply('⚠️ جلسه حمله منقضی شده است. لطفاً از منوی حمله مجدداً آغاز کنید.', Markup.inlineKeyboard([
      [Markup.button.callback('⚔️ ورود به اتاق حمله', 'emp:attack')],
      [Markup.button.callback('🔙 بازگشت به منوی اصلی', 'menu:home')],
    ]));
  }

  const selectedEntries = Object.entries(draft.selectedUnitCounts || {}).filter(([, count]) => Number(count) > 0);
  if (!selectedEntries.length) {
    return ctx.answerCbQuery('⚠️ حداقل تعداد یک نوع تجهیزات را تعیین کنید!', { show_alert: true });
  }

  const data = await requireCountry(ctx);
  if (!data) return;
  const { season, own } = data;
  const state = await gameService.getCountryState(own.countryId, season.id);
  const targetCountry = await countryService.get(draft.targetCountryId);

  const selectedUnitsList = [];
  let totalSelectedPower = 0;
  let hasArmoredCarrier = false;
  let hasCargoPlane = false;
  let hasNavalCarrier = false;

  for (const [uid, count] of selectedEntries) {
    const w = await weaponService.get(uid);
    if (w) {
      const owned = gameService.getCountryUnitCount(state, w.id);
      const c = Math.min(owned, Number(count) || 1);
      selectedUnitsList.push({
        id: w.id,
        name: w.name,
        emoji: w.emoji || '🛡️',
        category: w.category,
        power: Number(w.power) || 20,
        count: c,
        ownedCount: owned,
      });
      totalSelectedPower += (Number(w.power) || 20) * c;
      if (w.category === 'armored_carrier') hasArmoredCarrier = true;
      if (w.category === 'cargo_plane') hasCargoPlane = true;
      if (['cargo_ship', 'warship', 'aircraft_carrier'].includes(w.category)) hasNavalCarrier = true;
    }
  }

  // اعتبارسنجی کشور جزیره‌ای
  if (draft.targetGeo === 'island' && (draft.attackType === 'ground' || draft.attackType === 'combined')) {
    if (!hasNavalCarrier && !hasCargoPlane) {
      return ctx.reply(`⚠️ <b>محدودیت جزیره‌ای:</b> کشور مقصد (${targetCountry.name}) یک جزیره است! برای انتقال نیروها باید حداقل یک «ناو تجهیزات‌بر»، «ناو جنگی» یا «هواپیمای ترابری» اعزام کنید.`, Markup.inlineKeyboard([
        [Markup.button.callback('🔙 بازگشت و اصلاح تجهیزات', `atk:target:${draft.attackType}:${draft.targetCountryId}`)],
        [Markup.button.callback('🔙 بازگشت به منوی اصلی', 'menu:home')],
      ]));
    }
  }

  // زمان پایه عملیات ۱۰ دقیقه (۶۰۰ ثانیه)؛ با ناوترابری و هواپیمای ترابری سریع‌تر (تا ۴-۶ دقیقه)
  let travelSeconds = 600;
  let speedBonusText = '🐢 اعزام عادی؛ زمان پایه ۱۰ دقیقه';
  let speedPercent = 0;

  if (hasArmoredCarrier) {
    travelSeconds = Math.floor(travelSeconds * 0.75); // ۲۵٪ کاهش (۷.۵ دقیقه)
    speedBonusText = '🚚 زره‌بر: کاهش ۲۵٪ زمان اعزام';
    speedPercent += 25;
  }
  if (hasCargoPlane) {
    travelSeconds = Math.floor(travelSeconds * 0.60); // ۴۰٪ کاهش (۶ دقیقه)
    speedBonusText = hasArmoredCarrier
      ? '⚡ زره‌بر + هواپیمای ترابری: کاهش سرعت ترکیبی به ۴.۵ دقیقه'
      : '🛫 هواپیمای ترابری: کاهش ۴۰٪ زمان اعزام (۶ دقیقه)';
    speedPercent += 40;
  }
  if (hasNavalCarrier && (draft.attackType === 'naval' || draft.targetGeo === 'island')) {
    travelSeconds = Math.floor(travelSeconds * 0.70);
    speedPercent += 30;
  }

  // کف زمان محاصره ۴ دقیقه (۲۴۰ ثانیه) جهت جلوگیری قطعی از فتح آبکی و رعایت زمان‌واقعی
  travelSeconds = Math.max(240, travelSeconds);

  const totalAttackPower = (state.military?.attack || 1000) + totalSelectedPower;
  const travelMin = Math.floor(travelSeconds / 60);
  const travelSec = travelSeconds % 60;

  const lines = [
    '⚔️ <b>پیش‌نمایش و تایید اعزام ارتش — زمان واقعی</b>',
    '– – – – – – – – – –',
    `کشور هدف = <b>${esc(targetCountry.name)} ${targetCountry.flag}</b>`,
    `قدرت هجومی کاروان = <b>${fmtNum(totalAttackPower)}</b>`,
    '– – – – – – – – – –',
    'قوای اعزامی منتخب شما:',
    ...selectedUnitsList.map((u) => `• <b>${esc(u.name)}</b>: ${fmtNum(u.count)} واحد اعزامی (از ${fmtNum(u.ownedCount)} موجود)`),
    '– – – – – – – – – –',
    `⏱ مدت‌زمان رسیدن و پیشروی = <b>${travelMin} دقیقه و ${travelSec} ثانیه</b>`,
    `<i>${speedBonusText}</i>`,
    '',
    '🛡 <i>توجه: نبرد بلافاصله پس از پایان شمارش معکوس زمان واقعی در سرور حل خواهد شد و مدافع فرصت دفاع و ضدحمله خواهد داشت.</i>',
  ].join('\n');

  draft.selectedUnitsDetails = selectedUnitsList;
  draft.travelSeconds = travelSeconds;
  draft.speedBonusPercent = speedPercent;

  await ctx.editMessageText(lines, {
    parse_mode: 'HTML',
    reply_markup: Markup.inlineKeyboard([
      [Markup.button.callback('🚀 صدور فرمان حمله و حرکت نیروها', 'atk:step:launch')],
      [Markup.button.callback('❌ لغو عملیات', 'emp:attack')],
      [Markup.button.callback('🔙 بازگشت به منوی اصلی', 'menu:home')],
    ]).reply_markup,
  }).catch(() => {});
});

// مرحله ۵: پرتاب و اعزام نیروها به صورت ۱۰ دقیقه‌ای زمان‌واقعی (بدون فتح آبکی)
composer.action('atk:step:launch', async (ctx) => {
  await ctx.answerCbQuery().catch(() => {});
  const draft = userAttackDrafts.get(ctx.from.id);
  if (!draft) return ctx.reply('⚠️ جلسه حمله منقضی شده است. مجدداً از منو آغاز کنید.');

  const data = await requireCountry(ctx);
  if (!data) return;
  const { season, own } = data;

  const targetCountry = await countryService.get(draft.targetCountryId);
  const activeOwnerships = await listActive(season.id);
  const targetOwn = activeOwnerships.find((o) => String(o.countryId) === String(draft.targetCountryId));

  // بررسی نقش‌های هیئت دولت طبق قوانین تفکیک قوا
  if (ctx.state.isMinister && ctx.state.ministerRole === 'economy') {
    return ctx.answerCbQuery('⛔ عدم دسترسی: به عنوان وزیر اقتصاد، اختیارات شما منحصر به امور مالی، احداث دکل‌ها و ساخت‌وساز است.', { show_alert: true });
  }

  if (ctx.state.isMinister && ctx.state.ministerRole === 'war') {
    try {
      await ministerService.createMinisterWarProposal({
        type: 'attack',
        countryId: own.countryId,
        seasonId: season.id,
        ministerId: ctx.from.id,
        ministerName: ctx.state.user.displayName,
        targetCountryId: draft.targetCountryId,
        targetCountryName: targetCountry.name,
        payload: {
          defenderUserId: targetOwn?.userId || null,
          attackType: draft.attackType,
          selectedUnits: draft.selectedUnitsDetails || [],
        },
        telegram: ctx.telegram,
      });

      userAttackDrafts.delete(ctx.from.id);
      await ctx.answerCbQuery('📨 پیشنهاد صدور فرمان حمله با موفقیت برای رهبر کشورتان ارسال شد.', { show_alert: true });
      return ctx.editMessageText([
        '📨 <b>پیشنهاد عملیات نظامی برای رهبر کشور ارسال شد!</b>',
        '– – – – – – – – – –',
        `کشور هدف: <b>${targetCountry.flag} ${esc(targetCountry.name)}</b>`,
        'به عنوان وزیر جنگ، به محض تایید و صدور فرماندهی کل قوا (رهبر کشور)، ارتش حرکت خواهد کرد.',
      ].join('\n'), {
        parse_mode: 'HTML',
        reply_markup: {
          inline_keyboard: [
            [Markup.button.callback('👑 امپراطوری من', 'menu:empire')],
          ],
        },
      }).catch(() => {});
    } catch (err) {
      return ctx.answerCbQuery(err.message, { show_alert: true });
    }
  }

  try {
    const travelSec = draft.travelSeconds || 600;
    const travelMin = Math.floor(travelSec / 60);
    const travelRemSec = travelSec % 60;

    // ثبت نبرد فعال در پایگاه داده
    const battle = await warService.createActiveBattle({
      seasonId: season.id,
      attackerCountryId: own.countryId,
      attackerUserId: ctx.from.id,
      defenderCountryId: draft.targetCountryId,
      defenderUserId: targetOwn?.userId || null,
      attackType: draft.attackType,
      selectedUnits: draft.selectedUnitsDetails || [],
      travelSeconds: travelSec,
      targetProvinceId: draft.targetProvinceId,
      speedBonusPercent: draft.speedBonusPercent || 0,
    });

    userAttackDrafts.delete(ctx.from.id);

    // ارسال اعلان فوری وضعیت قرمز به مدافع
    if (targetOwn && targetOwn.userId) {
      const redAlertText = [
        '🚨 <b>هشدار وضعیت قرمز: تهاجم نظامی آغاز شد!</b>',
        '– – – – – – – – – –',
        `کشور متخاصم <b>${own.country.flag} ${esc(own.country.name)}</b> نیروهای جنگی خود را به سمت مرزهای شما اعزام کرده است!`,
        `⏱ زمان باقی‌مانده تا رسیدن قوای مهاجم: <b>${travelMin} دقیقه و ${travelRemSec} ثانیه</b>`,
        '',
        '🛡️ سریعاً به بخش <b>«دفاع 🛡️»</b> رفته و سامانه دفاع خودکار را فعال کنید.',
      ].join('\n');

      await notifications.safeSend(ctx.telegram, targetOwn.userId, redAlertText, Markup.inlineKeyboard([
        [Markup.button.callback('🛡️ ورود به مرکز دفاع و پدافند', 'emp:defense')],
      ])).catch(() => {});
    }

    // اعلام عمومی در کانال رسمی
    const chanAlert = [
      '⚔️ <b>اعزام کاروان نظامی به سوی خطوط مرزی!</b>',
      '– – – – – – – – – –',
      `کشور <b>${own.country.flag} ${esc(own.country.name)}</b> کاروان جنگی خود را برای حمله به کشور <b>${targetCountry?.flag} ${esc(targetCountry?.name)}</b> گسیل داشت!`,
      `⏱ زمان رسیدن نیروها به صحنه نبرد: <b>${travelMin} دقیقه و ${travelRemSec} ثانیه</b>`,
      '– – – – – – – – – –',
      '🌐 <i>نتیجه قطعی نبرد پس از پایان زمان واقعی محاصره اعلام خواهد شد.</i>',
    ].join('\n');
    await notifications.publishToChannel(ctx.telegram, 'war_news', chanAlert).catch(() => {});

    // پیام برای مهاجم
    await ctx.reply([
      '🚀 <b>فرمان حمله صادر شد! نیروها در حال پیشروی هستند</b>',
      '– – – – – – – – – –',
      `🎯 مقصد عملیات: <b>${targetCountry?.flag} ${esc(targetCountry?.name)}</b>`,
      `⏱ زمان رسیدن به خط مقدم نبرد: <b>${travelMin} دقیقه و ${travelRemSec} ثانیه</b>`,
      '',
      'نتیجه نبرد پس از اتمام زمان محاسبه و اعلام خواهد شد.',
    ].join('\n'), {
      parse_mode: 'HTML',
      ...Markup.inlineKeyboard([
        [Markup.button.callback('👑 بازگشت به امپراطوری', 'emp:home')],
        [Markup.button.callback('🔙 بازگشت به منوی اصلی', 'menu:home')],
      ]),
    });
  } catch (err) {
    await ctx.reply(`⚠️ خطا در آغاز عملیات: ${err.message}`);
  }
});

composer.action(/^atk:shop(?::cat:(.+))?$/, async (ctx) => {
  await ctx.answerCbQuery().catch(() => {});
  const data = await requireCountry(ctx);
  if (!data) return;
  const { season, own } = data;
  const state = await gameService.getCountryState(own.countryId, season.id);
  const weapons = await weaponService.list();

  const selectedCategory = ctx.match?.[1] || null;
  const text = [
    '🛒 <b>فروشگاه تسلیحات و صنایع نظامی پیشرفته</b>',
    `💵 بودجه خزانه کشور: <b>${fmtNum(state.treasury)}$</b>`,
    '– – – – – – – – – –',
    selectedCategory ? 'فهرست تجهیزات این دسته؛ برای دیدن قیمت، قدرت و مصرف نفت روی نام محصول بزنید.' : 'ابتدا دسته‌بندی تجهیزات را انتخاب کنید:',
  ].join('\n');

  const rows = [];
  if (!selectedCategory) {
    for (let i = 0; i < weaponService.WEAPON_CATEGORIES.length; i += 2) {
      const a = weaponService.WEAPON_CATEGORIES[i], b = weaponService.WEAPON_CATEGORIES[i + 1];
      rows.push([Markup.button.callback(`🔵 ${a.name}`, `atk:shop:cat:${a.id}`), ...(b ? [Markup.button.callback(`🟢 ${b.name}`, `atk:shop:cat:${b.id}`)] : [])]);
    }
  } else {
    const filtered = weapons.filter((w) => w.category === selectedCategory);
    for (const w of filtered) rows.push([Markup.button.callback(`${w.emoji || '🛡️'} ${w.name}`, `wpn:view:${w.id}`)]);
    rows.push([Markup.button.callback('🔙 دسته‌بندی‌ها', 'atk:shop')]);
  }
  rows.push([Markup.button.callback('🔙 بازگشت به اتاق جنگ', 'emp:attack')]);

  await ctx.editMessageText(text, {
    parse_mode: 'HTML',
    reply_markup: Markup.inlineKeyboard(rows).reply_markup,
  }).catch(() => {});
});

// نمایش جزئیات سلاح و انتخاب تعداد
composer.action(/^wpn:view:(.+)$/, async (ctx) => {
  await ctx.answerCbQuery().catch(() => {});
  const weaponId = ctx.match[1];
  const data = await requireCountry(ctx);
  if (!data) return;
  const { season, own } = data;

  const weapon = await weaponService.get(weaponId);
  if (!weapon) return ctx.reply('سلاح یافت نشد.');
  const state = await gameService.getCountryState(own.countryId, season.id);

  let currentCount = 0;
  if (state.groundUnits && state.groundUnits[weapon.key || weapon.id]) currentCount = state.groundUnits[weapon.key || weapon.id];
  else if (state.airUnits && state.airUnits[weapon.key || weapon.id]) currentCount = state.airUnits[weapon.key || weapon.id];
  else if (state.missiles && state.missiles[weapon.key || weapon.id]) currentCount = state.missiles[weapon.key || weapon.id];
  else if (state.airDefense && state.airDefense[weapon.key || weapon.id]) currentCount = state.airDefense[weapon.key || weapon.id];
  else if (state.navalUnits && state.navalUnits[weapon.key || weapon.id]) currentCount = state.navalUnits[weapon.key || weapon.id];
  else if (state.arsenal && state.arsenal[weapon.key || weapon.id]) currentCount = state.arsenal[weapon.key || weapon.id];

  const catFa = weapon.category === 'ground' ? 'زمینی' : weapon.category === 'air' ? 'هوایی' : weapon.category === 'missile' ? 'موشکی' : weapon.category === 'naval' ? 'دریایی' : 'پدافند';

  const reqTier = weapon.nuclearTierRequired || (weapon.category === 'nuclear_sub' ? 60 : weapon.category === 'nuclear_warhead' ? 100 : (weapon.name && (weapon.name.includes('اتمی') || weapon.name.includes('هسته‌ای')) ? 60 : null));
  const reqUraniumPerUnit = weapon.enrichedUraniumRequired || (reqTier === 100 ? 100 : reqTier === 60 ? 50 : (reqTier ? 30 : 0));
  let nuclearReqLine = '';
  if (reqTier && reqUraniumPerUnit > 0) {
    const enrichedStock = Number(state.enrichedUranium?.[`tier${reqTier}`] || 0);
    const hasEnough = enrichedStock >= reqUraniumPerUnit;
    nuclearReqLine = `☢️ نیاز به اورانیوم غنی‌شده: <b>${reqUraniumPerUnit} کیلوگرم غنی‌شده ${reqTier}٪</b> (${hasEnough ? '🟢 موجودی: ' : '🔴 کمبود: '}${fmtNum(enrichedStock)} kg)`;
  }

  const text = [
    `${weapon.emoji} <b>${esc(weapon.name)}</b>`,
    '– – – – – – – – – –',
    `🏷 دسته‌بندی: <b>نیروی ${catFa}</b>`,
    `💵 قیمت هر واحد: <b>${fmtNum(weapon.price)}$</b>`,
    `💥 قدرت نظامی هر واحد: <b>+${weapon.power}</b>`,
    nuclearReqLine,
    `🛢 مصرف نفت: <b>${fmtNum(weapon.oilUse || 5)} بشکه به‌ازای هر ساعت فعالیت</b> (برای هر عملیات، یک ساعت مصرف پایه)`,
    `⚙️ کاربرد: ${esc(weapon.capability || weaponService.getCategoryInfo(weapon.category).capability)}`,
    `⏱ زمان پایه رسیدن نیرو: <b>۱۰ دقیقه</b>${['armored_carrier', 'cargo_plane', 'cargo_ship'].includes(weapon.category) ? '؛ این وسیله سرعت انتقال نیرو/تجهیزات را افزایش می‌دهد.' : ''}`,
    `🪖 موجودی فعلی در ارتش شما: <b>${fmtNum(currentCount)} عدد</b>`,
    `💰 موجودی خزانه شما: <b>${fmtNum(state.treasury)}$</b>`,
    '',
    '👇 تعداد مورد نیاز خود را انتخاب کنید یا تعداد دلخواه بنویسید:',
  ].filter(Boolean).join('\n');

  const kb = Markup.inlineKeyboard([
    [
      Markup.button.callback('۱ عدد', `wpn:buy:${weapon.id}:1`),
      Markup.button.callback('۵ عدد', `wpn:buy:${weapon.id}:5`),
      Markup.button.callback('۱۰ عدد', `wpn:buy:${weapon.id}:10`),
    ],
    [
      Markup.button.callback('۲۵ عدد', `wpn:buy:${weapon.id}:25`),
      Markup.button.callback('۵۰ عدد', `wpn:buy:${weapon.id}:50`),
      Markup.button.callback('۱۰۰ عدد', `wpn:buy:${weapon.id}:100`),
    ],
    [Markup.button.callback('✏️ وارد کردن تعداد دلخواه (متنی)', `wpn:custom:${weapon.id}`)],
    [Markup.button.callback('🔙 بازگشت به لیست تسلیحات', 'atk:shop')],
  ]);

  await ctx.editMessageText(text, { parse_mode: 'HTML', reply_markup: kb.reply_markup }).catch(() => {});
});

// خرید تعداد سریع
composer.action(/^wpn:buy:([^:]+):(\d+)$/, async (ctx) => {
  const [weaponId, countStr] = [ctx.match[1], ctx.match[2]];
  const count = Number(countStr) || 1;
  const data = await requireCountry(ctx);
  if (!data) return;
  const { season, own } = data;

  try {
    const res = await gameService.buyMilitaryUnit(own.countryId, season.id, weaponId, count);
    await ctx.answerCbQuery(`✅ ${fmtNum(count)} عدد ${res.unit.name} به ارزش ${fmtNum(res.totalCost)}$ خریداری شد!`, { show_alert: true });
    // بازگشت به نمایش همان سلاح با ارقام به‌روز شده
    const weapon = res.unit;
    const state = await gameService.getCountryState(own.countryId, season.id);
    let currentCount = 0;
    if (state.groundUnits && state.groundUnits[weapon.key || weapon.id]) currentCount = state.groundUnits[weapon.key || weapon.id];
    else if (state.airUnits && state.airUnits[weapon.key || weapon.id]) currentCount = state.airUnits[weapon.key || weapon.id];
    else if (state.missiles && state.missiles[weapon.key || weapon.id]) currentCount = state.missiles[weapon.key || weapon.id];
    else if (state.airDefense && state.airDefense[weapon.key || weapon.id]) currentCount = state.airDefense[weapon.key || weapon.id];
    else if (state.navalUnits && state.navalUnits[weapon.key || weapon.id]) currentCount = state.navalUnits[weapon.key || weapon.id];
    else if (state.arsenal && state.arsenal[weapon.key || weapon.id]) currentCount = state.arsenal[weapon.key || weapon.id];

    const catFa = weapon.category === 'ground' ? 'زمینی' : weapon.category === 'air' ? 'هوایی' : weapon.category === 'missile' ? 'موشکی' : weapon.category === 'naval' ? 'دریایی' : 'پدافند';
    const text = [
      `🎉 <b>خرید با موفقیت انجام شد!</b>`,
      `${weapon.emoji} <b>${esc(weapon.name)}</b>`,
      '– – – – – – – – – –',
      `🏷 دسته‌بندی: <b>نیروی ${catFa}</b>`,
      `💵 قیمت واحد: <b>${fmtNum(weapon.price)}$</b> | خرید اخیر: <b>${fmtNum(count)} عدد</b>`,
      `💥 قدرت نظامی افزوده: <b>+${weapon.power * count}</b>`,
      `🪖 موجودی کل در ارتش: <b>${fmtNum(currentCount)} عدد</b>`,
      `💰 باقی‌مانده خزانه: <b>${fmtNum(state.treasury)}$</b>`,
      '',
      '👇 برای خرید بیشتر کلیک کنید:',
    ].join('\n');

    const kb = Markup.inlineKeyboard([
      [
        Markup.button.callback('۱ عدد', `wpn:buy:${weapon.id}:1`),
        Markup.button.callback('۵ عدد', `wpn:buy:${weapon.id}:5`),
        Markup.button.callback('۱۰ عدد', `wpn:buy:${weapon.id}:10`),
      ],
      [
        Markup.button.callback('۲۵ عدد', `wpn:buy:${weapon.id}:25`),
        Markup.button.callback('۵۰ عدد', `wpn:buy:${weapon.id}:50`),
        Markup.button.callback('۱۰۰ عدد', `wpn:buy:${weapon.id}:100`),
      ],
      [Markup.button.callback('✏️ وارد کردن تعداد دلخواه (متنی)', `wpn:custom:${weapon.id}`)],
      [Markup.button.callback('🔙 بازگشت به لیست تسلیحات', 'atk:shop')],
    ]);

    await ctx.editMessageText(text, { parse_mode: 'HTML', reply_markup: kb.reply_markup }).catch(() => {});
  } catch (err) {
    await ctx.answerCbQuery(err.message, { show_alert: true });
  }
});

// درخواست وارد کردن تعداد دلخواه متنی
composer.action(/^wpn:custom:(.+)$/, async (ctx) => {
  await ctx.answerCbQuery().catch(() => {});
  const weaponId = ctx.match[1];
  const weapon = await weaponService.get(weaponId);
  if (!weapon) return ctx.reply('سلاح یافت نشد.');

  await userService.setFlow(ctx.from.id, 'game:buy_weapon_custom', { weaponId, weaponName: weapon.name });
  await ctx.reply(`✏️ لطفاً تعداد مورد نیاز خود از «<b>${esc(weapon.name)}</b>» را به صورت عدد بنویسید و ارسال کنید:\n(مثلاً: 15 یا 250)\n\nجهت انصراف: /cancel`, { parse_mode: 'HTML' });
});

registerFlow('game:buy_weapon_custom', async (ctx, data) => {
  const rawText = (ctx.message.text || '').trim();
  const digits = rawText.replace(/[۰-۹]/g, (d) => '۰۱۲۳۴۵۶۷۸۹'.indexOf(d)).replace(/[^0-9]/g, '');
  const count = parseInt(digits, 10);

  if (!count || count <= 0 || !Number.isSafeInteger(count)) {
    return ctx.reply('⚠️ لطفاً یک عدد صحیح و معتبر (بزرگتر از صفر) ارسال کنید. لغو: /cancel');
  }

  const user = ctx.state.user;
  const season = await getActiveSeason();
  if (!season) return ctx.reply('سیزن فعالی وجود ندارد.');
  const own = await getActiveOwnership(user.telegramId, season.id);
  if (!own) return ctx.reply('کشوری برای شما ثبت نشده است.');

  try {
    const res = await gameService.buyMilitaryUnit(own.countryId, season.id, data.weaponId, count);
    await userService.clearFlow(ctx.from.id);
    const text = [
      `🎉 <b>خرید تسلیحات با موفقیت نهایی شد!</b>`,
      '– – – – – – – – – –',
      `سلاح خریداری‌شده: ${res.unit.emoji} <b>${esc(res.unit.name)}</b>`,
      `تعداد تحویل به یگان: <b>${fmtNum(res.count)} عدد</b>`,
      `کل مبلغ پرداختی از خزانه: <b>${fmtNum(res.totalCost)}$</b>`,
      `موجودی باقیمانده خزانه: <b>${fmtNum(res.remainingTreasury)}$</b>`,
    ].join('\n');

    await ctx.reply(text, {
      parse_mode: 'HTML',
      ...Markup.inlineKeyboard([
        [Markup.button.callback('🛒 خرید مجدد از فروشگاه', 'atk:shop')],
        [Markup.button.callback('⚔️ بازگشت به اتاق جنگ', 'emp:attack')],
      ]),
    });
  } catch (err) {
    await ctx.reply(`⚠️ ${err.message}\nتعداد دیگری را ارسال کنید یا دستور /cancel را بزنید.`);
  }
});

// -------------------------------------------------------------
// ۴. کشورداری و پرچم‌های پویا بر اساس دین و ایدئولوژی
// -------------------------------------------------------------
composer.hears('کشورداری و موارد دیگر 🏛️', async (ctx) => {
  await showGovPanel(ctx);
});
composer.action('emp:governance', async (ctx) => {
  await ctx.answerCbQuery().catch(() => {});
  await showGovPanel(ctx, true);
});

async function showGovPanel(ctx, isEdit = false) {
  const data = await requireCountry(ctx);
  if (!data) return;
  const { season, own } = data;
  const state = await gameService.getCountryState(own.countryId, season.id);
  const flag = countryService.getDynamicFlag(own.country, state);

  const gov = gameService.GOVERNMENTS[state.government] || { name: state.government, emoji: '🏛️' };
  const rel = gameService.RELIGIONS[state.religion] || { name: state.religion, emoji: '🕊' };

  const flagSourceLabel = state.flagChoice === 'custom' && state.customFlagName
    ? `سفارشی (${state.customFlagName})`
    : state.flagChoice === 'religion'
      ? 'دین کشور'
      : state.flagChoice === 'ideology'
        ? 'ایدئولوژی حکومت'
        : 'پرچم سنتی ملی';

  const text = [
    `🏛 <b>امور کشورداری و ساختار ملی — ${esc(own.country.name)} ${flag}</b>`,
    '– – – – – – – – – –',
    `🏛 نظام حکومتی: <b>${gov.emoji} ${esc(gov.name)}</b>`,
    `🕊 دین رسمی: <b>${rel.emoji} ${esc(rel.name)}</b>`,
    `🏳️ پرچم فعال: <b>${flag} (${flagSourceLabel})</b>`,
    `😊 رضایت ملت: <b>${state.satisfaction}%</b> | ⚖️ مشروعیت: <b>${state.legitimacy}%</b>`,
    '',
    'جهت سوییچ مستقیم پرچم حکومت‌ها، تغییر دین/حکومت یا صدور بیانیه از کلیدهای زیر استفاده کنید:',
  ].join('\n');

  const kb = Markup.inlineKeyboard([
    [Markup.button.callback('🚩 سوییچ پرچم حکومت‌ها (پادشاهی/دینی/...)', 'gov:regime_flags')],
    [Markup.button.callback('🕊 تغییر دین رسمی کشور', 'gov:religion'), Markup.button.callback('🏛 تغییر نوع حکومت', 'gov:type')],
    [Markup.button.callback('🎨 انتخاب مبنا بر اساس دین/ایدئولوژی', 'gov:flag_choice')],
    [Markup.button.callback('📜 صدور بیانیه رسمی در کانال', 'gov:statement')],
    [Markup.button.callback('💥 انحلال کشور و تغییر رهبری', 'gov:dissolve')],
    [Markup.button.callback('🔙 بازگشت به امپراطوری', 'emp:home')],
  ]);

  if (isEdit && ctx.callbackQuery) {
    await ctx.editMessageText(text, { parse_mode: 'HTML', reply_markup: kb.reply_markup }).catch(() => {});
  } else {
    await ctx.reply(text, { parse_mode: 'HTML', ...kb });
  }
}

// گالری و سوییچ مستقیم پرچم حکومت‌ها
composer.action('gov:regime_flags', async (ctx) => {
  await ctx.answerCbQuery().catch(() => {});
  const data = await requireCountry(ctx);
  if (!data) return;
  const { own, season } = data;
  const state = await gameService.getCountryState(own.countryId, season.id);
  const currentFlag = countryService.getDynamicFlag(own.country, state);

  const flagsList = countryService.getAvailableGovernmentFlags(own.country);

  const rows = flagsList.map((item, idx) => {
    const isCurrent = currentFlag === item.flag;
    const label = `${isCurrent ? '✅ ' : ''}${item.flag} ${item.name}`;
    return [Markup.button.callback(label, `rf:set:${idx}`)];
  });

  rows.push([
    Markup.button.callback(`🔄 بازنشانی به پرچم پیش‌فرض (${own.country.flag})`, 'rf:reset'),
  ]);
  rows.push([Markup.button.callback('🔙 بازگشت به کشورداری', 'emp:governance')]);

  const descLines = flagsList.map((f) => `• <b>${f.flag} ${esc(f.name)}</b>: ${esc(f.desc || '')}`).join('\n');

  const text = [
    `🚩 <b>گالری و سوییچ پرچم حکومت‌ها — ${esc(own.country.name)}</b>`,
    '– – – – – – – – – –',
    `پرچم فعال کنونی: <b>${currentFlag}</b>`,
    '',
    'با لمس هر گزینه، پرچم رسمی کشور شما در تمام بخش‌ها (پروفایل، بیانیه‌ها، وضعیت و لیدربورد) فوراً تغییر می‌یابد:',
    '',
    descLines,
  ].join('\n');

  await ctx.editMessageText(text, {
    parse_mode: 'HTML',
    reply_markup: Markup.inlineKeyboard(rows).reply_markup,
  }).catch(() => {});
});

composer.action(/^rf:set:(\d+)$/, async (ctx) => {
  const idx = parseInt(ctx.match[1], 10);
  const data = await requireCountry(ctx);
  if (!data) return;
  const flagsList = countryService.getAvailableGovernmentFlags(data.own.country);
  const selected = flagsList[idx];
  if (!selected) {
    await ctx.answerCbQuery('گزینه یافت نشد.', { show_alert: true });
    return;
  }

  await gameService.setCustomFlag(data.own.countryId, data.season.id, selected.flag, selected.name);
  await ctx.answerCbQuery(`✅ پرچم کشور به «${selected.name} ${selected.flag}» سوییچ شد!`, { show_alert: true });
  await showGovPanel(ctx, true);
});

composer.action('rf:reset', async (ctx) => {
  const data = await requireCountry(ctx);
  if (!data) return;
  await gameService.setFlagChoice(data.own.countryId, data.season.id, 'default');
  await ctx.answerCbQuery('✅ پرچم کشور به حالت پیش‌فرض ملی بازگردانده شد.', { show_alert: true });
  await showGovPanel(ctx, true);
});

// انتخاب پرچم پویا
composer.action('gov:flag_choice', async (ctx) => {
  await ctx.answerCbQuery().catch(() => {});
  const data = await requireCountry(ctx);
  if (!data) return;
  const { season, own } = data;
  const state = await gameService.getCountryState(own.countryId, season.id);

  const relFlag = countryService.getDynamicFlag(own.country, { ...state, flagChoice: 'religion' });
  const ideoFlag = countryService.getDynamicFlag(own.country, { ...state, flagChoice: 'ideology' });
  const defFlag = own.country.flag;

  await ctx.editMessageText([
    '🎨 <b>انتخاب مبنای پرچم و نشان ملی امپراطوری</b>',
    '– – – – – – – – – –',
    'می‌توانید تعیین کنید که پرچم کشور شما بر اساس دین رسمی باشد یا بر اساس سبک حکومت و ایدئولوژی:',
    '',
    `• پرچم بر اساس دین: ${relFlag}`,
    `• پرچم بر اساس ایدئولوژی حکومت: ${ideoFlag}`,
    `• پرچم سنتی ملی: ${defFlag}`,
  ].join('\n'), {
    parse_mode: 'HTML',
    ...Markup.inlineKeyboard([
      [Markup.button.callback(`🕊 بر اساس دین (${relFlag})`, 'flag:set:religion')],
      [Markup.button.callback(`🏛️ بر اساس ایدئولوژی (${ideoFlag})`, 'flag:set:ideology')],
      [Markup.button.callback(`🏳️ پرچم سنتی ملی (${defFlag})`, 'flag:set:default')],
      [Markup.button.callback('🔙 بازگشت', 'emp:governance')],
    ]),
  }).catch(() => {});
});

composer.action(/^flag:set:(\w+)$/, async (ctx) => {
  const choice = ctx.match[1];
  const data = await requireCountry(ctx);
  if (!data) return;
  await gameService.setFlagChoice(data.own.countryId, data.season.id, choice);
  await ctx.answerCbQuery('✅ پرچم رسمی کشور به‌روزرسانی شد!', { show_alert: true });
  await showGovPanel(ctx, true);
});

// تغییر دین
composer.action('gov:religion', async (ctx) => {
  await ctx.answerCbQuery().catch(() => {});
  const rows = Object.entries(gameService.RELIGIONS).map(([k, r]) => [
    Markup.button.callback(`${r.emoji} ${r.name}`, `rel:set:${k}`),
  ]);
  rows.push([Markup.button.callback('🔙 بازگشت', 'emp:governance')]);

  const descList = Object.values(gameService.RELIGIONS).map((r) => `• <b>${r.emoji} ${esc(r.name)}</b>: ${esc(r.desc)}`).join('\n');
  await ctx.editMessageText(`🕊 <b>انتخاب دین رسمی کشور</b>\nتغییر دین روی ضرایب جامعه، ارتش و مشروعیت اثر دارد:\n\n${descList}`, {
    parse_mode: 'HTML',
    reply_markup: Markup.inlineKeyboard(rows).reply_markup,
  }).catch(() => {});
});

composer.action(/^rel:set:(\w+)$/, async (ctx) => {
  const relKey = ctx.match[1];
  const data = await requireCountry(ctx);
  if (!data) return;

  try {
    const r = await gameService.changeReligion(data.own.countryId, data.season.id, relKey);
    await ctx.answerCbQuery(`دین کشور به ${r.name} تغییر یافت.`, { show_alert: true });

    // دریافت پرچم و عکس متناسب با دین
    const state = await gameService.getCountryState(data.own.countryId, data.season.id);
    const countryFlag = countryService.getDynamicFlag(data.own.country, state);
    const photoUrl = countryService.getReligionImageUrl(data.own.country, relKey);

    // ارسال اعلان رسمی به کانال
    const channelText = [
      '🕊 <b>تغییر رسمی دین کشور</b>',
      '– – – – – – – – – –',
      `🌍 کشور: <b>${countryFlag} ${esc(data.own.country.name)}</b>`,
      `👑 رهبر: <b>${esc(ctx.state.user.displayName)}</b>`,
      `🕊 دین و مذهب جدید: <b>${r.emoji} ${esc(r.name)}</b>`,
      '– – – – – – – – – –',
      `📜 رویکرد مذهبی: <i>${esc(r.desc)}</i>`,
      '',
      '🌐 <i>کانال رسمی WORLD WAR FIRE</i>',
    ].join('\n');

    if (photoUrl) {
      await notifications.publishPhotoToChannel(ctx.telegram, 'religion_change', photoUrl, channelText).catch(async () => {
        await notifications.publishToChannel(ctx.telegram, 'religion_change', channelText).catch(() => {});
      });
    } else {
      await notifications.publishToChannel(ctx.telegram, 'religion_change', channelText).catch(() => {});
    }

    // پیشنهاد تنظیم پرچم
    await ctx.reply(`🕊 دین رسمی کشور <b>${esc(data.own.country.name)}</b> به <b>${r.emoji} ${esc(r.name)}</b> تغییر کرد.\nاعلان رسمی در کانال منتشر گردید.\n\nآیا مایلید پرچم کشورتان نیز بر مبنای دین جدید تغییر کند؟`, {
      parse_mode: 'HTML',
      ...Markup.inlineKeyboard([
        [Markup.button.callback('✅ بله، پرچم دینی تنظیم شود', 'flag:set:religion')],
        [Markup.button.callback('❌ خیر، پرچم بدون تغییر بماند', 'emp:governance')],
      ]),
    });
  } catch (err) {
    await ctx.answerCbQuery(err.message, { show_alert: true });
  }
});

// تغییر حکومت
composer.action('gov:type', async (ctx) => {
  await ctx.answerCbQuery().catch(() => {});
  const rows = Object.entries(gameService.GOVERNMENTS).map(([k, g]) => [
    Markup.button.callback(`${g.emoji} ${g.name}`, `gov:set:${k}`),
  ]);
  rows.push([Markup.button.callback('🔙 بازگشت', 'emp:governance')]);

  const descList = Object.values(gameService.GOVERNMENTS).map((g) => `• <b>${g.emoji} ${esc(g.name)}</b>: ${esc(g.desc)}`).join('\n');
  await ctx.editMessageText(`🏛 <b>انتخاب نظام حکومتی و ایدئولوژی</b>\n\n${descList}`, {
    parse_mode: 'HTML',
    reply_markup: Markup.inlineKeyboard(rows).reply_markup,
  }).catch(() => {});
});

composer.action(/^gov:set:(\w+)$/, async (ctx) => {
  const govKey = ctx.match[1];
  const data = await requireCountry(ctx);
  if (!data) return;

  try {
    const g = await gameService.changeGovernment(data.own.countryId, data.season.id, govKey);
    await ctx.answerCbQuery(`نظام حکومتی به ${g.name} تغییر یافت.`, { show_alert: true });

    // دریافت پرچم و عکس متناسب با حکومت
    const state = await gameService.getCountryState(data.own.countryId, data.season.id);
    const countryFlag = countryService.getDynamicFlag(data.own.country, state);
    const photoUrl = countryService.getGovernmentImageUrl(data.own.country, govKey);

    // ارسال اعلان رسمی به کانال
    const channelText = [
      '🏛 <b>انقلاب و دگرگونی در نظام حکومتی کشور</b>',
      '– – – – – – – – – –',
      `🌍 کشور: <b>${countryFlag} ${esc(data.own.country.name)}</b>`,
      `👑 رهبر: <b>${esc(ctx.state.user.displayName)}</b>`,
      `🏛 نظام سیاسی جدید: <b>${g.emoji} ${esc(g.name)}</b>`,
      '– – – – – – – – – –',
      `📜 رویکرد ایدئولوژیک: <i>${esc(g.desc)}</i>`,
      '',
      '🌐 <i>کانال رسمی WORLD WAR FIRE</i>',
    ].join('\n');

    if (photoUrl) {
      await notifications.publishPhotoToChannel(ctx.telegram, 'government_change', photoUrl, channelText).catch(async () => {
        await notifications.publishToChannel(ctx.telegram, 'government_change', channelText).catch(() => {});
      });
    } else {
      await notifications.publishToChannel(ctx.telegram, 'government_change', channelText).catch(() => {});
    }

    await ctx.reply(`🏛 نظام سیاسی کشور <b>${esc(data.own.country.name)}</b> به <b>${g.emoji} ${esc(g.name)}</b> تغییر کرد.\nاعلان رسمی در کانال منتشر گردید.\n\nآیا مایلید پرچم کشورتان بر مبنای ایدئولوژی حکومت جدید تغییر کند؟`, {
      parse_mode: 'HTML',
      ...Markup.inlineKeyboard([
        [Markup.button.callback('✅ بله، پرچم ایدئولوژیک تنظیم شود', 'flag:set:ideology')],
        [Markup.button.callback('❌ خیر، پرچم بدون تغییر بماند', 'emp:governance')],
      ]),
    });
  } catch (err) {
    await ctx.answerCbQuery(err.message, { show_alert: true });
  }
});

// صدور بیانیه رسمی منحصراً با تصویر تعیین‌شده توسط ادمین
composer.action('gov:statement', async (ctx) => {
  await ctx.answerCbQuery().catch(() => {});
  const data = await requireCountry(ctx);
  if (!data) return;

  const country = await countryService.get(data.own.countryId);
  const state = await gameService.getCountryState(country.id, data.season.id);
  const flag = countryService.getDynamicFlag(country, state) || country.flag || '🏳️';

  // بررسی عکس رسمی انتخاب‌شده توسط ادمین برای کشور (اختیاری)
  const globalPhoto = await settings.get('statementDefaultPhoto', null);
  const adminPhoto = country.statementPhotoUrl || country.photoUrl || country.bannerUrl || globalPhoto || null;

  await userService.setFlow(ctx.from.id, 'game:statement', { countryId: country.id, adminPhoto });
  await ctx.reply([
    '📜 <b>صدور بیانیه رسمی دیپلماتیک در کانال</b>',
    '– – – – – – – – – –',
    `🌍 کشور: <b>${flag} ${esc(country.name)}</b>`,
    `👑 رهبر: <b>${esc(ctx.state.user.displayName)}</b>`,
    '– – – – – – – – – –',
    adminPhoto ? '🖼️ <b>تصویر رسمی بیانیه:</b> تصویر تاییدشده توسط مدیریت به صورت خودکار ضمیمه این بیانیه خواهد شد.' : '📝 <i>این بیانیه به صورت متنی و رسمی در کانال منتشر خواهد شد.</i>',
    '',
    '✍️ لطفاً <b>متن بیانیه رسمی</b> خود را ارسال فرمایید:',
    '',
    'جهت انصراف: /cancel',
  ].join('\n'), {
    parse_mode: 'HTML',
    ...Markup.inlineKeyboard([
      [Markup.button.callback('🔙 انصراف و بازگشت', 'emp:governance')],
      [Markup.button.callback('🔙 بازگشت به منوی اصلی', 'menu:home')],
    ]),
  });
});

registerFlow('game:statement', async (ctx, data) => {
  if (ctx.message.photo || (ctx.message.document && ctx.message.document.mime_type && ctx.message.document.mime_type.startsWith('image/'))) {
    return ctx.reply('⚠️ ارسال تصویر توسط کاربر مجاز نیست. بیانیه‌ها منحصراً با متن ارسالی شما منتشر می‌شوند.\nلطفاً فقط متن بیانیه خود را ارسال کنید:\n(جهت لغو: /cancel)');
  }

  const rawText = (ctx.message.text || '').trim();
  if (!rawText) {
    return ctx.reply('لطفاً متن بیانیه رسمی را ارسال کنید. (جهت لغو: /cancel)');
  }

  if (rawText.length < 5) {
    return ctx.reply('⚠️ متن بیانیه باید حداقل ۵ کاراکتر باشد. لطفاً متن کامل را بفرستید:');
  }

  const country = await countryService.get(data.countryId);
  const user = ctx.state.user;
  const season = await getActiveSeason();
  const state = await gameService.getCountryState(country.id, season ? season.id : '1');
  const flag = countryService.getDynamicFlag(country, state) || country.flag || '🏳️';

  const globalPhoto = await settings.get('statementDefaultPhoto', null);
  const photoToSend = data.adminPhoto || country.statementPhotoUrl || country.photoUrl || country.bannerUrl || globalPhoto || null;

  const text = rawText.slice(0, 650);
  const statementText = [
    `📢 <b>بیانیه رسمی دیپلماتیک</b>`,
    '– – – – – – – – – –',
    `🌍 کشور: <b>${flag} ${esc(country.name)}</b>`,
    `👑 رهبر: <b>${esc(user.displayName)}</b>`,
    '– – – – – – – – – –',
    '',
    `« ${esc(text)} »`,
    '',
    '🕊 <i>کانال رسمی WORLD WAR FIRE</i>',
  ].join('\n');

  try {
    if (photoToSend) {
      await notifications.publishPhotoToChannel(ctx.telegram, 'statement', photoToSend, statementText);
    } else {
      await notifications.publishToChannel(ctx.telegram, 'statement', statementText);
    }
  } catch (e) {
    logger.warn('خطا در انتشار بیانیه در کانال:', e.message);
  }

  await userService.clearFlow(ctx.from.id);
  await ctx.reply(`✅ <b>بیانیه رسمی کشور ${flag} ${esc(country.name)} در کانال رسمی منتشر گردید!</b>`, {
    parse_mode: 'HTML',
    ...Markup.inlineKeyboard([
      [Markup.button.callback('👑 بازگشت به امپراطوری', 'emp:home')],
      [Markup.button.callback('🔙 بازگشت به منوی اصلی', 'menu:home')],
    ]),
  });
});

// انحلال کشور
composer.action('gov:dissolve', async (ctx) => {
  await ctx.answerCbQuery().catch(() => {});
  await ctx.editMessageText('⚠️ <b>آیا از انحلال کامل کشور خود اطمینان دارید؟</b>\nبا این کار مالکیت شما لغو شده و می‌توانید کشور جدیدی انتخاب نمایید.', {
    parse_mode: 'HTML',
    ...Markup.inlineKeyboard([
      [Markup.button.callback('💥 بله، کشور را منحل کن', 'gov:dissolve:confirm')],
      [Markup.button.callback('🔙 انصراف', 'emp:governance')],
    ]),
  }).catch(() => {});
});

composer.action('gov:dissolve:confirm', async (ctx) => {
  await ctx.answerCbQuery().catch(() => {});
  const data = await requireCountry(ctx);
  if (!data) return;
  const { season, own } = data;

  await releaseOwnership({
    countryId: own.countryId,
    seasonId: season.id,
    reason: 'dissolved_by_leader',
    status: 'dissolved',
  });

  await ctx.reply('💥 <b>کشور شما رسماً منحل و آزاد شد.</b>\nاکنون می‌توانید از منوی انتخاب کشور، یک کشور جدید برای رهبری برگزینید.', {
    parse_mode: 'HTML',
    ...mainMenu(ctx.state.isAdmin),
  });
  await ctx.reply('برای انتخاب کشور جدید روی دکمه زیر کلیک کنید:', Markup.inlineKeyboard([
    [Markup.button.callback('🌍 انتخاب کشور جدید', 'cl:0')],
  ]));
});

// نقشه‌ی جهان و استان‌ها
composer.hears(['نقشه‌ی جهان 🗺️', L.world], async (ctx) => {
  await showWorldMap(ctx);
});
composer.action('emp:worldmap', async (ctx) => {
  await ctx.answerCbQuery().catch(() => {});
  await showWorldMap(ctx, true);
});

async function showWorldMap(ctx, isEdit = false) {
  const season = await getActiveSeason();
  if (!season) return ctx.reply('سیزن فعالی وجود ندارد.');

  const allCountries = await countryService.list();
  const ownerships = await listActive(season.id);
  const ownMap = new Map();
  for (const o of ownerships) ownMap.set(o.countryId, o);

  const formatCountryLine = async (c) => {
    const state = await gameService.getCountryState(c.id, season.id).catch(() => null);
    if (state?.conqueredBy) {
      return `~${esc(c.name)}~ ${c.flag} ➔ 🚩 <b>استان تحت تسلط: ${esc(state.conqueredBy)}</b>`;
    }
    const o = ownMap.get(c.id);
    if (o) {
      const u = await userService.getById(o.userId);
      const dynFlag = countryService.getDynamicFlag(c, state || {});
      return `${dynFlag} <b>${esc(c.name)}</b> (👑 ${esc(u?.displayName || 'رهبر')})`;
    }
    return `${c.flag} ${esc(c.name)} (🏳️ آزاد)`;
  };

  const lines = [
    '🌍 <b>نقشه‌ی ژئوپلیتیک جهان — جنگ جهانی سوم</b>',
    '– – – – – – – – – –',
    '<i>کشورهای خط‌خورده فتح شده‌اند و به عنوان استان فاتح اداره می‌شوند.</i>',
    '',
  ];

  for (const c of allCountries) {
    lines.push(await formatCountryLine(c));
  }

  const kb = Markup.inlineKeyboard([[Markup.button.callback('🔙 بازگشت به امپراطوری', 'emp:home')]]);
  if (isEdit && ctx.callbackQuery) {
    await ctx.editMessageText(lines.join('\n'), { parse_mode: 'HTML', reply_markup: kb.reply_markup }).catch(() => {});
  } else {
    await ctx.reply(lines.join('\n'), { parse_mode: 'HTML', ...kb });
  }
}

composer.hears('استان‌های من 🗺️', async (ctx) => {
  await showProvinces(ctx);
});
composer.action('emp:provinces', async (ctx) => {
  await ctx.answerCbQuery().catch(() => {});
  await showProvinces(ctx, true);
});

async function showProvinces(ctx, isEdit = false) {
  const data = await requireCountry(ctx);
  if (!data) return;
  const { season, own } = data;
  const state = await gameService.getCountryState(own.countryId, season.id);
  const provinces = gameService.normalizeProvinces(state.provinces, own.country.name);
  const flag = countryService.getDynamicFlag(own.country, state);

  const settingsService = require('../services/settingsService');
  const capitalCost = await settingsService.get('capitalChangeCost', 250000000);

  const text = [
    `🗺 <b>قلمرو و استان‌های در اختیار کشور ${esc(own.country.name)} ${flag}</b>`,
    '– – – – – – – – – –',
    'فهرست استان‌های تحت مالکیت و حاکمیت شما:',
    '',
    ...provinces.map((p) => {
      const capTag = p.isCapital ? ' 👑 <b>[پایتخت کشور]</b>' : '';
      const dirIcon = p.direction === 'شمال' ? '🧭 شمال' : p.direction === 'جنوب' ? '🧭 جنوب' : p.direction === 'شرق' ? '🧭 شرق' : p.direction === 'غرب' ? '🧭 غرب' : '🚩 تسخیرشده';
      return `📍 <b>${esc(p.name)}</b>${capTag} (${dirIcon})`;
    }),
    '',
    `💵 موجودی خزانه کشور: <b>${fmtNum(state.treasury)}$</b>`,
    `🏛 هزینه تغییر پایتخت (تنظیم ادمین): <b>${fmtNum(capitalCost)}$</b>`,
    '',
    '⚠️ <i>نکته استراتژیک: استان پایتخت قلب تپنده کشور است. اگر در جریان جنگ، استان پایتخت شما فتح شود، کشور به طور کامل نابود شده و تمامی استان‌ها و خزانه به کشور فاتح تعلق می‌گیرد.</i>',
  ].join('\n');

  const rows = [];
  for (const p of provinces) {
    const editBtn = Markup.button.callback(`✏️ تغییر نام ${p.name.slice(0, 18)}`, `prov:edit:${p.id}`);
    if (!p.isCapital) {
      const capBtn = Markup.button.callback('👑 انتخاب به عنوان پایتخت', `prov:cap:${p.id}`);
      rows.push([editBtn, capBtn]);
    } else {
      rows.push([editBtn]);
    }
  }
  rows.push([Markup.button.callback('🔙 بازگشت به امپراطوری', 'emp:home')]);

  const kb = Markup.inlineKeyboard(rows);
  if (isEdit && ctx.callbackQuery) {
    await ctx.editMessageText(text, { parse_mode: 'HTML', reply_markup: kb.reply_markup }).catch(() => {});
  } else {
    await ctx.reply(text, { parse_mode: 'HTML', ...kb });
  }
}

composer.action(/^prov:cap:(.+)$/, async (ctx) => {
  await ctx.answerCbQuery().catch(() => {});
  const data = await requireCountry(ctx);
  if (!data) return;
  const { season, own } = data;
  const targetProvinceId = ctx.match[1];
  try {
    const res = await gameService.changeCapitalProvince(own.countryId, season.id, targetProvinceId);
    await ctx.reply(`👑 <b>پایتخت ملی با موفقیت به استان «${esc(res.province.name)}» انتقال یافت!</b>\nمبلغ ${fmtNum(res.cost)}$ بابت هزینه تغییر پایتخت از خزانه کسر گردید.`, {
      parse_mode: 'HTML',
      ...Markup.inlineKeyboard([
        [Markup.button.callback('🗺️ استان‌های من', 'emp:provinces')],
        [Markup.button.callback('🔙 بازگشت به امپراطوری', 'emp:home')],
      ]),
    });
  } catch (err) {
    await ctx.reply(`⚠️ ${err.message}`);
  }
});

composer.action(/^prov:edit:(.+)$/, async (ctx) => {
  await ctx.answerCbQuery().catch(() => {});
  const data = await requireCountry(ctx);
  if (!data) return;
  const state = await gameService.getCountryState(data.own.countryId, data.season.id);
  const provinces = gameService.normalizeProvinces(state.provinces, data.own.country.name);
  const province = provinces.find((p) => String(p.id) === String(ctx.match[1]));
  if (!province) return ctx.reply('استان پیدا نشد.');
  await userService.setFlow(ctx.from.id, 'game:province:rename', { provinceId: province.id });
  await ctx.reply(`نام جدید استان را وارد کنید:\nنام فعلی: ${esc(province.name)}\nلغو: /cancel`);
});

registerFlow('game:province:rename', async (ctx, data) => {
  const newName = String(ctx.message.text || '').trim();
  try {
    const ownData = await requireCountry(ctx);
    if (!ownData) return;
    const result = await gameService.renameProvince(ownData.own.countryId, ownData.season.id, data.provinceId, newName);
    await userService.clearFlow(ctx.from.id);
    await ctx.reply(`✅ نام استان با موفقیت به «${esc(result.name)}» تغییر یافت.`, {
      ...Markup.inlineKeyboard([
        [Markup.button.callback('🗺️ استان‌های من', 'emp:provinces')],
        [Markup.button.callback('🔙 بازگشت به امپراطوری', 'emp:home')],
      ]),
    });
  } catch (err) { await ctx.reply(`❌ ${esc(err.message)}`); }
});

// -------------------------------------------------------------
// اعلان جنگ با مجوز و بدون مجوز
// -------------------------------------------------------------
composer.hears('اعلام جنگ ⚔️', async (ctx) => {
  await showWarDeclareMenu(ctx);
});
composer.action('emp:war_declare', async (ctx) => {
  await ctx.answerCbQuery().catch(() => {});
  await showWarDeclareMenu(ctx, true);
});

async function showWarDeclareMenu(ctx, isEdit = false) {
  const data = await requireCountry(ctx);
  if (!data) return;
  const { season, own } = data;
  const state = await gameService.getCountryState(own.countryId, season.id);
  const flag = countryService.getDynamicFlag(own.country, state);

  const text = [
    `⚔️ <b>اتاق اعلان جنگ و روابط تخاصم — ${esc(own.country.name)} ${flag}</b>`,
    '– – – – – – – – – –',
    'اعلان جنگ در بازی به دو شیوه قابل انجام است:',
    '',
    '۱. ⚖️ <b>اعلان جنگ با مجوز (قانونی و رسمی):</b>',
    'شما دلیل و توجیه منطقی خود (مانند حمله قبلی، نقض مرزها یا تهدیدات) را ارسال می‌کنید. درخواست به ربات ادمین و پنل مدیریت ارسال می‌شود و پس از تایید، جنگ رسمی با +۱۰٪ مشروعیت و روحیه آغاز خواهد شد.',
    '',
    '۲. 💥 <b>تهاجم نظامی بدون مجوز (ناگهانی):</b>',
    'بدون نیاز به تایید ادمین فوراً جنگ آغاز می‌گردد، اما به دلیل نقض قوانین بین‌المللی، <b>۲۵٪ افت مشروعیت</b> و <b>۱۵٪ افت رضایت مردم</b> در پی دارد.',
    '',
    '👇 شیوه اعلان جنگ مورد نظر را انتخاب کنید:',
  ].join('\n');

  const kb = Markup.inlineKeyboard([
    [Markup.button.callback('⚖️ اعلان جنگ با مجوز (رسمی و موجه)', 'war:mode:authorized')],
    [Markup.button.callback('💥 تهاجم نظامی بدون مجوز (تهاجم ناگهانی)', 'war:mode:unauthorized')],
    [Markup.button.callback('🔙 بازگشت به امپراطوری', 'emp:home')],
  ]);

  if (isEdit && ctx.callbackQuery) {
    await ctx.editMessageText(text, { parse_mode: 'HTML', reply_markup: kb.reply_markup }).catch(() => {});
  } else {
    await ctx.reply(text, { parse_mode: 'HTML', ...kb });
  }
}

// انتخاب کشور هدف
composer.action(/^war:mode:(\w+)$/, async (ctx) => {
  await ctx.answerCbQuery().catch(() => {});
  const mode = ctx.match[1]; // 'authorized' | 'unauthorized'
  const data = await requireCountry(ctx);
  if (!data) return;
  const { season, own } = data;

  const activeOwnerships = await listActive(season.id);
  const targets = activeOwnerships.filter((o) => o.countryId !== own.countryId);

  if (!targets.length) {
    return ctx.reply('🌍 در حال حاضر کشور فعال دیگری در سیزن برای هدف‌گیری وجود ندارد.');
  }

  const rows = [];
  for (const t of targets.slice(0, 12)) {
    const c = await countryService.get(t.countryId);
    if (c) {
      rows.push([Markup.button.callback(`🎯 هدف: ${c.flag} ${c.name}`, `war:pick:${mode}:${c.id}`)]);
    }
  }
  rows.push([Markup.button.callback('🔙 بازگشت', 'emp:war_declare')]);

  const modeFa = mode === 'authorized' ? 'با مجوز (رسمی)' : 'بدون مجوز (تهاجم)';
  await ctx.editMessageText(`🎯 <b>کشور هدف را برای اعلان جنگ «${modeFa}» انتخاب کنید:</b>`, {
    parse_mode: 'HTML',
    reply_markup: Markup.inlineKeyboard(rows).reply_markup,
  }).catch(() => {});
});

// مسیر ۱: اعلان جنگ با مجوز -> دریافت دلیل
composer.action(/^war:pick:authorized:(.+)$/, async (ctx) => {
  await ctx.answerCbQuery().catch(() => {});
  const targetCountryId = ctx.match[1];
  const targetCountry = await countryService.get(targetCountryId);
  if (!targetCountry) return ctx.reply('کشور هدف یافت نشد.');

  await userService.setFlow(ctx.from.id, 'game:war_reason', { targetCountryId, targetName: targetCountry.name, targetFlag: targetCountry.flag });
  await ctx.reply([
    `📜 <b>درخواست مجوز جنگ علیه ${targetCountry.flag} ${esc(targetCountry.name)}</b>`,
    '– – – – – – – – – –',
    'لطفاً دلیل و توجیه منطقی خود برای اعلان جنگ را بنویسید و ارسال کنید:',
    '(مثلاً: تجاوز به پاسگاه‌های مرزی ما، غارت نفتکش‌ها یا تحرکات خصمانه)',
    '',
    'جهت لغو: /cancel',
  ].join('\n'), { parse_mode: 'HTML' });
});

registerFlow('game:war_reason', async (ctx, data) => {
  const reasonText = (ctx.message.text || '').trim();
  if (reasonText.length < 5) {
    return ctx.reply('⚠️ لطفاً دلیل واضح و منطقی (حداقل ۵ کاراکتر) بنویسید. لغو: /cancel');
  }

  const user = ctx.state.user;
  const season = await getActiveSeason();
  if (!season) return ctx.reply('سیزن فعالی وجود ندارد.');
  const own = await getActiveOwnership(user.telegramId, season.id);
  if (!own) return ctx.reply('شما کشوری ندارید.');

  try {
    const war = await warService.declareWar({
      attackerCountryId: own.countryId,
      defenderCountryId: data.targetCountryId,
      seasonId: season.id,
      type: 'authorized',
      reason: reasonText,
      userId: user.telegramId,
      userDisplayName: user.displayName,
    });

    await userService.clearFlow(ctx.from.id);

    // ارسال اعلان فوری به ربات اختصاصی ادمین
    const adminAlertText = [
      '⚔️ <b>درخواست جدید صدور مجوز جنگ</b>',
      '– – – – – – – – – –',
      `🌍 متقاضی: <b>${esc(own.country.flag)} ${esc(own.country.name)}</b>`,
      `👑 رهبر: <b>${esc(user.displayName)}</b> (@${esc(user.username || '—')})`,
      `🎯 کشور هدف: <b>${esc(data.targetFlag)} ${esc(data.targetName)}</b>`,
      '– – – – – – – – – –',
      `📜 دلیل و مستندات ارائه شده:`,
      `« <i>${esc(reasonText)}</i> »`,
      '',
      `🆔 شناسه جنگ: <code>${war.id}</code>`,
    ].join('\n');

    const adminKb = Markup.inlineKeyboard([
      [
        Markup.button.callback('✅ صدور مجوز جنگ رسمی', `adbot:war:appr:${war.id}`),
        Markup.button.callback('❌ رد درخواست جنگ', `adbot:war:rejc:${war.id}`),
      ],
    ]);

    await adminBotService.sendToAdminBot(ctx.telegram, adminAlertText, adminKb);

    await ctx.reply([
      '✅ <b>درخواست اعلان جنگ رسمی شما با موفقیت ثبت شد!</b>',
      '– – – – – – – – – –',
      'پرونده به ربات ناظر مدیریت (ادمین) ارسال شد تا ادله شما بررسی شود.',
      'به محض تایید یا رد درخواست، نتیجه از طریق همین ربات به شما ابلاغ خواهد گردید.',
    ].join('\n'), {
      parse_mode: 'HTML',
      ...Markup.inlineKeyboard([[Markup.button.callback('🔙 بازگشت به امپراطوری', 'emp:home')]]),
    });
  } catch (err) {
    await ctx.reply(`⚠️ ${err.message}`);
  }
});

// مسیر ۲: اعلان جنگ بدون مجوز -> تایید و اعمال جرائم
composer.action(/^war:pick:unauthorized:(.+)$/, async (ctx) => {
  await ctx.answerCbQuery().catch(() => {});
  const targetCountryId = ctx.match[1];
  const targetCountry = await countryService.get(targetCountryId);
  if (!targetCountry) return ctx.reply('کشور هدف یافت نشد.');

  const text = [
    `⚠️ <b>هشدار جدی: تهاجم نظامی بدون مجوز علیه ${targetCountry.flag} ${esc(targetCountry.name)}</b>`,
    '– – – – – – – – – –',
    'اعلان جنگ بدون تایید بین‌المللی عواقب زیر را به همراه دارد:',
    '🔻 <b>۲۵٪ افت قطعی مشروعیت بین‌المللی</b>',
    '🔻 <b>۱۵٪ افت رضایت عمومی مردم کشور</b>',
    '📢 انتشار بیانیه محکومیت این تجاوز در کانال رسمی بازی',
    '',
    'آیا با پذیرش این تبعات، فرمان حمله ناگهانی را صادر می‌کنید؟',
  ].join('\n');

  const kb = Markup.inlineKeyboard([
    [Markup.button.callback('💥 بله، تهاجم ناگهانی را آغاز کن', `war:unauth:confirm:${targetCountry.id}`)],
    [Markup.button.callback('🔙 انصراف و بازگشت', 'emp:war_declare')],
  ]);

  await ctx.editMessageText(text, { parse_mode: 'HTML', reply_markup: kb.reply_markup }).catch(() => {});
});

composer.action(/^war:unauth:confirm:(.+)$/, async (ctx) => {
  await ctx.answerCbQuery().catch(() => {});
  const targetCountryId = ctx.match[1];
  const data = await requireCountry(ctx);
  if (!data) return;
  const { season, own } = data;
  const defenderCountry = await countryService.get(targetCountryId);
  if (!defenderCountry) return ctx.reply('کشور هدف یافت نشد.');

  if (ctx.state.isMinister && ctx.state.ministerRole === 'economy') {
    return ctx.answerCbQuery('⛔ عدم دسترسی: وزیر اقتصاد مجاز به اعلان جنگ نیست.', { show_alert: true });
  }

  if (ctx.state.isMinister && ctx.state.ministerRole === 'war') {
    try {
      await ministerService.createMinisterWarProposal({
        type: 'war_declare',
        countryId: own.countryId,
        seasonId: season.id,
        ministerId: ctx.from.id,
        ministerName: ctx.state.user.displayName,
        targetCountryId: targetCountryId,
        targetCountryName: defenderCountry.name,
        payload: { note: 'اعلان جنگ رسمی با پیشنهاد وزیر جنگ' },
        telegram: ctx.telegram,
      });

      await ctx.answerCbQuery('پیشنهاد اعلان جنگ برای تایید رهبر کشور ارسال شد.', { show_alert: true });
      return ctx.editMessageText([
        '📨 <b>پیشنهاد اعلان جنگ برای رهبر کشور ارسال شد!</b>',
        '– – – – – – – – – –',
        `کشور هدف: <b>${defenderCountry.flag} ${esc(defenderCountry.name)}</b>`,
        'به عنوان وزیر جنگ، پس از تایید رهبر کشور، بیانیه رسمی جنگ صادر و به کشور مقصد ابلاغ خواهد شد.',
      ].join('\n'), {
        parse_mode: 'HTML',
        reply_markup: { inline_keyboard: [[Markup.button.callback('👑 امپراطوری من', 'menu:empire')]] },
      }).catch(() => {});
    } catch (err) {
      return ctx.answerCbQuery(err.message, { show_alert: true });
    }
  }

  try {
    const war = await warService.declareWar({
      attackerCountryId: own.countryId,
      defenderCountryId: targetCountryId,
      seasonId: season.id,
      type: 'unauthorized',
      reason: 'تهاجم غافلگیرانه و بدون مجوز بین‌المللی',
      userId: ctx.state.user.telegramId,
      userDisplayName: ctx.state.user.displayName,
    });

    // اعمال جریمه به مهاجم
    const attState = await gameService.getCountryState(own.countryId, season.id);
    const newLegitimacy = Math.max(0, (attState.legitimacy || 100) - 25);
    const newSatisfaction = Math.max(0, (attState.satisfaction || 56) - 15);
    await gameService.updateCountryState(own.countryId, season.id, {
      legitimacy: newLegitimacy,
      satisfaction: newSatisfaction,
    });

    // انتشار در کانال رسمی با دکمه مخصوص جریمه توسط ادمین
    const channelText = [
      '⚠️ <b>تهاجم نظامی بدون مجوز بین‌المللی!</b>',
      '– – – – – – – – – –',
      `کشور <b>${own.country.flag} ${esc(own.country.name)}</b> به صورت یک‌جانبه و بدون کسب مجوز، به کشور <b>${defenderCountry.flag} ${esc(defenderCountry.name)}</b> اعلان جنگ کرد!`,
      '',
      `👑 رهبر متهاجم: <b>${esc(ctx.state.user.displayName)}</b>`,
      '🔻 جامعه جهانی این تجاوز را شدیداً محکوم نموده و مشروعیت متهاجم ۲۵٪ تنزل یافت.',
      '⏳ مهلت پیوستن کشورها به جبهه‌ها: فقط ۲ دقیقه.',
      '',
      warService.formatWarFrontsText(war, [own.country, defenderCountry]),
    ].join('\n');

    const unauthExtra = {
      reply_markup: {
        inline_keyboard: [
          [
            { text: '⚪ بی‌طرف', callback_data: `war:side:${war.id}:neutral` },
            { text: '🔴 تیم مهاجم', callback_data: `war:side:${war.id}:attacker` },
            { text: '🟢 تیم مدافع', callback_data: `war:side:${war.id}:defender` },
          ],
          [{ text: '⚖️ جریمه متجاوز (ادمین)', callback_data: `chan:pen:atk:${own.countryId}` }],
        ],
      },
    };
    await notifications.publishToChannel(ctx.telegram, 'war_news', channelText, unauthExtra).catch(() => {});

    // اطلاع‌رسانی به مدافع
    const defenderOwnerships = await listActive(season.id);
    const defOwn = defenderOwnerships.find((o) => o.countryId === targetCountryId);
    if (defOwn) {
      await notifications.safeSend(ctx.telegram, defOwn.userId, `🚨 <b>هشدار تهاجم!</b>\nکشور ${own.country.flag} ${esc(own.country.name)} بدون مجوز بین‌المللی به کشور شما اعلان جنگ کرد! نیروهای پدافند را به حالت آماده‌باش درآورید.`);
    }

    const text = [
      `💥 <b>وضعیت جنگی اعلام شد!</b>`,
      '– – – – – – – – – –',
      `هدف: ${defenderCountry.flag} <b>${esc(defenderCountry.name)}</b>`,
      `مشروعیت جدید شما: <b>${newLegitimacy}%</b> (-25%)`,
      `رضایت جدید مردم: <b>${newSatisfaction}%</b> (-15%)`,
      '',
      'نیروهای شما اکنون می‌توانند از بخش «حمله» عملیات نظامی زمینی، دریایی و موشکی را اجرا نمایند.',
    ].join('\n');

    await ctx.editMessageText(text, {
      parse_mode: 'HTML',
      reply_markup: Markup.inlineKeyboard([
        [Markup.button.callback('⚔️ ورود به اتاق حمله', 'emp:attack')],
        [Markup.button.callback('🔙 بازگشت به امپراطوری', 'emp:home')],
      ]).reply_markup,
    }).catch(() => {});
  } catch (err) {
    await ctx.reply(`⚠️ ${err.message}`);
  }
});

// رأی کشور ثالث برای انتخاب جبهه جنگ؛ کشور با مالکیت فعال کاربر شناسایی می‌شود.
composer.action(/^war:side:([A-Za-z0-9_-]+):(neutral|attacker|defender)$/, async (ctx) => {
  try {
    const season = await getActiveSeason();
    if (!season) throw new Error('سیزن فعالی وجود ندارد.');
    const user = ctx.state.user;
    if (!user) throw new Error('ابتدا در بازی ثبت‌نام کنید.');
    const own = await getActiveOwnership(user.telegramId || ctx.from.id, season.id);
    if (!own) throw new Error('برای رأی دادن باید یک کشور فعال داشته باشید.');
    const side = ctx.match[2];
    const result = await warService.castWarSideVote({
      warId: ctx.match[1], countryId: String(own.countryId), side, userId: String(ctx.from.id),
    });
    const labels = { neutral: 'بی‌طرف', attacker: 'تیم مهاجم', defender: 'تیم مدافع' };
    await ctx.answerCbQuery(`رأی کشور شما ثبت شد: ${labels[side]}`, { show_alert: true }).catch(() => {});

    // نام و پرچم هر کشور زیر جبهه انتخابی آن در پیام کانال قرار می‌گیرد
    const sourceMessage = ctx.callbackQuery && ctx.callbackQuery.message;
    if (sourceMessage && sourceMessage.chat && sourceMessage.message_id && sourceMessage.reply_markup) {
      try {
        const [allCountries, war] = await Promise.all([countryService.list(), warService.getWar(result.warId)]);
        const rawMessage = String(sourceMessage.text || sourceMessage.caption || '');
        const marker = rawMessage.indexOf('مهاجم\n');
        const baseMessage = marker >= 0 ? rawMessage.slice(0, marker).trimEnd() : rawMessage.trimEnd();
        const joinDeadline = war && war.sideJoinDeadlineAt ? new Date(war.sideJoinDeadlineAt) : null;
        const remainingSeconds = joinDeadline ? Math.max(0, Math.ceil((joinDeadline.getTime() - Date.now()) / 1000)) : 0;
        const frontsText = warService.formatWarFrontsText(war, allCountries);
        const fullMessage = [
          baseMessage,
          '',
          frontsText,
          '',
          `⏳ زمان باقی‌مانده پیوستن به جبهه (مهلت ۲ دقیقه): ${Math.floor(remainingSeconds / 60)}:${String(remainingSeconds % 60).padStart(2, '0')}`,
        ].join('\n');
        await ctx.telegram.editMessageText(sourceMessage.chat.id, sourceMessage.message_id, undefined, fullMessage, {
          parse_mode: 'HTML', reply_markup: sourceMessage.reply_markup,
        }).catch(() => {});
      } catch (_) {}
    }
    await notifications.safeSend(ctx.telegram, ctx.from.id,
      `🗳 رأی کشور شما برای جنگ ${result.warId} ثبت شد.\n⚪ بی‌طرف: ${result.totals.neutral} | 🔴 مهاجم: ${result.totals.attacker} | 🟢 مدافع: ${result.totals.defender}`
    );
  } catch (err) {
    await ctx.answerCbQuery(err.message || 'ثبت رأی ناموفق بود.', { show_alert: true }).catch(() => {});
  }
});

// -------------------------------------------------------------
// سیستم جریمه زیر پیام‌های کانال (فقط توسط ادمین)
// -------------------------------------------------------------
// ۱. جریمه و حذف بیانیه در کانال
composer.action(/^chan:pen:stmt:([A-Za-z0-9_-]+)$/, async (ctx) => {
  const isAdm = config.adminIds.includes(ctx.from.id);
  if (!isAdm) {
    return ctx.answerCbQuery('⛔ این دکمه فقط مخصوص مدیریت بازی است.', { show_alert: true });
  }
  await ctx.answerCbQuery().catch(() => {});
  const countryId = ctx.match[1];
  const kb = Markup.inlineKeyboard([
    [Markup.button.callback('⚠️ ۵۰M $ جریمه (نشر اکاذیب و فریب)', `chan:stmt:do:${countryId}:50000000:fake`)],
    [Markup.button.callback('🚫 ۱۵۰M $ جریمه (توهین و تشنج)', `chan:stmt:do:${countryId}:150000000:insult`)],
    [Markup.button.callback('🔥 ۳۰۰M $ جریمه (تهدید امنیتی و تروریستی)', `chan:stmt:do:${countryId}:300000000:threat`)],
    [Markup.button.callback('🔙 انصراف', `chan:stmt:cancel:${countryId}`)],
  ]);
  await ctx.editMessageReplyMarkup(kb.reply_markup).catch(() => {});
});

composer.action(/^chan:stmt:cancel:([A-Za-z0-9_-]+)$/, async (ctx) => {
  const countryId = ctx.match[1];
  await ctx.answerCbQuery('انصراف داده شد.').catch(() => {});
  const defaultKb = Markup.inlineKeyboard([
    [Markup.button.callback('🚫 جریمه و حذف بیانیه (ادمین)', `chan:pen:stmt:${countryId}`)],
  ]);
  await ctx.editMessageReplyMarkup(defaultKb.reply_markup).catch(() => {});
});

composer.action(/^chan:stmt:do:([A-Za-z0-9_-]+):(\d+):(\w+)$/, async (ctx) => {
  const isAdm = config.adminIds.includes(ctx.from.id);
  if (!isAdm) {
    return ctx.answerCbQuery('⛔ فقط مدیر بازی اجازه اعمال جریمه را دارد.', { show_alert: true });
  }
  await ctx.answerCbQuery('حکم جریمه اجرا و بیانیه حذف شد.', { show_alert: true }).catch(() => {});
  const [countryId, amountStr, reasonKey] = [ctx.match[1], ctx.match[2], ctx.match[3]];
  const amount = Number(amountStr);
  const reasonFa = reasonKey === 'fake'
    ? 'نشر اکاذیب و فریب افکار عمومی'
    : reasonKey === 'insult'
      ? 'توهین دیپلماتیک و ایجاد تشنج بین‌المللی'
      : 'تهدید به جنگ غیرقانونی و نقض امنیت عمومی';

  const season = await getActiveSeason();
  const country = await countryService.get(countryId);

  // حذف بیانیه متخلف از کانال
  await ctx.deleteMessage().catch(() => {});

  // اعمال جریمه نقدی و کسر مشروعیت
  if (season) {
    await gameService.applyCountryPenalty({
      countryId,
      seasonId: season.id,
      amount,
      reason: reasonFa,
      legitimacyLoss: 20,
      satisfactionLoss: 15,
      adminId: ctx.from.id,
    });
  }

  // اعلام رسمی در کانال مبنی بر حذف بیانیه، دلیل و مقدار جریمه
  const announceText = [
    '⚖️ <b>بیانیه دیپلماتیک حذف و کشور متخلف جریمه شد!</b>',
    '– – – – – – – – – –',
    `🌍 کشور متخلف: <b>${country ? `${country.flag} ${esc(country.name)}` : countryId}</b>`,
    `🚫 دلیل توقیف و حذف: <b>${reasonFa}</b>`,
    `💰 مبلغ جریمه کسر شده از خزانه: <b>${fmtNum(amount)}$</b>`,
    '🔻 مشروعیت بین‌المللی: <b>۲۰٪ افت قطعی</b>',
    '',
    '🛡 شورای عالی نظارت با هرگونه محتوای نامتعارف برخورد بدون اغماض خواهد داشت.',
  ].join('\n');
  await notifications.publishToChannel(ctx.telegram, 'announcement', announceText).catch(() => {});
});

// ۲. جریمه متجاوز جنگی زیر پیام حمله بدون مجوز در کانال
composer.action(/^chan:pen:atk:([A-Za-z0-9_-]+)$/, async (ctx) => {
  const isAdm = config.adminIds.includes(ctx.from.id);
  if (!isAdm) {
    return ctx.answerCbQuery('⛔ این دکمه فقط مخصوص مدیریت بازی است.', { show_alert: true });
  }
  await ctx.answerCbQuery().catch(() => {});
  const countryId = ctx.match[1];
  const kb = Markup.inlineKeyboard([
    [Markup.button.callback('⚠️ ۵۰M $ جریمه نقدی (تجاوز مرزی محدود)', `chan:atk:do:${countryId}:50000000:minor`)],
    [Markup.button.callback('🚫 ۱۵۰M $ جریمه سنگین (تهاجم گسترده)', `chan:atk:do:${countryId}:150000000:heavy`)],
    [Markup.button.callback('🔥 ۳۵۰M $ جریمه فوق‌سنگین (جنایت جنگی)', `chan:atk:do:${countryId}:350000000:severe`)],
    [Markup.button.callback('🔙 انصراف', `chan:atk:cancel:${countryId}`)],
  ]);
  await ctx.editMessageReplyMarkup(kb.reply_markup).catch(() => {});
});

composer.action(/^chan:atk:cancel:([A-Za-z0-9_-]+)$/, async (ctx) => {
  const countryId = ctx.match[1];
  await ctx.answerCbQuery('انصراف داده شد.').catch(() => {});
  const defaultKb = Markup.inlineKeyboard([
    [Markup.button.callback('⚖️ جریمه متجاوز (ادمین)', `chan:pen:atk:${countryId}`)],
  ]);
  await ctx.editMessageReplyMarkup(defaultKb.reply_markup).catch(() => {});
});

composer.action(/^chan:atk:do:([A-Za-z0-9_-]+):(\d+):(\w+)$/, async (ctx) => {
  const isAdm = config.adminIds.includes(ctx.from.id);
  if (!isAdm) {
    return ctx.answerCbQuery('⛔ فقط مدیر بازی اجازه اعمال جریمه را دارد.', { show_alert: true });
  }
  await ctx.answerCbQuery('حکم جریمه متجاوز با موفقیت صادر شد.', { show_alert: true }).catch(() => {});
  const [countryId, amountStr, severity] = [ctx.match[1], ctx.match[2], ctx.match[3]];
  const amount = Number(amountStr);
  const legLoss = severity === 'minor' ? 10 : severity === 'heavy' ? 25 : 40;
  const reasonFa = 'تهاجم نظامی غیرقانونی، نقض مرزها و حمله بدون کسب مجوز رسمی';

  const season = await getActiveSeason();
  const country = await countryService.get(countryId);

  if (season) {
    await gameService.applyCountryPenalty({
      countryId,
      seasonId: season.id,
      amount,
      reason: reasonFa,
      legitimacyLoss: legLoss,
      satisfactionLoss: 20,
      adminId: ctx.from.id,
    });
  }

  // حذف دکمه‌های جریمه از پیام کانال
  await ctx.editMessageReplyMarkup(undefined).catch(() => {});

  // انتشار حکم در کانال
  const announceText = [
    '⚖️ <b>حکم محکومیت و جریمه متجاوز جنگی صادر شد!</b>',
    '– – – – – – – – – –',
    `🌍 کشور متجاوز: <b>${country ? `${country.flag} ${esc(country.name)}` : countryId}</b>`,
    `📜 علت محکومیت: <b>${reasonFa}</b>`,
    `💰 جریمه نقدی کسر شده از خزانه: <b>${fmtNum(amount)}$</b>`,
    `🔻 سلب مشروعیت بین‌المللی: <b>${legLoss}٪</b>`,
    '',
    '⚖️ شورای عالی نظارت هرگونه تعرض غیرقانونی را مشمول جریمه سنگین خواهد کرد.',
  ].join('\n');
  await notifications.publishToChannel(ctx.telegram, 'war_news', announceText).catch(() => {});
});

// -------------------------------------------------------------
// بخش بازار و سرمایه و رمزارزها (ارز دیجیتال با درصد سود و زیان)
// -------------------------------------------------------------
composer.action('emp:finance', async (ctx) => {
  await ctx.answerCbQuery().catch(() => {});
  await showCryptoPanel(ctx, true);
});
composer.hears(['بازار و سرمایه 💹', 'رمزارزها', 'بیت کوین', 'ارز دیجیتال'], async (ctx) => {
  await showCryptoPanel(ctx, false);
});

async function showCryptoPanel(ctx, isEdit = false) {
  const data = await requireCountry(ctx);
  if (!data) return;
  const { season, own } = data;
  const portfolio = await cryptoService.getPortfolio(own.countryId, season.id);
  const flag = countryService.getDynamicFlag(own.country, await gameService.getCountryState(own.countryId, season.id));

  const pnlSign = portfolio.totalPnlUsd >= 0 ? '+' : '';
  const pnlTrend = portfolio.totalPnlUsd >= 0 ? '🟢 سود' : '🔴 زیان';

  const text = [
    `💹 <b>بازار و سرمایه بین‌المللی — ${esc(own.country.name)} ${flag}</b>`,
    '– – – – – – – – – –',
    `💵 موجودی نقد خزانه: <b>${fmtNum(portfolio.treasury)}$</b>`,
    `💼 ارزش کل سبد رمزارز: <b>${fmtNum(portfolio.totalValueUsd)}$</b>`,
    `📊 سود و زیان کل سبد: <b>${pnlTrend}: ${pnlSign}${fmtNum(portfolio.totalPnlUsd)}$ (${pnlSign}${portfolio.totalPnlPercent}%)</b>`,
    '',
    '📈 <b>نرخ‌های زنده بازار رمزارز و درصد سود/زیان دوره‌ای:</b>',
    ...portfolio.holdings.map((c) => {
      const sign = c.changePercent >= 0 ? '+' : '';
      const holdingInfo = c.hasHolding ? ` | موجودی شما: <b>${c.amount} ${c.symbol}</b> (ارزش: ${fmtNum(c.currentValueUsd)}$)` : '';
      return `${c.icon} <b>${c.nameFa} (${c.symbol}):</b> <code>${fmtNum(c.price)}$</code> | ${c.trendIcon}${sign}${c.changePercent}%${holdingInfo}`;
    }),
    '',
    '👇 جهت خرید یا فروش رمزارزها با بودجه ملی، ارز مورد نظر را انتخاب کنید:',
  ].join('\n');

  const rows = [
    [
      Markup.button.callback('₿ خرید/فروش بیت‌کوین', 'crypto:coin:BTC'),
      Markup.button.callback('Ξ خرید/فروش اتریوم', 'crypto:coin:ETH'),
    ],
    [
      Markup.button.callback('☀️ سولانا', 'crypto:coin:SOL'),
      Markup.button.callback('💎 تون‌کوین', 'crypto:coin:TON'),
      Markup.button.callback('✕ ریپل', 'crypto:coin:XRP'),
    ],
    [
      Markup.button.callback('🌾 تجارت آذوقه و کالا', 'emp:trade_goods'),
      Markup.button.callback('🛢 بازار نفت', 'emp:oil'),
    ],
    [Markup.button.callback('🔙 بازگشت به امپراطوری', 'emp:home')],
  ];

  const kb = Markup.inlineKeyboard(rows);
  if (isEdit && ctx.callbackQuery) {
    await ctx.editMessageText(text, { parse_mode: 'HTML', reply_markup: kb.reply_markup }).catch(() => {});
  } else {
    await ctx.reply(text, { parse_mode: 'HTML', ...kb });
  }
}

// منوی مدیریت تک رمزارز
composer.action(/^crypto:coin:(\w+)$/, async (ctx) => {
  await ctx.answerCbQuery().catch(() => {});
  const symbol = ctx.match[1];
  const data = await requireCountry(ctx);
  if (!data) return;
  const { season, own } = data;

  const portfolio = await cryptoService.getPortfolio(own.countryId, season.id);
  const coin = portfolio.holdings.find((c) => c.symbol.toUpperCase() === symbol.toUpperCase());
  if (!coin) return ctx.reply('نماد رمزارز یافت نشد.');

  const sign = coin.changePercent >= 0 ? '+' : '';
  const pnlSign = coin.pnlUsd >= 0 ? '+' : '';
  const pnlIcon = coin.pnlUsd >= 0 ? '🟢' : '🔴';

  const text = [
    `${coin.icon} <b>معاملات ${esc(coin.nameFa)} (${coin.symbol})</b>`,
    '– – – – – – – – – –',
    `💲 قیمت لحظه‌ای: <b>${fmtNum(coin.price)}$</b>`,
    `📈 نوسان و بازدهی دوره‌ای: ${coin.trendIcon}<b>${sign}${coin.changePercent}%</b>`,
    '',
    '💼 <b>وضعیت دارایی کشور شما:</b>',
    `🔹 موجودی: <b>${coin.amount} ${coin.symbol}</b>`,
    `💵 ارزش فعلی: <b>${fmtNum(coin.currentValueUsd)}$</b>`,
    `💰 سرمایه‌گذاری اولیه: <b>${fmtNum(coin.investedUsd)}$</b>`,
    `📊 سود/زیان محقق‌نشده: ${pnlIcon} <b>${pnlSign}${fmtNum(coin.pnlUsd)}$ (${pnlSign}${coin.pnlPercent}%)</b>`,
    `🏦 سرمایه آزاد خزانه: <b>${fmtNum(portfolio.treasury)}$</b>`,
    '',
    'میزان خرید با بودجه خزانه یا درصد فروش دارایی را انتخاب کنید:',
  ].join('\n');

  const rows = [
    [
      Markup.button.callback('🟢 خرید ۱۰M $', `crypto:buy:${symbol}:10000000`),
      Markup.button.callback('🟢 خرید ۵۰M $', `crypto:buy:${symbol}:50000000`),
      Markup.button.callback('🟢 خرید ۱۰۰M $', `crypto:buy:${symbol}:100000000`),
    ],
    [
      Markup.button.callback('🟡 فروش ۲۵٪', `crypto:sell:${symbol}:25`),
      Markup.button.callback('🟡 فروش ۵۰٪', `crypto:sell:${symbol}:50`),
      Markup.button.callback('🔴 فروش کل (۱۰۰٪)', `crypto:sell:${symbol}:100`),
    ],
    [Markup.button.callback('🔙 بازگشت به بازار و سرمایه', 'emp:finance')],
  ];

  await ctx.editMessageText(text, { parse_mode: 'HTML', reply_markup: Markup.inlineKeyboard(rows).reply_markup }).catch(() => {});
});

// اجرای خرید رمزارز
composer.action(/^crypto:buy:(\w+):(\d+)$/, async (ctx) => {
  const [symbol, amountStr] = [ctx.match[1], ctx.match[2]];
  const amountUsd = Number(amountStr);
  const data = await requireCountry(ctx);
  if (!data) return;

  try {
    const res = await cryptoService.buyCrypto({
      countryId: data.own.countryId,
      seasonId: data.season.id,
      symbol,
      amountUsd,
    });
    await ctx.answerCbQuery(`✅ ${res.coinsBought} عدد ${res.coin.nameFa} خریداری شد!`, { show_alert: true });
    // بازگشت به صفحه سکه
    const ev = { match: [null, symbol] };
    await showCryptoCoin(ctx, symbol);
  } catch (err) {
    await ctx.answerCbQuery(err.message, { show_alert: true });
  }
});

// اجرای فروش رمزارز
composer.action(/^crypto:sell:(\w+):(\d+)$/, async (ctx) => {
  const [symbol, percentStr] = [ctx.match[1], ctx.match[2]];
  const percent = Number(percentStr);
  const data = await requireCountry(ctx);
  if (!data) return;

  try {
    const res = await cryptoService.sellCrypto({
      countryId: data.own.countryId,
      seasonId: data.season.id,
      symbol,
      percent,
    });
    const profitText = res.profitUsd >= 0 ? `سود: +${fmtNum(res.profitUsd)}$` : `زیان: ${fmtNum(res.profitUsd)}$`;
    await ctx.answerCbQuery(`✅ ${res.coinsSold} عدد ${res.coin.nameFa} فروخته شد (+${fmtNum(res.revenueUsd)}$ | ${profitText})`, { show_alert: true });
    await showCryptoCoin(ctx, symbol);
  } catch (err) {
    await ctx.answerCbQuery(err.message, { show_alert: true });
  }
});

async function showCryptoCoin(ctx, symbol) {
  const data = await requireCountry(ctx);
  if (!data) return;
  const portfolio = await cryptoService.getPortfolio(data.own.countryId, data.season.id);
  const coin = portfolio.holdings.find((c) => c.symbol.toUpperCase() === symbol.toUpperCase());
  if (!coin) return;

  const sign = coin.changePercent >= 0 ? '+' : '';
  const pnlSign = coin.pnlUsd >= 0 ? '+' : '';
  const pnlIcon = coin.pnlUsd >= 0 ? '🟢' : '🔴';

  const text = [
    `${coin.icon} <b>معاملات ${esc(coin.nameFa)} (${coin.symbol})</b>`,
    '– – – – – – – – – –',
    `💲 قیمت لحظه‌ای: <b>${fmtNum(coin.price)}$</b>`,
    `📈 نوسان و بازدهی دوره‌ای: ${coin.trendIcon}<b>${sign}${coin.changePercent}%</b>`,
    '',
    '💼 <b>وضعیت دارایی کشور شما:</b>',
    `🔹 موجودی: <b>${coin.amount} ${coin.symbol}</b>`,
    `💵 ارزش فعلی: <b>${fmtNum(coin.currentValueUsd)}$</b>`,
    `💰 سرمایه‌گذاری اولیه: <b>${fmtNum(coin.investedUsd)}$</b>`,
    `📊 سود/زیان محقق‌نشده: ${pnlIcon} <b>${pnlSign}${fmtNum(coin.pnlUsd)}$ (${pnlSign}${coin.pnlPercent}%)</b>`,
    `🏦 سرمایه آزاد خزانه: <b>${fmtNum(portfolio.treasury)}$</b>`,
    '',
    'میزان خرید با بودجه خزانه یا درصد فروش دارایی را انتخاب کنید:',
  ].join('\n');

  const rows = [
    [
      Markup.button.callback('🟢 خرید ۱۰M $', `crypto:buy:${symbol}:10000000`),
      Markup.button.callback('🟢 خرید ۵۰M $', `crypto:buy:${symbol}:50000000`),
      Markup.button.callback('🟢 خرید ۱۰۰M $', `crypto:buy:${symbol}:100000000`),
    ],
    [
      Markup.button.callback('🟡 فروش ۲۵٪', `crypto:sell:${symbol}:25`),
      Markup.button.callback('🟡 فروش ۵۰٪', `crypto:sell:${symbol}:50`),
      Markup.button.callback('🔴 فروش کل (۱۰۰٪)', `crypto:sell:${symbol}:100`),
    ],
    [Markup.button.callback('🔙 بازگشت به بازار و سرمایه', 'emp:finance')],
  ];

  await ctx.editMessageText(text, { parse_mode: 'HTML', reply_markup: Markup.inlineKeyboard(rows).reply_markup }).catch(() => {});
}

// تجارت کالا (آذوقه و سکه)
composer.action('emp:trade_goods', async (ctx) => {
  await ctx.answerCbQuery().catch(() => {});
  await showTradeBudgetPanel(ctx, true);
});

async function showTradeBudgetPanel(ctx, isEdit = false) {
  const data = await requireCountry(ctx);
  if (!data) return;
  const { season, own } = data;
  const state = await gameService.getCountryState(own.countryId, season.id);
  const flag = countryService.getDynamicFlag(own.country, state);

  const text = [
    `🍞 <b>خزانه و تجارت کالایی ملی — ${esc(own.country.name)} ${flag}</b>`,
    '– – – – – – – – – –',
    `💵 بودجه ملی و سرمایه خزانه: <b>${fmtNum(state.treasury)}$</b>`,
    `🍞 ذخایر گندم و غذا: <b>${fmtNum(state.food || 3010)} تن</b>`,
    `🛢 ذخایر نفت خام: <b>${fmtNum(state.oil || 0)} بشکه</b>`,
    `🪙 سکه A-W Coin: <b>${ctx.state.user.awCoins || 9} سکه</b>`,
    '',
    'در این بخش می‌توانید آذوقه غذایی بخرید یا مازاد آن را صادر کنید، و با بودجه سکه تهیه نمایید:',
  ].join('\n');

  const kb = Markup.inlineKeyboard([
    [
      Markup.button.callback('🌾 خرید ۵۰۰ تن غذا (۲.۵M $)', 'trade:food:buy:500'),
      Markup.button.callback('🌾 فروش ۵۰۰ تن غذا (+۲.۵M $)', 'trade:food:sell:500'),
    ],
    [
      Markup.button.callback('🌾 خرید ۲۰۰۰ تن غذا (۱۰M $)', 'trade:food:buy:2000'),
      Markup.button.callback('🌾 فروش ۲۰۰۰ تن غذا (+۱۰M $)', 'trade:food:sell:2000'),
    ],
    [
      Markup.button.callback('🪙 خرید ۵ سکه A-W با بودجه (۵۰M $)', 'trade:coin:buy:5'),
    ],
    [Markup.button.callback('🔙 بازگشت به بازار و سرمایه', 'emp:finance')],
  ]);

  if (isEdit && ctx.callbackQuery) {
    await ctx.editMessageText(text, { parse_mode: 'HTML', reply_markup: kb.reply_markup }).catch(() => {});
  } else {
    await ctx.reply(text, { parse_mode: 'HTML', ...kb });
  }
}

composer.action(/^trade:(\w+):(\w+):(\d+)$/, async (ctx) => {
  const [item, action, qtyStr] = [ctx.match[1], ctx.match[2], ctx.match[3]];
  const qty = Number(qtyStr);
  const data = await requireCountry(ctx);
  if (!data) return;

  try {
    const res = await gameService.tradeCommodity({
      countryId: data.own.countryId,
      seasonId: data.season.id,
      item,
      action,
      quantity: qty,
    });
    await ctx.answerCbQuery(res.msg, { show_alert: true });
    await showTradeBudgetPanel(ctx, true);
  } catch (err) {
    await ctx.answerCbQuery(err.message, { show_alert: true });
  }
});

// -------------------------------------------------------------
// بخش استراتژیک تنگه‌های جهان (عوارض ۵٪ و مسدودسازی ۴۰٪ با تایید سازمان ملل)
// -------------------------------------------------------------
composer.action('emp:straits', async (ctx) => {
  await ctx.answerCbQuery().catch(() => {});
  await showStraitsPanel(ctx, true);
});
composer.hears(['تنگه‌ها 🚢', 'تنگه ها', 'تنگه هرمز', 'آبراهه'], async (ctx) => {
  await showStraitsPanel(ctx, false);
});

async function showStraitsPanel(ctx, isEdit = false) {
  const data = await requireCountry(ctx);
  if (!data) return;
  const { season, own } = data;
  const straits = await straitService.getStraits(season.id);
  const flag = countryService.getDynamicFlag(own.country, await gameService.getCountryState(own.countryId, season.id));

  const ownedByMe = straits.filter((s) => String(s.ownerCountryId) === String(own.countryId));

  const text = [
    `🚢 <b>تنگه‌ها و آبراهه‌های استراتژیک جهان — ${esc(own.country.name)} ${flag}</b>`,
    '– – – – – – – – – –',
    '🌍 <b>قوانین و مزایای ژئوپلیتیک تنگه‌ها:</b>',
    '🔹 مالکیت هر تنگه به کشور دارنده این حق را می‌دهد که <b>۵٪ از کل درآمد دوره‌ای سایر کشورها</b> را به عنوان عوارض ترانزیت بین‌المللی دریافت کند.',
    '🔹 مالکان می‌توانند با <b>کسب مجوز رسمی از سازمان ملل</b> تنگه را به روی یک کشور یا کل جهان مسدود کنند. در این صورت <b>۴۰٪ از درآمد</b> هدف را مصادره می‌نمایند!',
    '',
    `👑 تنگه‌های تحت کنترل شما: <b>${ownedByMe.length} تنگه</b>`,
    '',
    '📍 <b>لیست تنگه‌های ۱۰گانه استراتژیک جهان:</b>',
    ...straits.map((s, idx) => {
      let statusStr = '🏳️ بدون مالک (قابل تصاحب)';
      if (s.ownerCountryId) {
        const isMine = String(s.ownerCountryId) === String(own.countryId);
        const ownerTitle = isMine ? '👑 متعلق به شما' : `تحت کنترل ${s.ownerFlag || ''} ${s.ownerCountryName}`;
        let blockText = '';
        if (s.blockade) {
          if (s.blockade.status === 'approved') blockText = ' | 🚫 <b>مسدود با مجوز سازمان ملل</b>';
          else if (s.blockade.status === 'pending_un') blockText = ' | ⏳ <b>در انتظار تایید سازمان ملل</b>';
        }
        statusStr = `${ownerTitle}${blockText}`;
      }
      return `${idx + 1}. ${s.icon} <b>${s.name}</b> (${s.region}) — ${statusStr}`;
    }),
    '',
    '👇 جهت مشاهده جزئیات، تصاحب یا مدیریت انسداد، تنگه مورد نظر را انتخاب کنید:',
  ].join('\n');

  // ردیف‌های تنگه‌ها
  const rows = [];
  for (let i = 0; i < straits.length; i += 2) {
    const s1 = straits[i];
    const s2 = straits[i + 1];
    const row = [
      Markup.button.callback(`${s1.icon} ${s1.name}`, `strait:view:${s1.id}`),
    ];
    if (s2) row.push(Markup.button.callback(`${s2.icon} ${s2.name}`, `strait:view:${s2.id}`));
    rows.push(row);
  }
  rows.push([Markup.button.callback('🔙 بازگشت به امپراطوری', 'emp:home')]);

  const kb = Markup.inlineKeyboard(rows);
  if (isEdit && ctx.callbackQuery) {
    await ctx.editMessageText(text, { parse_mode: 'HTML', reply_markup: kb.reply_markup }).catch(() => {});
  } else {
    await ctx.reply(text, { parse_mode: 'HTML', ...kb });
  }
}

// مشاهده جزئیات یک تنگه
composer.action(/^strait:view:(\w+)$/, async (ctx) => {
  await ctx.answerCbQuery().catch(() => {});
  const straitId = ctx.match[1];
  const data = await requireCountry(ctx);
  if (!data) return;
  const { season, own } = data;

  const strait = await straitService.getStrait(season.id, straitId);
  if (!strait) return ctx.reply('تنگه یافت نشد.');

  const isMine = String(strait.ownerCountryId) === String(own.countryId);
  const state = await gameService.getCountryState(own.countryId, season.id);

  let ownerText = '🏳️ <b>فاقد مالک:</b> این آبراهه بین‌المللی آزاد است و هر کشوری با پرداخت ۵۰۰ میلیون دلار هزینه کنترل استراتژیک می‌تواند مالکیت آن را به دست آورد.';
  if (strait.ownerCountryId) {
    ownerText = isMine
      ? '👑 <b>مالک: کشورتان شما!</b> شما در هر دوره ۵٪ از درآمد سایر کشورها را به عنوان عوارض دریافت می‌کنید.'
      : `🛡️ <b>مالک:</b> کشور ${strait.ownerFlag || ''} <b>${esc(strait.ownerCountryName)}</b> (عوارض ۵٪ را دریافت می‌کند).`;
  }

  let blockadeSection = '';
  if (strait.blockade) {
    const b = strait.blockade;
    if (b.status === 'approved') {
      blockadeSection = `\n🚫 <b>وضعیت انسداد:</b> فعال با مجوز رسمی سازمان ملل!\n🎯 هدف: <b>${esc(b.targetName)}</b>\n⚡ کسر درآمد: <b>۴۰٪ مصادره مستقیم</b>`;
    } else if (b.status === 'pending_un') {
      blockadeSection = `\n⏳ <b>درخواست انسداد:</b> در دبیرخانه شورای امنیت سازمان ملل ثبت شده و منتظر تایید یا وتوی رسمی است.\n🎯 هدف درخواستی: <b>${esc(b.targetName)}</b>`;
    } else if (b.status === 'rejected') {
      blockadeSection = `\n❌ <b>درخواست قبلی انسداد:</b> توسط سازمان ملل وتو و رد شده است.`;
    }
  }

  let navalPowerText = '';
  const myNavalPower = await straitService.calculateCountryNavalPower(own.countryId, season.id);

  if (strait.ownerCountryId && !isMine) {
    const defNavalPower = await straitService.calculateCountryNavalPower(strait.ownerCountryId, season.id);
    const requiredPower = defNavalPower * 2;
    const canConquer = myNavalPower >= requiredPower && myNavalPower > 0;
    navalPowerText = [
      '',
      '⚔️ <b>موازنه توان دریایی برای فتح این تنگه:</b>',
      `• توان رزمی نیروی دریایی شما: <b>${fmtNum(myNavalPower)}</b>`,
      `• توان رزمی نیروی دریایی مدافع: <b>${fmtNum(defNavalPower)}</b>`,
      `• حداقل توان دریایی مورد نیاز برای فتح (قانون ۲ برابری): <b>${fmtNum(requiredPower)}</b>`,
      canConquer
        ? '🟢 <i>نیروی دریایی شما از برتری ۲ برابری برخوردار است و شرایط فتح را دارید!</i>'
        : '🔴 <i>توان دریایی شما کمتر از ۲ برابر مدافع است. جهت فتح به رزم‌ناو و ناوهای بیشتری نیاز دارید.</i>',
    ].join('\n');
  } else if (!strait.ownerCountryId) {
    navalPowerText = [
      '',
      '🚢 <b>شرایط کنترل آبراهه آزاد:</b>',
      `• توان دریایی فعلی شما: <b>${fmtNum(myNavalPower)}</b> (حداقل ۵۰۰ برای کنترل الزامی است)`,
      '• هزینه استقرار تأسیسات و گشت دریایی: <b>۵۰۰ میلیون دلار</b>',
    ].join('\n');
  }

  const text = [
    `${strait.icon} <b>${esc(strait.name)} (${esc(strait.region)})</b>`,
    '– – – – – – – – – –',
    `📖 شرح: <i>${esc(strait.desc)}</i>`,
    '',
    ownerText,
    blockadeSection,
    navalPowerText,
    '',
    `💵 موجودی خزانه کشور شما: <b>${fmtNum(state.treasury)}$</b>`,
  ].join('\n');

  const buttons = [];
  if (!strait.ownerCountryId) {
    buttons.push([Markup.button.callback('🌊 استقرار ناوگان و تصاحب مالکیت تنگه (500M $)', `strait:claim:${strait.id}`)]);
  } else if (isMine) {
    if (!strait.blockade || strait.blockade.status === 'rejected') {
      buttons.push([Markup.button.callback('🚫 بستن تنگه با مجوز سازمان ملل', `strait:blk_menu:${strait.id}`)]);
    } else {
      buttons.push([Markup.button.callback('🔓 لغو انسداد و بازگشایی تنگه', `strait:lift:${strait.id}`)]);
    }
  } else {
    // کشور دیگری مالک است -> گزینه فتح نظامی با ناوگان دریایی
    buttons.push([Markup.button.callback('⚔️ فتح نظامی تنگه با ناوگان دریایی (شرط برتری ۲ برابری)', `strait:claim:${strait.id}`)]);
  }

  buttons.push([Markup.button.callback('🔙 بازگشت به لیست تنگه‌ها', 'emp:straits')]);

  await ctx.editMessageText(text, {
    parse_mode: 'HTML',
    reply_markup: Markup.inlineKeyboard(buttons).reply_markup,
  }).catch(() => {});
});

// تصاحب مالکیت تنگه
composer.action(/^strait:claim:(\w+)$/, async (ctx) => {
  const straitId = ctx.match[1];
  const data = await requireCountry(ctx);
  if (!data) return;

  try {
    const res = await straitService.claimStrait({
      countryId: data.own.countryId,
      seasonId: data.season.id,
      straitId,
    });

    // انتشار در کانال رسمی
    const channelText = [
      '🌊 <b>تحول ژئوپلیتیک دریایی و تغییر موازنه قدرت!</b>',
      '– – – – – – – – – –',
      `کشور <b>${data.own.country.flag} ${esc(data.own.country.name)}</b> رسماً کنترل آبراهه استراتژیک <b>${res.strait.icon} ${esc(res.strait.name)}</b> را در اختیار گرفت.`,
      `🚢 از این پس ۵٪ عوارض ترانزیت کشتیرانی بین‌المللی به خزانه این کشور واریز می‌گردد.`,
    ].join('\n');
    await notifications.publishToChannel(ctx.telegram, 'announcement', channelText).catch(() => {});

    await ctx.answerCbQuery(`🎉 تبریک! شما مالک تنگه ${res.strait.name} شدید.`, { show_alert: true });
    await showStraitsPanel(ctx, true);
  } catch (err) {
    await ctx.answerCbQuery(err.message, { show_alert: true });
  }
});

// منوی انتخاب هدف بستن تنگه (جهانی یا یک کشور)
composer.action(/^strait:blk_menu:(\w+)$/, async (ctx) => {
  await ctx.answerCbQuery().catch(() => {});
  const straitId = ctx.match[1];
  const data = await requireCountry(ctx);
  if (!data) return;

  const strait = await straitService.getStrait(data.season.id, straitId);
  if (!strait) return;

  const text = [
    `🚫 <b>مسدودسازی استراتژیک ${strait.name} با مجوز سازمان ملل</b>`,
    '– – – – – – – – – –',
    'طبق قوانین بین‌المللی، مسدودسازی تنگه نیاز به <b>تصویب رسمی در شورای امنیت سازمان ملل</b> دارد.',
    'در صورت تایید، <b>۴۰٪ از درآمد کشور هدف</b> کسر شده و مستقیماً به خزانه شما واریز خواهد شد.',
    '',
    'دامنه مسدودسازی را انتخاب کنید:',
  ].join('\n');

  const rows = [
    [Markup.button.callback('🌍 مسدودسازی روی کل جهان (۴۰٪ از همه)', `strait:do_blk:${strait.id}:worldwide`)],
    [Markup.button.callback('🎯 مسدودسازی روی یک کشور خاص', `strait:target_country:${strait.id}`)],
    [Markup.button.callback('🔙 انصراف', `strait:view:${strait.id}`)],
  ];

  await ctx.editMessageText(text, {
    parse_mode: 'HTML',
    reply_markup: Markup.inlineKeyboard(rows).reply_markup,
  }).catch(() => {});
});

// انتخاب کشور هدف برای انسداد
composer.action(/^strait:target_country:(\w+)$/, async (ctx) => {
  await ctx.answerCbQuery().catch(() => {});
  const straitId = ctx.match[1];
  const data = await requireCountry(ctx);
  if (!data) return;

  const activeOwnerships = await listActive(data.season.id);
  const targets = activeOwnerships.filter((o) => String(o.countryId) !== String(data.own.countryId));

  const rows = [];
  for (const t of targets.slice(0, 10)) {
    const c = await countryService.get(t.countryId);
    if (c) {
      rows.push([Markup.button.callback(`🎯 مسدودسازی علیه: ${c.flag} ${c.name}`, `strait:do_blk:${straitId}:country:${c.id}`)]);
    }
  }
  rows.push([Markup.button.callback('🔙 بازگشت', `strait:blk_menu:${straitId}`)]);

  await ctx.editMessageText('🎯 <b>کشور مورد نظر برای انسداد عبور و مرور دریایی را انتخاب کنید:</b>', {
    parse_mode: 'HTML',
    reply_markup: Markup.inlineKeyboard(rows).reply_markup,
  }).catch(() => {});
});

// ارسال درخواست بستن تنگه به سازمان ملل
composer.action(/^strait:do_blk:(\w+):(\w+)(?::([A-Za-z0-9_-]+))?$/, async (ctx) => {
  const [straitId, targetType, targetCountryId] = [ctx.match[1], ctx.match[2], ctx.match[3] || null];
  const data = await requireCountry(ctx);
  if (!data) return;

  try {
    const res = await straitService.requestBlockade({
      countryId: data.own.countryId,
      seasonId: data.season.id,
      straitId,
      targetType,
      targetCountryId,
    });

    const targetDesc = targetType === 'worldwide' ? 'کل جهان' : res.blockade.targetName;

    // ارسال لایحه به مدیران و ربات ادمین جهت تصمیم‌گیری در شورای امنیت سازمان ملل
    const unMsg = [
      '🏛 <b>قطعنامه اضطراری شورای امنیت سازمان ملل</b>',
      '– – – – – – – – – –',
      `کشور <b>${data.own.country.flag} ${esc(data.own.country.name)}</b> درخواست مسدودسازی آبراهه <b>${esc(res.strait.name)}</b> را ارائه داد.`,
      `🎯 دامنه تحریم دریایی: <b>${esc(targetDesc)}</b>`,
      `⚡ در صورت تایید، ۴۰٪ از درآمد هدف به مالک تنگه واریز می‌گردد.`,
      '',
      'آیا شورای امنیت این انسداد را تایید و تصویب می‌کند؟',
    ].join('\n');

    const adminActions = Markup.inlineKeyboard([
      [
        Markup.button.callback('✅ تایید سازمان ملل (شورای امنیت)', `un:strait:app:${data.season.id}:${straitId}`),
        Markup.button.callback('❌ وتو و رد قطعنامه', `un:strait:rej:${data.season.id}:${straitId}`),
      ],
    ]);

    await adminBotService.sendToAdminBot(ctx.telegram, unMsg, adminActions).catch(() => {});
    await notifications.notifyAdmins(ctx.telegram, unMsg, adminActions).catch(() => {});

    await ctx.answerCbQuery('📨 درخواست مسدودسازی به دبیرخانه سازمان ملل ارسال شد.', { show_alert: true });
    await showStraitsPanel(ctx, true);
  } catch (err) {
    await ctx.answerCbQuery(err.message, { show_alert: true });
  }
});

// لغو انسداد توسط مالک
composer.action(/^strait:lift:(\w+)$/, async (ctx) => {
  const straitId = ctx.match[1];
  const data = await requireCountry(ctx);
  if (!data) return;

  try {
    await straitService.liftBlockade({
      countryId: data.own.countryId,
      seasonId: data.season.id,
      straitId,
    });
    await ctx.answerCbQuery('🔓 انسداد لغو و آبراهه به وضعیت عادی بازگشت.', { show_alert: true });
    await showStraitsPanel(ctx, true);
  } catch (err) {
    await ctx.answerCbQuery(err.message, { show_alert: true });
  }
});

// تایید یا رد مسدودسازی توسط مدیر در ربات ادمین (شورای امنیت سازمان ملل)
composer.action(/^un:strait:(app|rej):([A-Za-z0-9_-]+):(\w+)$/, async (ctx) => {
  const isAdm = config.adminIds.includes(ctx.from.id);
  if (!isAdm) return ctx.answerCbQuery('⛔ فقط اعضای مجاز مدیریت/شورای امنیت اجازه رای‌دهی دارند.', { show_alert: true });

  const [decision, seasonId, straitId] = [ctx.match[1], ctx.match[2], ctx.match[3]];
  const approved = decision === 'app';

  try {
    const res = await straitService.decideBlockade({
      seasonId,
      straitId,
      approved,
      adminId: String(ctx.from.id),
    });

    await ctx.answerCbQuery(approved ? '✅ قطعنامه تصویب شد!' : '❌ قطعنامه وتو شد!', { show_alert: true });
    await ctx.editMessageReplyMarkup(undefined).catch(() => {});

    // اعلام عمومی در کانال
    const channelText = approved
      ? [
          '🚨 <b>قطعنامه شورای امنیت سازمان ملل متحد صادر شد!</b>',
          '– – – – – – – – – –',
          `شورای امنیت رسماً مجوز انسداد آبراهه <b>${esc(res.strait.name)}</b> توسط کشور <b>${esc(res.strait.ownerCountryName)}</b> را تصویب کرد!`,
          `🎯 هدف انسداد: <b>${esc(res.strait.blockade.targetName)}</b>`,
          `⚡ طبق قطعنامه، ۴۰٪ از درآمد کشور هدف به عنوان خراج دریایی کسر می‌گردد.`,
        ].join('\n')
      : [
          '🕊 <b>شورای امنیت سازمان ملل قطعنامه مسدودسازی را وتو کرد!</b>',
          '– – – – – – – – – –',
          `درخواست انسداد آبراهه <b>${esc(res.strait.name)}</b> به دلیل مغایرت با اصول دریانوردی آزاد بین‌المللی رد و وتو گردید.`,
        ].join('\n');

    await notifications.publishToChannel(ctx.telegram, 'announcement', channelText).catch(() => {});
  } catch (err) {
    await ctx.answerCbQuery(err.message, { show_alert: true });
  }
});

// =============================================================
// بخش فرمانده کل و هیئت دولت (۳ وزیر تخصصی با تایید کاندیدا)
// =============================================================
const ministerService = require('../services/ministerService');
const militaryBaseService = require('../services/militaryBaseService');

composer.action(['emp:commander', 'emp:minister'], async (ctx) => {
  await ctx.answerCbQuery().catch(() => {});
  const data = await requireCountry(ctx);
  if (!data) return;
  const { own, season, isLeader, roleTitle } = data;

  const state = await gameService.getCountryState(own.countryId, season.id);
  const flag = countryService.getDynamicFlag(own.country, state);
  const ministers = await ministerService.getMinistersForCountry(own.countryId, season.id);

  const lines = [
    `🎖️ <b>فرماندهی کل قوا و هیئت دولت — ${esc(own.country.name)} ${flag}</b>`,
    '– – – – – – – – – –',
    `👑 رهبر و رئیس کشور: <b>${esc(own.leaderName || 'رهبر منتخب')}</b>`,
    ctx.state.isMinister ? `🎖️ سمت شما: <b>${esc(roleTitle || 'عضو هیئت دولت')}</b>` : '',
    '',
    '🏛️ <b>اعضای هیئت وزیران و مسئولیت‌ها:</b>',
    '',
    `⚔️ <b>۱. وزیر جنگ و نیروهای مسلح:</b>`,
    ministers.war ? `   👤 جناب <b>${esc(ministers.war.name)}</b> (<code>${ministers.war.telegramId}</code>)` : '   <i>⛔ بدون متصدی</i>',
    '   📋 <i>اختیارات: حمله، اعلان جنگ و سایبری (مشروط به تایید رهبر)</i>',
    '',
    `💰 <b>۲. وزیر اقتصاد و توسعه:</b>`,
    ministers.economy ? `   👤 جناب <b>${esc(ministers.economy.name)}</b> (<code>${ministers.economy.telegramId}</code>)` : '   <i>⛔ بدون متصدی</i>',
    '   📋 <i>اختیارات: احداث دکل، مگاپروژه‌ها، ساخت‌وساز و درآمدهای ملی</i>',
    '',
    `🎖️ <b>۳. وزیر کل و معاونت عالی:</b>`,
    ministers.prime ? `   👤 جناب <b>${esc(ministers.prime.name)}</b> (<code>${ministers.prime.telegramId}</code>)` : '   <i>⛔ بدون متصدی</i>',
    '   📋 <i>اختیارات: کلیه امور اجرایی و کشورداری با نظارت رهبر</i>',
    '',
    '🛡️ <i>هر وزیر منصوب، +۱۰٪ به پایداری دفاعی و مقاومت ملی کشور می‌افزاید.</i>',
  ];

  const rows = [];
  if (isLeader) {
    rows.push([
      ministers.war ? cb('❌ عزل وزیر جنگ', 'emp:min:dismiss:war', 'danger') : cb('➕ انتصاب وزیر جنگ', 'emp:min:list:war:0', 'success'),
      ministers.economy ? cb('❌ عزل وزیر اقتصاد', 'emp:min:dismiss:economy', 'danger') : cb('➕ انتصاب وزیر اقتصاد', 'emp:min:list:economy:0', 'success'),
    ]);
    rows.push([
      ministers.prime ? cb('❌ عزل وزیر کل', 'emp:min:dismiss:prime', 'danger') : cb('➕ انتصاب وزیر کل', 'emp:min:list:prime:0', 'success'),
    ]);
  } else {
    lines.push('', 'ℹ️ <i>مدیریت و صدور احکام وزرا تنها در صلاحیت رهبر کشور است.</i>');
  }

  rows.push([cb('🔙 بازگشت به امپراطوری', 'menu:empire', 'primary')]);

  await ctx.editMessageText(lines.filter(Boolean).join('\n'), {
    parse_mode: 'HTML',
    reply_markup: { inline_keyboard: rows },
  }).catch(() => {});
});

// فهرست شهروندان بدون کشور برای ارسال پیشنهاد وزارت
composer.action(/^emp:min:list:([a-z_]+)(?::(\d+))?$/, async (ctx) => {
  await ctx.answerCbQuery().catch(() => {});
  const data = await requireCountry(ctx);
  if (!data) return;
  const { own, season, isLeader } = data;
  if (!isLeader) {
    return ctx.answerCbQuery('تنها رهبر کشور می‌تواند وزیر جدید منصوب کند.', { show_alert: true });
  }

  const role = ctx.match[1];
  const roleConfig = ministerService.ROLES[role];
  if (!roleConfig) return;

  const page = Number(ctx.match[2] || 0);
  const PAGE_SIZE = 6;

  const { listActive } = require('../services/ownershipService');
  const activeOwnerships = await listActive(season.id).catch(() => []);
  const ownedUserIds = new Set(activeOwnerships.map((o) => Number(o.userId)));
  ownedUserIds.add(Number(ctx.state.user.telegramId));

  const { docs } = require('../db/firestore');
  const usersSnap = await col('users').limit(100).get();
  const allUsers = docs(usersSnap) || [];

  const candidates = allUsers.filter((u) => {
    const tid = Number(u.telegramId || u.id);
    return tid && !ownedUserIds.has(tid);
  });

  const totalPages = Math.max(1, Math.ceil(candidates.length / PAGE_SIZE));
  const currentPage = Math.min(Math.max(0, page), totalPages - 1);
  const pagedCandidates = candidates.slice(currentPage * PAGE_SIZE, (currentPage + 1) * PAGE_SIZE);

  const lines = [
    `👥 <b>انتخاب کاندیدا برای مقام: ${roleConfig.title}</b>`,
    `📄 صفحه ${fmtNum(currentPage + 1)} از ${fmtNum(totalPages)}`,
    '– – – – – – – – – –',
    '⚠️ <i>پس از انتخاب، دعوت‌نامه رسمی به پیوی شخص ارسال می‌شود و پس از تایید ایشان حکم صادر خواهد شد.</i>',
    '',
  ];

  const rows = [];
  if (pagedCandidates.length === 0) {
    lines.push('😕 در حال حاضر شهروند آنلاینی بدون کشور برای انتصاب یافت نشد.');
  } else {
    for (const cand of pagedCandidates) {
      const cName = cand.displayName || cand.firstName || `کاربر ${cand.telegramId}`;
      rows.push([
        cb(`🎖️ دعوت ${cName} (${cand.telegramId})`, `emp:min:inv:${role}:${cand.telegramId}`, 'success'),
      ]);
    }
  }

  const nav = [];
  if (currentPage > 0) nav.push(cb('◀️ قبلی', `emp:min:list:${role}:${currentPage - 1}`));
  if (currentPage < totalPages - 1) nav.push(cb('بعدی ▶️', `emp:min:list:${role}:${currentPage + 1}`));
  if (nav.length) rows.push(nav);

  rows.push([cb('🔙 بازگشت به هیئت دولت', 'emp:commander', 'primary')]);

  await ctx.editMessageText(lines.join('\n'), {
    parse_mode: 'HTML',
    reply_markup: { inline_keyboard: rows },
  }).catch(() => {});
});

// ارسال دعوت‌نامه رسمی انتصاب وزیر به پیوی کاربر
composer.action(/^emp:min:inv:([a-z_]+):(\d+)$/, async (ctx) => {
  await ctx.answerCbQuery().catch(() => {});
  const data = await requireCountry(ctx);
  if (!data) return;
  const { own, season, isLeader } = data;
  if (!isLeader) return ctx.answerCbQuery('فقط رهبر کشور مجاز است.', { show_alert: true });

  const role = ctx.match[1];
  const targetId = Number(ctx.match[2]);

  try {
    const targetUserSnap = await col('users').doc(String(targetId)).get();
    const targetUser = targetUserSnap.exists ? targetUserSnap.data() : null;
    const targetName = targetUser?.displayName || targetUser?.firstName || `فرمانده ${targetId}`;

    await ministerService.sendMinisterInvitation({
      countryId: own.countryId,
      seasonId: season.id,
      leaderId: ctx.state.user.telegramId,
      leaderName: ctx.state.user.displayName,
      candidateId: targetId,
      candidateName: targetName,
      role,
      telegram: ctx.telegram,
    });

    await ctx.answerCbQuery(`📨 پیشنهاد انتصاب برای ${targetName} ارسال شد و پس از تایید فعال می‌شود.`, { show_alert: true });
    await ctx.editMessageText([
      '📨 <b>پیشنهاد رسمی انتصاب در هیئت دولت صادر شد!</b>',
      '– – – – – – – – – –',
      `🌍 کشور: <b>${own.country.flag} ${esc(own.country.name)}</b>`,
      `🎖️ سمت پیشنهادی: <b>${ministerService.ROLES[role]?.title}</b>`,
      `👤 کاندیدای منتخب: <b>${esc(targetName)}</b> (<code>${targetId}</code>)`,
      '',
      '📩 <i>پیام دعوت همراه با کلیدهای تایید و رد برای کاربر ارسال گردید. به محض تایید ایشان، حکم رسماً فعال خواهد شد.</i>',
    ].join('\n'), {
      parse_mode: 'HTML',
      reply_markup: {
        inline_keyboard: [
          [cb('🎖️ مشاهده هیئت دولت', 'emp:commander', 'primary')],
          [cb('👑 امپراطوری من', 'menu:empire', 'success')],
        ],
      },
    }).catch(() => {});
  } catch (err) {
    await ctx.answerCbQuery(err.message, { show_alert: true });
  }
});

// قبول پیشنهاد انتصاب توسط کاربر دعوت‌شده
composer.action(/^min:acc:(.+)$/, async (ctx) => {
  await ctx.answerCbQuery().catch(() => {});
  const invId = ctx.match[1];
  try {
    const res = await ministerService.acceptMinisterInvitation({
      invitationId: invId,
      candidateUserId: ctx.from.id,
      telegram: ctx.telegram,
    });
    await ctx.editMessageText([
      '🎉 <b>تبریک! شما وارد هیئت دولت شدید!</b>',
      '– – – – – – – – – –',
      `🌍 کشور: <b>${res.invitation.countryFlag} ${esc(res.invitation.countryName)}</b>`,
      `🎖️ سمت رسمی شما: <b>${res.invitation.roleTitle}</b>`,
      '',
      'اکنون می‌توانید از طریق منوی «👑 امپراطوری من» به اداره امور کشور بپردازید.',
    ].join('\n'), {
      parse_mode: 'HTML',
      reply_markup: {
        inline_keyboard: [
          [cb('👑 ورود به امپراطوری من', 'menu:empire', 'success')],
        ],
      },
    }).catch(() => {});
  } catch (err) {
    await ctx.answerCbQuery(err.message, { show_alert: true });
  }
});

// رد پیشنهاد انتصاب توسط کاربر دعوت‌شده
composer.action(/^min:rej:(.+)$/, async (ctx) => {
  await ctx.answerCbQuery().catch(() => {});
  const invId = ctx.match[1];
  try {
    await ministerService.rejectMinisterInvitation({
      invitationId: invId,
      candidateUserId: ctx.from.id,
      telegram: ctx.telegram,
    });
    await ctx.editMessageText('❌ شما پیشنهاد تصدی این مقام را رد کردید.', {
      parse_mode: 'HTML',
    }).catch(() => {});
  } catch (err) {
    await ctx.answerCbQuery(err.message, { show_alert: true });
  }
});

// عزل وزیر توسط رهبر
composer.action(/^emp:min:dismiss:([a-z_]+)$/, async (ctx) => {
  await ctx.answerCbQuery().catch(() => {});
  const data = await requireCountry(ctx);
  if (!data) return;
  const { own, season, isLeader } = data;
  if (!isLeader) return ctx.answerCbQuery('تنها رهبر مجاز به عزل وزیر است.', { show_alert: true });

  const role = ctx.match[1];
  try {
    await ministerService.dismissMinister({
      countryId: own.countryId,
      seasonId: season.id,
      role,
      leaderUserId: ctx.state.user.telegramId,
      telegram: ctx.telegram,
    });
    await ctx.answerCbQuery('وزیر با موفقیت برکنار شد.', { show_alert: true });
    // بازسازی نمای هیئت دولت
    const state = await gameService.getCountryState(own.countryId, season.id);
    const flag = countryService.getDynamicFlag(own.country, state);
    const ministers = await ministerService.getMinistersForCountry(own.countryId, season.id);
    await ctx.editMessageText('✅ <b>حکم برکناری صادر گردید.</b>\nاکنون می‌توانید شخص دیگری را به عنوان وزیر منصوب فرمایید.', {
      parse_mode: 'HTML',
      reply_markup: {
        inline_keyboard: [
          [cb('🎖️ بازگشت به هیئت دولت', 'emp:commander', 'primary')],
          [cb('👑 امپراطوری من', 'menu:empire', 'success')],
        ],
      },
    }).catch(() => {});
  } catch (err) {
    await ctx.answerCbQuery(err.message, { show_alert: true });
  }
});

// =============================================================
// تایید و رد پیشنهادات عملیات نظامی وزیر جنگ توسط رهبر کشور
// =============================================================
composer.action(/^prop:appr:(.+)$/, async (ctx) => {
  await ctx.answerCbQuery().catch(() => {});
  const propId = ctx.match[1];
  const propRef = col('minister_proposals').doc(propId);
  const snapDoc = await propRef.get();
  if (!snapDoc.exists) return ctx.answerCbQuery('پیشنهاد عملیات یافت نشد.', { show_alert: true });
  const p = snapDoc.data();
  if (p.status !== 'pending') return ctx.answerCbQuery('این عملیات قبلاً بررسی شده است.', { show_alert: true });

  const data = await requireCountry(ctx);
  if (!data || !data.isLeader) return ctx.answerCbQuery('تنها رهبر کشور مجاز به صدور فرمان نهایی عملیات است.', { show_alert: true });

  await propRef.update({ status: 'approved', approvedAt: new Date().toISOString() });

  // اجرای عملیات متناسب با نوع آن
  if (p.type === 'attack') {
    try {
      await warService.startBattle({
        seasonId: p.seasonId,
        attackerCountryId: p.countryId,
        attackerUserId: ctx.from.id,
        defenderCountryId: p.targetCountryId,
        defenderUserId: p.payload?.defenderUserId || null,
        attackType: p.payload?.attackType || 'conquest',
        selectedUnits: p.payload?.selectedUnits || [],
      });
      await ctx.reply(`💥 <b>فرمان حمله تایید و ابلاغ شد!</b>\nارتش کشور جهت اجرای عملیات علیه ${p.targetCountryFlag} ${p.targetCountryName} به حرکت درآمد.`);
    } catch (err) {
      return ctx.reply(`❌ خطا در اجرای حمله: ${err.message}`);
    }
  } else if (p.type === 'war_declare') {
    await warService.declareWar({
      seasonId: p.seasonId,
      attackerCountryId: p.countryId,
      targetCountryId: p.targetCountryId,
      userId: ctx.from.id,
      note: p.payload?.note || 'اعلان جنگ رسمی با پیشنهاد وزیر جنگ و تایید رهبر',
      telegram: ctx.telegram,
    }).catch(() => {});
    await ctx.reply(`🚨 <b>اعلان جنگ رسمی به کشور ${p.targetCountryFlag} ${p.targetCountryName} ابلاغ گردید!</b>`);
  } else if (p.type === 'cyber') {
    // حمله سایبری
    await ctx.reply(`💻 <b>عملیات سایبری تایید و زیرساخت‌های کشور ${p.targetCountryFlag} ${p.targetCountryName} مورد نفوذ قرار گرفت!</b>`);
  }

  // اطلاع به وزیر جنگ
  if (p.ministerId) {
    await notifications.safeSend(
      ctx.telegram,
      p.ministerId,
      `✅ <b>فرمان عملیات صادر شد:</b> رهبر کشور با پیشنهاد عملیات شما علیه ${p.targetCountryFlag} ${p.targetCountryName} موافقت نمود و نیروها اعزام شدند.`
    ).catch(() => {});
  }

  await ctx.editMessageText('✅ <b>فرمان عملیات نظامی با تایید شما صادر و به ارتش ابلاغ شد.</b>', { parse_mode: 'HTML' }).catch(() => {});
});

composer.action(/^prop:rejc:(.+)$/, async (ctx) => {
  await ctx.answerCbQuery().catch(() => {});
  const propId = ctx.match[1];
  const propRef = col('minister_proposals').doc(propId);
  const snapDoc = await propRef.get();
  if (!snapDoc.exists) return;
  const p = snapDoc.data();
  if (p.status !== 'pending') return;

  const data = await requireCountry(ctx);
  if (!data || !data.isLeader) return ctx.answerCbQuery('تنها رهبر کشور مجاز است.', { show_alert: true });

  await propRef.update({ status: 'rejected', rejectedAt: new Date().toISOString() });

  if (p.ministerId) {
    await notifications.safeSend(
      ctx.telegram,
      p.ministerId,
      `❌ <b>رد پیشنهاد عملیات:</b> رهبر کشور با پیشنهاد عملیات نظامی علیه ${p.targetCountryFlag} ${p.targetCountryName} مخالفت نمود.`
    ).catch(() => {});
  }

  await ctx.editMessageText('❌ این عملیات نظامی توسط شما رد شد و نیروها در حالت آماده‌باش دفاعی باقی ماندند.', { parse_mode: 'HTML' }).catch(() => {});
});

// =============================================================
// بخش اختصاصی پایگاه‌های نظامی فرامرزی و تسلیحات مستقر
// =============================================================
composer.action(['emp:base', 'emp:military_base'], async (ctx) => {
  await ctx.answerCbQuery().catch(() => {});
  const data = await requireCountry(ctx);
  if (!data) return;
  const { own, season, isLeader } = data;

  const bases = await militaryBaseService.listCountryBases(own.countryId, season.id);
  const state = await gameService.getCountryState(own.countryId, season.id);
  const flag = countryService.getDynamicFlag(own.country, state);

  const lines = [
    `🪖 <b>ستاد فرماندهی پایگاه‌های نظامی فرامرزی — ${esc(own.country.name)} ${flag}</b>`,
    '– – – – – – – – – –',
    `💵 موجودی خزانه ملی: <b>${fmtNum(state.treasury || 0)}$</b>`,
    `🏗️ هزینه احداث هر پایگاه خارجی: <b>${fmtNum(militaryBaseService.BASE_BUILD_COST)}$</b>`,
    `💰 حق استقرار پرداختی به کشور میزبان: <b>${fmtNum(militaryBaseService.HOST_GRANT)}$</b>`,
    '',
    '🚩 <b>پایگاه‌های فعال شما در سایر کشورها:</b>',
  ];

  if (bases.ownedActive.length === 0) {
    lines.push('<i>هیچ پایگاه نظامی فعالی در کشورهای دیگر ندارید.</i>');
  } else {
    for (const b of bases.ownedActive) {
      const u = b.deployedUnits || {};
      lines.push(
        `• پایگاه مستقر در <b>${b.hostCountryFlag} ${esc(b.hostCountryName)}</b>:`,
        `  🪖 تسلیحات مستقر: ${fmtNum(u.tanks || 0)} تانک | ${fmtNum(u.fighters || 0)} جنگنده | ${fmtNum(u.soldiers || 0)} نیرو`,
        '  ⚡ <b>امتیاز راهبردی:</b> ۵۰٪ سرعت بیشتر در حمله به همسایگان این کشور'
      );
    }
  }

  lines.push('', '🏰 <b>پایگاه‌های نظامی سایر کشورها مستقر در خاک شما:</b>');
  if (bases.hostedActive.length === 0) {
    lines.push('<i>هیچ کشوری در خاک شما پایگاه نظامی ندارد.</i>');
  } else {
    for (const b of bases.hostedActive) {
      lines.push(`• پایگاه متعلق به <b>${b.ownerCountryFlag} ${esc(b.ownerCountryName)}</b> (فعال ✅)`);
    }
  }

  if (bases.ownedPending.length > 0) {
    lines.push('', `⏳ <b>درخواست‌های در انتظار تایید شما:</b> ${fmtNum(bases.ownedPending.length)} پایگاه`);
  }
  if (bases.hostedPending.length > 0) {
    lines.push('', `📥 <b>درخواست‌های دریافتی برای احداث در خاک شما:</b> ${fmtNum(bases.hostedPending.length)} تقاضا`);
  }

  const rows = [];
  if (isLeader) {
    rows.push([cb('➕ احداث پایگاه در کشور دیگر (۲۰۰M $)', 'base:new:0', 'success')]);
    if (bases.ownedActive.length > 0) {
      rows.push([cb('📦 ارسال و استقرار تسلیحات به پایگاه', 'base:deploy:list', 'primary')]);
    }
    if (bases.hostedPending.length > 0) {
      rows.push([cb(`📥 بررسی درخواست‌های میزبانی (${fmtNum(bases.hostedPending.length)})`, 'base:incoming:0', 'danger')]);
    }
  } else {
    lines.push('', 'ℹ️ <i>احداث و مدیریت پایگاه‌های فرامرزی در صلاحیت رهبر کشور است.</i>');
  }

  rows.push([cb('🔙 بازگشت به امپراطوری', 'menu:empire', 'primary')]);

  await ctx.editMessageText(lines.join('\n'), {
    parse_mode: 'HTML',
    reply_markup: { inline_keyboard: rows },
  }).catch(() => {});
});

// فهرست کشورها برای احداث پایگاه جدید
composer.action(/^base:new(?::(\d+))?$/, async (ctx) => {
  await ctx.answerCbQuery().catch(() => {});
  const data = await requireCountry(ctx);
  if (!data) return;
  const { own, season, isLeader } = data;
  if (!isLeader) return ctx.answerCbQuery('تنها رهبر مجاز است.', { show_alert: true });

  const page = Number(ctx.match[1] || 0);
  const PAGE_SIZE = 6;
  const allCountries = (await countryService.list()).filter((c) => String(c.id) !== String(own.countryId));

  const totalPages = Math.max(1, Math.ceil(allCountries.length / PAGE_SIZE));
  const currentPage = Math.min(Math.max(0, page), totalPages - 1);
  const paged = allCountries.slice(currentPage * PAGE_SIZE, (currentPage + 1) * PAGE_SIZE);

  const lines = [
    '🌍 <b>انتخاب کشور مقصد جهت احداث پایگاه نظامی فرامرزی</b>',
    `📄 صفحه ${fmtNum(currentPage + 1)} از ${fmtNum(totalPages)}`,
    '– – – – – – – – – –',
    `💵 هزینه احداث: <b>${fmtNum(militaryBaseService.BASE_BUILD_COST)}$</b>`,
    '⚠️ <i>پس از ارسال، درخواست برای رهبر کشور مقصد ارسال شده و در صورت تایید پایگاه احداث می‌گردد.</i>',
    '',
  ];

  const rows = [];
  for (const c of paged) {
    rows.push([cb(`🪖 احداث پایگاه در ${c.flag || '🏳️'} ${c.name}`, `base:req:${c.id}`, 'primary')]);
  }

  const nav = [];
  if (currentPage > 0) nav.push(cb('◀️ قبلی', `base:new:${currentPage - 1}`));
  if (currentPage < totalPages - 1) nav.push(cb('بعدی ▶️', `base:new:${currentPage + 1}`));
  if (nav.length) rows.push(nav);

  rows.push([cb('🔙 بازگشت به ستاد پایگاه‌ها', 'emp:base', 'primary')]);

  await ctx.editMessageText(lines.join('\n'), {
    parse_mode: 'HTML',
    reply_markup: { inline_keyboard: rows },
  }).catch(() => {});
});

// ارسال درخواست رسمی احداث پایگاه
composer.action(/^base:req:(.+)$/, async (ctx) => {
  await ctx.answerCbQuery().catch(() => {});
  const data = await requireCountry(ctx);
  if (!data) return;
  const { own, season, isLeader } = data;
  if (!isLeader) return;

  const hostCountryId = ctx.match[1];
  try {
    const res = await militaryBaseService.requestMilitaryBase({
      ownerCountryId: own.countryId,
      hostCountryId,
      seasonId: season.id,
      ownerUserId: ctx.state.user.telegramId,
      telegram: ctx.telegram,
    });

    await ctx.answerCbQuery(`درخواست احداث پایگاه برای رهبر کشور مقصد ارسال شد.`, { show_alert: true });
    await ctx.editMessageText([
      '🪖 <b>درخواست احداث پایگاه نظامی ارسال شد!</b>',
      '– – – – – – – – – –',
      `🌍 کشور میزبان: <b>${res.hostCountryFlag} ${esc(res.hostCountryName)}</b>`,
      `💵 مبلغ ${fmtNum(militaryBaseService.BASE_BUILD_COST)}$ از خزانه کسر گردید.`,
      '📩 <i>پیام رسمی برای رهبر آن کشور ارسال شد و در صورت تایید، پایگاه فعال خواهد شد. (در صورت رد درخواست، مبلغ به خزانه عودت داده می‌شود).</i>',
    ].join('\n'), {
      parse_mode: 'HTML',
      reply_markup: {
        inline_keyboard: [
          [cb('🪖 بازگشت به پایگاه‌ها', 'emp:base', 'primary')],
          [cb('👑 امپراطوری من', 'menu:empire', 'success')],
        ],
      },
    }).catch(() => {});
  } catch (err) {
    await ctx.answerCbQuery(err.message, { show_alert: true });
  }
});

// تایید و رد درخواست احداث پایگاه توسط کشور میزبان
composer.action(/^base:appr:(.+)$/, async (ctx) => {
  await ctx.answerCbQuery().catch(() => {});
  const baseId = ctx.match[1];
  try {
    await militaryBaseService.approveMilitaryBase({
      baseId,
      hostUserId: ctx.from.id,
      telegram: ctx.telegram,
    });
    await ctx.answerCbQuery('احداث پایگاه با موفقیت تایید شد و ۵۰M $ به خزانه واریز گردید!', { show_alert: true });
    await ctx.editMessageText('✅ <b>پایگاه نظامی با موافقت شما در خاک کشورتان مستقر گردید.</b>\nمبلغ ۵۰,۰۰۰,۰۰۰ $ به عنوان حق استقرار به خزانه ملی شما واریز شد.', {
      parse_mode: 'HTML',
      reply_markup: { inline_keyboard: [[cb('🪖 مشاهده پایگاه‌ها', 'emp:base', 'primary')]] },
    }).catch(() => {});
  } catch (err) {
    await ctx.answerCbQuery(err.message, { show_alert: true });
  }
});

composer.action(/^base:rejc:(.+)$/, async (ctx) => {
  await ctx.answerCbQuery().catch(() => {});
  const baseId = ctx.match[1];
  try {
    await militaryBaseService.rejectMilitaryBase({
      baseId,
      hostUserId: ctx.from.id,
      telegram: ctx.telegram,
    });
    await ctx.answerCbQuery('درخواست احداث پایگاه رد شد.', { show_alert: true });
    await ctx.editMessageText('❌ درخواست احداث پایگاه رد گردید و هزینه به کشور متقاضی بازگشت داده شد.', { parse_mode: 'HTML' }).catch(() => {});
  } catch (err) {
    await ctx.answerCbQuery(err.message, { show_alert: true });
  }
});

// درخواست‌های ورودی احداث پایگاه در کشور میزبان
composer.action(/^base:incoming(?::(\d+))?$/, async (ctx) => {
  await ctx.answerCbQuery().catch(() => {});
  const data = await requireCountry(ctx);
  if (!data) return;
  const { own, season, isLeader } = data;
  if (!isLeader) return;

  const bases = await militaryBaseService.listCountryBases(own.countryId, season.id);
  const pending = bases.hostedPending;

  const lines = [
    '📥 <b>درخواست‌های ورودی جهت احداث پایگاه نظامی در خاک شما</b>',
    '– – – – – – – – – –',
  ];

  const rows = [];
  if (pending.length === 0) {
    lines.push('<i>هیچ درخواست جدیدی وجود ندارد.</i>');
  } else {
    for (const b of pending) {
      lines.push(`• کشور <b>${b.ownerCountryFlag} ${esc(b.ownerCountryName)}</b> تقاضای احداث پایگاه دارد (۵۰M $ پاداش میزبانی)`);
      rows.push([
        cb(`✅ موافقت با ${b.ownerCountryName}`, `base:appr:${b.id}`, 'success'),
        cb(`❌ رد ${b.ownerCountryName}`, `base:rejc:${b.id}`, 'danger'),
      ]);
    }
  }

  rows.push([cb('🔙 بازگشت به پایگاه‌ها', 'emp:base', 'primary')]);

  await ctx.editMessageText(lines.join('\n'), {
    parse_mode: 'HTML',
    reply_markup: { inline_keyboard: rows },
  }).catch(() => {});
});

// انتقال تسلیحات به پایگاه نظامی
composer.action('base:deploy:list', async (ctx) => {
  await ctx.answerCbQuery().catch(() => {});
  const data = await requireCountry(ctx);
  if (!data) return;
  const { own, season, isLeader } = data;
  if (!isLeader) return;

  const bases = await militaryBaseService.listCountryBases(own.countryId, season.id);
  const activeBases = bases.ownedActive;

  if (activeBases.length === 0) {
    return ctx.answerCbQuery('شما پایگاه فعالی ندارید.', { show_alert: true });
  }

  const lines = [
    '📦 <b>انتخاب پایگاه مقصد جهت انتقال و استقرار تسلیحات:</b>',
    '– – – – – – – – – –',
  ];

  const rows = [];
  for (const b of activeBases) {
    rows.push([cb(`🏰 پایگاه مستقر در ${b.hostCountryFlag} ${b.hostCountryName}`, `base:dep:action:${b.id}`, 'primary')]);
  }
  rows.push([cb('🔙 بازگشت به پایگاه‌ها', 'emp:base', 'danger')]);

  await ctx.editMessageText(lines.join('\n'), {
    parse_mode: 'HTML',
    reply_markup: { inline_keyboard: rows },
  }).catch(() => {});
});

composer.action(/^base:dep:action:(.+)$/, async (ctx) => {
  await ctx.answerCbQuery().catch(() => {});
  const baseId = ctx.match[1];
  const data = await requireCountry(ctx);
  if (!data) return;
  const { own, season } = data;

  const state = await gameService.getCountryState(own.countryId, season.id);
  const mil = state.military || {};

  // انتقال سریع یک اسکادران تانک و نیرو به پایگاه
  const tanksToSend = Math.min(Number(mil.tanks || 0), 10);
  const fightersToSend = Math.min(Number(mil.fighters || 0), 5);
  const soldiersToSend = Math.min(Number(mil.soldiers || 0), 500);

  if (tanksToSend === 0 && fightersToSend === 0 && soldiersToSend === 0) {
    return ctx.answerCbQuery('موجودی تسلیحات در خاک اصلی برای اعزام کافی نیست.', { show_alert: true });
  }

  try {
    await militaryBaseService.deployWeaponsToBase({
      baseId,
      ownerCountryId: own.countryId,
      seasonId: season.id,
      units: {
        tanks: tanksToSend,
        fighters: fightersToSend,
        soldiers: soldiersToSend,
      },
    });

    await ctx.answerCbQuery(`تجهیزات با موفقیت به پایگاه فرامرزی اعزام شدند!`, { show_alert: true });
    await ctx.editMessageText([
      '✅ <b>تسلیحات با موفقیت به پایگاه اعزام و مستقر شدند!</b>',
      '– – – – – – – – – –',
      `🛡️ یگان‌های منتقل‌شده:`,
      `• تانک‌های سنگین: <b>${fmtNum(tanksToSend)}</b> عراده`,
      `• جنگنده‌ها: <b>${fmtNum(fightersToSend)}</b> فروند`,
      `• رزمندگان پیاده: <b>${fmtNum(soldiersToSend)}</b> نیرو`,
      '',
      '⚡ اکنون در صورت تهاجم به همسایگان این پایگاه، از ۵۰٪ سرعت رسیدن قوا بهره‌مند می‌شوید.',
    ].join('\n'), {
      parse_mode: 'HTML',
      reply_markup: {
        inline_keyboard: [
          [cb('🪖 بازگشت به پایگاه‌ها', 'emp:base', 'primary')],
        ],
      },
    }).catch(() => {});
  } catch (err) {
    await ctx.answerCbQuery(err.message, { show_alert: true });
  }
});

// =============================================================
// بخش اختصاصی ارتش سایبری و عملیات نفوذ
// =============================================================
composer.action(['emp:cyber', 'emp:cyber_attack'], async (ctx) => {
  await ctx.answerCbQuery().catch(() => {});
  const data = await requireCountry(ctx);
  if (!data) return;
  const { own, season, isLeader, role } = data;

  if (ctx.state.isMinister && role === 'economy') {
    return ctx.answerCbQuery('⛔ عدم دسترسی: به عنوان وزیر اقتصاد، اختیارات شما منحصر به امور مالی، احداث دکل‌ها و پروژه‌هاست.', { show_alert: true });
  }

  const state = await gameService.getCountryState(own.countryId, season.id);
  const flag = countryService.getDynamicFlag(own.country, state);

  const lines = [
    `💻 <b>فرماندهی ارتش سایبری و جنگ الکترونیک — ${esc(own.country.name)} ${flag}</b>`,
    '– – – – – – – – – –',
    `⚡ توان سایبری ملی: <b>${fmtNum(state.military?.cyber || 33)}</b>`,
    `📡 زیرساخت‌های شبکه‌ای: <b>پایدار و رمزنگاری‌شده ✅</b>`,
    '',
    '🎯 <b>اهداف عملیات سایبری:</b>',
    '• اختلال در استخراج نفت و ژنراتورهای برق کشور هدف به مدت ۳۰ دقیقه',
    '• سلب موقت دفاع خودکار پدافندی دشمن',
    '',
    ctx.state.isMinister && role === 'war' ? '⚠️ <i>شما به عنوان وزیر جنگ می‌توانید عملیات سایبری پیشنهاد دهید که پس از تایید رهبر کشور اجرا می‌شود.</i>' : '',
  ];

  const rows = [
    [cb('⚡ اجرای نفوذ سایبری به کشور دیگر', 'cyber:target:0', 'danger')],
    [cb('🔙 بازگشت به امپراطوری', 'menu:empire', 'primary')],
  ];

  await ctx.editMessageText(lines.filter(Boolean).join('\n'), {
    parse_mode: 'HTML',
    reply_markup: { inline_keyboard: rows },
  }).catch(() => {});
});

composer.action(/^cyber:target(?::(\d+))?$/, async (ctx) => {
  await ctx.answerCbQuery().catch(() => {});
  const data = await requireCountry(ctx);
  if (!data) return;
  const { own, season } = data;

  const page = Number(ctx.match[1] || 0);
  const PAGE_SIZE = 6;
  const allCountries = (await countryService.list()).filter((c) => String(c.id) !== String(own.countryId));

  const totalPages = Math.max(1, Math.ceil(allCountries.length / PAGE_SIZE));
  const currentPage = Math.min(Math.max(0, page), totalPages - 1);
  const paged = allCountries.slice(currentPage * PAGE_SIZE, (currentPage + 1) * PAGE_SIZE);

  const lines = [
    '🎯 <b>انتخاب کشور هدف برای حمله سایبری:</b>',
    `📄 صفحه ${fmtNum(currentPage + 1)} از ${fmtNum(totalPages)}`,
    '– – – – – – – – – –',
  ];

  const rows = [];
  for (const c of paged) {
    rows.push([cb(`💻 نفوذ به ${c.flag || '🏳️'} ${c.name}`, `cyber:exec:${c.id}`, 'danger')]);
  }

  const nav = [];
  if (currentPage > 0) nav.push(cb('◀️ قبلی', `cyber:target:${currentPage - 1}`));
  if (currentPage < totalPages - 1) nav.push(cb('بعدی ▶️', `cyber:target:${currentPage + 1}`));
  if (nav.length) rows.push(nav);

  rows.push([cb('🔙 بازگشت', 'emp:cyber', 'primary')]);

  await ctx.editMessageText(lines.join('\n'), {
    parse_mode: 'HTML',
    reply_markup: { inline_keyboard: rows },
  }).catch(() => {});
});

composer.action(/^cyber:exec:(.+)$/, async (ctx) => {
  await ctx.answerCbQuery().catch(() => {});
  const targetId = ctx.match[1];
  const data = await requireCountry(ctx);
  if (!data) return;
  const { own, season, isLeader, role } = data;

  const target = await countryService.get(targetId);
  if (!target) return;

  // اگر وزیر جنگ بود، نیاز به تایید رهبر کشور دارد
  if (ctx.state.isMinister && role === 'war') {
    try {
      await ministerService.createMinisterWarProposal({
        type: 'cyber',
        countryId: own.countryId,
        seasonId: season.id,
        ministerId: ctx.from.id,
        ministerName: ctx.state.user.displayName,
        targetCountryId: targetId,
        targetCountryName: target.name,
        payload: {},
        telegram: ctx.telegram,
      });

      await ctx.answerCbQuery('پیشنهاد حمله سایبری برای تایید رهبر کشور ارسال شد.', { show_alert: true });
      return ctx.editMessageText([
        '📨 <b>پیشنهاد حمله سایبری به رهبر کشور ارجاع شد!</b>',
        '– – – – – – – – – –',
        `کشور هدف: <b>${target.flag || '🏳️'} ${esc(target.name)}</b>`,
        'به عنوان وزیر جنگ، به محض تایید فرماندهی کل قوا (رهبر کشور)، ویروس سایبری تزریق خواهد شد.',
      ].join('\n'), {
        parse_mode: 'HTML',
        reply_markup: { inline_keyboard: [[cb('👑 امپراطوری من', 'menu:empire', 'primary')]] },
      }).catch(() => {});
    } catch (err) {
      return ctx.answerCbQuery(err.message, { show_alert: true });
    }
  }

  // رهبر مستقیم عملیات را اجرا می‌کند
  await ctx.editMessageText([
    '⚡ <b>حمله سایبری با موفقیت اجرا شد!</b>',
    '– – – – – – – – – –',
    `🌍 کشور هدف: <b>${target.flag || '🏳️'} ${esc(target.name)}</b>`,
    'بدافزارهای ارتش سایبری با موفقیت به سیستم‌های برق و سرورهای نفتی نفوذ کرده و تولید انرژی آن کشور را دچار اختلال موقت نمودند.',
  ].join('\n'), {
    parse_mode: 'HTML',
    reply_markup: {
      inline_keyboard: [
        [cb('💻 بازگشت به ارتش سایبری', 'emp:cyber', 'primary')],
        [cb('👑 امپراطوری من', 'menu:empire', 'success')],
      ],
    },
  }).catch(() => {});
});

// سایر دکمه‌های باقی‌مانده امپراطوری
const EMP_ACTIONS = [
  ['emp:dev', 'توسعه کشور ⚙️'],
  ['emp:drill', 'رزمایش 🪖'],
  ['emp:spy', 'جاسوسی 🕵️‍♂️'],
  ['emp:inflation', 'تورم 📉'],
  ['emp:factions', 'گروهک‌ها 🕶️'],
];

for (const [actionName, label] of EMP_ACTIONS) {
  composer.action(actionName, async (ctx) => {
    await ctx.answerCbQuery(`بخش «${label}» در فاز بعدی سیزن بازگشایی خواهد شد.`, { show_alert: true });
  });
  composer.hears(label, async (ctx) => {
    await ctx.reply(`⚙️ <b>بخش «${label}»</b>\nاین بخش در فازهای بعدی سیزن بازگشایی خواهد شد.`, { parse_mode: 'HTML' });
  });
}


// =============================================================
// بخش اختصاصی درخت غنی‌سازی هسته‌ای و مجمع عمومی سازمان ملل
// =============================================================
async function renderNuclearPanel(ctx, isEdit = false) {
  const data = await requireCountry(ctx);
  if (!data) return;
  const { season, own } = data;
  const state = await gameService.getCountryState(own.countryId, season.id);
  const flag = countryService.getDynamicFlag(own.country, state);

  const currentTier = Number(state.nuclearTier || 0);
  const licenses = state.nuclearLicenses || [];
  const tiers = gameService.NUCLEAR_TIERS;

  const rawUranium = Number(state.inventory?.uranium || 0);
  const enriched = state.enrichedUranium || {};
  const t20 = Number(enriched.tier20 || 0);
  const t40 = Number(enriched.tier40 || 0);
  const t60 = Number(enriched.tier60 || 0);
  const t100 = Number(enriched.tier100 || 0);

  const currentTierFa = currentTier > 0 ? `${currentTier}٪` : 'فاقد فناوری هسته‌ای (۰٪)';

  const lines = [
    `☢️ <b>درخت جامع غنی‌سازی هسته‌ای — ${esc(own.country.name)} ${flag}</b>`,
    '– – – – – – – – – –',
    `🔬 بالاترین سطح فناوری فعال: <b>${currentTierFa}</b>`,
    `💵 موجودی خزانه ملی: <b>${fmtNum(state.treasury || 0)}$</b>`,
    '– – – – – – – – – –',
    '📦 <b>انبار ذخایر اورانیوم و سوخت هسته‌ای کشور:</b>',
    `• 🪨 اورانیوم خام طبیعی: <b>${fmtNum(rawUranium)} کیلوگرم</b> (خرید از بازار جهانی)`,
    `• 🧪 اورانیوم غنی‌شده ۲۰٪ (پژوهشی/پزشکی): <b>${fmtNum(t20)} کیلوگرم</b>`,
    `• ⚡ اورانیوم غنی‌شده ۴۰٪ (سوخت نیروگاه برق): <b>${fmtNum(t40)} کیلوگرم</b>`,
    `• 🌊 اورانیوم غنی‌شده ۶۰٪ (پیشران زیردریایی اتمی): <b>${fmtNum(t60)} کیلوگرم</b>`,
    `• 💥 اورانیوم غنی‌شده ۱۰۰٪ (تسلیحات هسته‌ای و کلاهک): <b>${fmtNum(t100)} کیلوگرم</b>`,
    '– – – – – – – – – –',
    '<b>قوانین بین‌المللی برنامه هسته‌ای:</b>',
    '• ارتقا به هر مرحله <b>فقط با مجوز رسمی مجمع عمومی سازمان ملل</b> مجاز است.',
    '• کشور متقاضی ابتدا درخواست مجوز ثبت می‌کند و پرونده به مدت ۳۰ دقیقه به رأی عمومی گذاشته می‌شود.',
    '• پس از تصویب و اخذ مجوز، می‌توانید اورانیوم خام را به میزان دلخواه غنی‌سازی نمایید.',
    '',
    '📋 <b>مراحل چهارگانه درخت غنی‌سازی هسته‌ای:</b>',
  ];

  const buttons = [];
  let nextTierToUnlock = null;

  for (const t of tiers) {
    const isOwned = currentTier >= t.tier;
    const hasLicense = licenses.includes(t.tier);
    let statusText = '🔒 قفل (نیازمند مجوز)';
    if (isOwned) {
      statusText = '✅ فعال شده';
    } else if (hasLicense) {
      statusText = '📜 دارای مجوز سازمان ملل (آماده فعال‌سازی)';
    }

    lines.push(`• <b>${t.title}</b>\n   وضعیت: <b>${statusText}</b> | هزینه توسعه فناوری: <b>${fmtNum(t.cost)}$</b>\n   <i>${t.desc}</i>`);

    if (!isOwned && !nextTierToUnlock) {
      nextTierToUnlock = t;
    }
  }

  if (nextTierToUnlock) {
    const hasLicense = licenses.includes(nextTierToUnlock.tier);
    if (hasLicense) {
      buttons.push([Markup.button.callback(`⚡ فعال‌سازی فناوری غنی‌سازی ${nextTierToUnlock.percent} (${fmtNum(nextTierToUnlock.cost)}$)`, `nuc:upgrade:${nextTierToUnlock.tier}`)]);
    } else {
      buttons.push([Markup.button.callback(`📜 ثبت درخواست مجوز سازمان ملل برای غنی‌سازی ${nextTierToUnlock.percent}`, `nuc:req_un:${nextTierToUnlock.tier}`)]);
    }
  }

  // دکمه غنی‌سازی اورانیوم خام در صورت دارا بودن مجوز یا فناوری فعال
  if (currentTier >= 20 || licenses.length > 0) {
    buttons.push([Markup.button.callback('⚗️ غنی‌سازی اورانیوم خام (تعداد دلخواه)', 'nuc:enrich:menu')]);
  }

  buttons.push([Markup.button.callback('🛒 خرید اورانیوم خام از بازار جهانی', 'oil:gm:buy:uranium')]);
  buttons.push([Markup.button.callback('🇺🇳 مجمع عمومی سازمان ملل و رأی‌گیری‌های زنده', 'emp:un:votes')]);
  buttons.push([Markup.button.callback('🔙 بازگشت به امپراطوری', 'emp:home'), Markup.button.callback('🔙 منوی اصلی', 'menu:home')]);

  const text = lines.join('\n');
  const kb = Markup.inlineKeyboard(buttons);

  if (isEdit && ctx.callbackQuery) {
    await ctx.editMessageText(text, { parse_mode: 'HTML', reply_markup: kb.reply_markup }).catch(() => {});
  } else {
    await ctx.reply(text, { parse_mode: 'HTML', ...kb });
  }
}

composer.action('emp:nuclear', async (ctx) => {
  await ctx.answerCbQuery().catch(() => {});
  await renderNuclearPanel(ctx, true);
});
composer.hears(['برنامه هسته‌ای ☢️', 'هسته‌ای', '/nuclear'], async (ctx) => {
  await renderNuclearPanel(ctx, false);
});

// منوی انتخاب سطح غنی‌سازی اورانیوم خام
composer.action('nuc:enrich:menu', async (ctx) => {
  await ctx.answerCbQuery().catch(() => {});
  const data = await requireCountry(ctx);
  if (!data) return;
  const { season, own } = data;
  const state = await gameService.getCountryState(own.countryId, season.id);
  const currentTier = Number(state.nuclearTier || 0);
  const rawUranium = Number(state.inventory?.uranium || 0);

  if (currentTier < 20) {
    return ctx.reply('⚠️ کشور شما هنوز به هیچ مرحله‌ای از فناوری غنی‌سازی دست نیافته است. ابتدا مجوز سازمان ملل را دریافت و برنامه هسته‌ای را ارتقا دهید.', {
      ...Markup.inlineKeyboard([[Markup.button.callback('☢️ مشاهده برنامه هسته‌ای', 'emp:nuclear')]]),
    });
  }

  const text = [
    '⚗️ <b>اتاق سانتریفیوژ و غنی‌سازی اورانیوم خام</b>',
    '– – – – – – – – – –',
    `🪨 موجودی اورانیوم خام شما: <b>${fmtNum(rawUranium)} کیلوگرم</b>`,
    `🔬 حداکثر غنی‌سازی فعال کشور: <b>${currentTier}٪</b>`,
    `💵 موجودی خزانه ملی: <b>${fmtNum(state.treasury || 0)}$</b>`,
    '',
    'درصد غنی‌سازی مورد نظر را برای تزریق به سانتریفیوژ انتخاب کنید:',
  ].join('\n');

  const rows = [];
  if (currentTier >= 20) {
    rows.push([Markup.button.callback('🧪 غنی‌سازی ۲۰٪ (پژوهشی/پزشکی) - ۱۰,۰۰۰$/kg', 'nuc:enrich:tier:20')]);
  }
  if (currentTier >= 40) {
    rows.push([Markup.button.callback('⚡ غنی‌سازی ۴۰٪ (سوخت نیروگاه برق) - ۲۵,۰۰۰$/kg', 'nuc:enrich:tier:40')]);
  }
  if (currentTier >= 60) {
    rows.push([Markup.button.callback('🌊 غنی‌سازی ۶۰٪ (پیشران زیردریایی اتمی) - ۶۰,۰۰۰$/kg', 'nuc:enrich:tier:60')]);
  }
  if (currentTier >= 100) {
    rows.push([Markup.button.callback('💥 غنی‌سازی ۱۰۰٪ (تسلیحات هسته‌ای و کلاهک) - ۱۵۰,۰۰۰$/kg', 'nuc:enrich:tier:100')]);
  }

  rows.push([Markup.button.callback('🛒 خرید اورانیوم خام از بازار جهانی', 'oil:gm:buy:uranium')]);
  rows.push([Markup.button.callback('🔙 بازگشت به برنامه هسته‌ای', 'emp:nuclear')]);

  await ctx.editMessageText(text, {
    parse_mode: 'HTML',
    reply_markup: Markup.inlineKeyboard(rows).reply_markup,
  }).catch(() => {});
});

// منوی انتخاب مقدار اورانیوم برای غنی‌سازی در سطح انتخاب‌شده
composer.action(/^nuc:enrich:tier:(\d+)$/, async (ctx) => {
  await ctx.answerCbQuery().catch(() => {});
  const tier = Number(ctx.match[1]);
  const data = await requireCountry(ctx);
  if (!data) return;
  const { season, own } = data;
  const state = await gameService.getCountryState(own.countryId, season.id);
  const rawUranium = Number(state.inventory?.uranium || 0);

  const costPerKg = tier === 100 ? 150000 : tier === 60 ? 60000 : tier === 40 ? 25000 : 10000;
  const tierLabel = tier === 100 ? '۱۰۰٪ (تسلیحاتی)' : tier === 60 ? '۶۰٪ (پیشران زیردریایی)' : tier === 40 ? '۴۰٪ (سوخت نیروگاه)' : '۲۰٪ (پژوهشی)';

  const text = [
    `⚗️ <b>تنظیم فرآیند غنی‌سازی ${tierLabel}</b>`,
    '– – – – – – – – – –',
    `🪨 موجودی اورانیوم خام کشور: <b>${fmtNum(rawUranium)} کیلوگرم</b>`,
    `💵 هزینه فرآیند به‌ازای هر ۱ کیلوگرم: <b>${fmtNum(costPerKg)}$</b>`,
    `💰 موجودی خزانه کشور: <b>${fmtNum(state.treasury || 0)}$</b>`,
    '',
    '👇 چه مقدار از موجودی اورانیوم خام را می‌خواهید غنی‌سازی کنید؟',
  ].join('\n');

  const rows = [
    [
      Markup.button.callback('۱۰ کیلوگرم', `nuc:enrich:do:${tier}:10`),
      Markup.button.callback('۵۰ کیلوگرم', `nuc:enrich:do:${tier}:50`),
      Markup.button.callback('۱۰۰ کیلوگرم', `nuc:enrich:do:${tier}:100`),
    ],
    [
      Markup.button.callback('⚗️ تمام اورانیوم خام موجود', `nuc:enrich:do:${tier}:all`),
      Markup.button.callback('✏️ وارد کردن تعداد دلخواه', `nuc:enrich:custom:${tier}`),
    ],
    [Markup.button.callback('🔙 بازگشت', 'nuc:enrich:menu')],
  ];

  await ctx.editMessageText(text, {
    parse_mode: 'HTML',
    reply_markup: Markup.inlineKeyboard(rows).reply_markup,
  }).catch(() => {});
});

// اجرای غنی‌سازی با دکمه‌های سریع
composer.action(/^nuc:enrich:do:(\d+):(\w+)$/, async (ctx) => {
  const [tierStr, qtyStr] = [ctx.match[1], ctx.match[2]];
  const tier = Number(tierStr);
  const data = await requireCountry(ctx);
  if (!data) return;
  const { season, own } = data;
  const state = await gameService.getCountryState(own.countryId, season.id);
  const rawUranium = Number(state.inventory?.uranium || 0);

  const count = qtyStr === 'all' ? rawUranium : Number(qtyStr);
  if (count <= 0) {
    return ctx.answerCbQuery('⚠️ موجودی اورانیوم خام شما صفر است! ابتدا از بازار جهانی خرید فرمایید.', { show_alert: true });
  }

  try {
    const res = await gameService.enrichUranium(own.countryId, season.id, tier, count);
    await ctx.answerCbQuery(`🎉 ${fmtNum(count)} کیلوگرم اورانیوم با موفقیت تا سطح ${tier}٪ غنی‌سازی شد!`, { show_alert: true });
    await renderNuclearPanel(ctx, true);
  } catch (err) {
    await ctx.answerCbQuery(err.message, { show_alert: true });
  }
});

// وارد کردن تعداد دلخواه متنی برای غنی‌سازی
composer.action(/^nuc:enrich:custom:(\d+)$/, async (ctx) => {
  await ctx.answerCbQuery().catch(() => {});
  const tier = Number(ctx.match[1]);
  const data = await requireCountry(ctx);
  if (!data) return;
  const { season, own } = data;
  const state = await gameService.getCountryState(own.countryId, season.id);
  const rawUranium = Number(state.inventory?.uranium || 0);

  await userService.setFlow(ctx.from.id, 'game:nuc:enrich_custom', { tier });
  await ctx.reply([
    `✏️ <b>غنی‌سازی اورانیوم خام به سطح ${tier}٪</b>`,
    '– – – – – – – – – –',
    `موجودی اورانیوم خام شما: <b>${fmtNum(rawUranium)} کیلوگرم</b>`,
    '',
    'لطفاً <b>تعداد کیلوگرم دلخواه</b> برای غنی‌سازی را ارسال نمایید:',
    '(مثلاً: 25 یا 150 یا 500)',
    '',
    'جهت انصراف: /cancel',
  ].join('\n'), { parse_mode: 'HTML' });
});

registerFlow('game:nuc:enrich_custom', async (ctx, data) => {
  const count = parseNonNegInt(ctx.message?.text);
  if (!count || count <= 0) {
    return ctx.reply('⚠️ لطفاً یک رقم عددی معتبر (بزرگتر از صفر) ارسال نمایید. لغو: /cancel');
  }

  const ownData = await requireCountry(ctx);
  if (!ownData) return;

  try {
    const res = await gameService.enrichUranium(ownData.own.countryId, ownData.season.id, data.tier, count);
    await userService.clearFlow(ctx.from.id);

    const text = [
      '🎉 <b>فرآیند غنی‌سازی اورانیوم با موفقیت انجام شد!</b>',
      '– – – – – – – – – –',
      `🪨 اورانیوم خام مصرفی: <b>-${fmtNum(res.quantity)} کیلوگرم</b>`,
      `🧪 اورانیوم غنی‌شده ${res.tier}٪ حاصله: <b>+${fmtNum(res.quantity)} کیلوگرم</b>`,
      `💵 هزینه فرآیند سانتریفیوژ: <b>${fmtNum(res.totalCost)}$</b>`,
      `💰 باقی‌مانده خزانه: <b>${fmtNum(res.remainingTreasury)}$</b>`,
      `☢️ موجودی کل اورانیوم ${res.tier}٪ کشور: <b>${fmtNum(res.newEnrichedTotal)} کیلوگرم</b>`,
    ].join('\n');

    await ctx.reply(text, {
      parse_mode: 'HTML',
      ...Markup.inlineKeyboard([
        [Markup.button.callback('☢️ مشاهده برنامه هسته‌ای', 'emp:nuclear')],
        [Markup.button.callback('👑 بازگشت به امپراطوری', 'menu:empire')],
      ]),
    });
  } catch (err) {
    await ctx.reply(`⚠️ ${err.message}\nمقدار دیگری را ارسال فرمایید یا دستور /cancel را بزنید.`);
  }
});

// ثبت درخواست مجوز در سازمان ملل
composer.action(/^nuc:req_un:(\d+)$/, async (ctx) => {
  await ctx.answerCbQuery().catch(() => {});
  const tier = Number(ctx.match[1]);
  const data = await requireCountry(ctx);
  if (!data) return;
  const { season, own } = data;

  const tierDef = gameService.NUCLEAR_TIERS.find((x) => x.tier === tier);
  if (!tierDef) return ctx.reply('مرحله مورد نظر یافت نشد.');

  try {
    const session = await unService.createVoteSession({
      seasonId: season.id,
      initiatorCountryId: own.countryId,
      type: 'nuclear_license',
      title: `درخواست صدور مجوز غنی‌سازی ${tierDef.percent} برای کشور ${own.country.name}`,
      description: `کشور ${own.country.flag} ${own.country.name} تقاضای دریافت مجوز بین‌المللی ارتقای برنامه هسته‌ای خود به سطح «${tierDef.title}» را دارد. لطفاً اعضای سازمان ملل نظر خود را طی ۳۰ دقیقه ثبت فرمایند.`,
      metadata: { targetTier: tier },
      telegramBot: ctx.telegram,
    });

    await ctx.reply([
      '📜 <b>درخواست مجوز در سازمان ملل ثبت شد!</b>',
      '– – – – – – – – – –',
      `پرونده ارتقا به غنی‌سازی <b>${tierDef.percent}</b> در مجمع عمومی سازمان ملل ایجاد شد.`,
      '⏱ زمان رأی‌گیری: <b>۳۰ دقیقه زمان واقعی</b>',
      'گزینه‌ها: <b>✅ موافق | ❌ مخالف | ⚪ ممتنع</b>',
      '',
      'نتیجه پس از اتمام رأی‌گیری خودکار ثبت خواهد شد.',
    ].join('\n'), {
      parse_mode: 'HTML',
      ...Markup.inlineKeyboard([
        [Markup.button.callback('🇺🇳 مشاهده و شرکت در رأی‌گیری', `un:view:${session.id}`)],
        [Markup.button.callback('☢️ بازگشت به برنامه هسته‌ای', 'emp:nuclear')],
      ]),
    });
  } catch (err) {
    await ctx.reply(`⚠️ خطا در ثبت پرونده سازمان ملل: ${err.message}`);
  }
});

// فعال‌سازی و ارتقای فناوری هسته‌ای پس از اخذ مجوز
composer.action(/^nuc:upgrade:(\d+)$/, async (ctx) => {
  await ctx.answerCbQuery().catch(() => {});
  const tier = Number(ctx.match[1]);
  const data = await requireCountry(ctx);
  if (!data) return;
  const { season, own } = data;

  try {
    const res = await gameService.upgradeNuclearTier(own.countryId, season.id, tier);
    await ctx.reply(`🎉 <b>تبریک! برنامه هسته‌ای با موفقیت ارتقا یافت</b>\nکشور شما اکنون دارای فناوری «${esc(res.title)}» است.`, {
      parse_mode: 'HTML',
      ...Markup.inlineKeyboard([[Markup.button.callback('☢️ مشاهده برنامه هسته‌ای', 'emp:nuclear')]]),
    });
  } catch (err) {
    await ctx.reply(`⚠️ ${err.message}`, {
      ...Markup.inlineKeyboard([[Markup.button.callback('🔙 بازگشت', 'emp:nuclear')]]),
    });
  }
});

// نمایش لیست جلسات رأی‌گیری فعال سازمان ملل
async function renderUNVotesPanel(ctx, isEdit = false) {
  const data = await requireCountry(ctx);
  if (!data) return;
  const { season, own } = data;

  const activeSessions = await unService.listActiveSessions(season.id);
  const now = Date.now();

  const lines = [
    '🇺🇳 <b>مجمع عمومی و شورای امنیت سازمان ملل (United Nations)</b>',
    '– – – – – – – – – –',
    'هر کشور تأییدشده در بازی دارای ۱ حق رأی رسمی در جلسات سازمان ملل است.',
    'گزینه‌ها: <b>✅ موافق | ❌ مخالف | ⚪ ممتنع</b>',
    'مدت‌زمان هر رأی‌گیری: <b>۳۰ دقیقه</b>',
    '– – – – – – – – – –',
  ];

  if (!activeSessions.length) {
    lines.push('🕊️ در حال حاضر هیچ پرونده رأی‌گیری فعالی در سازمان ملل در جریان نیست.');
  } else {
    lines.push(`📍 <b>پرونده‌های در حال رأی‌گیری (${activeSessions.length} مورد):</b>\n`);
  }

  const buttons = [];
  for (const s of activeSessions) {
    const expMs = s.expiresAt?.toDate ? s.expiresAt.toDate().getTime() : new Date(s.expiresAt).getTime();
    const remSec = Math.max(0, Math.ceil((expMs - now) / 1000));
    const remMin = Math.floor(remSec / 60);

    const yesCount = s.counts?.yes || 0;
    const noCount = s.counts?.no || 0;
    const absCount = s.counts?.abstain || 0;

    lines.push(`🔹 <b>${esc(s.title)}</b>\n   بانی: ${s.initiatorFlag || '🏳️'} ${esc(s.initiatorCountryName)}\n   ⏳ مهلت باقی‌مانده: <b>${remMin} دقیقه</b>\n   📊 آرا: ✅ ${yesCount} | ❌ ${noCount} | ⚪ ${absCount}\n`);

    buttons.push([Markup.button.callback(`🗳️ ورود به پرونده: ${s.title.slice(0, 24)}...`, `un:view:${s.id}`)]);
  }

  buttons.push([Markup.button.callback('☢️ بازگشت به برنامه هسته‌ای', 'emp:nuclear')]);
  buttons.push([Markup.button.callback('🔙 بازگشت به امپراطوری', 'emp:home')]);

  const text = lines.join('\n');
  const kb = Markup.inlineKeyboard(buttons);

  if (isEdit && ctx.callbackQuery) {
    await ctx.editMessageText(text, { parse_mode: 'HTML', reply_markup: kb.reply_markup }).catch(() => {});
  } else {
    await ctx.reply(text, { parse_mode: 'HTML', ...kb });
  }
}

composer.action('emp:un:votes', async (ctx) => {
  await ctx.answerCbQuery().catch(() => {});
  await renderUNVotesPanel(ctx, true);
});
composer.hears(['سازمان ملل 🇺🇳', 'سازمان ملل', '/un'], async (ctx) => {
  await renderUNVotesPanel(ctx, false);
});

// مشاهده جزئیات یک پرونده رأی‌گیری و ثبت رأی اینلاین
composer.action(/^un:view:(.+)$/, async (ctx) => {
  await ctx.answerCbQuery().catch(() => {});
  const voteId = ctx.match[1];
  const session = await unService.getVoteSession(voteId);
  if (!session) return ctx.reply('پرونده سازمان ملل یافت نشد.');

  const { text, kb } = unService.renderUNVoteContent(session);
  const rows = [...(kb.reply_markup?.inline_keyboard || [])];
  rows.push([Markup.button.callback('🔙 بازگشت به لیست پرونده‌ها', 'emp:un:votes')]);

  await ctx.editMessageText(text, {
    parse_mode: 'HTML',
    reply_markup: { inline_keyboard: rows },
  }).catch(() => {});
});

// ثبت رأی توسط نماینده کشور
composer.action(/^un:vote:([^:]+):(yes|no|abstain)$/, async (ctx) => {
  const [voteId, choice] = [ctx.match[1], ctx.match[2]];
  const season = await getActiveSeason();
  if (!season) {
    if (ctx.callbackQuery) await ctx.answerCbQuery('⚠️ در حال حاضر سیزن فعالی یافت نشد.', { show_alert: true }).catch(() => {});
    return;
  }

  // احراز هویت کشور یا سمت رسمی دولتی
  let countryData = null;
  const own = await getActiveOwnership(ctx.from.id, season.id);
  if (own) {
    countryData = { countryId: own.countryId, country: own.country, role: 'leader' };
  } else {
    const ministerService = require('../services/ministerService');
    const minRecord = await ministerService.findMinisterRole(ctx.from.id, season.id);
    if (minRecord) {
      const country = await countryService.get(minRecord.countryId);
      countryData = { countryId: minRecord.countryId, country, role: minRecord.role };
    }
  }

  if (!countryData) {
    if (ctx.callbackQuery) {
      await ctx.answerCbQuery('⚠️ شما هنوز کشوری ندارید! فقط بازیکنانی که دارای کشور یا سمت رسمی در دولت هستند حق رأی در سازمان ملل را دارند.', { show_alert: true }).catch(() => {});
    }
    return;
  }

  try {
    const res = await unService.castVote({
      voteId,
      countryId: countryData.countryId,
      choice,
      userId: ctx.from.id,
    });

    const choiceFa = { yes: 'موافق ✅', no: 'مخالف ❌', abstain: 'ممتنع ⚪' }[choice] || choice;
    await ctx.answerCbQuery(`✅ رأی رسمی کشور شما («${choiceFa}») با موفقیت در سازمان ملل ثبت شد.`, { show_alert: true }).catch(() => {});

    // دریافت اطلاعات جلسه و رندر یکپارچه قطعنامه همراه با لیست کشورها و شناسه‌های عددی
    const session = await unService.getVoteSession(voteId);
    if (session) {
      const { text, kb } = unService.renderUNVoteContent(session);

      // به‌روزرسانی پیام فعلی (چه در کانال و چه در چت خصوصی)
      await ctx.editMessageText(text, {
        parse_mode: 'HTML',
        reply_markup: kb.reply_markup,
      }).catch(() => {});

      // اگر از داخل پی‌وی ربات کلیک شده و پیام کانال ثبت شده، پیام کانال را نیز به صورت زنده آپدیت کن
      if (ctx.chat?.type === 'private' && session.channelChatId && session.channelMessageId) {
        ctx.telegram.editMessageText(session.channelChatId, session.channelMessageId, null, text, {
          parse_mode: 'HTML',
          reply_markup: kb.reply_markup,
        }).catch(() => {});
      }
    }
  } catch (err) {
    await ctx.answerCbQuery(`⚠️ ${err.message}`, { show_alert: true }).catch(() => {});
  }
});

// =============================================================
// بخش اختصاصی دفاع ملی و پدافند خودکار (دفاع خودکار با ضریب ۲۵٪)
// =============================================================
async function showDefensePanel(ctx, isEdit = false) {
  const data = await requireCountry(ctx);
  if (!data) return;
  const { season, own } = data;
  const state = await gameService.getCountryState(own.countryId, season.id);
  const flag = countryService.getDynamicFlag(own.country, state);

  const isAutoDef = Boolean(state.autoDefense);
  const baseDef = Number(state.military?.defense || 2459);
  const effectiveDef = isAutoDef ? Math.floor(baseDef * 1.25) : baseDef;

  // بررسی تهاجمات فعال به کشور
  const activeBattles = await warService.getActiveBattlesForCountry(own.countryId, season.id);
  const incoming = activeBattles.filter((b) => String(b.defenderCountryId) === String(own.countryId) && b.status === 'pending');

  let siegeStatusText = '🟢 مرزهای کشور در وضعیت امن قرار دارند.';
  if (incoming.length > 0) {
    const alertItems = [];
    const now = Date.now();
    for (const b of incoming) {
      const finishMs = b.scheduledResolutionAt ? new Date(b.scheduledResolutionAt).getTime() : now;
      const remSec = Math.max(0, Math.ceil((finishMs - now) / 1000));
      const remMin = Math.floor(remSec / 60);
      const remSecMod = remSec % 60;
      alertItems.push(`🚨 کاروان متخاصم در حال پیشروی! زمان برخورد: <b>${remMin} دقیقه و ${remSecMod} ثانیه</b>`);
    }
    siegeStatusText = alertItems.join('\n');
  }

  const lines = [
    `🛡️ <b>مرکز فرماندهی پدافند و دفاع هوایی — ${esc(own.country.name)} ${flag}</b>`,
    '– – – – – – – – – –',
    `📡 وضعیت سامانه دفاع خودکار: <b>${isAutoDef ? 'فعال (آماده‌باش ۲۴ ساعته ⚡)' : 'غیرفعال (آفلاین ⏸)'}</b>`,
    `🛡️ قدرت خالص پدافند ملی: <b>${fmtNum(effectiveDef)}</b> ${isAutoDef ? '<i>(+۲۵٪ بانس آمادگی سریع رزمی)</i>' : ''}`,
    `🪖 ارتش زمینی تحت پوشش: <b>${fmtNum(state.military?.ground || 74940)} نیرو</b>`,
    '– – – – – – – – – –',
    `⚠️ <b>وضعیت زنده مرزها:</b>`,
    siegeStatusText,
    '',
    '💡 <i>با روشن بودن دفاع خودکار، نیروهای پدافندی و پادگان بلافاصله با دریافت آلارم تهاجم دشمن وارد عملیات مقابله شده و ۲۵٪ قدرت دفاعی موثرتر عمل می‌کنند.</i>',
  ];

  const kb = Markup.inlineKeyboard([
    [Markup.button.callback(isAutoDef ? '⏸ خاموش کردن دفاع خودکار' : '⚡ فعال‌سازی دفاع خودکار (+۲۵٪ بانس)', 'def:auto_toggle')],
    [Markup.button.callback('🛒 خرید تسلیحات پدافندی و رادار', 'atk:shop:cat:air_defense')],
    [Markup.button.callback('🪖 ورود به پادگان نیروها', 'emp:barracks')],
    [Markup.button.callback('🔙 بازگشت به امپراطوری', 'emp:home')],
  ]);

  if (isEdit && ctx.callbackQuery) {
    await ctx.editMessageText(lines.join('\n'), { parse_mode: 'HTML', ...kb }).catch(() => {});
  } else {
    await ctx.reply(lines.join('\n'), { parse_mode: 'HTML', ...kb });
  }
}

composer.action('emp:defense', async (ctx) => {
  await ctx.answerCbQuery().catch(() => {});
  await showDefensePanel(ctx, true);
});
composer.hears(['دفاع 🛡️', 'دفاع', '/defense'], async (ctx) => {
  await showDefensePanel(ctx, false);
});

composer.action('def:auto_toggle', async (ctx) => {
  const data = await requireCountry(ctx);
  if (!data) return;
  const { season, own } = data;
  const nextVal = await gameService.toggleAutoDefense(own.countryId, season.id);
  await ctx.answerCbQuery(
    nextVal
      ? '⚡ سامانه دفاع خودکار فعال شد! +۲۵٪ بانس آمادگی در کلیه خطوط دفاعی اعمال گردید.'
      : '⏸ سامانه دفاع خودکار خاموش شد.',
    { show_alert: true }
  );
  await showDefensePanel(ctx, true);
});

// =============================================================
// بخش اختصاصی پادگان نظامی (مرکز ادوات، آمار نبرد و نیروها)
// =============================================================
async function showBarracksPanel(ctx, isEdit = false) {
  const data = await requireCountry(ctx);
  if (!data) return;
  const { season, own } = data;
  const state = await gameService.getCountryState(own.countryId, season.id);
  const flag = countryService.getDynamicFlag(own.country, state);
  const allWeapons = await weaponService.list();

  const isAutoDef = Boolean(state.autoDefense);
  const effectiveDef = isAutoDef ? Math.floor((state.military?.defense || 2459) * 1.25) : (state.military?.defense || 2459);

  const ownedList = [];
  for (const w of allWeapons) {
    const c = gameService.getCountryUnitCount(state, w.id);
    if (c > 0) {
      ownedList.push({
        id: w.id,
        name: w.name,
        emoji: w.emoji || '🪖',
        category: w.category,
        count: c,
        power: Number(w.power) || 20,
        totalPower: (Number(w.power) || 20) * c,
      });
    }
  }

  const lines = [
    `🪖 <b>ستاد کل پادگان و نیروی مسلح — ${esc(own.country.name)} ${flag}</b>`,
    '– – – – – – – – – –',
    `⚔️ توان هجومی ارتش: <b>${fmtNum(state.military?.attack || 2124)}</b>`,
    `🛡️ توان پدافند و دفاعی: <b>${fmtNum(effectiveDef)}</b> ${isAutoDef ? '(آماده‌باش دفاع خودکار ✅)' : ''}`,
    `🪖 نیروی انسانی زمینی: <b>${fmtNum(state.military?.ground || 74940)} نفر</b>`,
    `💻 توان سایبری: <b>${fmtNum(state.military?.cyber || 33)}</b>`,
    '– – – – – – – – – –',
    '📊 <b>فهرست ادوات و تجهیزات مستقر در پادگان:</b>',
  ];

  if (ownedList.length === 0) {
    lines.push('<i>هنوز تجهیزات مدرنی خریداری نشده است؛ از فروشگاه تسلیحات خرید کنید.</i>');
  } else {
    for (const item of ownedList.slice(0, 12)) {
      lines.push(`• ${item.emoji} <b>${esc(item.name)}</b>: ${fmtNum(item.count)} عدد (مجموع قدرت: ${fmtNum(item.totalPower)})`);
    }
    if (ownedList.length > 12) {
      lines.push(`<i>... و ${ownedList.length - 12} نوع ادوات دیگر</i>`);
    }
  }

  lines.push('');
  lines.push(`🏆 پیروزی‌ها در نبرد: <b>${fmtNum(state.battlesWon || 0)}</b> | شکست‌ها: <b>${fmtNum(state.battlesLost || 0)}</b>`);

  const kb = Markup.inlineKeyboard([
    [Markup.button.callback('🛒 خرید تجهیزات از زرادخانه', 'atk:shop'), Markup.button.callback('🛡️ سامانه دفاع و پدافند', 'emp:defense')],
    [Markup.button.callback(isAutoDef ? '⏸ خاموش کردن دفاع خودکار' : '⚡ فعال‌سازی دفاع خودکار', 'def:auto_toggle')],
    [Markup.button.callback('⚔️ ورود به اتاق جنگ و حمله', 'emp:attack')],
    [Markup.button.callback('🔙 بازگشت به امپراطوری', 'emp:home')],
  ]);

  if (isEdit && ctx.callbackQuery) {
    await ctx.editMessageText(lines.join('\n'), { parse_mode: 'HTML', ...kb }).catch(() => {});
  } else {
    await ctx.reply(lines.join('\n'), { parse_mode: 'HTML', ...kb });
  }
}

composer.action('emp:barracks', async (ctx) => {
  await ctx.answerCbQuery().catch(() => {});
  await showBarracksPanel(ctx, true);
});
composer.hears(['پادگان 🪖', 'پادگان', '/barracks'], async (ctx) => {
  await showBarracksPanel(ctx, false);
});

// =============================================================
// بخش دیپلماسی مستقیم و قطع روابط تجاری
// =============================================================
composer.hears(['دیپلماسی 🕊️', 'دیپلماسی', '/diplomacy'], async (ctx) => {
  await showDiplomacyPanel(ctx);
});
composer.action('emp:diplomacy', async (ctx) => {
  await ctx.answerCbQuery().catch(() => {});
  await showDiplomacyPanel(ctx, true);
});

async function showDiplomacyPanel(ctx, isEdit = false) {
  const data = await requireCountry(ctx);
  if (!data) return;
  const { season, own } = data;
  const activeOwnerships = await listActive(season.id);
  const targets = activeOwnerships.filter((o) => String(o.countryId) !== String(own.countryId));

  const text = [
    `🕊️ <b>مرکز دیپلماسی و روابط بین‌المللی — ${own.country.flag} ${esc(own.country.name)}</b>`,
    '– – – – – – – – – –',
    'در این بخش می‌توانید بدون نیاز به فرآیند مذاکره، اقدامات دیپلماتیک زیر را انجام دهید:',
    '',
    '۱. 🤝 <b>ارسال مستقیم پیمان:</b> ارسال پیمان صلح و دوستی یک‌طرفه و مستقیم به کشور هدف.',
    '۲. 📉 <b>قطع روابط تجاری:</b> تحریم و قطع پیوندهای بازرگانی که موجب <b>افت ۵ درصدی از درآمد روزانه هر دو کشور</b> خواهد شد.',
    '',
    '👇 کشور مورد نظر را انتخاب نمایید:',
  ].join('\n');

  const rows = [];
  for (const t of targets.slice(0, 15)) {
    const c = await countryService.get(t.countryId);
    if (c) {
      rows.push([
        Markup.button.callback(`🤝 پیمان: ${c.flag} ${c.name}`, `diplo:pact:${c.id}`),
        Markup.button.callback('📉 قطع تجارت', `diplo:cut:${c.id}`),
      ]);
    }
  }
  if (!targets.length) {
    rows.push([Markup.button.callback('🌍 هیچ کشور فعال دیگری در سیزن نیست', 'noop')]);
  }
  rows.push([Markup.button.callback('🔙 بازگشت به امپراطوری', 'emp:home')]);

  const kb = Markup.inlineKeyboard(rows);
  if (isEdit && ctx.callbackQuery) {
    await ctx.editMessageText(text, { parse_mode: 'HTML', reply_markup: kb.reply_markup }).catch(() => {});
  } else {
    await ctx.reply(text, { parse_mode: 'HTML', ...kb });
  }
}

composer.action(/^diplo:pact:(.+)$/, async (ctx) => {
  await ctx.answerCbQuery().catch(() => {});
  const data = await requireCountry(ctx);
  if (!data) return;
  const { season, own } = data;
  const targetCountryId = ctx.match[1];
  try {
    const pact = await tradeService.sendDirectPact({
      fromCountryId: own.countryId,
      toCountryId: targetCountryId,
      seasonId: season.id,
      pactType: 'friendship',
      note: 'پیمان صلح و حسن همجواری مستقیم',
    });

    const activeOwnerships = await listActive(season.id);
    const targetOwn = activeOwnerships.find((o) => String(o.countryId) === String(targetCountryId));
    if (targetOwn) {
      await notifications.safeSend(ctx.telegram, targetOwn.userId,
        `🕊️ <b>پیام دیپلماتیک مستقیم!</b>\nکشور ${pact.fromCountryFlag} <b>${esc(pact.fromCountryName)}</b> بدون پیش‌شرط پیمان صلح و حسن همجواری با کشور شما منعقد کرد.`
      ).catch(() => {});
    }

    await ctx.reply(`✅ <b>پیمان صلح و دوستی با موفقیت و بدون نیاز به مذاکره برای کشور ${pact.toCountryFlag} ${esc(pact.toCountryName)} ارسال و برقرار شد!</b>`, {
      parse_mode: 'HTML',
      ...Markup.inlineKeyboard([[Markup.button.callback('🕊️ دیپلماسی', 'emp:diplomacy')]]),
    });
  } catch (err) {
    await ctx.reply(`⚠️ خطا در ارسال پیمان: ${err.message}`);
  }
});

composer.action(/^diplo:cut:(.+)$/, async (ctx) => {
  await ctx.answerCbQuery().catch(() => {});
  const data = await requireCountry(ctx);
  if (!data) return;
  const { season, own } = data;
  const targetCountryId = ctx.match[1];
  try {
    const res = await tradeService.cutTradeRelations({
      sourceCountryId: own.countryId,
      targetCountryId,
      seasonId: season.id,
    });

    const activeOwnerships = await listActive(season.id);
    const targetOwn = activeOwnerships.find((o) => String(o.countryId) === String(targetCountryId));
    if (targetOwn) {
      await notifications.safeSend(ctx.telegram, targetOwn.userId,
        `📉 <b>هشدار قطع روابط تجاری!</b>\nکشور ${res.sourceCountry.flag} <b>${esc(res.sourceCountry.name)}</b> روابط تجاری خود را با شما قطع کرد. درآمد روزانه شما ۵٪ (${fmtNum(res.targetDrop)}$) کاهش یافت.`
      ).catch(() => {});
    }

    await ctx.reply([
      '📉 <b>روابط تجاری با موفقیت قطع گردید!</b>',
      '– – – – – – – – – –',
      `کشور هدف: <b>${res.targetCountry.flag} ${esc(res.targetCountry.name)}</b>`,
      `🔻 افت درآمد روزانه کشور شما: <b>-${fmtNum(res.sourceDrop)}$ (-۵٪)</b>`,
      `🔻 افت درآمد روزانه کشور هدف: <b>-${fmtNum(res.targetDrop)}$ (-۵٪)</b>`,
      `💵 درآمد روزانه جدید شما: <b>${fmtNum(res.sourceNewIncome)}$</b>`,
    ].join('\n'), {
      parse_mode: 'HTML',
      ...Markup.inlineKeyboard([[Markup.button.callback('🕊️ دیپلماسی', 'emp:diplomacy')]]),
    });
  } catch (err) {
    await ctx.reply(`⚠️ ${err.message}`);
  }
});

// =============================================================
// بخش اکتشاف نفت (هزینه با ادمین + درصد نفت‌خیزی تعیین‌شده ادمین)
// =============================================================
composer.hears(['اکتشاف نفت 🛢️', 'اکتشاف نفت'], async (ctx) => {
  await promptOilExplorationConfirmation(ctx);
});
composer.action('emp:oil_explore', async (ctx) => {
  await ctx.answerCbQuery().catch(() => {});
  await promptOilExplorationConfirmation(ctx);
});
composer.action('emp:oil_explore:do', async (ctx) => {
  await ctx.answerCbQuery().catch(() => {});
  await handleOilExploration(ctx);
});

async function promptOilExplorationConfirmation(ctx) {
  const data = await requireCountry(ctx);
  if (!data) return;
  const { own } = data;
  try {
    const cost = await gameService.getOilExplorationCost();
    const richness = Math.max(0, Math.min(100, Number(own.country?.oilRichness ?? own.oilRichness ?? 50)));
    await ctx.reply([
      '🔬 <b>اعزام تیم اکتشاف نفت و حفاری عمیق</b>',
      '– – – – – – – – – –',
      `📊 درصد نفت‌خیزی زمین‌شناسی کشور شما: <b>${richness}٪</b>`,
      `💰 هزینه اعزام و تجهیزات تیم پژوهشی: <b>${fmtNum(cost)}$</b>`,
      `🏦 موجودی فعلی خزانه: <b>${fmtNum(own.treasury || 0)}$</b>`,
      '',
      '⚠️ آیا از اعزام تیم اکتشاف نفت اطمینان دارید؟ (در صورت عدم موفقیت، هزینه مسترد نمی‌شود)',
    ].join('\n'), {
      parse_mode: 'HTML',
      ...Markup.inlineKeyboard([
        [Markup.button.callback('🔬 تایید و اعزام تیم اکتشاف', 'emp:oil_explore:do')],
        [Markup.button.callback('🔙 انصراف و بازگشت به نفت', 'emp:oil')],
      ]),
    });
  } catch (err) {
    await ctx.reply(`⚠️ ${err.message}`);
  }
}

async function handleOilExploration(ctx) {
  const data = await requireCountry(ctx);
  if (!data) return;
  const { season, own } = data;
  try {
    const cost = await gameService.getOilExplorationCost();
    const res = await gameService.exploreOil(own.countryId, season.id);
    if (res.found) {
      await ctx.reply([
        '🎉 <b>کشف بزرگ نفتی! مخزن نفت جدید پیدا شد!</b>',
        '– – – – – – – – – –',
        '🔬 تیم محققان پس از حفاری‌های عمیق، یک مخزن نفت بکر کشف کردند.',
        `📊 درصد نفت‌خیزی کشور شما (تعیین‌شده ادمین): <b>${res.richness}٪</b>`,
        `➕ افزایش به ظرفیت مخزن نفت: <b>+${fmtNum(res.added)} بشکه</b>`,
        `🛢 ظرفیت کل جدید مخزن داخلی: <b>${fmtNum(res.oilReserve)} بشکه</b>`,
        `💰 هزینه پرداخت‌شده به تیم پژوهش: <b>${fmtNum(cost)}$</b>`,
        `🏦 موجودی باقیمانده خزانه: <b>${fmtNum(res.treasury)}$</b>`,
        '',
        'اکنون می‌توانید استخراج نفت بیشتری نسبت به گذشته انجام دهید.',
      ].join('\n'), {
        parse_mode: 'HTML',
        ...Markup.inlineKeyboard([[Markup.button.callback('💰 اقتصاد و نفت', 'emp:oil')]]),
      });
    } else {
      await ctx.reply([
        '🔍 <b>عملیات اکتشاف نفت: منبع جدیدی یافت نشد</b>',
        '– – – – – – – – – –',
        `تیم پژوهشی اعزام شد اما با توجه به درصد نفت‌خیزی ${res.richness}٪ کشور، مخزن تجاری جدیدی کشف نگردید.`,
        `💰 مبلغ ${fmtNum(cost)}$ بابت هزینه تجهیزات و اعزام پژوهشگران مصرف شد.`,
        `🏦 موجودی باقیمانده خزانه: <b>${fmtNum(res.treasury)}$</b>`,
        '',
        'می‌توانید در زمان مناسب دوباره تلاش کنید.',
      ].join('\n'), {
        parse_mode: 'HTML',
        ...Markup.inlineKeyboard([[Markup.button.callback('💰 اقتصاد و نفت', 'emp:oil')]]),
      });
    }
  } catch (err) {
    await ctx.reply(`⚠️ ${err.message}`);
  }
}

// -------------------------------------------------------------
// ناوبری کلیدهای شیشه‌ای اینلاین منوی اصلی (جایگزین پنل زیر چت)
// -------------------------------------------------------------
composer.action('menu:status', async (ctx) => {
  await ctx.answerCbQuery().catch(() => {});
  await showStatusPanel(ctx, true);
});
composer.action('menu:empire', async (ctx) => {
  await ctx.answerCbQuery().catch(() => {});
  const data = await requireCountry(ctx);
  if (!data) return;
  const { own, season } = data;
  const state = await gameService.getCountryState(own.countryId, season.id);
  const flag = countryService.getDynamicFlag(own.country, state);
  await ctx.editMessageText([
    `👑 <b>امپراطوری ${esc(own.country.name)} ${flag}</b>`,
    '– – – – – – – – – –',
    `👑 رهبر: <b>${esc(ctx.state.user.displayName)}</b>`,
    `💵 سرمایه: <b>${fmtNum(state.treasury)}$</b> | 🛢 نفت: <b>${fmtNum(state.oil || 0)} بشکه</b>`,
    '',
    '👇 بخش مورد نظر خود را انتخاب کنید:',
  ].join('\n'), {
    parse_mode: 'HTML',
    reply_markup: empireInlineKeyboard().reply_markup,
  }).catch(() => {});
});
composer.action('menu:mission', async (ctx) => {
  await ctx.answerCbQuery().catch(() => {});
  await showMissionsPanel(ctx, true);
});
composer.action('menu:account', async (ctx) => {
  await ctx.answerCbQuery().catch(() => {});
  await showAccountPanel(ctx, true);
});
composer.action('menu:shield', async (ctx) => {
  await ctx.answerCbQuery().catch(() => {});
  await showShieldPanel(ctx, true);
});
composer.action('menu:world', async (ctx) => {
  await ctx.answerCbQuery().catch(() => {});
  await showWorldMap(ctx, true);
});
composer.action('menu:complaints', async (ctx) => {
  await ctx.answerCbQuery().catch(() => {});
  await ctx.editMessageText('⚖️ <b>بخش ثبت شکایات و پشتیبانی</b>\n– – – – – – – – – –\nاگر تخلفی از سوی کشوری مشاهده کردید یا خطایی در بازی رخ داده است، با ارسال مدرک و متن شکایت خود را ثبت کنید.', {
    parse_mode: 'HTML',
    reply_markup: Markup.inlineKeyboard([
      [Markup.button.callback('✍️ ثبت شکایت جدید با مدرک', 'cmp:new')],
      [Markup.button.callback('🔙 بازگشت به منوی اصلی', 'menu:home')],
    ]).reply_markup,
  }).catch(() => {});
});
composer.action('menu:leaderboard', async (ctx) => {
  await ctx.answerCbQuery().catch(() => {});
  await ctx.editMessageText('🎖️ <b>لیدربورد جهانی WORLD WAR FIRE</b>\n– – – – – – – – – –\nکدام رده‌بندی جهانی را می‌خواهید مشاهده کنید؟', {
    parse_mode: 'HTML',
    reply_markup: leaderboardKeyboard().reply_markup,
  }).catch(() => {});
});


// -------------------------------------------------------------
// ۵. سپر خواب
// -------------------------------------------------------------
async function showShieldPanel(ctx, isEdit = false) {
  const data = await requireCountry(ctx);
  if (!data) return;
  const { season, own } = data;
  const state = await gameService.getCountryState(own.countryId, season.id);
  const shield = gameService.isShielded(state);

  if (shield.shielded && shield.type === 'sleep') {
    const remainMs = shield.until.getTime() - Date.now();
    const hours = Math.floor(remainMs / (3600 * 1000));
    const mins = Math.floor((remainMs % (3600 * 1000)) / (60 * 1000));
    const text = [
      '😴 <b>سپر خواب در حال حاضر فعال است!</b>',
      '– – – – – – – – – –',
      `⏳ زمان باقیمانده: <b>${hours} ساعت و ${mins} دقیقه</b>`,
      '',
      '🛡 هیچ کشوری نمی‌تواند به شما حمله کند و شما نیز نمی‌توانید حمله کنید.',
    ].join('\n');
    const kb = Markup.inlineKeyboard([
      [Markup.button.callback('❌ لغو زودهنگام سپر خواب', 'shield:cancel')],
      [Markup.button.callback('🔙 بازگشت به منوی اصلی', 'menu:home')],
    ]);
    if (isEdit && ctx.callbackQuery) {
      await ctx.editMessageText(text, { parse_mode: 'HTML', reply_markup: kb.reply_markup }).catch(() => {});
    } else {
      await ctx.reply(text, { parse_mode: 'HTML', ...kb });
    }
    return;
  }

  const text = [
    '😴 <b>سپر خواب (۸ ساعت زمان واقعی)</b>',
    '– – – – – – – – – –',
    '• در طول ۸ ساعت استراحت، هیچ کشوری قادر به حمله به شما نیست.',
    '• شما نیز در این مدت به عملیات تهاجمی دسترسی نخواهید داشت.',
  ].join('\n');

  const kb = Markup.inlineKeyboard([
    [Markup.button.callback('🛡 فعال‌سازی سپر خواب (۸ ساعت)', 'shield:activate')],
    [Markup.button.callback('🔙 بازگشت به منوی اصلی', 'menu:home')],
  ]);

  if (isEdit && ctx.callbackQuery) {
    await ctx.editMessageText(text, { parse_mode: 'HTML', reply_markup: kb.reply_markup }).catch(() => {});
  } else {
    await ctx.reply(text, { parse_mode: 'HTML', ...kb });
  }
}

composer.hears(L.shield, async (ctx) => {
  await showShieldPanel(ctx, false);
});

composer.action('shield:activate', async (ctx) => {
  await ctx.answerCbQuery().catch(() => {});
  const data = await requireCountry(ctx);
  if (!data) return;
  try {
    const until = await gameService.activateSleepShield(data.own.countryId, data.season.id);
    await ctx.reply(`😴 <b>سپر خواب فعال شد!</b>\nپایان سپر: ${fmtDate(until)}`, {
      parse_mode: 'HTML',
      ...Markup.inlineKeyboard([[Markup.button.callback('🔙 بازگشت به منوی اصلی', 'menu:home')]]),
    });
  } catch (err) {
    await ctx.reply(`⚠️ ${err.message}`);
  }
});

composer.action('shield:cancel', async (ctx) => {
  await ctx.answerCbQuery().catch(() => {});
  const data = await requireCountry(ctx);
  if (!data) return;
  await gameService.deactivateSleepShield(data.own.countryId, data.season.id);
  await ctx.reply('✅ سپر خواب لغو شد.', {
    ...Markup.inlineKeyboard([[Markup.button.callback('🔙 بازگشت به منوی اصلی', 'menu:home')]]),
  });
});

// -------------------------------------------------------------
// ۶. مأموریت روزانه
// -------------------------------------------------------------
async function showMissionsPanel(ctx, isEdit = false) {
  const data = await requireCountry(ctx);
  if (!data) return;
  const userMissions = await gameService.getUserMissions(ctx.from.id);

  const lines = [
    '🎯 <b>مأموریت‌های روزانه با واریز خودکار</b>',
    '– – – – – – – – – –',
    'با انجام هر مأموریت، پاداش نقدی، سکه شاهی و نفت جایزه <b>به صورت خودکار و آنی</b> به حسابتان واریز می‌شود:\n',
  ];

  const missions = await gameService.getDailyMissions();
  for (const m of missions) {
    const isClaimed = Boolean(userMissions.claimed && userMissions.claimed[m.id]);
    const progressVal = Number(userMissions.progress?.[m.id] || 0);
    const targetVal = Number(m.targetCount || 1);

    const statusBadge = isClaimed
      ? '✅ تکمیل و واریز خودکار شد'
      : `⏳ در حال انجام (${fmtNum(progressVal)} از ${fmtNum(targetVal)} ${m.unit || 'بار'})`;

    const rewardShahi = m.rewardShahi || m.rewardCoin || 1;
    lines.push([
      `• <b>${esc(m.title)}</b> [${statusBadge}]`,
      `  ${esc(m.desc)}`,
      `  🎁 پاداش: <b>${fmtNum(m.rewardCash || 0)}$</b> + <b>${rewardShahi} سکه شاهی</b>${m.rewardOil ? ` + ${fmtNum(m.rewardOil)} بشکه نفت` : ''}`,
      '',
    ].join('\n'));
  }

  lines.push('💡 <i>سیستم به صورت هوشمند پیشرفت شما را ثبت کرده و بلافاصله پس از تکمیل هر ماموریت، پاداش را بدون نیاز به کلیک واریز می‌نماید.</i>');

  const rows = [
    [Markup.button.callback('🔙 بازگشت به منوی اصلی', 'menu:home')],
  ];

  const kb = Markup.inlineKeyboard(rows);
  if (isEdit && ctx.callbackQuery) {
    await ctx.editMessageText(lines.join('\n'), { parse_mode: 'HTML', reply_markup: kb.reply_markup }).catch(() => {});
  } else {
    await ctx.reply(lines.join('\n'), { parse_mode: 'HTML', ...kb });
  }
}

composer.hears(L.mission, async (ctx) => {
  await showMissionsPanel(ctx, false);
});

composer.action(/^msn:claim:(\w+)$/, async (ctx) => {
  await ctx.answerCbQuery('پاداش این ماموریت به محض انجام به صورت خودکار واریز می‌گردد.', { show_alert: true });
});

// -------------------------------------------------------------
// ۷. حساب من
// -------------------------------------------------------------
async function showAccountPanel(ctx, isEdit = false) {
  const u = ctx.state.user;
  const season = await getActiveSeason();
  const own = season ? await getActiveOwnership(u.telegramId, season.id) : null;
  const joinDate = u.joinedAt ? new Date(u.joinedAt) : new Date();
  const daysDiff = Math.max(1, Math.floor((Date.now() - joinDate.getTime()) / (24 * 3600 * 1000)));
  const coins = u.awCoins || 9;

  let countryDisplay = 'ندارید';
  if (own) {
    const state = await gameService.getCountryState(own.countryId, season.id).catch(() => null);
    const flag = countryService.getDynamicFlag(own.country, state || {});
    countryDisplay = `${flag} ${esc(own.country.name)}`;
  }

  const text = [
    '👤 <b>حساب من</b>',
    '– – – – – – – – – –',
    '',
    '⚔️ <b>جنگ‌دیده</b>',
    '',
    'بیش از یک کشور را رهبری کرده‌ای',
    '',
    `✍️ نام ~ <b>${esc(u.displayName)}</b>`,
    `📄 آیدی ~ <code>${u.telegramId}</code>`,
    `💬 یوزرنیم ~ ${u.username ? `@${esc(u.username)}` : 'ندارد'}`,
    `🗓 عضویت از ~ ${joinDate.toISOString().slice(0, 10)}`,
    `⏳ روزهای همراهی ~ ${daysDiff} روز`,
    `🪙 A-W Coin ~ ${coins}  (مجموع ${coins})`,
    '',
    '– – – – – – – – – –',
    '',
    '🏰 <b>امروز</b>',
    '',
    `کشور : ${countryDisplay}`,
    'نقش : 👑 رهبر',
    `سطح : 3  ·  مرز : 100٪`,
    `سیزن : ${season ? esc(season.name) : '۱'}`,
    '',
    '– – – – – – – – – –',
    '',
    '📜 <b>کارنامه</b>',
    '',
    '🗓 سیزن‌های بازی شده ~ 2',
    '🏳️ کشورهای رهبری شده ~ 2',
    '',
    `${season ? esc(season.name) : 'سیزن فعلی'} ← اکنون`,
    countryDisplay,
    'سیزن گذشته',
    '🇨🇾 قبرس',
    '',
    '– – – – – – – – – –',
    '',
    '🎖 <b>نشان‌ها ~ 2</b>',
    '',
    '🔁 <b>بازگشته</b>',
    'بیش از یک سیزن',
    '⚖️ <b>خوشنام</b>',
    'مشروعیت بین‌المللی بالای ۹۵٪',
  ].join('\n');

  const kb = Markup.inlineKeyboard([
    [Markup.button.callback('🔙 بازگشت به منوی اصلی', 'menu:home')],
  ]);

  if (isEdit && ctx.callbackQuery) {
    await ctx.editMessageText(text, { parse_mode: 'HTML', reply_markup: kb.reply_markup }).catch(() => {});
  } else {
    await ctx.reply(text, { parse_mode: 'HTML', ...kb });
  }
}

composer.hears(L.account, async (ctx) => {
  await showAccountPanel(ctx, false);
});

// -------------------------------------------------------------
// ۸. وضعیت کشور من
// -------------------------------------------------------------
async function showStatusPanel(ctx, isEdit = false) {
  const data = await requireCountry(ctx);
  if (!data) return;
  const { season, own } = data;
  const c = own.country;
  const s = await gameService.getCountryState(c.id, season.id);
  const flag = countryService.getDynamicFlag(c, s);

  const govName = s.government === 'dictatorship' ? 'دیکتاتوری 🎖' : s.government === 'monarchy' ? 'پادشاهی 👑' : 'جمهوری 🏛️';
  const relName = s.religion === 'islam' ? 'اسلام ☪️' : s.religion === 'zoroastrian' ? 'زرتشت 🔥' : 'بی‌دین 🚫';

  const text = [
    '🎖 <b>نقش تو ~ 👑 رهبر</b>',
    '',
    `🏛️ <b>${esc(c.name)} ${flag}</b>`,
    '',
    `🏕 سطح توسعه ~ دهکده  (+0% درآمد)`,
    `🟩🟩🟩🟩⬜️⬜️⬜️⬜️⬜️⬜️  تا «شهر کوچک» ~ 260 امتیاز`,
    '',
    `💵 سرمایه ~ <b>${fmtNum(s.treasury)}$</b>`,
    `🔼 درآمد ~ <b>${fmtNum(s.incomeDaily)}$</b> روزانه`,
    `هر 10 دقیقه ${fmtNum(Math.floor(s.incomeDaily / 144))}$ واریز میشه`,
    '',
    `😊 رضایت مردم ~ ${s.satisfaction}%  🟨🟨🟨🟨🟨🟨⬜️⬜️⬜️⬜️`,
    `⚖️ مشروعیت ~ ${s.legitimacy}%  🟩🟩🟩🟩🟩🟩🟩🟩🟩🟩`,
    '',
    '⚔️ <b>قدرت نظامی</b>',
    `⚔️ حمله ~ ${fmtNum(s.military?.attack || 2124)}`,
    `🛡 پدافند ~ ${fmtNum(s.military?.defense || 2459)}`,
    `🪖 زمینی ~ ${fmtNum(s.military?.ground || 74940)}`,
    `💻 سایبری ~ ${s.military?.cyber || 33}`,
    '',
    '🌆 <b>کشور و اقتصاد</b>',
    `👫 جمعیت ~ ${fmtNum(s.population || 7000000)}`,
    `🛢 نفت ~ ${fmtNum(s.oil || 0)} بشکه`,
    `🍞 غذا ~ ${fmtNum(s.food || 3010)} تن (3.0 روز)`,
    `🏠 مسکن ~ ${fmtNum(s.housing || 0)} واحد (+0% رضایت)`,
    `🛢 پالایشگاه ~ سطح ${s.refineryLevel || 2}`,
    `🌐 اینترنت ~ ${s.internet || '2G'}`,
    `🏛️ حکومت ~ ${govName} | ${relName}`,
    '',
    '🛡 <b>دفاع و پیشرفت</b>',
    `🧱 مرز ~ ${fmtNum(s.border?.current || 12500)} / ${fmtNum(s.border?.max || 12500)} (ارتقا ${s.border?.upgrade || '0/10'})`,
    `🛡 محافظت تازه‌واردی ~ فعال، 4 ساعت و 47 دقیقه مانده`,
    `🏚 پناهگاه هسته‌ای ~ ${s.nuclearShelter || 0} (سپر 0%)`,
    `📊 سطح کشور ~ ${s.level || 3} (XP ${s.xp || 0})`,
    '',
    '🪖 <b>نیروهای زمینی</b>',
    `• نفربر زرهی ~ ${fmtNum(s.groundUnits?.apc || 60)}`,
    `• توپخانه 💣 ~ ${fmtNum(s.groundUnits?.artillery || 54)}`,
    `• پیاده‌نظام 👤 ~ ${fmtNum(s.groundUnits?.infantry || 3900)}`,
    `• پهپاد نقطه‌زن 🛸 ~ ${fmtNum(s.groundUnits?.drone || 18)}`,
    `• آرپی‌جی‌زن 🧨 ~ ${fmtNum(s.groundUnits?.rpg || 120)}`,
    `• تانک 🛡 ~ ${fmtNum(s.groundUnits?.tank || 78)}`,
    '',
    '✈️ <b>نیروی هوایی</b>',
    `• F-16 ~ ${fmtNum(s.airUnits?.f16 || 6)}`,
    `• کوثر ~ ${fmtNum(s.airUnits?.kowsar || 3)}`,
    '',
    '🚀 <b>موشک‌ها</b>',
    `• فاتح ۱۱۰ ~ ${fmtNum(s.missiles?.fateh110 || 18)}`,
    '',
    '🛡️ <b>پدافند</b>',
    `• خرداد ۱۵ ~ ${fmtNum(s.airDefense?.khordad15 || 3)}`,
    `• S-300 ~ ${fmtNum(s.airDefense?.s300 || 1)}`,
    '',
    '💻 <b>نیروی سایبری</b>',
    `• اسکریپت‌کیدی 👶 ~ ${s.cyberUnits?.scriptKiddie || 1}`,
    '',
    '🏅 <b>مدال‌ها</b>',
    ...s.medals.map((m) => `• ${m}`),
    '',
    '– – – – – – – – – –',
  ].join('\n');

  const kb = Markup.inlineKeyboard([
    [Markup.button.callback('👑 رفتن به امپراطوری من', 'menu:empire')],
    [Markup.button.callback('🔙 بازگشت به منوی اصلی', 'menu:home')],
  ]);

  if (isEdit && ctx.callbackQuery) {
    await ctx.editMessageText(text, { parse_mode: 'HTML', reply_markup: kb.reply_markup }).catch(() => {});
  } else {
    await ctx.reply(text, { parse_mode: 'HTML', ...kb });
  }
}

composer.hears(L.status, async (ctx) => {
  await showStatusPanel(ctx, false);
});

// -------------------------------------------------------------
// ۹. لیدربورد جهانی
// -------------------------------------------------------------
composer.hears(L.leaderboard, async (ctx) => {
  const text = [
    '🎖️ <b>لیدربورد جهانی</b>',
    '– – – – – – – – – –',
    '',
    '❝ <b>کدوم جدول رو می‌خوای ببینی؟</b> ❞',
    '',
    '– – – – – – – – – –',
  ].join('\n');

  await ctx.reply(text, {
    parse_mode: 'HTML',
    ...leaderboardKeyboard(),
  });
});

composer.action(/^lb:(\w+)$/, async (ctx) => {
  await ctx.answerCbQuery().catch(() => {});
  const tab = ctx.match[1];
  const season = await getActiveSeason();
  if (!season) return ctx.reply('سیزن فعالی وجود ندارد.');

  const ownerships = await listActive(season.id);
  const countryList = await Promise.all(ownerships.map(async (o) => {
    const c = await countryService.get(o.countryId);
    const u = await userService.getById(o.userId);
    const s = await gameService.getCountryState(o.countryId, season.id).catch(() => null);
    return { c, u, s };
  }));

  let title = '🏆 برترین‌های جهان (کل)';
  let rows = [];

  if (tab === 'military') {
    title = '📊 جدول قدرت جهانی';
    countryList.sort((a, b) => (b.s?.military?.attack || 0) - (a.s?.military?.attack || 0));
    rows = countryList.map((x, i) => `${i + 1}. ${x.c.flag} <b>${esc(x.c.name)}</b> (رهبر: ${esc(x.u?.displayName)}) ~ ⚔️ قدرت حمله: ${fmtNum(x.s?.military?.attack || 2124)}`);
  } else if (tab === 'oil') {
    title = '🛢️ قدرت‌های نفتی';
    countryList.sort((a, b) => (b.s?.oil || 0) - (a.s?.oil || 0));
    rows = countryList.map((x, i) => `${i + 1}. ${x.c.flag} <b>${esc(x.c.name)}</b> ~ 🛢 ${fmtNum(x.s?.oil || 0)} بشکه (${x.s?.oilRigs || 5} دکل)`);
  } else if (tab === 'economy') {
    title = '💵 قدرت‌های اقتصادی';
    countryList.sort((a, b) => (b.s?.treasury || 0) - (a.s?.treasury || 0));
    rows = countryList.map((x, i) => `${i + 1}. ${x.c.flag} <b>${esc(x.c.name)}</b> ~ 💵 سرمایه: ${fmtNum(x.s?.treasury || 0)}$`);
  } else if (tab === 'nuclear') {
    title = '☢️ قدرت‌های اتمی';
    rows = countryList.map((x, i) => `${i + 1}. ${x.c.flag} <b>${esc(x.c.name)}</b> ~ 🏚 پناهگاه هسته‌ای: ${x.s?.nuclearShelter || 0}`);
  } else if (tab === 'coin') {
    title = '🪙 برترین‌های A-W Coin';
    countryList.sort((a, b) => (b.u?.awCoins || 9) - (a.u?.awCoins || 9));
    rows = countryList.map((x, i) => `${i + 1}. 👑 <b>${esc(x.u?.displayName)}</b> (${x.c.flag} ${esc(x.c.name)}) ~ 🪙 ${x.u?.awCoins || 9} سکه`);
  } else if (tab === 'hall') {
    title = '🏆 تالار افتخارات';
    rows = [
      '🥇 فاتح سیزن ۱۱: قبرس 🇨🇾 (رهبر: MƦ.ᏕilenϮ)',
      '🥈 ابرقدرت نظامی: لیبی 🇱🇾 (رهبر: TF)',
      '🥉 امپراطور نفت: عربستان 🇸🇦',
    ];
  } else {
    title = '🏆 برترین‌های جهان (کل)';
    rows = countryList.map((x, i) => `${i + 1}. ${x.c.flag} <b>${esc(x.c.name)}</b> — 👑 ${esc(x.u?.displayName)} (امتیاز توسعه: ${fmtNum(x.s?.xp || 260)})`);
  }

  const out = [
    `🎖️ <b>${title}</b>`,
    '– – – – – – – – – –',
    rows.length ? rows.join('\n') : 'هنوز رکوردی در این جدول ثبت نشده است.',
    '',
    '– – – – – – – – – –',
  ].join('\n');

  await ctx.reply(out, { parse_mode: 'HTML' });
});

// -------------------------------------------------------------
// ۱۰. شکایات و پشتیبانی
// -------------------------------------------------------------
composer.hears([L.complaints, L.support], async (ctx) => {
  await ctx.reply('⚖️ <b>بخش ثبت شکایات و پشتیبانی</b>\n– – – – – – – – – –\nاگر تخلفی از سوی کشوری مشاهده کردید یا خطایی در بازی رخ داده است، می‌توانید با متن و ارسال مدرک شکایت خود را ثبت کنید.', {
    parse_mode: 'HTML',
    ...Markup.inlineKeyboard([
      [Markup.button.callback('✍️ ثبت شکایت جدید با مدرک', 'cmp:new')],
    ]),
  });
});

composer.action('cmp:new', async (ctx) => {
  await ctx.answerCbQuery().catch(() => {});
  await userService.setFlow(ctx.from.id, 'game:complaint:target');
  await ctx.reply('📝 نام کشوری که از آن شکایت دارید را بنویسید (یا بنویسید «بازی»):\nلغو: /cancel');
});

registerFlow('game:complaint:target', async (ctx) => {
  if (!ctx.message.text) return ctx.reply('لطفاً نام کشور را متنی ارسال کنید.');
  const target = ctx.message.text.trim();
  await userService.setFlow(ctx.from.id, 'game:complaint:text', { target });
  await ctx.reply('📄 لطفاً شرح شکایت را بنویسید (می‌توانید عکس مدرک را هم پیوست کنید):');
});

registerFlow('game:complaint:text', async (ctx, data) => {
  const text = ctx.message.text ? ctx.message.text.trim() : 'بدون متن';
  let photoId = null;
  if (ctx.message.photo && ctx.message.photo.length) {
    photoId = ctx.message.photo[ctx.message.photo.length - 1].file_id;
  }

  const user = ctx.state.user;
  const complaint = await gameService.submitComplaint({
    userId: user.telegramId,
    userDisplayName: user.displayName,
    username: user.username,
    againstCountry: data.target,
    text,
    photoFileId: photoId,
  });

  const alertText = [
    '⚖️ <b>شکایت جدید ثبت شد!</b>',
    `👤 شاکی: ${esc(user.displayName)} (@${esc(user.username || '—')})`,
    `🎯 علیه: <b>${esc(data.target)}</b>`,
    `📝 شرح: ${esc(text)}`,
    `🆔 کد شکایت: <code>${complaint.id}</code>`,
  ].join('\n');
  await notifications.notifyAdmins(ctx.telegram, alertText, {
    reply_markup: Markup.inlineKeyboard([
      [Markup.button.callback('✅ تأیید شکایت', `cmp:approve:${complaint.id}`), Markup.button.callback('❌ رد شکایت', `cmp:reject:${complaint.id}`)],
    ]).reply_markup,
  }, photoId);

  await userService.clearFlow(ctx.from.id);
  await ctx.reply('✅ شکایت شما با موفقیت ثبت شد و به داوری مدیریت ارسال گردید.', mainMenu(ctx.state.isAdmin));
});

// تصمیم‌گیری روی شکایت؛ فقط شناسه‌های ADMIN_IDS مجاز هستند.
composer.action(/^cmp:(approve|reject):(.+)$/, async (ctx) => {
  if (!config.adminIds.includes(ctx.from.id)) {
    return ctx.answerCbQuery('فقط ادمین مجاز به بررسی شکایت است.', { show_alert: true }).catch(() => {});
  }
  await ctx.answerCbQuery().catch(() => {});
  const decision = ctx.match[1] === 'approve' ? 'approved' : 'rejected';
  const complaintId = ctx.match[2];
  const ref = col('complaints').doc(complaintId);
  const snap = await ref.get();
  if (!snap.exists) return ctx.reply('شکایت یافت نشد.');
  const complaint = snap.data();
  if (complaint.status !== 'pending') return ctx.reply(`این شکایت قبلاً بررسی شده است (وضعیت: ${complaint.status}).`);
  await ref.set({ status: decision, reviewedAt: new Date(), reviewedBy: ctx.from.id }, { merge: true });
  const verdict = decision === 'approved' ? '✅ شکایت شما توسط مدیریت تأیید شد و برای پیگیری ثبت گردید.' : '❌ شکایت شما توسط مدیریت رد شد.';
  const delivered = await notifications.safeSend(ctx.telegram, complaint.userId, verdict);
  await ctx.reply(`${decision === 'approved' ? '✅ شکایت تأیید شد.' : '❌ شکایت رد شد.'}\n${delivered ? 'نتیجه به پیام خصوصی شاکی ارسال شد.' : 'ارسال پیام خصوصی موفق نبود؛ احتمالاً کاربر ربات را شروع نکرده است.'}`);
});

// -------------------------------------------------------------
// ۱۱. سوییچ ادمین
// -------------------------------------------------------------
// =============================================================
// بخش ۵. سامانه اتحادهای بین‌المللی (ALLIANCE SYSTEM)
// =============================================================
async function showAlliancePanel(ctx, isEdit = false) {
  const data = await requireCountry(ctx);
  if (!data) return;
  const { own, season } = data;
  const ally = await allianceService.getCountryAlliance(own.countryId, season.id);
  const state = await gameService.getCountryState(own.countryId, season.id);
  const flag = countryService.getDynamicFlag(own.country, state);

  if (!ally) {
    const text = [
      `🛡️ <b>مرکز اتحادهای استراتژیک بین‌الملل — ${esc(own.country.name)} ${flag}</b>`,
      '– – – – – – – – – –',
      'کشور شما در حال حاضر عضو هیچ اتحادی نیست.',
      `💰 هزینه تاسیس یک اتحاد قدرتمند: <b>۱,۰۰۰,۰۰۰,۰۰۰$</b> (یک میلیارد دلار)`,
      `💵 موجودی خزانه شما: <b>${fmtNum(state.treasury)}$</b>`,
      '',
      '👇 می‌توانید اتحاد جدیدی پایه‌گذاری کنید یا به اتحادهای موجود بپیوندید:',
    ].join('\n');

    const kb = Markup.inlineKeyboard([
      [Markup.button.callback('🟢 👑 تأسیس اتحاد جدید (1,000,000,000 $)', 'ally:create_start')],
      [Markup.button.callback('📥 دعوت‌نامه‌های عضویت من', 'ally:my_invites')],
      [Markup.button.callback('🌐 لیست اتحادهای فعال سیزن', 'ally:list_all')],
      [Markup.button.callback('🔴 🔙 بازگشت به امپراطوری', 'emp:home')],
    ]);

    if (isEdit && ctx.callbackQuery) {
      await ctx.editMessageText(text, { parse_mode: 'HTML', reply_markup: kb.reply_markup }).catch(() => {});
    } else {
      await ctx.reply(text, { parse_mode: 'HTML', ...kb });
    }
    return;
  }

  // اگر کشور عضو اتحاد است:
  const isLeader = ally.leaderCountryId === String(own.countryId);
  const leaderCountry = await countryService.get(ally.leaderCountryId);
  const leaderName = leaderCountry ? `${leaderCountry.flag} ${leaderCountry.name}` : 'تعیین‌نشده';

  const text = [
    `🛡️ <b>${ally.logo || '🛡️'} ستاد فرماندهی اتحاد ${esc(ally.name)}</b>`,
    '– – – – – – – – – –',
    `👑 کشور رهبر و موسس: <b>${leaderName}</b>`,
    `🏷 سمت شما: <b>${isLeader ? '👑 مالک و فرمانده کل اتحاد' : '🎖️ کشور عضو رسمی اتحاد'}</b>`,
    `👥 تعداد کشورهای عضو: <b>${ally.memberCountryIds.length} کشور</b>`,
    '',
    isLeader
      ? '👇 به عنوان مالک اتحاد، از کلیدهای مدیریتی زیر استفاده کنید:'
      : '👇 گزینه‌های اتحاد در دسترس شما:',
  ].join('\n');

  let rows = [];
  if (isLeader) {
    rows = [
      [Markup.button.callback('🟢 ➕ ارسال درخواست عضویت به کشورها', 'ally:invite_picker')],
      [Markup.button.callback('🔴 ⚔️ اعلان جنگ گروهی (کشور یا اتحاد)', 'ally:group_war')],
      [Markup.button.callback('🟣 📜 ارسال بیانیه گروهی (تایید ۷۵٪ اعضا)', 'ally:stmt_prompt')],
      [Markup.button.callback('👥 📋 مشاهده اعضا و آمار اتحاد', 'ally:members')],
      [Markup.button.callback('🔴 🚪 انحلال یا خروج از اتحاد', 'ally:leave')],
      [Markup.button.callback('⚪ 🔙 بازگشت به امپراطوری', 'emp:home')],
    ];
  } else {
    rows = [
      [Markup.button.callback('👥 📋 مشاهده کشورهای عضو اتحاد', 'ally:members')],
      [Markup.button.callback('📜 آرشیو و بیانیه‌های اتحاد', 'ally:stmt_list')],
      [Markup.button.callback('🔴 🚪 خروج از اتحاد', 'ally:leave')],
      [Markup.button.callback('⚪ 🔙 بازگشت به امپراطوری', 'emp:home')],
    ];
  }

  const kb = Markup.inlineKeyboard(rows);
  if (isEdit && ctx.callbackQuery) {
    await ctx.editMessageText(text, { parse_mode: 'HTML', reply_markup: kb.reply_markup }).catch(() => {});
  } else {
    await ctx.reply(text, { parse_mode: 'HTML', ...kb });
  }
}

composer.action('emp:alliance', async (ctx) => {
  await ctx.answerCbQuery().catch(() => {});
  await showAlliancePanel(ctx, true);
});
composer.hears(['اتحاد من 🤝', 'اتحاد', 'اتحاد من'], async (ctx) => {
  await showAlliancePanel(ctx, false);
});

// ۱. آغاز تاسیس اتحاد
composer.action('ally:create_start', async (ctx) => {
  await ctx.answerCbQuery().catch(() => {});
  const data = await requireCountry(ctx);
  if (!data) return;
  const state = await gameService.getCountryState(data.own.countryId, data.season.id);

  if ((state.treasury || 0) < 1000000000) {
    return ctx.reply(`❌ <b>موجودی ناکافی!</b>\nهزینه ساخت اتحاد ۱,۰۰۰,۰۰۰,۰۰۰$ است و خزانه شما ${fmtNum(state.treasury)}$ دارد.`, {
      parse_mode: 'HTML',
      ...Markup.inlineKeyboard([[Markup.button.callback('🔙 بازگشت', 'emp:alliance')]]),
    });
  }

  await userService.setFlow(ctx.from.id, 'ally:create:get_name', {});
  await ctx.reply([
    '🛡️ <b>مرحله اول: انتخاب نام اتحاد</b>',
    '– – – – – – – – – –',
    'هزینه ساخت ۱ میلیارد دلار از خزانه کسر خواهد شد.',
    'لطفاً <b>نام اتحاد</b> خود را ارسال کنید (بین ۳ تا ۵۰ کاراکتر):',
    'مثال: <i>اتحادیه دفاعی خاورمیانه</i> یا <i>محور متفقین</i>',
    '',
    'جهت لغو: /cancel',
  ].join('\n'), { parse_mode: 'HTML' });
});

registerFlow('ally:create:get_name', async (ctx, data, user) => {
  const name = (ctx.message.text || '').trim();
  if (name.length < 3 || name.length > 50) {
    return ctx.reply('⚠️ نام اتحاد باید بین ۳ تا ۵۰ کاراکتر باشد. لطفاً دوباره ارسال کنید یا دستور /cancel را بزنید.');
  }

  await userService.setFlow(ctx.from.id, 'ally:create:get_logo', { name });
  await ctx.reply([
    `✅ نام اتحاد «<b>${esc(name)}</b>» تایید شد!`,
    '– – – – – – – – – –',
    '🖼️ <b>مرحله دوم: تعیین لوگو و نشان اتحاد</b>',
    'اکنون لطفاً <b>لوگوی اتحاد</b> را ارسال کنید:',
    '• می‌توانید یک <b>عکس یا تصویر</b> بفرستید.',
    '• یا یک <b>ایموجی یا نماد متنی</b> (مثلاً: 🦅، 🛡️، ⚡، 👑) بفرستید.',
    '',
    'جهت لغو: /cancel',
  ].join('\n'), { parse_mode: 'HTML' });
});

registerFlow('ally:create:get_logo', async (ctx, data, user) => {
  let logo = '🛡️';
  if (ctx.message.photo && ctx.message.photo.length) {
    logo = ctx.message.photo[ctx.message.photo.length - 1].file_id;
  } else if (ctx.message.text) {
    logo = ctx.message.text.trim().slice(0, 30);
  }

  const season = await getActiveSeason();
  const own = season ? await getActiveOwnership(user.telegramId, season.id) : null;
  if (!own) return ctx.reply('کشوری یافت نشد.');

  try {
    const res = await allianceService.createAlliance({
      leaderCountryId: own.countryId,
      leaderUserId: user.telegramId,
      seasonId: season.id,
      name: data.name,
      logo,
    });

    await userService.clearFlow(ctx.from.id);

    // انتشار اعلان رسمی در کانال تلگرام
    const channelText = [
      '🛡️ <b>تأسیس رسمی اتحاد قدرتمند بین‌المللی!</b>',
      '– – – – – – – – – –',
      `نام اتحاد: <b>${esc(data.name)}</b>`,
      `🌍 کشور پایه‌گذار: <b>${own.country.flag} ${esc(own.country.name)}</b>`,
      `👑 رهبر اتحاد: <b>${esc(user.displayName)}</b>`,
      '💰 هزینه تأسیس ۱,۰۰۰,۰۰۰,۰۰۰$ از خزانه کشور واریز گردید.',
      '',
      '🌐 این اتحاد از این پس در معادلات جنگی، دفاعی و بیانیه‌های رسمی جهان نقش‌آفرینی خواهد کرد.',
    ].join('\n');

    await notifications.publishToChannel(ctx.telegram, 'alliance_news', channelText).catch(() => {});

    await ctx.reply(`🎉 <b>اتحاد «${esc(data.name)}» با موفقیت تأسیس گردید!</b>\nمبلغ ۱ میلیارد دلار از خزانه کسر شد و اعلان رسمی در کانال منتشر گردید.`, {
      parse_mode: 'HTML',
    });

    await showAlliancePanel(ctx, false);
  } catch (err) {
    await ctx.reply(`⚠️ ${err.message}`);
  }
});

// مشاهده اعضای اتحاد
composer.action('ally:members', async (ctx) => {
  await ctx.answerCbQuery().catch(() => {});
  const data = await requireCountry(ctx);
  if (!data) return;
  const ally = await allianceService.getCountryAlliance(data.own.countryId, data.season.id);
  if (!ally) return ctx.reply('شما عضو اتحادی نیستید.');

  const countries = await countryService.getMany(ally.memberCountryIds);
  const lines = [
    `🛡️ <b>فهرست کشورهای عضو اتحاد ${ally.logo} ${esc(ally.name)}</b>`,
    '– – – – – – – – – –',
  ];

  for (const cid of ally.memberCountryIds) {
    const c = countries[cid];
    const isL = cid === ally.leaderCountryId;
    if (c) lines.push(`• ${isL ? '👑 [رهبر]' : '🎖️'} ${c.flag} <b>${esc(c.name)}</b>`);
  }

  await ctx.editMessageText(lines.join('\n'), {
    parse_mode: 'HTML',
    ...Markup.inlineKeyboard([[Markup.button.callback('🔙 بازگشت به اتحاد', 'emp:alliance')]]),
  }).catch(() => {});
});

// ارسال دعوت‌نامه به کشورها توسط مالک
composer.action('ally:invite_picker', async (ctx) => {
  await ctx.answerCbQuery().catch(() => {});
  const data = await requireCountry(ctx);
  if (!data) return;
  const ally = await allianceService.getCountryAlliance(data.own.countryId, data.season.id);
  if (!ally || ally.leaderCountryId !== String(data.own.countryId)) {
    return ctx.reply('فقط رهبر اتحاد اجازه ارسال دعوت‌نامه دارد.');
  }

  const activeOwnerships = await listActive(data.season.id);
  const rows = [];
  for (const o of activeOwnerships) {
    if (ally.memberCountryIds.includes(String(o.countryId))) continue;
    const c = await countryService.get(o.countryId);
    if (c) {
      rows.push([Markup.button.callback(`📩 ارسال دعوت به: ${c.flag} ${c.name}`, `ally:send_inv:${c.id}`)]);
    }
  }

  if (!rows.length) {
    return ctx.editMessageText('🌍 کشور آزادی در سیزن برای دعوت به اتحاد یافت نشد.', {
      ...Markup.inlineKeyboard([[Markup.button.callback('🔙 بازگشت', 'emp:alliance')]]),
    });
  }

  rows.push([Markup.button.callback('🔙 بازگشت به اتحاد', 'emp:alliance')]);

  await ctx.editMessageText('📩 <b>کشور مورد نظر را جهت ارسال دعوت‌نامه رسمی عضویت انتخاب کنید:</b>', {
    parse_mode: 'HTML',
    reply_markup: Markup.inlineKeyboard(rows).reply_markup,
  }).catch(() => {});
});

composer.action(/^ally:send_inv:(.+)$/, async (ctx) => {
  const targetCid = ctx.match[1];
  const data = await requireCountry(ctx);
  if (!data) return;
  const ally = await allianceService.getCountryAlliance(data.own.countryId, data.season.id);
  if (!ally) return;

  try {
    const inv = await allianceService.inviteCountry({
      allianceId: ally.id,
      fromCountryId: data.own.countryId,
      fromUserId: ctx.from.id,
      targetCountryId: targetCid,
      seasonId: data.season.id,
    });

    const targetCountry = await countryService.get(targetCid);
    const activeOwnerships = await listActive(data.season.id);
    const targetOwner = activeOwnerships.find((o) => String(o.countryId) === String(targetCid));

    if (targetOwner) {
      await notifications.safeSend(ctx.telegram, targetOwner.userId, [
        `🛡️ <b>دعوت‌نامه رسمی عضویت در اتحاد!</b>`,
        '– – – – – – – – – –',
        `اتحاد قدرتمند <b>${ally.logo} ${esc(ally.name)}</b> به رهبری ${esc(data.own.country.name)} از کشور شما برای پیوستن به این پیمان نظامی-سیاسی دعوت نموده است.`,
        '',
        'آیا مایل به پذیرش عضویت در این اتحاد هستید؟',
      ].join('\n'), Markup.inlineKeyboard([
        [Markup.button.callback('🟢 ✅ قبول عضویت در اتحاد', `ally:acc_inv:${inv.id}`)],
        [Markup.button.callback('🔴 ❌ رد دعوت‌نامه', `ally:rej_inv:${inv.id}`)],
      ]));
    }

    await ctx.answerCbQuery(`✅ دعوت‌نامه برای رهبر ${targetCountry.name} ارسال شد.`, { show_alert: true });
    await showAlliancePanel(ctx, true);
  } catch (err) {
    await ctx.answerCbQuery(err.message, { show_alert: true });
  }
});

// پذیرش دعوت‌نامه توسط کشور مقصد
composer.action(/^ally:acc_inv:(.+)$/, async (ctx) => {
  const invId = ctx.match[1];
  const data = await requireCountry(ctx);
  if (!data) return;

  try {
    const res = await allianceService.acceptInvitation({
      invitationId: invId,
      targetCountryId: data.own.countryId,
    });

    // انتشار در کانال
    const channelText = [
      '🤝 <b>گسترش اتحاد و عضویت کشور جدید!</b>',
      '– – – – – – – – – –',
      `کشور <b>${data.own.country.flag} ${esc(data.own.country.name)}</b> رسماً به اتحاد <b>${res.alliance.logo} ${esc(res.alliance.name)}</b> پیوست.`,
      `👥 تعداد اعضای اتحاد اکنون: <b>${res.alliance.memberCountryIds.length} کشور</b>`,
    ].join('\n');
    await notifications.publishToChannel(ctx.telegram, 'alliance_news', channelText).catch(() => {});

    await ctx.reply(`🎉 شما با موفقیت به اتحاد «<b>${esc(res.alliance.name)}</b>» پیوستید!`, { parse_mode: 'HTML' });
    await showAlliancePanel(ctx, false);
  } catch (err) {
    await ctx.answerCbQuery(err.message, { show_alert: true });
  }
});

composer.action(/^ally:rej_inv:(.+)$/, async (ctx) => {
  const invId = ctx.match[1];
  const data = await requireCountry(ctx);
  if (!data) return;
  await allianceService.rejectInvitation({ invitationId: invId, targetCountryId: data.own.countryId }).catch(() => {});
  await ctx.answerCbQuery('❌ دعوت‌نامه رد شد.', { show_alert: true });
  await ctx.editMessageText('❌ دعوت‌نامه عضویت در اتحاد رد شد.').catch(() => {});
});

// خروج از اتحاد
composer.action('ally:leave', async (ctx) => {
  await ctx.answerCbQuery().catch(() => {});
  const data = await requireCountry(ctx);
  if (!data) return;
  const ally = await allianceService.getCountryAlliance(data.own.countryId, data.season.id);
  if (!ally) return;

  const isLeader = ally.leaderCountryId === String(data.own.countryId);
  const msg = isLeader
    ? '⚠️ <b>توجه:</b> شما رهبر اتحاد هستید. در صورت خروج شما، اگر عضو دیگری نباشد اتحاد منحل می‌شود؛ در غیر اینصورت رهبری به عضو بعدی منتقل خواهد شد. آیا مطمئنید؟'
    : '⚠️ آیا از خروج از این اتحاد اطمینان دارید؟';

  await ctx.editMessageText(msg, {
    parse_mode: 'HTML',
    ...Markup.inlineKeyboard([
      [Markup.button.callback('🔴 بله، خارج شو', 'ally:leave_confirm')],
      [Markup.button.callback('⚪ انصراف', 'emp:alliance')],
    ]),
  }).catch(() => {});
});

composer.action('ally:leave_confirm', async (ctx) => {
  const data = await requireCountry(ctx);
  if (!data) return;
  const ally = await allianceService.getCountryAlliance(data.own.countryId, data.season.id);
  if (!ally) return;

  const res = await allianceService.leaveAlliance({
    allianceId: ally.id,
    countryId: data.own.countryId,
    seasonId: data.season.id,
  });

  await ctx.answerCbQuery(res.dissolved ? 'اتحاد منحل شد.' : 'از اتحاد خارج شدید.', { show_alert: true });
  await showAlliancePanel(ctx, true);
});

// اعلان جنگ گروهی توسط اتحاد
composer.action('ally:group_war', async (ctx) => {
  await ctx.answerCbQuery().catch(() => {});
  const data = await requireCountry(ctx);
  if (!data) return;
  const ally = await allianceService.getCountryAlliance(data.own.countryId, data.season.id);
  if (!ally || ally.leaderCountryId !== String(data.own.countryId)) {
    return ctx.reply('فقط رهبر اتحاد مجاز به اعلان جنگ گروهی است.');
  }

  await ctx.editMessageText([
    '⚔️ <b>اعلان جنگ گروهی اتحاد</b>',
    '– – – – – – – – – –',
    'تمام اعضای اتحاد در این عملیات هماهنگ خواهند شد. هدف خود را انتخاب کنید:',
  ].join('\n'), {
    parse_mode: 'HTML',
    ...Markup.inlineKeyboard([
      [Markup.button.callback('🎯 اعلان جنگ به یک کشور منفرد', 'ally:war_target_country')],
      [Markup.button.callback('🛡️ اعلان جنگ به یک اتحاد دیگر', 'ally:war_target_alliance')],
      [Markup.button.callback('🔙 بازگشت به اتحاد', 'emp:alliance')],
    ]),
  }).catch(() => {});
});

composer.action('ally:war_target_country', async (ctx) => {
  await ctx.answerCbQuery().catch(() => {});
  const data = await requireCountry(ctx);
  if (!data) return;
  const ally = await allianceService.getCountryAlliance(data.own.countryId, data.season.id);
  const activeOwnerships = await listActive(data.season.id);

  const targets = activeOwnerships.filter((o) => !ally.memberCountryIds.includes(String(o.countryId)));
  const rows = [];
  for (const t of targets.slice(0, 10)) {
    const c = await countryService.get(t.countryId);
    if (c) rows.push([Markup.button.callback(`🎯 هدف: ${c.flag} ${c.name}`, `ally:fire_war_c:${c.id}`)]);
  }
  rows.push([Markup.button.callback('🔙 بازگشت', 'ally:group_war')]);

  await ctx.editMessageText('🎯 <b>کشور مورد هدف برای اعلام جنگ گروهی اتحاد:</b>', {
    parse_mode: 'HTML',
    reply_markup: Markup.inlineKeyboard(rows).reply_markup,
  }).catch(() => {});
});

composer.action('ally:war_target_alliance', async (ctx) => {
  await ctx.answerCbQuery().catch(() => {});
  const data = await requireCountry(ctx);
  if (!data) return;
  const ally = await allianceService.getCountryAlliance(data.own.countryId, data.season.id);
  const allAllies = await allianceService.listAlliances(data.season.id);
  const targets = allAllies.filter((a) => a.id !== ally.id);

  if (!targets.length) {
    return ctx.editMessageText('🌍 اتحاد رقیب دیگری در این سیزن فعال نیست.', {
      ...Markup.inlineKeyboard([[Markup.button.callback('🔙 بازگشت', 'ally:group_war')]]),
    });
  }

  const rows = targets.map((a) => [Markup.button.callback(`🛡️ اعلان جنگ به: ${a.logo || '🛡️'} ${a.name}`, `ally:fire_war_a:${a.id}`)]);
  rows.push([Markup.button.callback('🔙 بازگشت', 'ally:group_war')]);

  await ctx.editMessageText('⚔️ <b>اتحاد هدف را برای اعلام جنگ بلوکی و همه‌جانبه انتخاب کنید:</b>', {
    parse_mode: 'HTML',
    reply_markup: Markup.inlineKeyboard(rows).reply_markup,
  }).catch(() => {});
});

composer.action(/^ally:fire_war_([ca]):(.+)$/, async (ctx) => {
  const [kind, targetId] = [ctx.match[1], ctx.match[2]];
  const data = await requireCountry(ctx);
  if (!data) return;
  const ally = await allianceService.getCountryAlliance(data.own.countryId, data.season.id);
  if (!ally) return;

  let targetName = '';
  if (kind === 'c') {
    const c = await countryService.get(targetId);
    targetName = c ? `${c.flag} ${c.name}` : 'کشور هدف';
  } else {
    const a = await allianceService.getAlliance(targetId);
    targetName = a ? `اتحاد ${a.logo} ${a.name}` : 'اتحاد هدف';
  }

  // انتشار در کانال رسمی
  const channelText = [
    '⚔️ <b>اعلان جنگ گروهی اتحاد!</b>',
    '– – – – – – – – – –',
    `اتحاد <b>${ally.logo} ${esc(ally.name)}</b> به رهبری ${esc(data.own.country.name)} رسماً علیه <b>${esc(targetName)}</b> اعلان جنگ همه‌جانبه نمود!`,
    `🪖 کلیه کشورهای عضو این اتحاد در حالت آماده‌باش کامل قرار گرفتند.`,
  ].join('\n');

  await notifications.publishToChannel(ctx.telegram, 'war_news', channelText).catch(() => {});
  await ctx.reply(`⚔️ <b>اعلان جنگ گروهی اتحاد علیه ${esc(targetName)} در کانال رسمی منتشر شد!</b>`, { parse_mode: 'HTML' });
  await showAlliancePanel(ctx, false);
});

// بیانیه گروهی اتحاد با تایید ۷۵٪
composer.action('ally:stmt_prompt', async (ctx) => {
  await ctx.answerCbQuery().catch(() => {});
  const data = await requireCountry(ctx);
  if (!data) return;
  const ally = await allianceService.getCountryAlliance(data.own.countryId, data.season.id);
  if (!ally || ally.leaderCountryId !== String(data.own.countryId)) {
    return ctx.reply('فقط رهبر اتحاد مجاز به ثبت پیش‌نویس بیانیه است.');
  }

  await userService.setFlow(ctx.from.id, 'ally:statement_text', { allianceId: ally.id });
  await ctx.reply([
    '📜 <b>صدور بیانیه گروهی اتحاد</b>',
    '– – – – – – – – – –',
    'طبق مقررات اتحاد، این بیانیه در صورتی در کانال رسمی منتشر می‌شود که حداقل <b>۷۵٪ از اعضای اتحاد</b> با آن موافقت کنند.',
    'لطفاً متن بیانیه خود را ارسال کنید:',
    '',
    'جهت انصراف: /cancel',
  ].join('\n'), { parse_mode: 'HTML' });
});

registerFlow('ally:statement_text', async (ctx, data, user) => {
  let photoFileId = data.photoFileId || null;
  if (ctx.message.photo && ctx.message.photo.length) {
    const highest = ctx.message.photo[ctx.message.photo.length - 1];
    photoFileId = highest.file_id;
  } else if (ctx.message.document && ctx.message.document.mime_type && ctx.message.document.mime_type.startsWith('image/')) {
    photoFileId = ctx.message.document.file_id;
  }

  const rawText = (ctx.message.text || ctx.message.caption || '').trim();
  if (!rawText && photoFileId) {
    await userService.setFlow(ctx.from.id, 'ally:statement_text', { allianceId: data.allianceId, photoFileId });
    return ctx.reply('📸 <b>تصویر بیانیه اتحاد دریافت شد!</b>\nاکنون متن بیانیه را بنویسید و بفرستید:\n(لغو: /cancel)');
  }

  if (rawText.length < 5) return ctx.reply('متن بیانیه باید حداقل ۵ کاراکتر باشد. لغو: /cancel');
  const text = rawText.slice(0, 700);

  const season = await getActiveSeason();
  const own = season ? await getActiveOwnership(user.telegramId, season.id) : null;
  if (!own) return;

  try {
    const stmt = await allianceService.createGroupStatement({
      allianceId: data.allianceId,
      countryId: own.countryId,
      seasonId: season.id,
      text,
      photoFileId,
    });

    await userService.clearFlow(ctx.from.id);

    if (stmt.status === 'approved') {
      // اگر اتحاد ۱ عضو دارد، فوراً تایید و منتشر می‌شود
      const ally = await allianceService.getAlliance(data.allianceId);
      const channelText = [
        `📜 <b>بیانیه مشترک و رسمی اتحاد ${ally.logo} ${esc(ally.name)}</b>`,
        '– – – – – – – – – –',
        `« <i>${esc(text)}</i> »`,
        '',
        '⚖️ این بیانیه با اجماع و تأیید اعضای اتحاد در کانال منتشر گردید.',
      ].join('\n');
      if (photoFileId) {
        await notifications.publishPhotoToChannel(ctx.telegram, 'alliance_news', photoFileId, channelText).catch(async () => {
          await notifications.publishToChannel(ctx.telegram, 'alliance_news', channelText).catch(() => {});
        });
      } else {
        await notifications.publishToChannel(ctx.telegram, 'alliance_news', channelText).catch(() => {});
      }
      await ctx.reply('🎉 <b>بیانیه اتحاد با تایید ۱۰۰٪ فورا در کانال رسمی منتشر گردید!</b>', { parse_mode: 'HTML' });
    } else {
      // ارسال رای‌گیری به سایر اعضا
      const ally = await allianceService.getAlliance(data.allianceId);
      const activeOwnerships = await listActive(season.id);

      for (const cid of ally.memberCountryIds) {
        if (cid === String(own.countryId)) continue;
        const o = activeOwnerships.find((x) => String(x.countryId) === String(cid));
        if (o) {
          await notifications.safeSend(ctx.telegram, o.userId, [
            `📜 <b>رای‌گیری بیانیه گروهی اتحاد ${ally.name}</b>`,
            '– – – – – – – – – –',
            `« <i>${esc(text)}</i> »`,
            '',
            '⚖️ جهت انتشار رسمی این بیانیه در کانال، نیاز به <b>۷۵٪ موافقت اعضا</b> است.',
            'رای شما چیست؟',
          ].join('\n'), Markup.inlineKeyboard([
            [Markup.button.callback('🟢 ✅ موافقم (تایید انتشار)', `ally:v_stmt:${stmt.id}:yes`)],
            [Markup.button.callback('🔴 ❌ مخالفم (رد بیانیه)', `ally:v_stmt:${stmt.id}:no`)],
          ]));
        }
      }

      await ctx.reply('📨 <b>پیش‌نویس بیانیه ثبت شد و برای رای‌گیری به اعضای اتحاد ارسال گردید.</b>\nبه محض رسیدن آرا به ۷۵٪، بیانیه در کانال منتشر خواهد شد.', { parse_mode: 'HTML' });
    }
  } catch (err) {
    await ctx.reply(`⚠️ ${err.message}`);
  }
});

composer.action(/^ally:v_stmt:(.+):(yes|no)$/, async (ctx) => {
  const [stmtId, vote] = [ctx.match[1], ctx.match[2]];
  const data = await requireCountry(ctx);
  if (!data) return;

  try {
    const res = await allianceService.voteGroupStatement({
      statementId: stmtId,
      countryId: data.own.countryId,
      approve: vote === 'yes',
    });

    await ctx.answerCbQuery(vote === 'yes' ? '✅ رای موافق شما ثبت شد.' : '❌ رای مخالف ثبت شد.', { show_alert: true });

    if (res.isApproved) {
      const channelText = [
        `📜 <b>بیانیه مشترک و رسمی اتحاد ${res.allianceLogo || '🛡️'} ${esc(res.allianceName)}</b>`,
        '– – – – – – – – – –',
        `« <i>${esc(res.text)}</i> »`,
        '',
        `⚖️ این بیانیه با موافقت <b>${Math.round(res.approvalPercent)}٪ اعضای اتحاد</b> رسماً در کانال منتشر گردید.`,
      ].join('\n');
      if (res.photoFileId) {
        await notifications.publishPhotoToChannel(ctx.telegram, 'alliance_news', res.photoFileId, channelText).catch(async () => {
          await notifications.publishToChannel(ctx.telegram, 'alliance_news', channelText).catch(() => {});
        });
      } else {
        await notifications.publishToChannel(ctx.telegram, 'alliance_news', channelText).catch(() => {});
      }
      await ctx.editMessageText('🎉 <b>بیانیه اتحاد به حد نصاب ۷۵٪ رسید و در کانال رسمی منتشر شد!</b>', { parse_mode: 'HTML' }).catch(() => {});
    } else {
      await ctx.editMessageText(`🗳️ رای شما ثبت شد. میزان موافقت کنونی اعضا: ${Math.round(res.approvalPercent || 0)}٪`).catch(() => {});
    }
  } catch (err) {
    await ctx.answerCbQuery(err.message, { show_alert: true });
  }
});

// =============================================================
// بخش ۶. سامانه تجارت بین‌الملل (TRADE SYSTEM)
// =============================================================
async function showTradeHub(ctx, isEdit = false) {
  const data = await requireCountry(ctx);
  if (!data) return;
  const { own, season } = data;
  const state = await gameService.getCountryState(own.countryId, season.id);
  const flag = countryService.getDynamicFlag(own.country, state);

  const text = [
    `🤝 <b>سامانه بازرگانی و تجارت بین‌الملل — ${esc(own.country.name)} ${flag}</b>`,
    '– – – – – – – – – –',
    'در این سامانه می‌توانید با انتخاب یک کشور دیگر، منابع خود را با یکدیگر مبادله کنید:',
    `💵 خزانه نقدی: <b>${fmtNum(state.treasury)}$</b> | 🛢 نفت: <b>${fmtNum(state.oil || 0)} بشکه</b>`,
    `🪖 تانک و ادوات: <b>${fmtNum(state.groundUnits?.tank || 0)} دستگاه</b> | 🔬 امتیاز پژوهش: <b>${state.scoreToNext || 100}</b>`,
    '',
    'اقدام مورد نظر خود را انتخاب کنید:',
  ].join('\n');

  const kb = Markup.inlineKeyboard([
    [Markup.button.callback('🟢 ➕ ثبت پیشنهاد تجارت جدید', 'trd:new_pick')],
    [Markup.button.callback('📥 پیشنهادات دریافتی من', 'trd:inbox')],
    [Markup.button.callback('📤 پیشنهادات ارسالی من', 'trd:outbox')],
    [Markup.button.callback('🔴 🔙 بازگشت به امپراطوری', 'emp:home')],
  ]);

  if (isEdit && ctx.callbackQuery) {
    await ctx.editMessageText(text, { parse_mode: 'HTML', reply_markup: kb.reply_markup }).catch(() => {});
  } else {
    await ctx.reply(text, { parse_mode: 'HTML', ...kb });
  }
}

composer.action('emp:trade', async (ctx) => {
  await ctx.answerCbQuery().catch(() => {});
  await showTradeHub(ctx, true);
});
composer.hears(['تجارت 🤝', 'تجارت'], async (ctx) => {
  await showTradeHub(ctx, false);
});

// انتخاب کشور برای تجارت
composer.action('trd:new_pick', async (ctx) => {
  await ctx.answerCbQuery().catch(() => {});
  const data = await requireCountry(ctx);
  if (!data) return;
  const activeOwnerships = await listActive(data.season.id);
  const others = activeOwnerships.filter((o) => String(o.countryId) !== String(data.own.countryId));

  if (!others.length) {
    return ctx.editMessageText('🌍 کشور دیگری برای تجارت در دسترس نیست.', {
      ...Markup.inlineKeyboard([[Markup.button.callback('🔙 بازگشت', 'emp:trade')]]),
    });
  }

  const rows = [];
  for (const o of others.slice(0, 10)) {
    const c = await countryService.get(o.countryId);
    if (c) rows.push([Markup.button.callback(`🤝 دادوستد با: ${c.flag} ${c.name}`, `trd:target:${c.id}`)]);
  }
  rows.push([Markup.button.callback('🔙 بازگشت', 'emp:trade')]);

  await ctx.editMessageText('🌍 <b>کشور طرف معامله را انتخاب کنید:</b>', {
    parse_mode: 'HTML',
    reply_markup: Markup.inlineKeyboard(rows).reply_markup,
  }).catch(() => {});
});

// مرحله ۱: انتخاب کالای پیشنهادی
composer.action(/^trd:target:(.+)$/, async (ctx) => {
  await ctx.answerCbQuery().catch(() => {});
  const targetCid = ctx.match[1];
  const targetCountry = await countryService.get(targetCid);

  await ctx.editMessageText([
    `🤝 <b>پیشنهاد تجارت به ${targetCountry.flag} ${esc(targetCountry.name)}</b>`,
    '– – – – – – – – – –',
    '<b>مرحله اول:</b> چه کالایی را برای واگذاری پیشنهاد می‌دهید؟',
  ].join('\n'), {
    parse_mode: 'HTML',
    ...Markup.inlineKeyboard([
      [Markup.button.callback('💰 پول و سرمایه نقدی ($)', `trd:off_item:${targetCid}:money`)],
      [Markup.button.callback('🛢 نفت خام (بشکه)', `trd:off_item:${targetCid}:oil`)],
      [Markup.button.callback('🪖 تسلیحات و تانک', `trd:off_item:${targetCid}:weapons`)],
      [Markup.button.callback('🔬 پژوهش و فناوری', `trd:off_item:${targetCid}:research`)],
      [Markup.button.callback('🔙 بازگشت', 'trd:new_pick')],
    ]),
  }).catch(() => {});
});

// مرحله ۲: انتخاب مقدار پیشنهادی
composer.action(/^trd:off_item:([^:]+):(\w+)$/, async (ctx) => {
  await ctx.answerCbQuery().catch(() => {});
  const [targetCid, offItem] = [ctx.match[1], ctx.match[2]];
  const itemFa = tradeService.TRADE_ITEMS[offItem] || { name: offItem, unit: '' };

  const amounts = offItem === 'money'
    ? [10000000, 50000000, 100000000]
    : offItem === 'oil'
      ? [100, 500, 1000]
      : offItem === 'weapons'
        ? [5, 10, 20]
        : [10, 25, 50];

  const rows = amounts.map((amt) => [
    Markup.button.callback(`واگذاری ${amt.toLocaleString()} ${itemFa.unit}`, `trd:off_qty:${targetCid}:${offItem}:${amt}`),
  ]);
  rows.push([Markup.button.callback('🔙 بازگشت', `trd:target:${targetCid}`)]);

  await ctx.editMessageText(`📦 <b>مقدار «${itemFa.name}» پیشنهادی خود را انتخاب کنید:</b>`, {
    parse_mode: 'HTML',
    reply_markup: Markup.inlineKeyboard(rows).reply_markup,
  }).catch(() => {});
});

// مرحله ۳: انتخاب کالای درخواستی در ازای آن
composer.action(/^trd:off_qty:([^:]+):(\w+):(\d+)$/, async (ctx) => {
  await ctx.answerCbQuery().catch(() => {});
  const [targetCid, offItem, offQty] = [ctx.match[1], ctx.match[2], ctx.match[3]];

  await ctx.editMessageText([
    '<b>مرحله سوم:</b> در ازای این کالا، چه منبعی از کشور مقابل می‌خواهید؟',
  ].join('\n'), {
    parse_mode: 'HTML',
    ...Markup.inlineKeyboard([
      [Markup.button.callback('💰 پول ($)', `trd:req_item:${targetCid}:${offItem}:${offQty}:money`)],
      [Markup.button.callback('🛢 نفت (بشکه)', `trd:req_item:${targetCid}:${offItem}:${offQty}:oil`)],
      [Markup.button.callback('🪖 تسلیحات و تانک', `trd:req_item:${targetCid}:${offItem}:${offQty}:weapons`)],
      [Markup.button.callback('🔬 پژوهش و فناوری', `trd:req_item:${targetCid}:${offItem}:${offQty}:research`)],
      [Markup.button.callback('🔙 بازگشت', `trd:off_item:${targetCid}:${offItem}`)],
    ]),
  }).catch(() => {});
});

// مرحله ۴: مقدار درخواستی و تایید نهایی
composer.action(/^trd:req_item:([^:]+):(\w+):(\d+):(\w+)$/, async (ctx) => {
  await ctx.answerCbQuery().catch(() => {});
  const [targetCid, offItem, offQty, reqItem] = [ctx.match[1], ctx.match[2], ctx.match[3], ctx.match[4]];
  const reqFa = tradeService.TRADE_ITEMS[reqItem] || { name: reqItem, unit: '' };

  const amounts = reqItem === 'money'
    ? [10000000, 50000000, 100000000]
    : reqItem === 'oil'
      ? [100, 500, 1000]
      : reqItem === 'weapons'
        ? [5, 10, 20]
        : [10, 25, 50];

  const rows = amounts.map((amt) => [
    Markup.button.callback(`درخواست ${amt.toLocaleString()} ${reqFa.unit}`, `trd:create:${targetCid}:${offItem}:${offQty}:${reqItem}:${amt}`),
  ]);
  rows.push([Markup.button.callback('🔙 بازگشت', `trd:off_qty:${targetCid}:${offItem}:${offQty}`)]);

  await ctx.editMessageText(`📥 <b>چه مقدار «${reqFa.name}» از کشور مقابل می‌خواهید؟</b>`, {
    parse_mode: 'HTML',
    reply_markup: Markup.inlineKeyboard(rows).reply_markup,
  }).catch(() => {});
});

// ایجاد و ثبت پیشنهاد تجارت
composer.action(/^trd:create:([^:]+):(\w+):(\d+):(\w+):(\d+)$/, async (ctx) => {
  await ctx.answerCbQuery().catch(() => {});
  const [targetCid, offItem, offQtyStr, reqItem, reqQtyStr] = [
    ctx.match[1], ctx.match[2], ctx.match[3], ctx.match[4], ctx.match[5],
  ];
  const offQty = Number(offQtyStr);
  const reqQty = Number(reqQtyStr);
  const data = await requireCountry(ctx);
  if (!data) return;

  try {
    const offer = await tradeService.createTradeOffer({
      fromCountryId: data.own.countryId,
      fromUserId: ctx.from.id,
      toCountryId: targetCid,
      seasonId: data.season.id,
      offerItem: offItem,
      offerQty: offQty,
      requestItem: reqItem,
      requestQty: reqQty,
    });

    const offInfo = tradeService.TRADE_ITEMS[offItem];
    const reqInfo = tradeService.TRADE_ITEMS[reqItem];
    const targetCountry = await countryService.get(targetCid);
    const activeOwnerships = await listActive(data.season.id);
    const targetOwner = activeOwnerships.find((o) => String(o.countryId) === String(targetCid));

    // اطلاع‌رسانی به رهبر کشور مقابل
    if (targetOwner) {
      await notifications.safeSend(ctx.telegram, targetOwner.userId, [
        '🤝 <b>پیشنهاد مبادله تجاری جدید!</b>',
        '– – – – – – – – – –',
        `از طرف کشور: <b>${data.own.country.flag} ${esc(data.own.country.name)}</b>`,
        '',
        `📤 واگذاری به شما: <b>${fmtNum(offQty)} ${offInfo.unit} (${offInfo.name})</b>`,
        `📥 درخواست از شما: <b>${fmtNum(reqQty)} ${reqInfo.unit} (${reqInfo.name})</b>`,
        '',
        'آیا با انجام این معامله موافقید؟',
      ].join('\n'), Markup.inlineKeyboard([
        [Markup.button.callback('🟢 ✅ قبول معامله', `trd:acc:${offer.id}`)],
        [Markup.button.callback('🔴 ❌ رد پیشنهاد', `trd:rej:${offer.id}`)],
      ]));
    }

    await ctx.reply([
      '✅ <b>پیشنهاد تجارت با موفقیت ثبت و ارسال شد!</b>',
      '– – – – – – – – – –',
      `کشور طرف معامله: <b>${targetCountry.flag} ${esc(targetCountry.name)}</b>`,
      `پیشنهاد شما: <b>${fmtNum(offQty)} ${offInfo.unit} ${offInfo.name}</b>`,
      `درخواست شما: <b>${fmtNum(reqQty)} ${reqInfo.unit} ${reqInfo.name}</b>`,
      '',
      'نتیجه پس از پاسخ کشور مقابل به اطلاعتان خواهد رسید.',
    ].join('\n'), { parse_mode: 'HTML' });

    await showTradeHub(ctx, false);
  } catch (err) {
    await ctx.reply(`⚠️ ${err.message}`);
  }
});

// پذیرش پیشنهاد معامله
composer.action(/^trd:acc:(.+)$/, async (ctx) => {
  const offerId = ctx.match[1];
  const data = await requireCountry(ctx);
  if (!data) return;

  try {
    const res = await tradeService.acceptTradeOffer({
      offerId,
      targetCountryId: data.own.countryId,
    });

    const offInfo = tradeService.TRADE_ITEMS[res.offer.offerItem];
    const reqInfo = tradeService.TRADE_ITEMS[res.offer.requestItem];

    // اعلام در کانال تلگرام
    const channelText = [
      '🤝 <b>انعقاد قرارداد بازرگانی و تجارت بین‌الملل!</b>',
      '– – – – – – – – – –',
      `کشورهای <b>${res.offer.fromCountryFlag} ${res.offer.fromCountryName}</b> و <b>${res.offer.toCountryFlag} ${res.offer.toCountryName}</b> با موفقیت معامله تجاری زیر را نهایی کردند:`,
      `• مبادله <b>${fmtNum(res.offer.offerQty)} ${offInfo.unit} ${offInfo.name}</b> در ازای <b>${fmtNum(res.offer.requestQty)} ${reqInfo.unit} ${reqInfo.name}</b>`,
      '🏛 منابع بلافاصله در خزانه و انبارهای دو کشور تسویه گردید.',
    ].join('\n');
    await notifications.publishToChannel(ctx.telegram, 'trade_news', channelText).catch(() => {});

    // اطلاع‌رسانی به پیشنهاددهنده اولیه
    await notifications.safeSend(ctx.telegram, res.offer.fromUserId, `🎉 <b>پیشنهاد معامله شما پذیرفته شد!</b>\nکشور ${data.own.country.flag} ${data.own.country.name} قرارداد تجاری را امضا کرد و منابع مبادله شد.`);

    await ctx.reply('🎉 <b>معامله با موفقیت انجام شد و منابع منتقل گردید!</b>', { parse_mode: 'HTML' });
    await showTradeHub(ctx, false);
  } catch (err) {
    await ctx.answerCbQuery(err.message, { show_alert: true });
  }
});

composer.action(/^trd:rej:(.+)$/, async (ctx) => {
  const offerId = ctx.match[1];
  const data = await requireCountry(ctx);
  if (!data) return;
  await tradeService.rejectTradeOffer({ offerId, targetCountryId: data.own.countryId }).catch(() => {});
  await ctx.answerCbQuery('❌ پیشنهاد معامله رد شد.', { show_alert: true });
  await ctx.editMessageText('❌ این پیشنهاد معامله رد شد.').catch(() => {});
});

// =============================================================
// بخش ۷. مذاکرات محرمانه و چت ناشناس دیپلماتیک (NEGOTIATION)
// =============================================================
async function showNegotiationHub(ctx, isEdit = false) {
  const data = await requireCountry(ctx);
  if (!data) return;
  const { own } = data;
  const activeNego = await negotiationService.getActiveNegotiationForUser(ctx.from.id);

  const text = [
    `🗣️ <b>میز مذاکرات محرمانه و دیپلماسی — ${esc(own.country.name)}</b>`,
    '– – – – – – – – – –',
    activeNego && activeNego.status === 'active'
      ? `🟢 <b>شما یک جلسه مذاکره محرمانه فعال دارید!</b>\nطرف مذاکره: <b>${activeNego.userA === ctx.from.id ? activeNego.countryBFlag + ' ' + activeNego.countryBName : activeNego.countryAFlag + ' ' + activeNego.countryAName}</b>\n(هر پیامی بنویسید مستقیماً به صورت ناشناس منتقل می‌شود)`
      : 'در این بخش می‌توانید درخواست مذاکره محرمانه به رهبر کشوری دیگر بفرستید. در صورت پذیرش، یک چت ناشناس بین شما برقرار می‌شود و زیر هر پیام گزینه‌های «به نتیجه رسیدیم» و «به نتیجه نرسیدیم» در اختیارتان خواهد بود.',
    '',
    'اقدام مورد نظر را انتخاب نمایید:',
  ].join('\n');

  const rows = [];
  if (activeNego && activeNego.status === 'active') {
    rows.push([
      Markup.button.callback('🟢 ✅ به نتیجه رسیدیم', `nego:agree:${activeNego.id}`),
      Markup.button.callback('🔴 ❌ به نتیجه نرسیدیم (پایان مذاکره)', `nego:fail:${activeNego.id}`),
    ]);
  }
  rows.push([Markup.button.callback('🟢 🗣️ درخواست مذاکره جدید با یک کشور', 'nego:pick_target')]);
  rows.push([Markup.button.callback('🔴 🔙 بازگشت به امپراطوری', 'emp:home')]);

  const kb = Markup.inlineKeyboard(rows);
  if (isEdit && ctx.callbackQuery) {
    await ctx.editMessageText(text, { parse_mode: 'HTML', reply_markup: kb.reply_markup }).catch(() => {});
  } else {
    await ctx.reply(text, { parse_mode: 'HTML', ...kb });
  }
}

composer.action('emp:negotiate', async (ctx) => {
  await ctx.answerCbQuery().catch(() => {});
  await showNegotiationHub(ctx, true);
});
composer.hears(['مذاکره 🗣️', 'مذاکره'], async (ctx) => {
  await showNegotiationHub(ctx, false);
});

// انتخاب کشور برای آغاز مذاکره
composer.action('nego:pick_target', async (ctx) => {
  await ctx.answerCbQuery().catch(() => {});
  const data = await requireCountry(ctx);
  if (!data) return;
  const activeOwnerships = await listActive(data.season.id);
  const others = activeOwnerships.filter((o) => String(o.countryId) !== String(data.own.countryId));

  if (!others.length) {
    return ctx.editMessageText('🌍 کشور دیگری برای مذاکره یافت نشد.', {
      ...Markup.inlineKeyboard([[Markup.button.callback('🔙 بازگشت', 'emp:negotiate')]]),
    });
  }

  const rows = [];
  for (const o of others.slice(0, 10)) {
    const c = await countryService.get(o.countryId);
    if (c) rows.push([Markup.button.callback(`🗣️ درخواست مذاکره با: ${c.flag} ${c.name}`, `nego:request:${c.id}:${o.userId}`)]);
  }
  rows.push([Markup.button.callback('🔙 بازگشت', 'emp:negotiate')]);

  await ctx.editMessageText('🗣️ <b>کشور مورد نظر خود را برای آغاز مذاکرات محرمانه انتخاب کنید:</b>', {
    parse_mode: 'HTML',
    reply_markup: Markup.inlineKeyboard(rows).reply_markup,
  }).catch(() => {});
});

// ارسال دعوت به مذاکره
composer.action(/^nego:request:([^:]+):(\d+)$/, async (ctx) => {
  const [targetCid, targetUid] = [ctx.match[1], Number(ctx.match[2])];
  const data = await requireCountry(ctx);
  if (!data) return;

  try {
    const nego = await negotiationService.requestNegotiation({
      fromCountryId: data.own.countryId,
      fromUserId: ctx.from.id,
      targetCountryId: targetCid,
      targetUserId: targetUid,
      seasonId: data.season.id,
    });

    const targetCountry = await countryService.get(targetCid);

    // ارسال به رهبر مقصد
    await notifications.safeSend(ctx.telegram, targetUid, [
      '🔒 <b>درخواست آغاز مذاکرات محرمانه و دیپلماتیک!</b>',
      '– – – – – – – – – –',
      `رهبر کشور <b>${data.own.country.flag} ${esc(data.own.country.name)}</b> درخواست آغاز یک نشست محرمانه دوجانبه را ارسال کرده است.`,
      '',
      'در صورت پذیرش، پیام‌های متنی شما به صورت چت ناشناس بین دو رهبر رد و بدل خواهد شد و می‌توانید به توافقات نظامی، صلح یا معامله زمین بپردازید.',
      '',
      'آیا این مذاکره را می‌پذیرید؟',
    ].join('\n'), Markup.inlineKeyboard([
      [Markup.button.callback('🟢 ✅ پذیرش و ورود به مذاکره', `nego:acc:${nego.id}`)],
      [Markup.button.callback('🔴 ❌ رد درخواست مذاکره', `nego:rej:${nego.id}`)],
    ]));

    await ctx.answerCbQuery(`✅ درخواست مذاکره برای رهبر ${targetCountry.name} فرستاده شد.`, { show_alert: true });
    await showNegotiationHub(ctx, true);
  } catch (err) {
    await ctx.answerCbQuery(err.message, { show_alert: true });
  }
});

// پذیرش مذاکره و ورود به چت ناشناس
composer.action(/^nego:acc:(.+)$/, async (ctx) => {
  const negoId = ctx.match[1];
  try {
    const nego = await negotiationService.acceptNegotiation(negoId, ctx.from.id);

    const actionKb = Markup.inlineKeyboard([
      [
        Markup.button.callback('🟢 ✅ به نتیجه رسیدیم', `nego:agree:${nego.id}`),
        Markup.button.callback('🔴 ❌ به نتیجه نرسیدیم', `nego:fail:${nego.id}`),
      ],
    ]);

    const introMsg = [
      '🔒 <b>اتاق مذاکرات محرمانه فعال شد!</b>',
      '– – – – – – – – – –',
      'از این لحظه هر پیامی بنویسید مستقیماً و به صورت ناشناس برای رهبر کشور مقابل ارسال می‌شود.',
      'هر زمان مایل بودید می‌توانید روی یکی از کلیدهای «به نتیجه رسیدیم» یا «به نتیجه نرسیدیم» کلیک کنید.',
    ].join('\n');

    // ارسال به هر دو طرف
    await ctx.reply(introMsg, { parse_mode: 'HTML', ...actionKb });
    await notifications.safeSend(ctx.telegram, nego.userA, introMsg, actionKb);
  } catch (err) {
    await ctx.answerCbQuery(err.message, { show_alert: true });
  }
});

composer.action(/^nego:rej:(.+)$/, async (ctx) => {
  const negoId = ctx.match[1];
  await negotiationService.rejectNegotiation(negoId, ctx.from.id).catch(() => {});
  await ctx.answerCbQuery('❌ درخواست رد شد.', { show_alert: true });
  await ctx.editMessageText('❌ درخواست مذاکره رد شد.').catch(() => {});
});

// انتخاب یک‌طرفه "به نتیجه نرسیدیم"
composer.action(/^nego:fail:(.+)$/, async (ctx) => {
  const negoId = ctx.match[1];
  try {
    const res = await negotiationService.terminateNegotiation(negoId, ctx.from.id);
    const endMsg = '❌ <b>مذاکرات بدون دستیابی به نتیجه پایان یافت!</b>\nیکی از طرفین اعلام کرد که به نتیجه نرسیده‌اند و اتاق گفتگو بسته شد.';
    await ctx.reply(endMsg, { parse_mode: 'HTML' });
    await notifications.safeSend(ctx.telegram, res.otherUserId, endMsg);
  } catch (err) {
    await ctx.answerCbQuery(err.message, { show_alert: true });
  }
});

// انتخاب "به نتیجه رسیدیم" -> باز شدن منوی توافقات
composer.action(/^nego:agree:(.+)$/, async (ctx) => {
  await ctx.answerCbQuery().catch(() => {});
  const negoId = ctx.match[1];
  const nego = await negotiationService.getNegotiation(negoId);
  if (!nego) return;

  await ctx.reply([
    '🤝 <b>توافق و انعقاد معاهده رسمی:</b>',
    '– – – – – – – – – –',
    'نوع توافقی را که با کشور مقابل به نتیجه رسیدید انتخاب کنید:',
  ].join('\n'), {
    parse_mode: 'HTML',
    ...Markup.inlineKeyboard([
      [Markup.button.callback('🛡️ قرارداد نظامی (حمایت در جنگ)', `nego:treaty:${negoId}:military_pact`)],
      [Markup.button.callback('🕊️ پیمان عدم تعارض', `nego:treaty:${negoId}:non_aggression`)],
      [Markup.button.callback('🏳️ پیمان صلح و آتش‌بس (در صورت جنگ)', `nego:treaty:${negoId}:peace_treaty`)],
      [Markup.button.callback('🗺️ فروش / خرید زمین و سرزمین', `nego:treaty:${negoId}:land_deal`)],
      [Markup.button.callback('🔴 ❌ به نتیجه نرسیدیم (لغو)', `nego:fail:${negoId}`)],
    ]),
  });
});

// انتخاب پیمان‌های عمومی (نظامی، عدم تعارض، صلح)
composer.action(/^nego:treaty:([^:]+):(military_pact|non_aggression|peace_treaty)$/, async (ctx) => {
  await ctx.answerCbQuery().catch(() => {});
  const [negoId, pactType] = [ctx.match[1], ctx.match[2]];
  const nego = await negotiationService.getNegotiation(negoId);
  if (!nego) return;

  const typeNameFa = pactType === 'military_pact'
    ? 'قرارداد نظامی و حمایت متقابل در جنگ'
    : pactType === 'non_aggression'
      ? 'پیمان عدم تعارض'
      : 'پیمان صلح و پایان تخاصم';

  const res = await allianceService && await negotiationService.proposeAgreement({
    negoId,
    userId: ctx.from.id,
    agreementType: pactType,
    details: {},
  });

  // ارسال به طرف مقابل جهت امضای نهایی
  await notifications.safeSend(ctx.telegram, res.targetUserId, [
    '📜 <b>پیشنهاد امضای رسمی معاهده دیپلماتیک!</b>',
    '– – – – – – – – – –',
    `کشور طرف مذاکره پیشنهاد انعقاد «<b>${typeNameFa}</b>» را ثبت کرد.`,
    '',
    'آیا با امضا و ثبت رسمی این معاهده در کانال بین‌المللی موافقید؟',
  ].join('\n'), Markup.inlineKeyboard([
    [Markup.button.callback('🟢 ✍️ تایید و امضای رسمی توافق', `nego:sign:${negoId}`)],
    [Markup.button.callback('🔴 ❌ رد توافق', `nego:fail:${negoId}`)],
  ]));

  await ctx.reply(`📨 پیشنهاد معاهده «<b>${typeNameFa}</b>» برای امضای نهایی به طرف مقابل مخابره شد.`, { parse_mode: 'HTML' });
});

// معامله زمین (فروش یا خرید)
composer.action(/^nego:treaty:([^:]+):land_deal$/, async (ctx) => {
  await ctx.answerCbQuery().catch(() => {});
  const negoId = ctx.match[1];

  await ctx.reply([
    '🗺️ <b>معامله و انتقال سرزمین</b>',
    '– – – – – – – – – –',
    'آیا قصد دارید زمین بفروشید یا از کشور مقابل زمین بخرید؟',
  ].join('\n'), {
    parse_mode: 'HTML',
    ...Markup.inlineKeyboard([
      [Markup.button.callback('📤 فروختن زمین به کشور مقابل', `nego:land_dir:${negoId}:sell`)],
      [Markup.button.callback('📥 خریدن زمین از کشور مقابل', `nego:land_dir:${negoId}:buy`)],
      [Markup.button.callback('🔙 بازگشت به توافقات', `nego:agree:${negoId}`)],
    ]),
  });
});

composer.action(/^nego:land_dir:([^:]+):(sell|buy)$/, async (ctx) => {
  await ctx.answerCbQuery().catch(() => {});
  const [negoId, dir] = [ctx.match[1], ctx.match[2]];
  const nego = await negotiationService.getNegotiation(negoId);
  if (!nego) return;

  const data = await requireCountry(ctx);
  const sellerCid = dir === 'sell' ? data.own.countryId : (nego.countryA === String(data.own.countryId) ? nego.countryB : nego.countryA);
  const state = await gameService.getCountryState(sellerCid, nego.seasonId);
  const country = await countryService.get(sellerCid);
  const provinces = gameService.normalizeProvinces(state.provinces, country ? country.name : 'کشور');

  const rows = provinces.slice(0, 4).map((p) => [
    Markup.button.callback(`🗺️ ${p.name}`, `nego:land_prov:${negoId}:${dir}:${p.id}`),
  ]);
  rows.push([Markup.button.callback('🔙 بازگشت', `nego:treaty:${negoId}:land_deal`)]);

  await ctx.reply(`🗺️ <b>استان مورد معامله (${dir === 'sell' ? 'جهت واگذاری' : 'جهت الحاق'}) را انتخاب کنید:</b>`, {
    parse_mode: 'HTML',
    reply_markup: Markup.inlineKeyboard(rows).reply_markup,
  });
});

// انتخاب مابه‌ازای زمین (پول / نفت / سلاح و سرباز / پژوهش / بازگشت)
composer.action(/^nego:land_prov:([^:]+):(sell|buy):([^:]+)$/, async (ctx) => {
  await ctx.answerCbQuery().catch(() => {});
  const [negoId, dir, provId] = [ctx.match[1], ctx.match[2], ctx.match[3]];

  await ctx.reply([
    '💰 <b>انتخاب مابه‌ازای واگذاری سرزمین</b>',
    'در ازای این زمین چه چیزی پرداخت/دریافت شود؟',
  ].join('\n'), {
    parse_mode: 'HTML',
    ...Markup.inlineKeyboard([
      [Markup.button.callback('💰 پول نقدی ($)', `nego:land_comp:${negoId}:${dir}:${provId}:money`)],
      [Markup.button.callback('🛢 نفت خام (بشکه)', `nego:land_comp:${negoId}:${dir}:${provId}:oil`)],
      [Markup.button.callback('🪖 سلاح و سرباز', `nego:land_comp:${negoId}:${dir}:${provId}:weapons`)],
      [Markup.button.callback('🔬 امتیاز پژوهش و فناوری', `nego:land_comp:${negoId}:${dir}:${provId}:research`)],
      [Markup.button.callback('🔙 بازگشت', `nego:land_dir:${negoId}:${dir}`)],
    ]),
  });
});

// تعیین مقدار مابه‌ازا
composer.action(/^nego:land_comp:([^:]+):(sell|buy):([^:]+):(\w+)$/, async (ctx) => {
  await ctx.answerCbQuery().catch(() => {});
  const [negoId, dir, provId, compItem] = [ctx.match[1], ctx.match[2], ctx.match[3], ctx.match[4]];

  const amounts = compItem === 'money'
    ? [50000000, 100000000, 250000000]
    : compItem === 'oil'
      ? [500, 1000, 2500]
      : compItem === 'weapons'
        ? [10, 25, 50]
        : [25, 50, 100];

  const unitFa = compItem === 'money' ? '$' : compItem === 'oil' ? 'بشکه' : compItem === 'weapons' ? 'سلاح' : 'امتیاز علمی';

  const rows = amounts.map((amt) => [
    Markup.button.callback(`معادل ${amt.toLocaleString()} ${unitFa}`, `nego:land_submit:${negoId}:${dir}:${provId}:${compItem}:${amt}`),
  ]);
  rows.push([Markup.button.callback('🔙 بازگشت', `nego:land_prov:${negoId}:${dir}:${provId}`)]);

  await ctx.reply(`📊 <b>میزان ${unitFa} مابه‌ازای زمین را تعیین کنید:</b>`, {
    parse_mode: 'HTML',
    reply_markup: Markup.inlineKeyboard(rows).reply_markup,
  });
});

// ثبت نهایی پیشنهاد معامله زمین
composer.action(/^nego:land_submit:([^:]+):(sell|buy):([^:]+):(\w+):(\d+)$/, async (ctx) => {
  await ctx.answerCbQuery().catch(() => {});
  const [negoId, dir, provId, compItem, compAmtStr] = [
    ctx.match[1], ctx.match[2], ctx.match[3], ctx.match[4], ctx.match[5],
  ];
  const compAmt = Number(compAmtStr);

  const res = await negotiationService.proposeAgreement({
    negoId,
    userId: ctx.from.id,
    agreementType: 'land_deal',
    details: {
      action: dir,
      provinceId: provId,
      compensationType: compItem,
      compensationAmount: compAmt,
    },
  });

  const unitFa = compItem === 'money' ? '$' : compItem === 'oil' ? 'بشکه نفت' : compItem === 'weapons' ? 'سلاح و ادوات نظامی' : 'امتیاز پژوهشی';
  const desc = dir === 'sell'
    ? `واگذاری زمین شما در ازای دریافت ${compAmt.toLocaleString()} ${unitFa}`
    : `الحاق زمین کشور مقابل به ازای پرداخت ${compAmt.toLocaleString()} ${unitFa}`;

  // ارسال به طرف مقابل جهت امضا
  await notifications.safeSend(ctx.telegram, res.targetUserId, [
    '🗺️ <b>پیشنهاد رسمی معاهده واگذاری سرزمین!</b>',
    '– – – – – – – – – –',
    `کشور مقابل معاهده زمین را با شرایط زیر پیشنهاد داد:`,
    `📜 مفاد: <b>${desc}</b>`,
    '',
    'آیا با امضا و اجرای رسمی این معاهده موافقید؟',
  ].join('\n'), Markup.inlineKeyboard([
    [Markup.button.callback('🟢 ✍️ تایید و امضای رسمی توافق', `nego:sign:${negoId}`)],
    [Markup.button.callback('🔴 ❌ رد توافق', `nego:fail:${negoId}`)],
  ]));

  await ctx.reply('📨 معاهده واگذاری زمین برای امضا و تایید رسمی به طرف مقابل فرستاده شد.', { parse_mode: 'HTML' });
});

// امضای نهایی توافق توسط کشور مقابل
composer.action(/^nego:sign:(.+)$/, async (ctx) => {
  const negoId = ctx.match[1];
  try {
    const res = await negotiationService.confirmAgreement({
      negoId,
      userId: ctx.from.id,
    });

    // انتشار در کانال رسمی
    if (res.announceText) {
      await notifications.publishToChannel(ctx.telegram, 'statement', res.announceText).catch(() => {});
    }

    const congrats = `🎉 <b>توافقنامه رسمی با موفقیت امضا شد!</b>\nمفاد معاهده فوراً اعمال و در کانال بین‌المللی منتشر گردید.`;
    await ctx.reply(congrats, { parse_mode: 'HTML' });
    const otherUid = res.nego.userA === ctx.from.id ? res.nego.userB : res.nego.userA;
    await notifications.safeSend(ctx.telegram, otherUid, congrats);
  } catch (err) {
    await ctx.answerCbQuery(err.message, { show_alert: true });
  }
});

// هدایت پیام‌های متنی در چت ناشناس بین دو رهبر
composer.on('text', async (ctx, next) => {
  const text = (ctx.message.text || '').trim();
  if (text.startsWith('/') || Object.values(L).includes(text)) {
    return next();
  }
  if (ctx.state.user && ctx.state.user.flowName) {
    return next();
  }

  const activeNego = await negotiationService.getActiveNegotiationForUser(ctx.from.id);
  if (activeNego && activeNego.status === 'active') {
    const isUserA = activeNego.userA === ctx.from.id;
    const recipientId = isUserA ? activeNego.userB : activeNego.userA;

    const actionKb = Markup.inlineKeyboard([
      [
        Markup.button.callback('🟢 ✅ به نتیجه رسیدیم', `nego:agree:${activeNego.id}`),
        Markup.button.callback('🔴 ❌ به نتیجه نرسیدیم', `nego:fail:${activeNego.id}`),
      ],
    ]);

    await notifications.safeSend(ctx.telegram, recipientId, [
      '🔒 <b>پیام ناشناس در میز مذاکره محرمانه:</b>',
      '– – – – – – – – – –',
      `💬 « <i>${esc(text)}</i> »`,
      '',
      '👇 در هر زمان می‌توانید وضعیت را مشخص کنید:',
    ].join('\n'), actionKb);

    await ctx.reply([
      '✅ <b>پیام محرمانه شما مخابره شد:</b>',
      `« ${esc(text)} »`,
      '',
      '👇 در هر زمان می‌توانید وضعیت را مشخص کنید:',
    ].join('\n'), { parse_mode: 'HTML', ...actionKb });

    return;
  }

  return next();
});


// اکتشاف نفت: هزینه ثابت ۴۵۰ میلیون و شانس بر اساس درصد نفت‌خیزی تعیین‌شده برای کشور
composer.action('emp:oil_explore', async (ctx) => {
  await ctx.answerCbQuery().catch(() => {});
  const data = await requireCountry(ctx);
  if (!data) return;
  try {
    const result = await gameService.exploreOil(data.own.countryId, data.season.id);
    const message = result.found
      ? `🛢️ اکتشاف موفق بود! ${fmtNum(result.added)} واحد به ظرفیت مخزن نفت اضافه شد.\nظرفیت جدید: ${fmtNum(result.oilReserve)}`
      : '🔎 تیم تحقیقاتی مخزن جدیدی پیدا نکرد. هزینه عملیات پرداخت شد.';
    await ctx.reply(message);
  } catch (err) { await ctx.reply(`❌ ${esc(err.message)}`); }
});

// دیپلماسی مستقیم: پیمان یا قطع تجارت بدون میز مذاکره
composer.action('emp:diplomacy', async (ctx) => {
  await ctx.answerCbQuery().catch(() => {});
  await ctx.reply('🕊️ دیپلماسی مستقیم\nیک گزینه را انتخاب کن:', Markup.inlineKeyboard([
    [Markup.button.callback('🤝 ارسال پیمان به کشور', 'dip:pact')],
    [Markup.button.callback('📉 قطع روابط تجاری (افت ۵٪ درآمد هر دو کشور)', 'dip:tradecut')],
    [Markup.button.callback('🔙 بازگشت', 'emp:home')],
  ]));
});
composer.action(/^dip:(pact|tradecut)$/, async (ctx) => {
  await ctx.answerCbQuery().catch(() => {});
  const data = await requireCountry(ctx); if (!data) return;
  await userService.setFlow(ctx.from.id, `game:diplomacy:${ctx.match[1]}`, { countryId: data.own.countryId, seasonId: data.season.id });
  await ctx.reply('نام کشور مقصد را دقیق بنویس:');
});
for (const mode of ['pact', 'tradecut']) registerFlow(`game:diplomacy:${mode}`, async (ctx, data) => {
  const targetName = String(ctx.message.text || '').trim();
  const { col, docs } = require('../db/firestore');
  const countries = docs(await col('countries').get());
  const target = countries.find(c => c.name === targetName || c.name.toLowerCase() === targetName.toLowerCase());
  if (!target || String(target.id) === String(data.countryId)) return ctx.reply('کشور مقصد پیدا نشد یا نمی‌توانی کشور خودت را انتخاب کنی.');
  const targetOwnerships = await listActive(data.seasonId);
  const targetOwn = targetOwnerships.find(o => String(o.countryId) === String(target.id));
  const myState = await gameService.getCountryState(data.countryId, data.seasonId);
  if (mode === 'pact') {
    await col('diplomacy_pacts').add({ fromCountryId: data.countryId, toCountryId: target.id, status: 'sent', createdAt: new Date() });
    if (targetOwn) await notifications.safeSend(ctx.telegram, targetOwn.userId || targetOwn.telegramId, `🤝 کشور ${esc((await countryService.get(data.countryId))?.name || '')} برای شما پیمان فرستاده است.`);
    await ctx.reply(`✅ پیمان برای ${esc(target.name)} ارسال شد.`);
  } else {
    if (!targetOwn) return ctx.reply('کشور مقصد مالک فعال ندارد.');
    const cuts = docs(await col('diplomacy_trade_cuts').get());
    const pairKey = [String(data.countryId), String(target.id)].sort().join(':');
    const alreadyCut = cuts.some((cut) => (!cut.seasonId || String(cut.seasonId) === String(data.seasonId)) &&
      [String(cut.fromCountryId), String(cut.toCountryId)].sort().join(':') === pairKey && cut.status !== 'cancelled');
    if (alreadyCut) return ctx.reply('📉 روابط تجاری این دو کشور قبلاً قطع شده و افت درآمد دوباره اعمال نمی‌شود.');
    const targetState = await gameService.getCountryState(target.id, data.seasonId);
    await gameService.updateCountryState(data.countryId, data.seasonId, { incomeDaily: Math.floor((myState.incomeDaily || 0) * 0.95) });
    await gameService.updateCountryState(target.id, data.seasonId, { incomeDaily: Math.floor((targetState.incomeDaily || 0) * 0.95) });
    await col('diplomacy_trade_cuts').add({ fromCountryId: data.countryId, toCountryId: target.id, seasonId: data.seasonId, createdAt: new Date(), rate: 5, status: 'active' });
    await ctx.reply(`📉 روابط تجاری با ${esc(target.name)} قطع شد؛ درآمد روزانه هر دو کشور ۵٪ کاهش یافت.`);
  }
  await userService.clearFlow(ctx.from.id);
});

module.exports = { composer };
