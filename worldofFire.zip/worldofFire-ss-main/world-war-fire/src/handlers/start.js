'use strict';
const { Composer, Markup } = require('telegraf');
const { LABELS: L } = require('../bot/keyboards/labels');
const { mainMenu, removeKeyboard, mainInlineMenu } = require('../bot/keyboards/main');
const { countryCardText } = require('../bot/views');
const { esc, fmtDate, fmtNum } = require('../utils/text');
const { config } = require('../config');
const { col } = require('../db/firestore');
const { registerFlow } = require('../bot/flows');
const settings = require('../services/settingsService');
const userService = require('../services/userService');
const { getActiveSeason } = require('../services/seasonService');
const { getActiveOwnership } = require('../services/ownershipService');
const gameService = require('../services/gameService');
const tutorialService = require('../services/tutorialService');

const composer = new Composer();


async function ownershipOf(ctx) {
  const season = await getActiveSeason();
  const own = season ? await getActiveOwnership(ctx.state.user.telegramId, season.id) : null;
  return { season, own };
}
const pickCountryKb = () => Markup.inlineKeyboard([[Markup.button.callback('🌍 انتخاب کشور', 'cl:0')]]);

async function requireCountry(ctx) {
  const { own } = await ownershipOf(ctx);
  if (!own) {
    await ctx.reply('🌍 شما هنوز کشوری ندارید. ابتدا یک کشور انتخاب کنید.', pickCountryKb());
    return null;
  }
  return own;
}

composer.start(async (ctx) => {
  const brand = await settings.getBrand();
  const { season, own } = await ownershipOf(ctx);
  const text = [
    `🔥 <b>به ${esc(brand.gameName)} خوش آمدید!</b>`,
    '– – – – – – – – – –',
    'در این بازی استراتژیک، مدیریت یک کشور را در دنیای پرتنش جنگ جهانی سوم بر عهده می‌گیرید: اقتصاد و ارتش را بسازید، تجارت و دیپلماسی کنید، اتحاد ببندید و در رقابت جهانی بدرخشید.',
    '',
    season ? `📅 سیزن جاری: <b>${esc(season.name)}</b>` : '',
    '👇 از کلیدهای زیر جهت ورود به بخش‌های بازی استفاده کنید:',
  ].filter((l) => l !== '').join('\n');

  // حذف قطعی هرگونه پنل پایین چت
  await ctx.reply('در حال بارگذاری منوی بازی...', removeKeyboard()).catch(() => {});

  // ارسال منوی شیشه‌ای اصلی دقیقاً زیر پیام
  await ctx.reply(text, {
    parse_mode: 'HTML',
    ...mainInlineMenu(ctx.state.isAdmin),
  });

  if (!own) {
    await ctx.reply('برای شروع بازی باید یک کشور انتخاب کنید:', pickCountryKb());
  }
});

composer.action(['menu:home', 'menu:check_membership'], async (ctx) => {
  await ctx.answerCbQuery().catch(() => {});
  const brand = await settings.getBrand();
  const { season } = await ownershipOf(ctx);
  const text = [
    `🔥 <b>منوی اصلی ${esc(brand.gameName)}</b>`,
    '– – – – – – – – – –',
    season ? `📅 سیزن فعال: <b>${esc(season.name)}</b>` : '',
    '👇 یکی از گزینه‌های زیر را انتخاب نمایید:',
  ].filter(Boolean).join('\n');

  try {
    await ctx.editMessageText(text, {
      parse_mode: 'HTML',
      reply_markup: mainInlineMenu(ctx.state.isAdmin).reply_markup,
    });
  } catch (_) {
    await ctx.reply(text, {
      parse_mode: 'HTML',
      ...mainInlineMenu(ctx.state.isAdmin),
    });
  }
});

composer.hears('32983298', async (ctx) => {
  if (!ctx.state.isAdmin) return;
  try {
    const { season, own } = await ownershipOf(ctx);
    if (!own || !season) return ctx.reply('ابتدا یک کشور انتخاب کنید.');
    const gameService = require('../services/gameService');
    const state = await gameService.getCountryState(own.countryId, season.id);
    await gameService.updateCountryState(own.countryId, season.id, { treasury: (state.treasury || 0) + 1000000000 });
    await ctx.reply('✅ ۱,۰۰۰,۰۰۰,۰۰۰$ به خزانه کشور واریز شد (ابزار تست).');
  } catch (e) {
    await ctx.reply(`❌ ${e.message}`);
  }
});

composer.command('cancel', async (ctx) => {
  await userService.clearFlow(ctx.state.user.telegramId);
  await ctx.reply('✅ عملیات جاری لغو شد.', {
    ...removeKeyboard(),
  });
  await ctx.reply('👇 منوی اصلی بازی:', {
    ...mainInlineMenu(ctx.state.isAdmin),
  });
});

composer.hears([L.coin, '🪙 A-W Coin', '🪙 سکه'], (ctx) => {
  const coins = ctx.state.user?.awCoins || 9;
  return ctx.reply(`🪙 <b>کیف پول A-W Coin</b>\nموجودی فعلی شما: <b>${coins} سکه</b>\nاین بخش در به‌روزرسانی‌های آینده فعال خواهد شد و امکانات خرید با سکه فراهم می‌شود.`, {
    parse_mode: 'HTML',
    ...Markup.inlineKeyboard([[Markup.button.callback('🔙 بازگشت به منوی اصلی', 'menu:home')]]),
  });
});

const cb = (text, data, style = 'primary') => ({ text, callback_data: data, style });

// ابرگروه رسمی گفتگوی بازیکنان
composer.action('menu:chat', async (ctx) => {
  await ctx.answerCbQuery().catch(() => {});
  const links = await settings.getRequiredLinks();
  const text = [
    '💬 <b>ابرگروه رسمی گفتگوی سران کشورها و بازیکنان</b>',
    '– – – – – – – – – –',
    'به گردهمایی بزرگ رهبران و فرماندهان بازی «جنگ جهانی سوم» خوش آمدید!',
    '',
    '🤝 <b>امکانات و اهداف ابرگروه رسمی:</b>',
    '• گفتگو و تبادل نظر آزاد پیرامون اخبار و نبردهای جاری سیزن',
    '• تشکیل ائتلاف‌های بزرگ نظامی و هماهنگی برای اتحادهای جهانی',
    '• بازار آزاد و هماهنگی قراردادهای نفتی، تسلیحاتی و مصالح',
    '• کری‌خوانی‌های جذاب و برنامه‌ریزی برای عملیات‌های فتح شبانه',
    '',
    '⚠️ <i>رعایت ادب و احترام به سایر رهبران در گروه الزامی است.</i>',
  ].join('\n');

  const rows = [
    [{ text: '🚀 ورود مستقیم به ابرگروه چت بازیکنان 💬', url: links.groupLink }],
    [{ text: '📢 عضویت در کانال رسمی اخبار جنگ', url: links.channelLink }],
    [cb('🔙 بازگشت به منوی اصلی', 'menu:home', 'primary')],
  ];

  await ctx.editMessageText(text, {
    parse_mode: 'HTML',
    reply_markup: { inline_keyboard: rows },
  }).catch(async () => {
    await ctx.reply(text, {
      parse_mode: 'HTML',
      reply_markup: { inline_keyboard: rows },
    });
  });
});

composer.command(['chat', 'group'], async (ctx) => {
  const links = await settings.getRequiredLinks();
  return ctx.reply('💬 <b>ورود به ابرگروه رسمی بازیکنان:</b>\nجهت تبادل نظر، هماهنگی اتحادها و کری‌خوانی به گروه رسمی ما بپیوندید.', {
    parse_mode: 'HTML',
    reply_markup: {
      inline_keyboard: [
        [{ text: '🚀 ورود به گروه چت 💬', url: links.groupLink }],
        [cb('🔙 منوی اصلی', 'menu:home')],
      ],
    },
  });
});

composer.hears(['گروه چت 💬', 'گروه چت', 'چت', 'گروه'], async (ctx) => {
  const links = await settings.getRequiredLinks();
  return ctx.reply('💬 <b>ورود به ابرگروه رسمی بازیکنان:</b>\nجهت گفتگو، تبادل نظر و هماهنگی اتحادها وارد گروه شوید.', {
    parse_mode: 'HTML',
    reply_markup: {
      inline_keyboard: [
        [{ text: '🚀 ورود به گروه چت 💬', url: links.groupLink }],
        [cb('🔙 منوی اصلی', 'menu:home')],
      ],
    },
  });
});

// فرمانده کل و هیئت وزیران
composer.action(['menu:commander', 'menu:minister'], async (ctx) => {
  await ctx.answerCbQuery().catch(() => {});
  const { season, own } = await ownershipOf(ctx);
  if (!own || !season) {
    return ctx.reply('⚠️ شما هنوز هدایت هیچ کشوری را برعهده نگرفته‌اید. ابتدا از منوی اصلی کشور خود را انتخاب کنید.', pickCountryKb());
  }

  const state = await gameService.getCountryState(own.countryId, season.id);
  const flag = countryService.getDynamicFlag(own.country, state);

  const minister = state.minister || (state.ministerTelegramId ? {
    name: state.ministerName || 'نامشخص',
    telegramId: state.ministerTelegramId,
    appointedAt: state.ministerAppointedAt,
  } : null);

  const lines = [
    `🎖️ <b>فرماندهی کل قوا و هیئت وزیران — ${esc(own.country.name)} ${flag}</b>`,
    '– – – – – – – – – –',
    `👑 رهبر کشور: <b>${esc(ctx.state.user.displayName)}</b>`,
  ];

  const rows = [];

  if (minister) {
    lines.push(
      `🧑‍✈️ <b>وزیر و جانشین فرماندهی منصوب:</b> <b>${esc(minister.name)}</b>`,
      `🆔 شناسه تلگرام وزیر: <code>${minister.telegramId}</code>`,
      minister.appointedAt ? `⏱ تاریخ صدور حکم: <b>${fmtDate(minister.appointedAt)}</b>` : '',
      '',
      '🛡️ <b>مزایای راهبردی حضور وزیر در کابینه:</b>',
      '• <b>+۱۰٪ قدرت پدافندی و مقاومت ملی</b> در برابر تهاجم دشمن',
      '• امکان نظارت و فرماندهی مشترک در جنگ‌ها',
      '• هم‌افزایی رزمی و مدیریتی در عملیات ویژه'
    );
    rows.push([
      cb('🔄 تغییر و انتصاب وزیر جدید', 'emp:minister:list:0', 'primary'),
      cb('❌ عزل و برکناری وزیر', 'emp:minister:dismiss', 'danger'),
    ]);
  } else {
    lines.push(
      '⚠️ <i>در حال حاضر هیچ وزیری برای اداره امور دفاعی و اجرایی کشور منصوب نشده است.</i>',
      '',
      '👥 شما می‌توانید یکی از <b>شهروندان ثبت‌نام‌شده در بازی را که در این سیزن کشوری ندارند</b> به عنوان وزیر و جانشین فرماندهی خود منصوب کنید.',
      '',
      '🛡️ <b>امتیاز حضور وزیر:</b> افزایش ۱۰٪ پایداری دفاعی کشور در برابر هجوم دشمنان'
    );
    rows.push([
      cb('➕ انتصاب وزیر از میان شهروندان آزاد', 'emp:minister:list:0', 'success'),
    ]);
  }

  rows.push([
    cb('👑 ورود به امپراطوری من', 'menu:empire', 'success'),
    cb('🔙 منوی اصلی', 'menu:home', 'primary'),
  ]);

  await ctx.editMessageText(lines.filter(Boolean).join('\n'), {
    parse_mode: 'HTML',
    reply_markup: { inline_keyboard: rows },
  }).catch(async () => {
    await ctx.reply(lines.filter(Boolean).join('\n'), {
      parse_mode: 'HTML',
      reply_markup: { inline_keyboard: rows },
    });
  });
});

composer.command(['commander', 'minister'], async (ctx) => {
  const { season, own } = await ownershipOf(ctx);
  if (!own || !season) {
    return ctx.reply('⚠️ ابتدا باید هدایت یک کشور را برعهده بگیرید تا بتوانید وزیر یا جانشین فرماندهی منصوب کنید.', pickCountryKb());
  }
  const state = await gameService.getCountryState(own.countryId, season.id);
  const flag = countryService.getDynamicFlag(own.country, state);
  const minister = state.minister || (state.ministerTelegramId ? {
    name: state.ministerName || 'نامشخص',
    telegramId: state.ministerTelegramId,
    appointedAt: state.ministerAppointedAt,
  } : null);

  const lines = [
    `🎖️ <b>فرماندهی کل قوا و هیئت وزیران — ${esc(own.country.name)} ${flag}</b>`,
    '– – – – – – – – – –',
    `👑 رهبر کشور: <b>${esc(ctx.state.user.displayName)}</b>`,
    minister ? `🧑‍✈️ وزیر منصوب: <b>${esc(minister.name)}</b> (شناسه: <code>${minister.telegramId}</code>)` : '⚠️ وزیری منصوب نشده است.',
    '',
    '🛡️ <b>مزیت فعال:</b> +۱۰٪ پایداری دفاعی در برابر حملات',
  ];
  const rows = [
    minister ? [cb('🔄 تغییر وزیر', 'emp:minister:list:0', 'primary'), cb('❌ عزل وزیر', 'emp:minister:dismiss', 'danger')] : [cb('➕ انتصاب وزیر', 'emp:minister:list:0', 'success')],
    [cb('🔙 بازگشت به منوی اصلی', 'menu:home', 'primary')],
  ];
  return ctx.reply(lines.join('\n'), {
    parse_mode: 'HTML',
    reply_markup: { inline_keyboard: rows },
  });
});

composer.hears(['فرمانده 🧑‍✈️', 'فرمانده', 'وزیر', 'هیئت وزیران'], async (ctx) => {
  const { season, own } = await ownershipOf(ctx);
  if (!own || !season) {
    return ctx.reply('⚠️ ابتدا باید هدایت یک کشور را برعهده بگیرید تا بتوانید وزیر یا جانشین فرماندهی منصوب کنید.', pickCountryKb());
  }
  const state = await gameService.getCountryState(own.countryId, season.id);
  const flag = countryService.getDynamicFlag(own.country, state);
  const minister = state.minister || (state.ministerTelegramId ? {
    name: state.ministerName || 'نامشخص',
    telegramId: state.ministerTelegramId,
  } : null);

  const lines = [
    `🎖️ <b>فرماندهی کل قوا و هیئت وزیران — ${esc(own.country.name)} ${flag}</b>`,
    '– – – – – – – – – –',
    `👑 رهبر کشور: <b>${esc(ctx.state.user.displayName)}</b>`,
    minister ? `🧑‍✈️ وزیر منصوب: <b>${esc(minister.name)}</b> (شناسه: <code>${minister.telegramId}</code>)` : '⚠️ وزیری منصوب نشده است.',
  ];
  const rows = [
    minister ? [cb('🔄 تغییر وزیر', 'emp:minister:list:0', 'primary'), cb('❌ عزل وزیر', 'emp:minister:dismiss', 'danger')] : [cb('➕ انتصاب وزیر', 'emp:minister:list:0', 'success')],
    [cb('🔙 منوی اصلی', 'menu:home', 'primary')],
  ];
  return ctx.reply(lines.join('\n'), {
    parse_mode: 'HTML',
    reply_markup: { inline_keyboard: rows },
  });
});

composer.action(['menu:coin', 'menu:shahi'], async (ctx) => {
  ctx.answerCbQuery().catch(() => {});
  const { season, own } = await ownershipOf(ctx);
  const userCoins = Number(ctx.state.user?.shahiCoins ?? ctx.state.user?.awCoins ?? 0);
  let countryCoins = userCoins;
  let treasury = 0;
  if (own && season) {
    const state = await gameService.getCountryState(own.countryId, season.id).catch(() => ({}));
    countryCoins = Number(state.shahiCoins || userCoins);
    treasury = Number(state.treasury || 0);
  }

  const rate = await gameService.getShahiExchangeRate();
  const text = [
    '👑 <b>مدیریت سکه شاهی (واحد ارزی پرمیوم متصل به خارج از بازی)</b>',
    '– – – – – – – – – –',
    'سکه شاهی ارزی ارزشمند و معتبر است که تنها از طریق <b>واریز مستقیم توسط ادمین</b> و یا <b>تکمیل ماموریت‌های روزانه</b> قابل دریافت است.',
    '',
    `👑 موجودی سکه شاهی شما: <b>${countryCoins.toLocaleString()} سکه</b>`,
    `💵 نرخ تبدیل معین ادمین: هر ۱ سکه شاهی = <b>${rate.toLocaleString()} $</b>`,
    own ? `🏛 موجودی فعلی خزانه کشور: <b>${treasury.toLocaleString()} $</b>` : '',
    '',
    '👇 جهت تبدیل سکه‌های شاهی به دلار خزانه یکی از گزینه‌های زیر را انتخاب کنید:',
  ].filter(Boolean).join('\n');

  const realPriceToman = await settings.get('shahi_coin_real_price_toman', 50000);

  const rows = [
    [
      cb('💎 خرید سکه شاهی (VIP با کارت به کارت / فیش)', 'shahi:vip:menu', 'success'),
    ],
    [
      cb(`💱 تبدیل ۱ سکه (+${(rate).toLocaleString()} $)`, 'coin:conv:1', 'primary'),
      cb(`💱 تبدیل ۵ سکه (+${(rate * 5).toLocaleString()} $)`, 'coin:conv:5', 'primary'),
    ],
    [
      cb('💱 تبدیل کل موجودی سکه شاهی به دلار', 'coin:conv:all', 'success'),
    ],
    [
      cb('🎯 ماموریت‌های روزانه (کسب سکه شاهی)', 'menu:mission', 'primary'),
      cb('🔙 بازگشت به منوی اصلی', 'menu:home', 'danger'),
    ],
  ];

  return ctx.editMessageText(text + `\n\n💎 <b>قیمت خرید مستقیم هر سکه شاهی:</b> <b>${fmtNum(realPriceToman)} تومان</b>`, {
    parse_mode: 'HTML',
    reply_markup: { inline_keyboard: rows },
  }).catch(() => {});
});

// منوی خرید سکه شاهی VIP (مشابه خرید کشور ویژه با کارت به کارت و فیش)
composer.action('shahi:vip:menu', async (ctx) => {
  ctx.answerCbQuery().catch(() => {});
  const realPriceToman = await settings.get('shahi_coin_real_price_toman', 50000);

  const text = [
    '💎 <b>خرید مستقیم سکه شاهی (VIP)</b>',
    '– – – – – – – – – –',
    'سکه شاهی ارزشمندترین دارایی و اعتبار امپراطوری در بازی است.',
    `💰 <b>قیمت هر ۱ سکه شاهی:</b> <b>${fmtNum(realPriceToman)} تومان</b>`,
    '',
    '👇 لطفاً بسته مورد نظر خود را جهت خرید انتخاب کنید:',
  ].join('\n');

  const rows = [
    [
      cb(`💎 ۵ سکه (${fmtNum(5 * realPriceToman)} ت)`, 'shahi:vip:buy:5', 'success'),
      cb(`💎 ۱۰ سکه (${fmtNum(10 * realPriceToman)} ت)`, 'shahi:vip:buy:10', 'success'),
    ],
    [
      cb(`💎 ۲۰ سکه (${fmtNum(20 * realPriceToman)} ت)`, 'shahi:vip:buy:20', 'success'),
      cb(`💎 ۵۰ سکه (${fmtNum(50 * realPriceToman)} ت)`, 'shahi:vip:buy:50', 'success'),
    ],
    [
      cb('✏️ تعیین تعداد دلخواه سکه شاهی', 'shahi:vip:buy:custom', 'primary'),
    ],
    [
      cb('🔙 بازگشت به مدیریت سکه شاهی', 'menu:coin', 'danger'),
    ],
  ];

  await ctx.editMessageText(text, {
    parse_mode: 'HTML',
    reply_markup: { inline_keyboard: rows },
  }).catch(() => {});
});

async function initiateShahiOrder(ctx, count) {
  const realPriceToman = await settings.get('shahi_coin_real_price_toman', 50000);
  const card = await settings.get('paymentCardNumber', '');
  const holder = await settings.get('paymentCardHolder', '');
  const note = await settings.get('paymentNote', '');

  const totalToman = count * realPriceToman;
  const { own } = await ownershipOf(ctx);

  const orderRef = col('shahi_orders').doc();
  const orderId = orderRef.id;

  await orderRef.set({
    id: orderId,
    userId: String(ctx.from.id),
    telegramId: Number(ctx.from.id),
    displayName: ctx.state.user?.displayName || ctx.from.first_name || 'کاربر',
    countryId: own?.countryId || null,
    countryName: own?.country?.name || null,
    countryFlag: own?.country?.flag || '👑',
    coinsCount: count,
    unitPriceToman: realPriceToman,
    totalPriceToman: totalToman,
    status: 'awaiting_receipt',
    createdAt: new Date(),
  });

  await userService.setFlow(ctx.from.id, `shahi:receipt:${orderId}`, {
    orderId,
    coinsCount: count,
    totalPriceToman: totalToman,
  });

  const lines = [
    `💎 <b>سفارش خرید VIP: ${fmtNum(count)} عدد سکه شاهی</b>`,
    '– – – – – – – – – –',
    `💰 مبلغ کل قابل پرداخت: <b>${fmtNum(totalToman)} تومان</b>`,
    `💳 شماره کارت واریز: <code>${esc(card || 'تنظیم‌نشده توسط مدیر')}</code>`,
    holder ? `👤 به نام: <b>${esc(holder)}</b>` : '',
    note ? `📝 نکته: <i>${esc(note)}</i>` : '',
    '',
    '📸 لطفاً پس از کارت به کارت، <b>تصویر فیش واریزی</b> یا <b>کد پیگیری تراکنش (متن)</b> را همین‌جا ارسال فرمایید.',
    '<i>(جهت انصراف عبارت /cancel را ارسال کنید)</i>',
  ].filter(Boolean);

  await ctx.reply(lines.join('\n'), { parse_mode: 'HTML' });
}

composer.action(/^shahi:vip:buy:(\d+)$/, async (ctx) => {
  await ctx.answerCbQuery().catch(() => {});
  const count = Number(ctx.match[1]);
  await initiateShahiOrder(ctx, count);
});

composer.action('shahi:vip:buy:custom', async (ctx) => {
  await ctx.answerCbQuery().catch(() => {});
  await userService.setFlow(ctx.from.id, 'shahi:vip:custom_count');
  await ctx.reply('✍️ لطفاً <b>تعداد سکه شاهی مورد نیاز</b> خود را به صورت عدد انگلیسی یا فارسی بنویسید و ارسال کنید:\n(مثال: 15 یا 25)\nلغو: /cancel', {
    parse_mode: 'HTML',
  });
});

registerFlow('shahi:vip:custom_count', async (ctx) => {
  const raw = String(ctx.message?.text || '').trim();
  if (raw === '/cancel') {
    await userService.clearFlow(ctx.from.id);
    return ctx.reply('عملیات خرید لغو شد.');
  }
  const count = parseInt(raw.replace(/[۰-۹]/g, (d) => String(d.charCodeAt(0) - 0x06f0)), 10);
  if (!Number.isFinite(count) || count <= 0 || count > 1000) {
    return ctx.reply('⚠️ لطفاً عددی معتبر بین ۱ تا ۱۰۰۰ وارد فرمایید.');
  }
  await initiateShahiOrder(ctx, count);
});

// ثبت فیش واریزی توسط کاربر
registerFlow(/^shahi:receipt:(.+)$/, async (ctx, match, data) => {
  const orderId = match ? match[1] : data.orderId;
  const isCancel = ctx.message?.text === '/cancel';
  if (isCancel) {
    await userService.clearFlow(ctx.from.id);
    return ctx.reply('ارسال فیش لغو شد.');
  }

  const isPhoto = Boolean(ctx.message?.photo && ctx.message.photo.length);
  const textMsg = ctx.message?.text || ctx.message?.caption || '';

  if (!isPhoto && (!textMsg || textMsg.length < 4)) {
    return ctx.reply('⚠️ لطفاً یک تصویر فیش واریزی یا متن کامل کد رهگیری بانکی ارسال فرمایید.');
  }

  const photoFileId = isPhoto ? ctx.message.photo[ctx.message.photo.length - 1].file_id : null;

  const orderRef = col('shahi_orders').doc(orderId);
  const orderSnap = await orderRef.get();
  if (!orderSnap.exists) {
    await userService.clearFlow(ctx.from.id);
    return ctx.reply('سفارش مورد نظر یافت نشد.');
  }

  const orderData = orderSnap.data();
  const receiptData = {
    type: isPhoto ? 'photo' : 'text',
    fileId: photoFileId,
    text: textMsg,
    submittedAt: new Date(),
  };

  await orderRef.update({
    status: 'pending_admin',
    receipt: receiptData,
  });

  await userService.clearFlow(ctx.from.id);

  // پیام تایید به کاربر
  await ctx.reply([
    '✅ <b>رسید واریز شما با موفقیت ثبت شد!</b>',
    '– – – – – – – – – –',
    `💎 تعداد سکه درخواستی: <b>${fmtNum(orderData.coinsCount)} سکه شاهی</b>`,
    `💰 مبلغ واریزی: <b>${fmtNum(orderData.totalPriceToman)} تومان</b>`,
    'اطلاعات برای بررسی و تایید در صف مدیریت قرار گرفت. به محض تایید مدیر، سکه‌ها به صورت خودکار به حسابتان واریز خواهد شد.',
  ].join('\n'), {
    parse_mode: 'HTML',
    reply_markup: {
      inline_keyboard: [
        [cb('👑 بازگشت به سکه شاهی', 'menu:coin', 'primary')],
      ],
    },
  });

  // اعلان به مدیران
  const { notifyAdmins } = require('../services/notificationService');
  const adminMsg = [
    '🧾 <b>درخواست جدید خرید سکه شاهی VIP با فیش بانکی!</b>',
    '– – – – – – – – – –',
    `👤 کاربر: <b>${esc(orderData.displayName)}</b> (<code>${orderData.telegramId}</code>)`,
    orderData.countryName ? `🌍 کشور: <b>${orderData.countryFlag} ${esc(orderData.countryName)}</b>` : '',
    `💎 تعداد سکه: <b>${fmtNum(orderData.coinsCount)} سکه شاهی</b>`,
    `💰 مبلغ فیش: <b>${fmtNum(orderData.totalPriceToman)} تومان</b>`,
    `📋 شناسه سفارش: <code>${orderId}</code>`,
    'جهت بررسی و تایید به ربات یا پنل مدیریت مراجعه فرمایید.',
  ].filter(Boolean).join('\n');

  await notifyAdmins(ctx.telegram, adminMsg, {
    reply_markup: {
      inline_keyboard: [
        [{ text: '🔍 بررسی در پنل', callback_data: `adbot:shahi:view:${orderId}` }],
      ],
    },
  }).catch(() => {});
});

composer.action(/^coin:conv:(1|5|all)$/, async (ctx) => {
  ctx.answerCbQuery().catch(() => {});
  const { season, own } = await ownershipOf(ctx);
  if (!own || !season) {
    return ctx.reply('برای تبدیل سکه شاهی به دلار ابتدا باید رهبری یک کشور را داشته باشید.');
  }

  const state = await gameService.getCountryState(own.countryId, season.id);
  const currentShahi = Number(state.shahiCoins || ctx.state.user?.shahiCoins || 0);
  const choice = ctx.match[1];
  let toConvert = choice === 'all' ? currentShahi : Number(choice);

  if (toConvert <= 0 || currentShahi < toConvert) {
    return ctx.reply(`⚠️ سکه شاهی کافی برای تبدیل ندارید! موجودی فعلی شما: ${currentShahi} سکه است.`);
  }

  try {
    const res = await gameService.convertShahiToDollars(own.countryId, season.id, toConvert, ctx.from.id);
    await ctx.reply(`✅ <b>تبدیل موفق سکه شاهی!</b>\nتعداد <b>${res.convertedShahi} سکه شاهی</b> با نرخ هر سکه <b>${res.rate.toLocaleString()}$</b> تبدیل شد و مبلغ <b>${res.addedDollars.toLocaleString()}$</b> مستقیماً به خزانه کشور واریز گردید.\n\n👑 موجودی باقی‌مانده سکه شاهی: <b>${res.newShahiCoins}</b>\n💵 موجودی جدید خزانه: <b>${res.newTreasury.toLocaleString()}$</b>`, {
      parse_mode: 'HTML',
      reply_markup: {
        inline_keyboard: [
          [cb('👑 بازگشت به مدیریت سکه شاهی', 'menu:coin', 'primary')],
          [cb('👑 امپراطوری من', 'menu:empire', 'success')],
        ],
      },
    });
  } catch (err) {
    await ctx.reply(`⚠️ خطا در تبدیل سکه شاهی: ${err.message}`);
  }
});


async function renderTutorialPanel(ctx, isEdit = false) {
  const userId = ctx.from.id;
  const tut = await tutorialService.getPlayerTutorial(userId);
  const { season, own } = await ownershipOf(ctx);

  const completed = tut.completedSteps || [];
  const steps = tutorialService.TUTORIAL_STEPS;
  const isAllDone = completed.length >= 10;

  const lines = [
    '🎓 <b>آموزش تعاملی ۱۰ مرحله‌ای رهبری و کشورداری</b>',
    '– – – – – – – – – –',
    'با پشت سر گذاشتن این ۱۰ گام راهبردی، به یک رهبر تمام‌عیار تبدیل شده و <b>۱۰۰ میلیون دلار وجه نقد + ۵ سکه شاهی</b> پاداش شروع دریافت کنید:',
    '',
    `📊 وضعیت پیشرفت شما: <b>${completed.length} از ۱۰ گام تکمیل شده</b>`,
    '– – – – – – – – – –',
  ];

  let nextStepToVerify = null;

  for (const s of steps) {
    const isDone = completed.includes(s.id);
    if (isDone) {
      lines.push(`✅ <b>گام ${s.id}: ${esc(s.title)}</b> (تکمیل شد)`);
    } else {
      lines.push(`⏳ <b>گام ${s.id}: ${esc(s.title)}</b>\n   <i>${esc(s.desc)}</i>`);
      if (!nextStepToVerify) nextStepToVerify = s.id;
    }
  }

  lines.push('– – – – – – – – – –');

  const rows = [];
  if (!isAllDone && nextStepToVerify && own && season) {
    rows.push([Markup.button.callback(`🔍 بررسی و ثبت خودکار گام ${nextStepToVerify}`, `tut:verify:${nextStepToVerify}`)]);
  }

  if (isAllDone) {
    if (tut.rewardClaimed) {
      lines.push('🎉 <b>تبریک! کلیه مراحل آموزش تکمیل و پاداش یکبار مصرف اولیه قبلاً دریافت شده است.</b>');
    } else {
      lines.push('🎁 <b>کلیه ۱۰ گام با موفقیت تکمیل شدند! اکنون می‌توانید پاداش شروع را دریافت نمایید:</b>');
      rows.push([Markup.button.callback('🎁 دریافت پاداش ۱۰۰M $ + ۵ سکه شاهی', 'tut:claim_reward')]);
    }
  }

  rows.push([Markup.button.callback('🔙 بازگشت به منوی اصلی', 'menu:home')]);

  const text = lines.join('\n');
  const kb = Markup.inlineKeyboard(rows);

  if (isEdit && ctx.callbackQuery) {
    await ctx.editMessageText(text, { parse_mode: 'HTML', reply_markup: kb.reply_markup }).catch(() => {});
  } else {
    await ctx.reply(text, { parse_mode: 'HTML', ...kb });
  }
}

composer.hears(L.tutorial, async (ctx) => {
  await renderTutorialPanel(ctx, false);
});

composer.action('menu:tutorial', async (ctx) => {
  await ctx.answerCbQuery().catch(() => {});
  await renderTutorialPanel(ctx, true);
});

composer.action(/^tut:verify:(\d+)$/, async (ctx) => {
  const stepId = Number(ctx.match[1]);
  const { season, own } = await ownershipOf(ctx);
  if (!own || !season) {
    return ctx.answerCbQuery('برای ثبت مراحل آموزش ابتدا باید یک کشور انتخاب کنید.', { show_alert: true });
  }

  const res = await tutorialService.completeTutorialStep(ctx.from.id, own.countryId, season.id, stepId);
  if (res && res.alreadyCompleted) {
    await ctx.answerCbQuery('این مرحله قبلاً ثبت شده است.');
  } else if (res && res.valid) {
    await ctx.answerCbQuery(`🎉 گام ${stepId} با موفقیت تایید و تکمیل شد!`, { show_alert: true });
  } else {
    await ctx.answerCbQuery(`⚠️ شرایط گام ${stepId} هنوز برقرار نشده است. طبق راهنما اقدام کنید.`, { show_alert: true });
  }
  await renderTutorialPanel(ctx, true);
});

composer.action('tut:claim_reward', async (ctx) => {
  const { season, own } = await ownershipOf(ctx);
  if (!own || !season) {
    return ctx.answerCbQuery('برای دریافت پاداش ابتدا باید کشور داشته باشید.', { show_alert: true });
  }

  try {
    const res = await tutorialService.claimTutorialReward(ctx.from.id, own.countryId, season.id);
    await ctx.answerCbQuery('🎉 پاداش ۱۰۰ میلیون دلار + ۵ سکه شاهی با موفقیت به حسابتان واریز شد!', { show_alert: true });
    await ctx.reply([
      '🎁 <b>تبریک! پاداش شروع بازی واریز شد</b>',
      '– – – – – – – – – –',
      `💵 وجه نقد واریز شده به خزانه: <b>+${res.cashReward.toLocaleString()}$</b>`,
      `👑 سکه شاهی اهدایی: <b>+${res.shahiReward} سکه شاهی</b>`,
      '',
      'اکنون کشور شما دارای پشتوانه قوی اقتصادی برای توسعه صنعتی و نظامی است.',
    ].join('\n'), {
      parse_mode: 'HTML',
      ...Markup.inlineKeyboard([[Markup.button.callback('👑 ورود به امپراطوری من', 'menu:empire')]]),
    });
    await renderTutorialPanel(ctx, false);
  } catch (err) {
    await ctx.answerCbQuery(`⚠️ ${err.message}`, { show_alert: true });
  }
});

composer.action('noop', (ctx) => ctx.answerCbQuery().catch(() => {}));

module.exports = { composer, requireCountry, ownershipOf, pickCountryKb };
