'use strict';
// پنل تلگرامی مدیر (سبک): بررسی درخواست‌ها و پرداخت‌ها. مدیریت کامل در داشبورد وب است.
const { Composer, Markup } = require('telegraf');
const { adminHome, backHome, requestActions } = require('../bot/keyboards/admin');
const { render, answer } = require('../bot/ui');
const { requestCardText } = require('../bot/views');
const { registerFlow } = require('../bot/flows');
const { esc, fmtNum } = require('../utils/text');
const { config } = require('../config');
const actions = require('../services/adminActions');
const selection = require('../services/selectionService');
const countryService = require('../services/countryService');
const userService = require('../services/userService');
const { getActiveSeason } = require('../services/seasonService');
const settings = require('../services/settingsService');
const logger = require('../utils/logger');

const composer = new Composer();
const ID = '([A-Za-z0-9_-]{3,40})';
const dashboardUrl = () => (config.publicUrl && config.publicUrl.startsWith('https://') ? `${config.publicUrl}/` : null);

// همه چیز سمت سرور با شناسه عددی بررسی می‌شود
composer.use(async (ctx, next) => {
  const data = ctx.callbackQuery && ctx.callbackQuery.data;
  if (data && data.startsWith('ad:') && !ctx.state.isAdmin) {
    logger.warn(`تلاش غیرمجاز برای دسترسی به پنل مدیریت از کاربر ${ctx.from.id}`);
    await ctx.answerCbQuery('⛔ دسترسی ندارید', { show_alert: true }).catch(() => {});
    return undefined;
  }
  return next();
});

// پنل ادمین به طور کامل از ربات اصلی حذف شده و به ربات اختصاصی ادمین (adminBotService) منتقل گردیده است.
const ADMIN_MOVED_MSG = [
  '🛡️ <b>اطلاعیه مدیریت بازی</b>',
  '– – – – – – – – – –',
  'پنل مدیریت به طور کامل از ربات اصلی حذف گردیده و به <b>ربات اختصاصی و مجزای ادمین</b> منتقل شده است.',
  'ربات اصلی صرفاً برای تجربه گیم‌پلی بازیکنان اختصاص دارد.',
  'جهت انجام امور مدیریتی، لطفاً از ربات دوم مدیریت استفاده فرمایید.',
].join('\n');

composer.command('admin', async (ctx) => {
  if (!ctx.state.isAdmin) return;
  await ctx.reply(ADMIN_MOVED_MSG, { parse_mode: 'HTML' });
});


// (پنل ادمین قدیمی به ربات اختصاصی منتقل شده؛ callbackهای ad: در صورت نیاز توسط هندلرهای اختصاصی پردازش می‌شوند)


composer.action('ad:backtoplayer', async (ctx) => {
  await answer(ctx);
  await userService.clearFlow(ctx.state.user.telegramId);
  const { mainInlineMenu } = require('../bot/keyboards/main');
  await ctx.reply('👇 بازگشت به منوی بازی:', mainInlineMenu(ctx.state.isAdmin));
});

composer.action('ad:rql', async (ctx) => {
  await answer(ctx);
  const reqs = (await selection.listOpenRequests()).slice(0, 25);
  if (!reqs.length) return render(ctx, '📭 درخواست بازی وجود ندارد.', backHome());
  const icon = (r) => (r.paymentStatus === 'submitted' ? '💳' : r.paymentStatus === 'awaiting' ? '⏳' : '🆓');
  const rows = reqs.map((r) => [Markup.button.callback(`${icon(r)} ${r.country?.flag || ''} ${r.country?.name || '?'} — ${r.displayName}`.slice(0, 60), `ad:rq:${r.id}`)]);
  rows.push([Markup.button.callback('🏠 پنل', 'ad:home')]);
  await render(ctx, `📥 <b>درخواست‌های باز</b> (${fmtNum(reqs.length)})\n💳 رسید ارسال‌شده  ⏳ منتظر رسید  🆓 رایگان`, Markup.inlineKeyboard(rows));
});

async function showRequest(ctx, id) {
  const req = await selection.getRequest(id);
  if (!req) return render(ctx, '❌ درخواست یافت نشد.', backHome());
  const [country, user] = [await countryService.get(req.countryId), await userService.getById(req.userId)];
  await render(ctx, requestCardText(req, country, user), requestActions(req));
}
composer.action(new RegExp(`^ad:rq:${ID}$`), async (ctx) => { await answer(ctx); await showRequest(ctx, ctx.match[1]); });

composer.action(new RegExp(`^ad:rqa:${ID}:(\\w+)$`), async (ctx) => {
  const [id, act] = [ctx.match[1], ctx.match[2]];
  const adminId = ctx.from.id;
  await answer(ctx);
  if (act === 'payok') { await actions.approvePayment(ctx.telegram, id, adminId); return showRequest(ctx, id); }
  if (act === 'assign') { await actions.assignRequest(ctx.telegram, id, adminId); return showRequest(ctx, id); }
  if (act === 'payno' || act === 'no') {
    await userService.setFlow(adminId, 'adm:reject', { requestId: id, kind: act === 'payno' ? 'pay' : 'req' });
    return ctx.reply('📝 دلیل رد را بنویسید (برای ردکردن بدون توضیح «-» بفرستید). لغو: /cancel');
  }
  if (act === 'rcpt') {
    const pay = await selection.getPayment(id);
    if (!pay) return ctx.reply('رسیدی ثبت نشده است.');
    const cap = `🧾 رسید درخواست #${String(id).slice(-6)}${pay.receipt.text ? `\n${esc(pay.receipt.text)}` : ''}`;
    if (pay.receipt.type === 'photo') return ctx.replyWithPhoto(pay.receipt.fileId, { caption: cap, parse_mode: 'HTML' });
    return ctx.reply(cap, { parse_mode: 'HTML' });
  }
  return undefined;
});

registerFlow('adm:reject', async (ctx, data) => {
  if (!ctx.message.text) return ctx.reply('لطفاً متن بفرستید.');
  const note = ctx.message.text.trim().slice(0, 500);
  if (data.kind === 'pay') await actions.rejectPayment(ctx.telegram, data.requestId, ctx.from.id, note);
  else await actions.rejectRequest(ctx.telegram, data.requestId, ctx.from.id, note);
  await userService.clearFlow(ctx.from.id);
  await ctx.reply('✅ ثبت شد و به بازیکن اطلاع داده شد.', backHome());
});

composer.action('ad:cmpl', async (ctx) => {
  await answer(ctx);
  const { col, docs } = require('../db/firestore');
  const q = await col('complaints').limit(15).get();
  const list = docs(q);
  if (!list.length) return render(ctx, '📭 در حال حاضر هیچ شکایتی ثبت نشده است.', backHome());
  const rows = list.map((c) => [Markup.button.callback(`⚖️ ${c.userDisplayName} علیه ${c.againstCountry}`.slice(0, 50), `ad:cmpv:${c.id}`)]);
  rows.push([Markup.button.callback('🏠 پنل', 'ad:home')]);
  await render(ctx, `⚖️ <b>فهرست آخرین شکایات کاربران</b> (${list.length}):`, Markup.inlineKeyboard(rows));
});

composer.action(/^ad:cmpv:(.+)$/, async (ctx) => {
  await answer(ctx);
  const id = ctx.match[1];
  const { col, snap } = require('../db/firestore');
  const c = snap(await col('complaints').doc(id).get());
  if (!c) return render(ctx, 'شکایت یافت نشد.', backHome());
  const text = [
    `⚖️ <b>بررسی شکایت #${c.id.slice(-6)}</b>`,
    '– – – – – – – – – –',
    `👤 شاکی: ${esc(c.userDisplayName)} (آیدی: <code>${c.userId}</code>)`,
    `🎯 طرف شکایت: <b>${esc(c.againstCountry)}</b>`,
    `🕒 تاریخ: ${fmtDate(c.createdAt)}`,
    '',
    `📝 شرح شکایت:\n« ${esc(c.text)} »`,
  ].join('\n');
  const reviewKb = Markup.inlineKeyboard([
    [Markup.button.callback('✅ تأیید شکایت', `ad:cmpdo:${id}:approved`), Markup.button.callback('❌ رد شکایت', `ad:cmpdo:${id}:rejected`)],
    [Markup.button.callback('🔙 فهرست شکایات', 'ad:cmpl'), Markup.button.callback('🏠 پنل', 'ad:home')],
  ]);
  if (c.photoFileId) {
    await ctx.replyWithPhoto(c.photoFileId, { caption: text, parse_mode: 'HTML', ...reviewKb });
  } else {
    await render(ctx, text, reviewKb);
  }
});

composer.action(/^ad:cmpdo:(.+):(approved|rejected)$/, async (ctx) => {
  await answer(ctx);
  const id = ctx.match[1], status = ctx.match[2];
  const { col, snap } = require('../db/firestore');
  const ref = col('complaints').doc(id);
  const c = snap(await ref.get());
  if (!c) return render(ctx, 'شکایت پیدا نشد.', backHome());
  if (c.status === 'approved' || c.status === 'rejected') return render(ctx, 'این شکایت قبلاً بررسی شده است.', backHome());
  const statusText = status === 'approved' ? 'تأیید شد' : 'رد شد';
  await ref.update({ status, reviewedAt: new Date(), reviewedBy: String(ctx.from.id) });
  await ctx.telegram.sendMessage(Number(c.userId), `⚖️ نتیجه بررسی شکایت شما: ${statusText}\nکد شکایت: ${id}`).catch(() => {});
  await render(ctx, `✅ شکایت ${statusText} شد و نتیجه به پیوی شاکی ارسال شد.`, backHome());
});

// ارسال پیام اختصاصی فقط به یک بازیکن (با شناسه عددی تلگرام)
composer.action('ad:dm:prompt', async (ctx) => {
  await answer(ctx);
  await userService.setFlow(ctx.from.id, 'adm:dm:target', {});
  await ctx.reply('شناسه عددی تلگرام بازیکن مقصد را بفرست:');
});
registerFlow('adm:dm:target', async (ctx) => {
  const targetId = String(ctx.message.text || '').trim();
  if (!/^\\d{4,20}$/.test(targetId)) return ctx.reply('شناسه نامعتبر است؛ فقط عدد بفرست.');
  await userService.setFlow(ctx.from.id, 'adm:dm:text', { targetId });
  await ctx.reply('متن پیام اختصاصی را بفرست:');
});
registerFlow('adm:dm:text', async (ctx, data) => {
  const body = String(ctx.message.text || '').trim();
  if (!body) return ctx.reply('متن پیام خالی است.');
  try {
    await ctx.telegram.sendMessage(Number(data.targetId), `📩 پیام اختصاصی مدیریت:\\n\\n${body}`);
    await ctx.reply('✅ پیام فقط برای همان بازیکن ارسال شد.');
    await userService.clearFlow(ctx.from.id);
  } catch (err) { await ctx.reply('❌ ارسال پیام ناموفق بود؛ شناسه را بررسی کن و مطمئن شو بازیکن ربات را شروع کرده است.'); }
});

// ارسال اطلاعیه از طریق ربات با متن یا عکس
composer.action('ad:bc:prompt', async (ctx) => {
  await answer(ctx);
  await userService.setFlow(ctx.from.id, 'adm:broadcast', {});
  await ctx.reply('📢 <b>ارسال اطلاعیه رسمی:</b>\nلطفاً متن اطلاعیه خود را بفرستید، یا یک تصویر همراه با متن (کپشن) ارسال کنید.\nجهت انصراف: /cancel', backHome());
});

registerFlow('adm:broadcast', async (ctx) => {
  let text = '';
  let photoFileId = null;

  if (ctx.message.photo && ctx.message.photo.length) {
    const highest = ctx.message.photo[ctx.message.photo.length - 1];
    photoFileId = highest.file_id;
    text = (ctx.message.caption || '').trim();
  } else if (ctx.message.text) {
    text = ctx.message.text.trim();
  }

  if (!text && !photoFileId) {
    return ctx.reply('لطفاً یک متن یا تصویر با متن برای اطلاعیه بفرستید.');
  }

  if (!text) text = 'اطلاعیه مهم مدیریت World War Fire';

  await ctx.reply('⏳ در حال انتشار اطلاعیه به کانال رسمی و ارسال به کاربران...');
  try {
    const res = await actions.broadcast(ctx.telegram, {
      text,
      photoUrl: photoFileId,
      target: 'both',
    }, ctx.from.id, 'bot');

    await userService.clearFlow(ctx.from.id);
    await ctx.reply(`✅ <b>اطلاعیه با موفقیت ارسال شد!</b>\nکانال: ${res.channel === 'ok' ? 'منتشر شد ✅' : 'رد شد'}\nکاربران موفق: ${res.ok} نفر | ناموفق: ${res.fail} نفر`, backHome());
  } catch (err) {
    await userService.clearFlow(ctx.from.id);
    await ctx.reply(`❌ خطا در ارسال اطلاعیه: ${err.message}`, backHome());
  }
});

composer.command('unshield', async (ctx) => {
  if (!ctx.state.isAdmin) return;
  const parts = String(ctx.message.text || '').trim().split(/\s+/);
  const countryId = parts[1];
  if (!countryId) return ctx.reply('استفاده: /unshield <countryId>');
  const seasonService = require('../services/seasonService');
  const gameService = require('../services/gameService');
  const season = await seasonService.getActiveSeason();
  if (!season) return ctx.reply('سیزن فعالی وجود ندارد.');
  await gameService.deactivateSleepShield(countryId, season.id);
  await ctx.reply(`✅ سپر خواب کشور ${countryId} لغو شد.`);
});
composer.command('setprovinces', async (ctx) => {
  if (!ctx.state.isAdmin) return;
  const parts = String(ctx.message.text || '').trim().split(/\s+/);
  const countryId = parts[1];
  const json = ctx.message.text.slice(ctx.message.text.indexOf(parts[2] || '')).trim();
  if (!countryId || !json) return ctx.reply('استفاده: /setprovinces <countryId> <JSON provinces>');
  try {
    const provinces = JSON.parse(json);
    const seasonService = require('../services/seasonService');
    const gameService = require('../services/gameService');
    const season = await seasonService.getActiveSeason();
    if (!season) return ctx.reply('سیزن فعالی وجود ندارد.');
    await gameService.updateCountryState(countryId, season.id, { provinces });
    await ctx.reply(`✅ استان‌های کشور ${countryId} به‌روزرسانی شد (${Array.isArray(provinces) ? provinces.length : 0} استان).`);
  } catch (e) {
    await ctx.reply(`❌ ${e.message}`);
  }
});
composer.command('setmapregion', async (ctx) => {
  if (!ctx.state.isAdmin) return;
  const parts = String(ctx.message.text || '').trim().split(/\s+/);
  const countryId = parts[1];
  const regionId = parts[2];
  if (!countryId || !regionId) return ctx.reply('استفاده: /setmapregion <countryId> <regionId>');
  try {
    const countryService = require('../services/countryService');
    await countryService.update(countryId, { mapRegion: regionId });
    await ctx.reply(`✅ ناحیهٔ نقشهٔ کشور ${countryId} به «${regionId}» تنظیم شد.`);
  } catch (e) {
    await ctx.reply(`❌ ${e.message}`);
  }
});
composer.command('warlogtoggle', async (ctx) => {
  if (!ctx.state.isAdmin) return;
  const parts = String(ctx.message.text || '').trim().split(/\s+/);
  const arg = (parts[1] || '').toLowerCase();
  const settingsService = require('../services/settingsService');
  let current = await settingsService.get('war_logs_enabled', true);
  let next = current;
  if (arg === 'on') next = true;
  else if (arg === 'off') next = false;
  else next = !current;
  await settingsService.set('war_logs_enabled', next);
  await ctx.reply(`✅ لاگ جنگ ${next ? 'روشن' : 'خاموش'} شد.`);
});
composer.command('analysis', async (ctx) => {
  if (!ctx.state.isAdmin) return;
  try {
    const seasonService = require('../services/seasonService');
    const warService = require('../services/warService');
    const straitService = require('../services/straitService');
    const season = await seasonService.getActiveSeason();
    const wars = season ? await warService.listWars(season.id) : [];
    const straits = season ? await straitService.getStraits(season.id) : [];
    const closed = straits.filter((s) => s.blockade && s.blockade.status === 'approved');
    const lines = [
      '📊 <b>تحلیل استراتژیک بازی</b>',
      '– – – – – – – – – –',
      `جنگ‌های فعال: <b>${wars.filter((w) => ['active', 'approved'].includes(w.status)).length}</b>`,
      `تنگه‌های بسته: <b>${closed.length}</b>`,
      closed.length ? `تنگه‌های بسته: ${closed.map((s) => s.name).join('، ')}` : 'هیچ تنگه‌ای بسته نیست.',
      '',
      '💡 <b>تحلیل:</b>',
      closed.length ? '• بسته شدن تنگه‌ها موجب افزایش قیمت منابع و فشار اقتصادی بر کشورهای وابسته می‌شود.' : '• مسیرهای دریایی آزاد است؛ فشار اقتصادی ناشی از تنگه وجود ندارد.',
      wars.length ? '• جنگ‌های فعال موجب مصرف منابع نظامی و کاهش بودجهٔ کشورهای درگیر می‌شوند.' : '• در حال حاضر جنگ فعالی ثبت نشده است.',
      '',
      '– – – – – – – – – –',
      'برای جزئیات بیشتر از داشبورد وب استفاده کنید.',
    ].join('\\n');
    await ctx.reply(lines, { parse_mode: 'HTML' });
  } catch (e) {
    await ctx.reply(`❌ ${e.message}`);
  }
});
module.exports = { composer };
