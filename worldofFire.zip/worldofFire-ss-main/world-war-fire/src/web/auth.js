'use strict';
const crypto = require('crypto');
const { config } = require('../config');

const TTL_MS = 12 * 60 * 60 * 1000;
const b64 = (s) => Buffer.from(s).toString('base64url');
const hmac = (s) => crypto.createHmac('sha256', config.sessionSecret).update(s).digest('base64url');

function safeEqual(a, b) {
  const ha = crypto.createHash('sha256').update(String(a)).digest();
  const hb = crypto.createHash('sha256').update(String(b)).digest();
  return crypto.timingSafeEqual(ha, hb);
}

function issueToken() {
  const payload = b64(JSON.stringify({ exp: Date.now() + TTL_MS }));
  return `${payload}.${hmac(payload)}`;
}

function verifyToken(token) {
  if (!token || typeof token !== 'string' || !token.includes('.')) return false;
  const [payload, sig] = token.split('.');
  if (!sig || !safeEqual(sig, hmac(payload))) return false;
  try {
    return JSON.parse(Buffer.from(payload, 'base64url').toString()).exp > Date.now();
  } catch (_) { return false; }
}

// محدودیت تلاش ناموفق ورود برای هر IP
const attempts = new Map();
const MAX_FAILS = 5;
const LOCK_MS = 10 * 60 * 1000;

function loginLocked(ip) {
  const a = attempts.get(ip);
  return Boolean(a && a.until && a.until > Date.now());
}
function recordFail(ip) {
  const a = attempts.get(ip) || { count: 0, until: 0 };
  a.count += 1;
  if (a.count >= MAX_FAILS) { a.until = Date.now() + LOCK_MS; a.count = 0; }
  attempts.set(ip, a);
}
const clearFails = (ip) => attempts.delete(ip);

function requireAuth(req, res, next) {
  const h = req.get('authorization') || '';
  const token = h.startsWith('Bearer ') ? h.slice(7) : '';
  if (!verifyToken(token)) return res.status(401).json({ error: 'نیاز به ورود' });
  return next();
}

function checkPassword(p) { return safeEqual(p || '', config.adminPassword); }

module.exports = { issueToken, verifyToken, requireAuth, checkPassword, loginLocked, recordFail, clearFails, safeEqual };
