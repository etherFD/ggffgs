'use strict';
const path = require('path');
const crypto = require('crypto');
const express = require('express');
const { config } = require('../config');
const logger = require('../utils/logger');
const { GameError } = require('../utils/errors');
const auth = require('./auth');
const actions = require('../services/adminActions');
const selection = require('../services/selectionService');
const countryService = require('../services/countryService');
const userService = require('../services/userService');
const seasonService = require('../services/seasonService');
const ownership = require('../services/ownershipService');
const settings = require('../services/settingsService');
const audit = require('../services/auditService');
const webhook = require('../services/webhookService');
const weaponService = require('../services/weaponService');
const warService = require('../services/warService');
const notifications = require('../services/notificationService');
const gameService = require('../services/gameService');
const straitService = require('../services/straitService');
const cryptoService = require('../services/cryptoService');
const gameLoopService = require('../services/gameLoopService');
const { col, docs } = require('../db/firestore');

const WEB_ADMIN = 0; // شناسه ادمین وب در گزارش حسابرسی (via='web')
const VIA = 'web';
const PUBLIC_DIR = path.join(__dirname, '..', '..', 'public');

// bot: نمونه Telegraf؛ ready: Promise آماده‌شدن دیتابیس/ربات
function createWebApp({ bot, ready = Promise.resolve() }) {
  const app = express();
  app.set('trust proxy', true);
  app.disable('x-powered-by');
  app.use((req, res, next) => {
    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.setHeader('Referrer-Policy', 'no-referrer');
    next();
  });

  app.get('/health', (req, res) => res.json({ ok: true, service: 'world-war-fire' }));

  // ---------- وب‌هوک تلگرام ----------
  const handleTgWebhook = async (req, res) => {
    const sec = req.headers['x-telegram-bot-api-secret-token'];
    if (config.webhookSecret && sec !== config.webhookSecret) {
      return res.status(401).json({ error: 'توکن مخفی وب‌هوک نامعتبر است' });
    }
    try {
      await ready;
      if (req.body && typeof req.body === 'object' && Object.keys(req.body).length > 0) {
        await bot.handleUpdate(req.body);
      }
    } catch (err) {
      logger.error('خطای پردازش آپدیت تلگرام:', err.message);
    }
    return res.status(200).json({ ok: true });
  };

  const fallbackWebhook = async (req, res) => {
    return res.status(200).json({ ok: true });
  };

  app.post(`/telegram/${config.webhookPath}`, express.json({ limit: '10mb' }), handleTgWebhook);
  app.post('/telegram/webhook', express.json({ limit: '10mb' }), fallbackWebhook);
  app.post('/api/telegram/webhook', express.json({ limit: '10mb' }), fallbackWebhook);
  app.get([`/telegram/${config.webhookPath}`, '/telegram/webhook', '/api/telegram/webhook'], (req, res) => {
    res.status(200).json({ ok: true, message: 'وب‌هوک فعال است.' });
  });

  const uploadsDir = path.join(PUBLIC_DIR, 'uploads');
  const flagsDir = path.join(PUBLIC_DIR, 'flags');
  try {
    const fs = require('fs');
    if (!fs.existsSync(uploadsDir)) fs.mkdirSync(uploadsDir, { recursive: true });
    if (!fs.existsSync(flagsDir)) fs.mkdirSync(flagsDir, { recursive: true });
  } catch (_) {}
  app.use('/uploads', express.static(uploadsDir));
  app.use('/flags', express.static(flagsDir));

  // ---------- صفحه داشبورد ----------
  const page = (req, res) => res.sendFile(path.join(PUBLIC_DIR, 'admin.html'));
  app.get('/miniapp', (req, res) => res.sendFile(path.join(PUBLIC_DIR, 'miniapp.html')));
  app.get('/miniapp/', (req, res) => res.redirect(302, '/miniapp'));
  app.get(['/', '/admin', '/admin/*'], page);


  // ---------- Telegram Mini App API (initData HMAC verification) ----------
  function verifyTelegramInitData(initData) {
    if (!initData || typeof initData !== 'string' || initData.length > 8192 || !config.botToken) return null;
    try {
      const params = new URLSearchParams(initData);
      const receivedHash = params.get('hash');
      const userRaw = params.get('user');
      const authDate = Number(params.get('auth_date'));
      if (!receivedHash || !/^[a-f0-9]{64}$/i.test(receivedHash) || !userRaw || !Number.isFinite(authDate)) return null;
      const nowSeconds = Math.floor(Date.now() / 1000);
      if (authDate > nowSeconds + 30 || nowSeconds - authDate > 86400) return null;
      const dataCheckString = [...params.entries()]
        .filter(([key]) => key !== 'hash')
        .sort(([a], [b]) => (a < b ? -1 : a > b ? 1 : 0))
        .map(([key, value]) => `${key}=${value}`)
        .join('\n');
      const secretKey = crypto.createHmac('sha256', 'WebAppData').update(config.botToken).digest();
      const expectedHash = crypto.createHmac('sha256', secretKey).update(dataCheckString).digest('hex');
      const received = Buffer.from(receivedHash, 'hex');
      const expected = Buffer.from(expectedHash, 'hex');
      if (received.length !== expected.length || !crypto.timingSafeEqual(received, expected)) return null;
      const user = JSON.parse(userRaw);
      if (!user || !Number.isSafeInteger(Number(user.id)) || Number(user.id) <= 0) return null;
      return { id: Number(user.id), first_name: String(user.first_name || ''), username: user.username || null };
    } catch (_) { return null; }
  }

  const miniApi = express.Router();
  miniApi.use(express.json({ limit: '32kb' }));
  miniApi.use((req, res, next) => {
    const header = req.get('authorization') || '';
    const initData = header.startsWith('tma ') ? header.slice(4) : '';
    const user = verifyTelegramInitData(initData);
    if (!user) return res.status(401).json({ error: 'ورود Mini App از داخل تلگرام معتبر نیست یا منقضی شده است. دوباره از منوی ربات بازش کن.' });
    req.telegramWebAppUser = user;
    next();
  });

  async function miniPlayer(req) {
    await ready;
    if (await settings.isBotDisabled()) throw new GameError('ربات اصلی بازی خاموش است.');
    const season = await seasonService.getActiveSeason();
    if (!season) throw new GameError('سیزن فعالی وجود ندارد.');
    const user = req.telegramWebAppUser;
    const player = await userService.getById(user.id);
    if (player && player.status === 'banned') throw new GameError('حساب شما مسدود است.');
    const own = await ownership.getActiveOwnership(user.id, season.id);
    return { season, user, own };
  }

  const miniHandler = (fn) => async (req, res) => {
    try {
      const result = await fn(req, res);
      if (!res.headersSent) res.json(result === undefined ? { ok: true } : result);
    } catch (err) {
      if (err instanceof GameError || err.userFacing) return res.status(400).json({ error: err.message });
      logger.error(`خطای Mini App ${req.method} ${req.path}:`, err.stack || err.message);
      return res.status(500).json({ error: 'خطای داخلی Mini App' });
    }
  };

  miniApi.get('/state', miniHandler(async (req) => {
    const { season, user, own } = await miniPlayer(req);
    if (!own || !own.country) return { hasCountry: false, user: { id: user.id, firstName: user.first_name }, season: { id: season.id, name: season.name } };
    const country = own.country;
    const state = await gameService.getCountryState(own.countryId, season.id);
    const activeOwnerships = await ownership.listActive(season.id);
    const targetCountries = [];
    for (const entry of activeOwnerships) {
      if (String(entry.countryId) === String(own.countryId)) continue;
      const target = await countryService.get(entry.countryId);
      if (target) targetCountries.push({ id: target.id, name: target.name, flag: target.flag });
    }
    const [shahiRate, dailyMissions, userMissions] = await Promise.all([
      gameService.getShahiExchangeRate(),
      gameService.getDailyMissions(),
      gameService.getUserMissions(user.id),
    ]);
    return {
      hasCountry: true,
      user: { id: user.id, firstName: user.first_name },
      season: { id: season.id, name: season.name },
      country: { id: country.id, name: country.name, flag: country.flag, oilRichness: country.oilRichness ?? 50 },
      state: {
        treasury: state.treasury || 0,
        shahiCoins: Number(state.shahiCoins || 0),
        incomeDaily: state.incomeDaily || 0,
        oil: state.oil || 0,
        oilReserve: gameService.calculateOilReserveCapacity(state, country).total,
        oilRichness: country.oilRichness ?? state.oilRichness ?? 50,
        capitalChangeCost: Number(await settings.get('capitalChangeCost', 250000000)),
        shahiExchangeRate: shahiRate,
        fallen: Boolean(state.fallen),
      },
      dailyMissions,
      userMissions,
      provinces: gameService.normalizeProvinces(state.provinces, country.name),
      targetCountries,
    };
  }));

  miniApi.post('/missions/:missionId/claim', miniHandler(async (req) => {
    const { season, user, own } = await miniPlayer(req);
    if (!own) throw new GameError('ابتدا باید یک کشور برای رهبری انتخاب کنی.');
    const result = await gameService.claimMission(user.id, own.countryId, season.id, req.params.missionId);
    return {
      ok: true,
      ...result,
      message: `ماموریت با موفقیت انجام شد! ${result.rewardShahi} سکه شاهی و ${result.mission.rewardCash.toLocaleString('fa-IR')} دلار به حسابتان واریز شد.`,
    };
  }));

  miniApi.post('/shahi/convert', miniHandler(async (req) => {
    const { season, user, own } = await miniPlayer(req);
    if (!own) throw new GameError('ابتدا باید یک کشور برای رهبری انتخاب کنی.');
    const amount = Number(req.body?.amount || 1);
    const result = await gameService.convertShahiToDollars(own.countryId, season.id, amount, user.id);
    return {
      ok: true,
      ...result,
      message: `تعداد ${result.convertedShahi} سکه شاهی با نرخ هر سکه ${result.rate.toLocaleString('fa-IR')} دلار تبدیل شد و مبلغ ${result.addedDollars.toLocaleString('fa-IR')} دلار به خزانه افزوده شد.`,
    };
  }));

  miniApi.post('/provinces/:provinceId/capital', miniHandler(async (req) => {
    const { season, own } = await miniPlayer(req);
    if (!own) throw new GameError('ابتدا باید یک کشور برای رهبری انتخاب کنی.');
    const result = await gameService.changeCapitalProvince(own.countryId, season.id, req.params.provinceId);
    return {
      ok: true,
      ...result,
      message: `پایتخت ملی به استان «${result.province.name}» منتقل شد. ${result.cost.toLocaleString('fa-IR')} دلار از خزانه کسر شد.`,
    };
  }));

  miniApi.post('/oil/explore', miniHandler(async (req) => {
    const { season, own } = await miniPlayer(req);
    if (!own) throw new GameError('ابتدا باید یک کشور برای رهبری انتخاب کنی.');
    const result = await gameService.exploreOil(own.countryId, season.id);
    return { ...result, message: result.found ? `اکتشاف موفق؛ ${result.added.toLocaleString('fa-IR')} واحد به ظرفیت مخزن اضافه شد.` : 'تیمی که فرستادی مخزن تازه‌ای پیدا نکرد؛ هزینه اعزام پرداخت شد.' };
  }));

  miniApi.patch('/provinces/:provinceId', miniHandler(async (req) => {
    const { season, own } = await miniPlayer(req);
    if (!own) throw new GameError('ابتدا باید یک کشور برای رهبری انتخاب کنی.');
    const name = String(req.body?.name || '').trim();
    const capital = req.body?.capital === undefined ? undefined : String(req.body.capital || '').trim();
    const province = await gameService.renameProvince(own.countryId, season.id, req.params.provinceId, name, capital);
    return { ok: true, province };
  }));

  miniApi.post('/diplomacy/pact', miniHandler(async (req) => {
    const { season, own } = await miniPlayer(req);
    if (!own) throw new GameError('ابتدا باید یک کشور برای رهبری انتخاب کنی.');
    const targetId = String(req.body?.targetCountryId || '');
    if (!targetId || targetId === String(own.countryId)) throw new GameError('کشور مقصد نامعتبر است.');
    const targetOwn = await ownership.getOwnerOfCountry(targetId, season.id);
    const target = await countryService.get(targetId);
    if (!target || !targetOwn) throw new GameError('کشور مقصد باید بازیکن فعال داشته باشد.');
    const existing = docs(await col('diplomacy_pacts').get()).find((p) => String(p.fromCountryId) === String(own.countryId) && String(p.toCountryId) === targetId && ['sent', 'accepted'].includes(p.status));
    if (existing) throw new GameError('برای این کشور قبلاً پیمان ارسال شده و هنوز تعیین تکلیف نشده است.');
    await col('diplomacy_pacts').add({ fromCountryId: own.countryId, toCountryId: targetId, seasonId: season.id, status: 'sent', createdAt: new Date() });
    if (bot?.telegram) await bot.telegram.sendMessage(Number(targetOwn.userId), `🤝 کشور ${own.country.flag} ${own.country.name} برای شما یک پیمان دیپلماتیک ارسال کرده است.`).catch(() => {});
    return { ok: true, message: `پیمان برای ${target.flag} ${target.name} ارسال شد.` };
  }));

  miniApi.post('/diplomacy/trade-cut', miniHandler(async (req) => {
    const { season, own } = await miniPlayer(req);
    if (!own) throw new GameError('ابتدا باید یک کشور برای رهبری انتخاب کنی.');
    const targetId = String(req.body?.targetCountryId || '');
    if (!targetId || targetId === String(own.countryId)) throw new GameError('کشور مقصد نامعتبر است.');
    const targetOwn = await ownership.getOwnerOfCountry(targetId, season.id);
    const target = await countryService.get(targetId);
    if (!target || !targetOwn) throw new GameError('کشور مقصد باید بازیکن فعال داشته باشد.');
    const cuts = docs(await col('diplomacy_trade_cuts').get());
    const pairMatch = (cut) => (!cut.seasonId || String(cut.seasonId) === String(season.id)) && [String(cut.fromCountryId), String(cut.toCountryId)].sort().join(':') === [String(own.countryId), targetId].sort().join(':') && cut.status !== 'cancelled';
    if (cuts.some(pairMatch)) throw new GameError('روابط تجاری این دو کشور قبلاً قطع شده است؛ کاهش درآمد دوباره اعمال نمی‌شود.');
    const [myState, targetState] = await Promise.all([
      gameService.getCountryState(own.countryId, season.id),
      gameService.getCountryState(targetId, season.id),
    ]);
    await Promise.all([
      gameService.updateCountryState(own.countryId, season.id, { incomeDaily: Math.floor((myState.incomeDaily || 0) * 0.95) }),
      gameService.updateCountryState(targetId, season.id, { incomeDaily: Math.floor((targetState.incomeDaily || 0) * 0.95) }),
    ]);
    await col('diplomacy_trade_cuts').add({ fromCountryId: own.countryId, toCountryId: targetId, seasonId: season.id, createdAt: new Date(), rate: 5, status: 'active' });
    if (bot?.telegram) await bot.telegram.sendMessage(Number(targetOwn.userId), `📉 کشور ${own.country.flag} ${own.country.name} روابط تجاری خود را با شما قطع کرد؛ درآمد روزانه کشور شما ۵٪ کاهش یافت.`).catch(() => {});
    return { ok: true, message: `روابط تجاری با ${target.flag} ${target.name} قطع شد؛ درآمد روزانه هر دو کشور ۵٪ کاهش یافت.` };
  }));

  app.use('/miniapp/api', miniApi);

  // ---------- API ----------
  const api = express.Router();
  api.use(express.json({ limit: '50mb' }));
  api.use((req, res, next) => { res.setHeader('Cache-Control', 'no-store'); next(); });

  const h = (fn) => async (req, res) => {
    try {
      await ready;
      const out = await fn(req, res);
      if (!res.headersSent) res.json(out === undefined ? { ok: true } : out);
    } catch (err) {
      if (err instanceof GameError || err.userFacing) return res.status(400).json({ error: err.message });
      logger.error(`خطای API ${req.method} ${req.path}:`, err.stack || err.message);
      return res.status(500).json({ error: 'خطای داخلی سرور' });
    }
  };

  api.post('/login', (req, res) => {
    const ip = req.ip;
    if (auth.loginLocked(ip)) return res.status(429).json({ error: 'تلاش‌های ناموفق زیاد؛ ۱۰ دقیقه دیگر دوباره امتحان کنید.' });
    if (!auth.checkPassword(req.body && req.body.password)) {
      auth.recordFail(ip);
      return res.status(401).json({ error: 'رمز نادرست است.' });
    }
    auth.clearFails(ip);
    return res.json({ token: auth.issueToken() });
  });

  api.use(auth.requireAuth);
  const tg = () => bot.telegram;

  api.get('/overview', h(async (req) => {
    const [users, open, countries, season, brand, channelId, botDisabled] = await Promise.all([
      userService.listAll().catch(() => []),
      selection.listOpenRequests().catch(() => []),
      countryService.list().catch(() => []),
      seasonService.getActiveSeason().catch(() => null),
      settings.getBrand().catch(() => config.brandDefaults),
      settings.getChannelId().catch(() => ''),
      settings.isBotDisabled().catch(() => false),
    ]);
    let wh = null;
    try {
      if (bot && bot.isAuthorized !== false) {
        wh = await webhook.webhookInfo(tg());
      } else {
        wh = { isSet: false, error: 'توکن ربات تلگرام در سرور تایید نشد (401: Unauthorized)' };
      }
    } catch (e) {
      wh = { error: e.description || e.message };
    }
    return {
      players: users.length, bannedPlayers: users.filter((u) => u.status === 'banned').length,
      openRequests: open.length, countries: countries.length,
      season: season && { id: season.id, name: season.name, number: season.number },
      brand, channelId, adminIds: config.adminIds.length, webhook: wh,
      botAuthorized: !(bot && bot.isAuthorized === false),
      botUsername: (bot && bot.botInfo && bot.botInfo.username) || null,
      botDisabled: Boolean(botDisabled),
      suggestedBaseUrl: config.publicUrl || `${req.protocol}://${req.get('host')}`,
    };
  }));

  // وضعیت روشن/خاموش بودن ربات توسط ادمین
  api.get('/bot/status', h(async () => {
    const disabled = await settings.isBotDisabled();
    return { disabled };
  }));
  api.post('/bot/status', h(async (req) => {
    const disabled = Boolean(req.body && req.body.disabled);
    await settings.setBotDisabled(disabled, WEB_ADMIN);
    await audit.audit(WEB_ADMIN, disabled ? 'bot.disable' : 'bot.enable', null, { disabled }, VIA);
    return { ok: true, disabled };
  }));

  // درخواست‌ها
  api.get('/requests', h(async () => {
    const reqs = await selection.listOpenRequests();
    return Promise.all(reqs.map(async (r) => {
      const pay = ['submitted', 'approved'].includes(r.paymentStatus) ? await selection.getPayment(r.id) : null;
      return {
        id: r.id, userId: r.userId, displayName: r.displayName, username: r.username,
        country: r.country && { id: r.country.id, name: r.country.name, flag: r.country.flag },
        selectionType: r.selectionType, status: r.status, paymentStatus: r.paymentStatus, price: r.price, createdAt: r.createdAt,
        receipt: pay && { type: pay.receipt.type, text: pay.receipt.text },
      };
    }));
  }));
  api.post('/requests/:id/:action', h(async (req) => {
    const { id, action } = req.params;
    const note = req.body && req.body.note;
    if (action === 'payok') await actions.approvePayment(tg(), id, WEB_ADMIN, VIA);
    else if (action === 'payno') await actions.rejectPayment(tg(), id, WEB_ADMIN, note, VIA);
    else if (action === 'assign') await actions.assignRequest(tg(), id, WEB_ADMIN, VIA);
    else if (action === 'reject') await actions.rejectRequest(tg(), id, WEB_ADMIN, note, VIA);
    else throw new GameError('اقدام نامعتبر است.');
    return { ok: true };
  }));
  api.get('/requests/:id/receipt', h(async (req, res) => {
    const pay = await selection.getPayment(req.params.id);
    if (!pay || pay.receipt.type !== 'photo') throw new GameError('رسید تصویری وجود ندارد.');
    const link = await tg().getFileLink(pay.receipt.fileId);
    const r = await fetch(link.href);
    if (!r.ok) throw new GameError('دریافت تصویر از تلگرام ناموفق بود.');
    res.setHeader('Content-Type', r.headers.get('content-type') || 'image/jpeg');
    res.send(Buffer.from(await r.arrayBuffer()));
  }));

  // کشورها
  api.get('/countries', h(async () => {
    const [countries, season] = await Promise.all([countryService.list(), seasonService.getActiveSeason()]);
    const owners = {};
    if (season) {
      for (const o of await ownership.listActive(season.id)) {
        const u = await userService.getById(o.userId);
        owners[o.countryId] = u && { telegramId: u.telegramId, gameId: u.gameId, displayName: u.displayName };
      }
    }
    return countries.map((c) => ({ ...c, owner: owners[c.id] || null }));
  }));
  api.post('/countries', h(async (req) => actions.createCountry(WEB_ADMIN, req.body || {}, VIA)));
  api.post('/countries/seed', h(async () => actions.seedCountries(WEB_ADMIN, VIA)));
  api.post('/countries/clear-all', h(async () => {
    const res = await countryService.clearAll();
    await audit.audit(WEB_ADMIN, 'countries.clearAll', null, res, VIA);
    return res;
  }));
  api.post('/countries/bulk', h(async (req) => {
    const text = req.body && req.body.text;
    const res = await countryService.bulkCreate(text);
    await audit.audit(WEB_ADMIN, 'countries.bulkCreate', null, { count: res.count }, VIA);
    return res;
  }));
  api.patch('/countries/:id', h(async (req) => actions.updateCountry(WEB_ADMIN, req.params.id, req.body || {}, VIA)));
  api.patch('/countries/:id/flags', h(async (req) => {
    const patch = req.body || {};
    const c = await countryService.update(req.params.id, {
      photoUrl: patch.photoUrl,
      bannerUrl: patch.bannerUrl,
      statementPhotoUrl: patch.statementPhotoUrl,
      religionFlags: patch.religionFlags,
      ideologyFlags: patch.ideologyFlags,
      religionUrls: patch.religionUrls,
      governmentUrls: patch.governmentUrls,
      governmentFlags: patch.governmentFlags,
      activeFlagSource: patch.activeFlagSource,
    });
    await audit.audit(WEB_ADMIN, 'countries.flagsUpdate', req.params.id, patch, VIA);
    return c;
  }));
  api.post('/countries/:id/assign', h(async (req) => {
    const r = await actions.manualAssign(tg(), req.params.id, req.body && req.body.player, WEB_ADMIN, VIA);
    return { ok: true, player: r.user.displayName };
  }));
  api.post('/countries/:id/release', h(async (req) => { await actions.releaseCountry(tg(), req.params.id, WEB_ADMIN, VIA); }));
  api.post('/countries/:id/reset-assets', h(async (req) => {
    return actions.resetPlayerAssets(tg(), req.params.id, req.body && req.body.reason, WEB_ADMIN, VIA);
  }));

  // کنترل‌های انجماد و تنظیم دوره واریز درآمد
  api.post('/payouts/toggle-freeze', h(async (req) => actions.togglePayoutFreeze(WEB_ADMIN, req.body?.frozen, VIA)));
  api.post('/payouts/interval', h(async (req) => actions.setPayoutIntervalMinutes(WEB_ADMIN, req.body?.minutes, VIA)));

  // بازیکنان
  api.get('/players', h(async (req) => {
    const [players, season, countries] = await Promise.all([userService.search(req.query.q), seasonService.getActiveSeason(), countryService.list()]);
    const cmap = Object.fromEntries(countries.map((c) => [c.id, c]));
    const own = {};
    if (season) for (const o of await ownership.listActive(season.id)) own[o.userId] = cmap[o.countryId];
    return players.map((u) => ({
      telegramId: u.telegramId, gameId: u.gameId, displayName: u.displayName, username: u.username, status: u.status,
      banReason: u.banReason, joinedAt: u.joinedAt, lastSeenAt: u.lastSeenAt,
      country: own[u.telegramId] ? { name: own[u.telegramId].name, flag: own[u.telegramId].flag } : null,
      isAdmin: config.adminIds.includes(u.telegramId),
    }));
  }));
  api.post('/players/:id/ban', h(async (req) => { await actions.banPlayer(tg(), Number(req.params.id), req.body && req.body.reason, WEB_ADMIN, VIA); }));
  api.post('/players/:id/unban', h(async (req) => { await actions.unbanPlayer(tg(), Number(req.params.id), WEB_ADMIN, VIA); }));

  // سیزن
  api.get('/seasons', h(async () => seasonService.listSeasons(15)));
  api.post('/seasons', h(async (req) => actions.createSeason(tg(), WEB_ADMIN, req.body && req.body.name, VIA)));
  api.post('/seasons/reset', h(async () => actions.resetCurrentSeason(tg(), WEB_ADMIN, VIA)));
  api.post('/seasons/delete', h(async () => actions.deleteCurrentSeason(tg(), WEB_ADMIN, VIA)));
  api.post('/seasons/advance', h(async (req) => actions.advanceSeason(tg(), WEB_ADMIN, req.body && req.body.winnerNote, VIA)));

  // تسلیحات نظامی و تجهیزات جنگی
  api.get('/weapons/categories', h(async () => weaponService.WEAPON_CATEGORIES));
  api.get('/weapons', h(async () => weaponService.list()));
  api.post('/weapons', h(async (req) => {
    const w = await weaponService.create(req.body || {});
    await audit.audit(WEB_ADMIN, 'weapon.create', w.id, w, VIA);
    return w;
  }));
  api.post('/weapons/bulk', h(async (req) => {
    const res = await weaponService.bulkCreate(req.body && req.body.text, req.body && req.body.category);
    await audit.audit(WEB_ADMIN, 'weapon.bulkCreate', null, { count: res.count, category: req.body && req.body.category }, VIA);
    return res;
  }));
  api.post('/weapons/seed', h(async () => {
    const res = await weaponService.seedDefaults();
    await audit.audit(WEB_ADMIN, 'weapon.seedDefaults', null, res, VIA);
    return res;
  }));
  api.post('/weapons/clear-all', h(async () => {
    const res = await weaponService.clearAll();
    await audit.audit(WEB_ADMIN, 'weapon.clearAll', null, res, VIA);
    return res;
  }));
  api.delete('/weapons/:id', h(async (req) => {
    const res = await weaponService.remove(req.params.id);
    await audit.audit(WEB_ADMIN, 'weapon.delete', req.params.id, null, VIA);
    return res;
  }));

  // اعلان‌های جنگ و مجوزها
  api.get('/wars', h(async () => warService.listWars()));
  api.post('/wars/:id/approve', h(async (req) => {
    const war = await warService.approveWar(req.params.id, WEB_ADMIN);
    const season = await seasonService.getActiveSeason();
    if (season) {
      const attState = await gameService.getCountryState(war.attackerCountryId, season.id);
      await gameService.updateCountryState(war.attackerCountryId, season.id, {
        legitimacy: Math.min(100, (attState.legitimacy || 100) + 10),
      });
    }

    // ارسال اعلان رسمی به کانال
    const channelText = [
      '⚔️ <b>اعلان جنگ رسمی و قانونی!</b>',
      '– – – – – – – – – –',
      `شورای عالی نظارت با درخواست اعلان جنگ کشور <b>${war.attackerFlag} ${war.attackerName}</b> علیه <b>${war.defenderFlag} ${war.defenderName}</b> موافقت کرد.`,
      '',
      `📜 دلیل احراز شده: «<i>${war.reason}</i>»`,
      '',
      '⚖️ این جنگ با مجوز رسمی آغاز شده و مشروعیت بین‌المللی دارد.',
      '⏳ مهلت پیوستن کشورها به جبهه‌ها: فقط ۲ دقیقه.',
      '',
      '🗳 کشورهای هر جبهه',
      '🔴 مهاجم', '—',
      '🟢 مدافع', '—',
      '⚪ بی‌طرف', '—',
    ].join('\n');
    await notifications.publishToChannel(tg(), 'war_news', channelText, {
      reply_markup: { inline_keyboard: [[
        { text: '⚪ بی‌طرف', callback_data: `war:side:${war.id}:neutral` },
        { text: '🔴 تیم مهاجم', callback_data: `war:side:${war.id}:attacker` },
        { text: '🟢 تیم مدافع', callback_data: `war:side:${war.id}:defender` },
      ]] },
    }).catch(() => {});

    // پیام مستقیم به مهاجم و مدافع
    if (war.userId) {
      await notifications.safeSend(tg(), war.userId, `✅ <b>مجوز جنگ صادر شد!</b>\nدرخواست اعلان جنگ شما علیه ${war.defenderFlag} ${war.defenderName} توسط مدیریت تایید و در کانال اعلام شد.`);
    }

    await audit.audit(WEB_ADMIN, 'war.approve', war.id, war, VIA);
    return war;
  }));
  api.post('/wars/:id/reject', h(async (req) => {
    const note = (req.body && req.body.note) || 'عدم احراز دلیل منطقی و کافی';
    const war = await warService.rejectWar(req.params.id, WEB_ADMIN, note);
    if (war.userId) {
      await notifications.safeSend(tg(), war.userId, `❌ <b>درخواست جنگ رد شد</b>\nدرخواست اعلان جنگ شما علیه ${war.defenderFlag} ${war.defenderName} به دلیل عدم کفایت دلایل رد شد.${note ? `\nتوضیح: ${note}` : ''}`);
    }
    await audit.audit(WEB_ADMIN, 'war.reject', war.id, { note }, VIA);
    return war;
  }));

  // تنظیمات
  api.get('/settings', h(async () => actions.getSettingsView()));
  api.put('/settings', h(async (req) => actions.setSetting(tg(), req.body && req.body.key, req.body && req.body.value, WEB_ADMIN, VIA)));

  // اعطای بودجه و کمک بشردوستانه به کشور با انتشار رسمی در کانال
  api.post('/budget/grant', h(async (req) => {
    const { countryId, amount, donor, note } = req.body || {};
    if (!countryId) throw new GameError('کشور مشخص نشده است.');
    const numAmount = Number(amount);
    if (!numAmount || numAmount <= 0) throw new GameError('مبلغ بودجه باید بزرگتر از صفر باشد.');

    const season = await seasonService.getActiveSeason();
    if (!season) throw new GameError('سیزن فعالی یافت نشد.');

    const country = await countryService.get(countryId);
    if (!country) throw new GameError('کشور یافت نشد.');

    const donorName = (donor || 'سازمان بین‌المللی امداد و صلح جهانی').trim();
    const donorNote = (note || 'کمک بشردوستانه جهت بازسازی زیرساخت‌ها، رفاه مردم و رونق اقتصاد ملی').trim();

    const res = await gameService.grantBudget({
      countryId,
      seasonId: season.id,
      amount: numAmount,
      donor: donorName,
      note: donorNote,
    });

    // انتشار پیام کمک بشردوستانه در کانال رسمی
    const channelText = [
      '🕊️ <b>اعطای کمک بشردوستانه و تزریق بودجه بین‌المللی!</b>',
      '– – – – – – – – – –',
      `🌍 کشور دریافت‌کننده: <b>${country.flag} ${country.name}</b>`,
      `💰 مبلغ اهدایی: <b>${numAmount.toLocaleString('fa-IR')}$</b>`,
      `🏢 نهاد اهداکننده: <b>${donorName}</b>`,
      donorNote ? `📝 یادداشت: «<i>${donorNote}</i>»` : '',
      '',
      '🏛 این بودجه مستقیماً به خزانه کشور واریز گردید تا صرف بازسازی، رفاه مردم و رونق اقتصادی گردد.',
    ].filter(Boolean).join('\n');

    await notifications.publishToChannel(tg(), 'announcement', channelText).catch(() => {});

    // اطلاع‌رسانی به رهبر کشور در صورت وجود
    const owners = await ownership.listActive(season.id);
    const own = owners.find((o) => o.countryId === countryId);
    if (own) {
      await notifications.safeSend(tg(), own.userId, `🎉 <b>کمک بشردوستانه به کشور شما واریز شد!</b>\nمبلغ ${numAmount.toLocaleString('fa-IR')}$ از سوی «${donorName}» به خزانه کشور واریز و در کانال اعلام گردید.`);
    }

    await audit.audit(WEB_ADMIN, 'budget.grant', countryId, { amount: numAmount, donor: donorName }, VIA);
    return { ok: true, country: country.name, amount: numAmount, newTreasury: res.newTreasury };
  }));

  // اطلاعیه هدفمند (کانال / کاربران / هر دو)
  api.post('/broadcast', h(async (req) => actions.broadcast(tg(), {
    text: req.body && req.body.text,
    target: req.body && req.body.target,
    photoUrl: req.body && req.body.photoUrl,
  }, WEB_ADMIN, VIA)));

  api.get('/webhook', h(async () => {
    if (bot && bot.isAuthorized === false) {
      return {
        isSet: false,
        host: null,
        pendingUpdates: 0,
        lastError: 'توکن ربات تلگرام در سرور تایید نشده است (401: Unauthorized)',
        lastErrorDate: new Date().toISOString(),
        unauthorized: true,
      };
    }
    return webhook.webhookInfo(tg());
  }));
  api.post('/webhook', h(async (req) => {
    if (bot && bot.isAuthorized === false) {
      throw new GameError('توکن ربات تلگرام در سرور تایید نشده است (401: Unauthorized). لطفاً توکن معتبر از @BotFather را در تنظیمات وارد نمایید.');
    }
    const url = await webhook.setWebhook(tg(), req.body && req.body.baseUrl);
    await audit.audit(WEB_ADMIN, 'webhook.set', null, { host: new URL(url).host }, VIA);
    return { ok: true, host: new URL(url).host };
  }));
  api.delete('/webhook', h(async (req) => {
    if (bot && bot.isAuthorized !== false) {
      await tg().deleteWebhook({ drop_pending_updates: true }).catch(() => {});
      try {
        bot.launch({ dropPendingUpdates: true }).catch(() => {});
      } catch (_) {}
    }
    await audit.audit(WEB_ADMIN, 'webhook.delete', null, { resetToPolling: true }, VIA);
    return { ok: true, message: 'وب‌هوک با موفقیت حذف و ربات به حالت دریافت مستقیم بازگشت.' };
  }));
  api.post('/webhook/fix', h(async () => {
    if (bot && bot.isAuthorized !== false) {
      await tg().deleteWebhook({ drop_pending_updates: true }).catch(() => {});
      try {
        bot.launch({ dropPendingUpdates: true }).catch(() => {});
      } catch (_) {}
    }
    await audit.audit(WEB_ADMIN, 'webhook.fix', null, { cleared: true }, VIA);
    return { ok: true, message: 'خطای وب‌هوک با موفقیت برطرف شد، پیام‌های مسدودشده پاکسازی شدند و سیستم به وضعیت سالم بازگشت.' };
  }));

  api.post(['/upload', '/upload/flag'], express.json({ limit: '25mb' }), h(async (req) => {
    const dataUrl = req.body && req.body.image;
    if (!dataUrl || typeof dataUrl !== 'string') throw new GameError('داده تصویر معتبر نیست.');
    const match = dataUrl.match(/^data:image\/([a-zA-Z0-9+]+);base64,(.+)$/);
    if (!match) throw new GameError('فرمت تصویر باید base64 DataURL باشد.');
    const ext = match[1] === 'jpeg' ? 'jpg' : match[1];
    const buffer = Buffer.from(match[2], 'base64');
    const isFlag = req.path.includes('/flag') || req.body.type === 'flag' || req.body.category === 'flag';
    const folder = isFlag ? 'flags' : 'uploads';
    const prefix = isFlag ? 'flag' : 'img';
    const filename = `${prefix}_${Date.now()}_${Math.random().toString(36).slice(2, 8)}.${ext}`;
    const targetDir = path.join(PUBLIC_DIR, folder);
    const filePath = path.join(targetDir, filename);
    const fs = require('fs');
    if (!fs.existsSync(targetDir)) fs.mkdirSync(targetDir, { recursive: true });
    await fs.promises.writeFile(filePath, buffer);
    const publicUrl = `/${folder}/${filename}`;
    return { ok: true, url: publicUrl, filename, category: folder };
  }));

  // تنگه‌های استراتژیک و شورای امنیت سازمان ملل
  api.get('/straits', h(async () => {
    const season = await seasonService.getActiveSeason();
    if (!season) return [];
    return straitService.getStraits(season.id);
  }));

  api.post('/straits/:id/decide', h(async (req) => {
    const season = await seasonService.getActiveSeason();
    if (!season) throw new GameError('سیزن فعالی وجود ندارد.');
    const { id } = req.params;
    const { approved, note } = req.body || {};
    const res = await straitService.decideBlockade({
      seasonId: season.id,
      straitId: id,
      approved: Boolean(approved),
      adminId: 'WEB_ADMIN_UN_COUNCIL',
      note,
    });

    // اعلان عمومی در کانال
    const channelText = res.approved
      ? [
          '🚨 <b>قطعنامه شورای امنیت سازمان ملل متحد صادر شد!</b>',
          '– – – – – – – – – –',
          `شورای امنیت رسماً مجوز انسداد آبراهه <b>${res.strait.name}</b> توسط کشور <b>${res.strait.ownerCountryName}</b> را تصویب کرد!`,
          `🎯 هدف انسداد: <b>${res.strait.blockade.targetName}</b>`,
          `⚡ طبق قطعنامه، ۴۰٪ از درآمد کشور هدف به عنوان خراج دریایی کسر می‌گردد.`,
        ].join('\n')
      : [
          '🕊 <b>شورای امنیت سازمان ملل قطعنامه مسدودسازی را وتو کرد!</b>',
          '– – – – – – – – – –',
          `درخواست انسداد آبراهه <b>${res.strait.name}</b> به دلیل مغایرت با اصول دریانوردی آزاد بین‌المللی رد و وتو گردید.`,
        ].join('\n');

    await notifications.publishToChannel(tg(), 'announcement', channelText).catch(() => {});
    await audit.audit(WEB_ADMIN, 'strait.decide', id, { approved: res.approved }, VIA);
    return { ok: true, strait: res.strait };
  }));

  // بازار رمزارز و سرمایه
  api.get('/crypto/market', h(async () => cryptoService.getCryptoMarket()));
  api.post('/crypto/bulletin', h(async () => {
    await cryptoService.publishCryptoBulletin(tg());
    return { ok: true, message: 'بولتن رمزارزها در کانال رسمی منتشر شد.' };
  }));

  // اجرای دستی چرخه واریز ۱۰ دقیقه‌ای
  api.post('/game/payout-10min', h(async () => {
    await gameLoopService.executeTenMinutePayout(tg());
    return { ok: true, message: 'واریز ۱۰ دقیقه‌ای درآمد و نفت برای کلیه کشورهای فعال انجام و پیام اطلاع‌رسانی ارسال شد.' };
  }));

  // ماموریت‌های روزانه با پاداش سکه شاهی و نفت جایزه
  api.get('/game/missions', h(async (req) => {
    const userId = Number(req.query.userId) || WEB_ADMIN;
    const missions = await gameService.getDailyMissions();
    const userMissions = await gameService.getUserMissions(userId);
    return { missions, userMissions };
  }));

  api.post('/game/missions/:id/claim', h(async (req) => {
    const { countryId, userId } = req.body || {};
    const season = await seasonService.getActiveSeason();
    if (!season) throw new GameError('سیزن فعالی یافت نشد.');
    const uId = Number(userId) || WEB_ADMIN;
    let cId = countryId;
    if (!cId) {
      const activeOwn = await ownership.getActiveOwnership(uId, season.id);
      cId = activeOwn?.countryId;
    }
    if (!cId) {
      const allActive = await ownership.listActive(season.id);
      cId = allActive[0]?.countryId;
    }
    if (!cId) throw new GameError('کشور یافت نشد.');
    return gameService.claimMission(uId, cId, season.id, req.params.id);
  }));

  // مرکز پدافند و دفاع خودکار (+۲۵٪ بانس)
  api.post('/countries/:id/auto-defense', h(async (req) => {
    const season = await seasonService.getActiveSeason();
    if (!season) throw new GameError('سیزن فعالی وجود ندارد.');
    const autoDefense = await gameService.toggleAutoDefense(req.params.id, season.id);
    return { ok: true, autoDefense };
  }));

  // ستاد کل پادگان نظامی و ادوات
  api.get('/countries/:id/barracks', h(async (req) => {
    const season = await seasonService.getActiveSeason();
    if (!season) throw new GameError('سیزن فعالی وجود ندارد.');
    const [state, country, allWeapons, activeBattles] = await Promise.all([
      gameService.getCountryState(req.params.id, season.id),
      countryService.get(req.params.id),
      weaponService.list(),
      warService.getActiveBattlesForCountry(req.params.id, season.id),
    ]);
    const units = [];
    for (const w of allWeapons) {
      const c = gameService.getCountryUnitCount(state, w.id);
      if (c > 0) {
        units.push({
          id: w.id,
          name: w.name,
          emoji: w.emoji || '🪖',
          category: w.category,
          count: c,
          power: Number(w.power) || 20,
          totalPower: (Number(w.power) || 20) * c,
        });
      }
    }
    const incomingBattles = activeBattles.filter((b) => String(b.defenderCountryId) === String(req.params.id) && b.status === 'pending');
    const outgoingBattles = activeBattles.filter((b) => String(b.attackerCountryId) === String(req.params.id) && b.status === 'pending');
    return {
      country,
      military: state.military || {},
      autoDefense: Boolean(state.autoDefense),
      effectiveDefense: state.autoDefense ? Math.floor((state.military?.defense || 2459) * 1.25) : (state.military?.defense || 2459),
      units,
      battlesWon: state.battlesWon || 0,
      battlesLost: state.battlesLost || 0,
      incomingBattles,
      outgoingBattles,
    };
  }));

  // نبردهای فعال جاری (شمارش معکوس ۱۰ دقیقه‌ای واقعی)
  api.get('/game/active-battles', h(async () => {
    const season = await seasonService.getActiveSeason();
    if (!season) return [];
    return warService.listActiveBattles(season.id);
  }));

  // مدیریت سهامدار عمده ۵۱٪ (تغییر نام و تغییر زمینه صنعت)
  api.post('/market/stocks/:key/control', h(async (req) => {
    const { countryId, newName, newSector } = req.body || {};
    const season = await seasonService.getActiveSeason();
    if (!season) throw new GameError('سیزن فعالی وجود ندارد.');
    const constructionService = require('../services/constructionService');
    const result = await constructionService.controlStockEnterprise(
      countryId,
      season.id,
      req.params.key,
      { newName, newSector },
      gameService
    );
    return { ok: true, ...result };
  }));

  // مدیریت بازه‌های زمانی واریز دوره‌ای و توقف/از سرگیری توسط ادمین
  api.get('/admin/payout-settings', h(async () => {
    const [isFrozen, intervalMinutes] = await Promise.all([
      settings.isPayoutsFrozen(),
      settings.getPayoutInterval(),
    ]);
    return { isFrozen, intervalMinutes };
  }));

  api.post('/admin/payout-settings', h(async (req) => {
    const { isFrozen, intervalMinutes } = req.body || {};
    if (typeof isFrozen === 'boolean') {
      await settings.setPayoutsFrozen(isFrozen, WEB_ADMIN);
    }
    if (typeof intervalMinutes === 'number' && intervalMinutes > 0) {
      await settings.setPayoutInterval(intervalMinutes, WEB_ADMIN);
    }
    const [frozen, interval] = await Promise.all([
      settings.isPayoutsFrozen(),
      settings.getPayoutInterval(),
    ]);
    return { ok: true, isFrozen: frozen, intervalMinutes: interval };
  }));

  // نرخ خرید تومانی و دلار سکه شاهی
  api.get('/shahi/price', h(async () => {
    const [priceToman, rate] = await Promise.all([
      settings.get('shahi_coin_real_price_toman', 50000),
      gameService.getShahiExchangeRate(),
    ]);
    return { priceToman: Number(priceToman), rate: Number(rate) };
  }));

  api.post('/admin/shahi/price', h(async (req) => {
    const { priceToman, rate } = req.body || {};
    if (typeof priceToman === 'number' && priceToman > 0) {
      await settings.set('shahi_coin_real_price_toman', Math.floor(priceToman));
    }
    if (typeof rate === 'number' && rate > 0) {
      await settings.set('shahiToDollarRate', Math.floor(rate));
    }
    const [newPrice, newRate] = await Promise.all([
      settings.get('shahi_coin_real_price_toman', 50000),
      gameService.getShahiExchangeRate(),
    ]);
    return { ok: true, priceToman: Number(newPrice), rate: Number(newRate) };
  }));

  // سفارشات خرید VIP سکه شاهی
  api.get('/shahi/orders', h(async () => {
    const snap = await col('shahi_orders').orderBy('createdAt', 'desc').limit(50).get().catch(() => ({ docs: [] }));
    return docs(snap) || [];
  }));

  api.post('/shahi/orders/:id/approve', h(async (req) => {
    const orderId = req.params.id;
    const orderRef = col('shahi_orders').doc(orderId);
    const snap = await orderRef.get();
    if (!snap.exists) throw new GameError('سفارش یافت نشد.');
    const ord = snap.data();
    if (ord.status === 'approved') return { ok: true, message: 'قبلاً تایید شده است.' };

    const season = await seasonService.getActiveSeason();
    if (season && ord.countryId) {
      await gameService.grantShahiCoins(ord.countryId, season.id, ord.coinsCount, 'خرید VIP سکه شاهی (داشبورد وب)');
    }

    const userRef = col('users').doc(String(ord.telegramId));
    const uSnap = await userRef.get();
    const curCoins = uSnap.exists ? Number(uSnap.data().shahiCoins || 0) : 0;
    await userRef.set({ shahiCoins: curCoins + ord.coinsCount }, { merge: true });

    await orderRef.update({
      status: 'approved',
      reviewedAt: new Date(),
      reviewedBy: 'web_admin',
    });

    if (ord.telegramId) {
      await notifications.safeSend(
        tg(),
        ord.telegramId,
        `🎉 <b>سفارش خرید VIP تایید شد!</b>\nتعداد ${ord.coinsCount} سکه شاهی به حسابتان واریز گردید.`
      ).catch(() => {});
    }

    return { ok: true, orderId, status: 'approved' };
  }));

  api.post('/shahi/orders/:id/reject', h(async (req) => {
    const orderId = req.params.id;
    const orderRef = col('shahi_orders').doc(orderId);
    const snap = await orderRef.get();
    if (!snap.exists) throw new GameError('سفارش یافت نشد.');
    const ord = snap.data();

    await orderRef.update({
      status: 'rejected',
      reviewedAt: new Date(),
      reviewedBy: 'web_admin',
    });

    if (ord.telegramId) {
      await notifications.safeSend(
        tg(),
        ord.telegramId,
        `❌ <b>اطلاعیه سفارش سکه شاهی:</b> فیش ارسالی برای سفارش خرید ${ord.coinsCount} سکه شاهی تایید نگردید.`
      ).catch(() => {});
    }

    return { ok: true, orderId, status: 'rejected' };
  }));

  // مصالح سفارشی مگاپروژه‌ها توسط ادمین
  api.get('/admin/projects/materials', h(async () => {
    const [projects, config] = await Promise.all([
      gameService.getMegaprojectsList(),
      gameService.getProjectMaterialsConfig(),
    ]);
    return { projects, config };
  }));

  api.post('/admin/projects/materials', h(async (req) => {
    const { projectKey, materials, cost, science } = req.body || {};
    if (!projectKey) throw new GameError('کلید پروژه الزامی است.');
    const curConfig = await gameService.getProjectMaterialsConfig();
    curConfig[projectKey] = {
      materials: materials || {},
      cost: cost !== undefined ? Number(cost) : undefined,
      science: science !== undefined ? Number(science) : undefined,
    };
    await gameService.setProjectMaterialsConfig(curConfig);
    return { ok: true, projectKey, updated: curConfig[projectKey] };
  }));

  // لاگ زنده پژوهش و پیشرفت‌های علمی
  api.get('/research/logs', h(async () => {
    return gameService.getResearchLogs(60);
  }));

  // کاندیداهای فرمانده/وزیر و انتصاب
  api.get('/commander/candidates', h(async () => {
    const season = await seasonService.getActiveSeason();
    const activeOwnerships = season ? await ownership.listActive(season.id).catch(() => []) : [];
    const ownedUserIds = new Set(activeOwnerships.map((o) => Number(o.userId)));

    const usersSnap = await col('users').limit(150).get();
    const allUsers = docs(usersSnap) || [];
    return allUsers.filter((u) => {
      const tid = Number(u.telegramId || u.id);
      return tid && !ownedUserIds.has(tid);
    }).map((u) => ({
      telegramId: Number(u.telegramId || u.id),
      displayName: u.displayName || u.firstName || `شهروند ${u.telegramId}`,
    }));
  }));

  api.post('/commander/appoint', h(async (req) => {
    const { countryId, candidateTelegramId } = req.body || {};
    if (!countryId || !candidateTelegramId) throw new GameError('اطلاعات ناقص است.');
    const season = await seasonService.getActiveSeason();
    if (!season) throw new GameError('سیزن فعالی وجود ندارد.');

    const targetUserSnap = await col('users').doc(String(candidateTelegramId)).get();
    const targetUser = targetUserSnap.exists ? targetUserSnap.data() : null;
    const targetName = targetUser?.displayName || targetUser?.firstName || `فرمانده ${candidateTelegramId}`;

    const ministerData = {
      userId: String(candidateTelegramId),
      telegramId: Number(candidateTelegramId),
      name: targetName,
      appointedAt: new Date().toISOString(),
    };

    await gameService.updateCountryState(countryId, season.id, {
      minister: ministerData,
      ministerName: targetName,
      ministerTelegramId: Number(candidateTelegramId),
      ministerAppointedAt: ministerData.appointedAt,
    });

    const country = await countryService.get(countryId);
    if (country) {
      await notifications.publishToChannel(
        tg(),
        'leader_change',
        `🎖️ <b>انتصاب جدید در هیئت دولت!</b>\nرهبر کشور <b>${country.flag} ${country.name}</b>، جناب <b>${targetName}</b> را به عنوان وزیر و جانشین فرماندهی کشور منصوب نمود.`
      ).catch(() => {});
    }

    return { ok: true, minister: ministerData };
  }));

  api.post('/commander/dismiss', h(async (req) => {
    const { countryId } = req.body || {};
    if (!countryId) throw new GameError('شناسه کشور الزامی است.');
    const season = await seasonService.getActiveSeason();
    if (!season) throw new GameError('سیزن فعالی وجود ندارد.');

    await gameService.updateCountryState(countryId, season.id, {
      minister: null,
      ministerName: null,
      ministerTelegramId: null,
      ministerAppointedAt: null,
    });
    return { ok: true };
  }));

  api.get('/war/logs', h(async (req) => {
    const season = await seasonService.getActiveSeason();
    return warService.listWarLogs(season ? season.id : null, 60);
  }));
  api.get('/audit', h(async () => audit.recent(60)));


  api.use((req, res) => res.status(404).json({ error: 'یافت نشد' }));
  app.use('/api', api);
  return app;
}

module.exports = { createWebApp };
