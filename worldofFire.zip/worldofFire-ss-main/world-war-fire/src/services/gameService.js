'use strict';
const { col, snap, docs } = require('../db/firestore');
const { GameError } = require('../utils/errors');
const countryService = require('./countryService');
const seasonService = require('./seasonService');
const weaponService = require('./weaponService');
const warService = require('./warService');
const ownershipService = require('./ownershipService');
const settingsService = require('./settingsService');
const centralBankService = require('./centralBankService');

// محاسبه قیمت نوسانی نفت هر ۲ ساعت (بین ۶۵ تا ۱۱۵ دلار)
function getOilMarketPrice() {
  const hourBlock = Math.floor(Date.now() / (2 * 3600 * 1000));
  const pseudoRandom = Math.sin(hourBlock * 9301 + 49297);
  const normalized = (pseudoRandom - Math.floor(pseudoRandom));
  return Math.floor(65 + normalized * 50); // بین 65 تا 115 دلار
}

function defaultCountryState(country) {
  const isLarge = (country.population || 10000000) > 40000000;
  return {
    treasury: 400000000,
    incomeDaily: isLarge ? 420000000 : 302733520,
    satisfaction: 56,
    legitimacy: 100,
    developmentLevel: 'دهکده',
    scoreToNext: 260,
    military: {
      attack: isLarge ? 3400 : 2124,
      defense: isLarge ? 3800 : 2459,
      ground: isLarge ? 95000 : 74940,
      cyber: 33,
    },
    groundUnits: {
      apc: 60,
      artillery: 54,
      infantry: 3900,
      drone: 18,
      rpg: 120,
      tank: 78,
    },
    airUnits: {
      f16: 6,
      kowsar: 3,
    },
    missiles: {
      fateh110: 18,
    },
    airDefense: {
      khordad15: 3,
      s300: 1,
    },
    cyberUnits: {
      scriptKiddie: 1,
    },
    population: country.population || 7000000,
    shahiCoins: Number.isFinite(country.shahiCoins) ? country.shahiCoins : 0,
    oil: 1500, // بشکه
    oilReserve: Number.isFinite(country.oilReserve) ? country.oilReserve : 5000, // ظرفیت کل مخزن نفت
    oilReserveBonus: 0, // ظرفیت اضافه‌ای که از اکتشاف به دست آمده
    oilRichness: Number.isFinite(country.oilRichness) ? country.oilRichness : 50, // درصد نفت‌خیزی
    oilRigs: 5, // دکل نفت
    workers: 120, // کارگران پالایشگاه
    safeVault: 50000000, // صندوق امن ضد هک
    autoMode: false, // حالت خودکار استخراج
    flagChoice: 'default', // 'default', 'religion', 'ideology'
    food: 3010, // تن
    housing: 0,
    refineryLevel: 2,
    internet: '2G',
    government: country.governmentType || 'dictatorship',
    religion: country.religion || 'none',
    border: {
      current: 12500,
      max: 12500,
      upgrade: '0/10',
    },
    newbieProtectionUntil: new Date(Date.now() + 4 * 3600 * 1000 + 47 * 60 * 1000), // حدود ۵ ساعت
    sleepShieldUntil: null,
    nuclearShelter: 0,
    level: 3,
    xp: 0,
    provinces: getInitialProvinces(country.name),
    conqueredBy: null,
    medals: [
      '🪖 ژنرال (ارتش بالای ۵۰ هزار)',
      '🛢 بارون نفت (۲۰ دکل فعال)',
      '👻 دست‌نخورده (یک هفته بدون یک ضربه)',
    ],
    updatedAt: new Date(),
  };
}

function getInitialProvinces(countryName) {
  return [
    { id: 'north', name: `استان شمالی (${countryName})`, direction: 'شمال', isCapital: true, capital: `پایتخت ${countryName}`, defense: 100, level: 1, garrison: 15000, status: 'امن' },
    { id: 'south', name: `استان جنوبی (${countryName})`, direction: 'جنوب', defense: 100, level: 1, garrison: 15000, status: 'امن' },
    { id: 'east', name: `استان شرقی (${countryName})`, direction: 'شرق', defense: 100, level: 1, garrison: 15000, status: 'امن' },
    { id: 'west', name: `استان غربی (${countryName})`, direction: 'غرب', defense: 100, level: 1, garrison: 15000, status: 'امن' },
  ];
}

// ظرفیت استخراج از تنظیم پایه کشور + ظرفیت اضافه اکتشاف محاسبه می‌شود؛ موجودی نفت خریداری‌شده سقف مخزن را بالا نمی‌برد.
function calculateOilReserveCapacity(state = {}, country = {}) {
  const rawBase = Number(country && country.oilReserve !== undefined ? country.oilReserve : 5000);
  const base = Number.isFinite(rawBase) ? Math.max(0, rawBase) : 5000;
  let bonus;
  if (state && state.oilReserveBonus !== undefined && Number.isFinite(Number(state.oilReserveBonus))) {
    bonus = Math.max(0, Number(state.oilReserveBonus));
  } else {
    // سازگاری با ذخیره‌های قدیمی که پیش از فیلد oilReserveBonus اکتشاف کرده‌اند.
    const legacyCapacity = Number(state && state.oilReserve);
    bonus = Number.isFinite(legacyCapacity) ? Math.max(0, legacyCapacity - base) : 0;
  }
  return { base, bonus, total: base + bonus };
}

function normalizeProvinces(rawProvinces, countryName) {
  const defaults = getInitialProvinces(countryName);
  if (!Array.isArray(rawProvinces)) return defaults;
  // یک آرایه خالی معنای مشخصی دارد: کشور سقوط کرده و استان بومی باقی نمانده است.
  if (rawProvinces.length === 0) return [];
  if (typeof rawProvinces[0] === 'object' && rawProvinces[0].direction) {
    return rawProvinces.map((p, index) => ({
      ...p,
      isCapital: p.isCapital === undefined ? index === 0 : Boolean(p.isCapital),
      capital: p.capital || (index === 0 ? `پایتخت ${countryName}` : undefined),
    }));
  }
  const conquered = rawProvinces.filter((p) => typeof p === 'string' && p !== countryName && p.includes('فتح'));
  const extra = conquered.map((c, i) => ({
    id: `conq_${i + 1}`,
    name: c,
    direction: 'تسخیرشده',
    defense: 80,
    level: 1,
    garrison: 8000,
    status: 'تحت تسلط',
  }));
  return [...defaults, ...extra];
}

async function getCountryState(countryId, seasonId) {
  const ref = col('country_states').doc(`${seasonId}_${countryId}`);
  const s = await ref.get();
  if (s.exists) return snap(s);

  const country = await countryService.get(countryId);
  if (!country) throw new GameError('کشور یافت نشد.');
  const initial = defaultCountryState(country);
  await ref.set(initial);
  return { id: ref.id, ...initial };
}

async function updateCountryState(countryId, seasonId, patch) {
  const ref = col('country_states').doc(`${seasonId}_${countryId}`);
  patch.updatedAt = new Date();
  await ref.set(patch, { merge: true });
  const s = await ref.get();
  return snap(s);
}

// خرید نفت
async function buyOil(countryId, seasonId, barrels) {
  const state = await getCountryState(countryId, seasonId);
  const price = getOilMarketPrice();
  const totalCost = barrels * price;
  if (state.treasury < totalCost) {
    throw new GameError(`سرمایه کافی نیست. هزینه خرید: ${totalCost.toLocaleString()}$ و موجودی: ${state.treasury.toLocaleString()}$`);
  }
  const newTreasury = state.treasury - totalCost;
  const newOil = (state.oil || 0) + barrels;
  await updateCountryState(countryId, seasonId, { treasury: newTreasury, oil: newOil });
  return { barrels, price, totalCost, remainingTreasury: newTreasury, currentOil: newOil };
}

// خرید دکل نفت (هر دکل ۵۰ میلیون دلار) - طبق دستور کاربر، درآمد نفتی فقط از طریق فروش با کشتی است و دکل صرفاً ظرفیت استخراج را بالا می‌برد
const RIG_COST = 50000000;
async function buyOilRig(countryId, seasonId, count = 1) {
  const state = await getCountryState(countryId, seasonId);
  const totalCost = count * RIG_COST;
  if (state.treasury < totalCost) {
    throw new GameError(`سرمایه کافی برای خرید ${count} دکل نفت ندارید. نیاز به ${totalCost.toLocaleString()}$`);
  }
  const newTreasury = state.treasury - totalCost;
  const newRigs = (state.oilRigs || 0) + count;
  await updateCountryState(countryId, seasonId, { treasury: newTreasury, oilRigs: newRigs });
  return { count, totalCost, remainingTreasury: newTreasury, currentRigs: newRigs };
}

// فروش نفت در بازار با ترانزیت نفت‌کش (واریز بعد از ۱ دقیقه طبق درخواست کاربر)
async function sellOilMarket(countryId, seasonId, percent, userTelegramId = null) {
  const state = await getCountryState(countryId, seasonId);
  if (!state.oil || state.oil <= 0) {
    throw new GameError('شما هیچ بشکه نفتی برای فروش در انبار ندارید!');
  }
  const fraction = percent === 100 ? 1 : percent === 50 ? 0.5 : 0.25;
  const barrelsToSell = Math.max(1, Math.floor(state.oil * fraction));
  const price = getOilMarketPrice();
  const rawRevenue = barrelsToSell * price;
  let tax = 0;
  if (percent === 100) {
    tax = Math.floor(rawRevenue * 0.03); // کارمزد ۳ درصدی فروش نفت کامل به بانک مرکزی
    await centralBankService.addCentralBankTax(tax, 'کارمزد ۳٪ فروش کل نفت در بازار');
  }
  const revenue = rawRevenue - tax;

  const newOil = state.oil - barrelsToSell;
  await updateCountryState(countryId, seasonId, { oil: newOil });

  // ثبت محموله نفت‌کش با زمان رسیدن ۱ دقیقه بعد (۶۰ ثانیه)
  const shipRef = col('oil_shipments').doc();
  const deliverAt = new Date(Date.now() + 60000);
  const shipment = {
    id: shipRef.id,
    countryId: String(countryId),
    seasonId: String(seasonId),
    userTelegramId: userTelegramId ? String(userTelegramId) : null,
    barrelsSold: barrelsToSell,
    price,
    tax,
    revenue,
    status: 'in_transit',
    createdAt: new Date(),
    deliverAt,
  };
  await shipRef.set(shipment);

  return { barrelsSold: barrelsToSell, price, revenue, rawRevenue, tax, remainingOil: newOil, deliverAt, inTransit: true };
}

// پردازش محموله‌های نفت‌کش پس از اتمام ۱ دقیقه و واریز وجه به خزانه
async function processPendingOilShipments(telegram) {
  const now = new Date();
  const q = await col('oil_shipments').where('status', '==', 'in_transit').get();
  const list = docs(q);
  const { safeSend } = require('./notificationService');
  const { fmtNum } = require('../utils/text');

  for (const s of list) {
    const deliverTime = s.deliverAt && s.deliverAt.toDate ? s.deliverAt.toDate() : new Date(s.deliverAt);
    if (deliverTime <= now) {
      await col('oil_shipments').doc(s.id).update({ status: 'delivered', deliveredAt: now });
      const curState = await getCountryState(s.countryId, s.seasonId);
      const newTreasury = (curState.treasury || 0) + s.revenue;
      await updateCountryState(s.countryId, s.seasonId, { treasury: newTreasury });

      if (telegram && s.userTelegramId) {
        const msg = [
          '🚢 <b>محموله نفت‌کش به بندر مقصد رسید!</b>',
          '– – – – – – – – – –',
          `🛢 تعداد نفت فروخته شده: <b>${fmtNum(s.barrelsSold)} بشکه</b>`,
          `💵 قیمت فروش هر بشکه: <b>${fmtNum(s.price)}$</b>`,
          `💰 درآمد واریز شده به خزانه: <b>+${fmtNum(s.revenue)}$</b>`,
          `🏦 موجودی کل جدید خزانه: <b>${fmtNum(newTreasury)}$</b>`,
        ].join('\n');
        const shipmentKb = {
          reply_markup: {
            inline_keyboard: [
              [{ text: '💰 اقتصاد و نفت', callback_data: 'emp:oil' }],
              [{ text: '🔙 بازگشت به منوی اصلی', callback_data: 'menu:home' }],
            ],
          },
        };
        await safeSend(telegram, s.userTelegramId, msg, shipmentKb).catch(() => {});
      }
    }
  }
}

// تجهیزات نظامی قابل خرید
const MILITARY_STORE = {
  tank: { name: 'تانک پیشرفته', emoji: '🛡', cost: 1500000, power: 25, type: 'ground', key: 'tank' },
  artillery: { name: 'توپخانه سنگین', emoji: '💣', cost: 800000, power: 15, type: 'ground', key: 'artillery' },
  infantry: { name: 'پیاده‌نظام (دسته ۱۰ نفره)', emoji: '👤', cost: 50000, power: 5, type: 'ground', key: 'infantry', bundle: 10 },
  drone: { name: 'پهپاد نقطه‌زن', emoji: '🛸', cost: 2000000, power: 40, type: 'ground', key: 'drone' },
  rpg: { name: 'آرپی‌جی‌زن (دسته ۵ نفره)', emoji: '🧨', cost: 100000, power: 10, type: 'ground', key: 'rpg', bundle: 5 },
  apc: { name: 'نفربر زرهی', emoji: '🪖', cost: 1000000, power: 18, type: 'ground', key: 'apc' },
  f16: { name: 'جنگنده F-16', emoji: '✈️', cost: 35000000, power: 500, type: 'air', key: 'f16' },
  kowsar: { name: 'جنگنده کوثر', emoji: '✈️', cost: 20000000, power: 300, type: 'air', key: 'kowsar' },
  fateh110: { name: 'موشک فاتح ۱۱۰', emoji: '🚀', cost: 15000000, power: 250, type: 'missile', key: 'fateh110' },
  khordad15: { name: 'پدافند خرداد ۱۵', emoji: '🛡️', cost: 30000000, power: 400, type: 'airDefense', key: 'khordad15' },
  s300: { name: 'پدافند S-300', emoji: '🛡️', cost: 60000000, power: 750, type: 'airDefense', key: 's300' },
};

function getCountryUnitCount(state, unitId) {
  if (!state) return 0;
  if (state.inventory && state.inventory[unitId] !== undefined) return state.inventory[unitId];
  if (state.units && state.units[unitId] !== undefined) return state.units[unitId];
  if (state.arsenal && state.arsenal[unitId] !== undefined) return state.arsenal[unitId];
  if (state.groundUnits && state.groundUnits[unitId] !== undefined) return state.groundUnits[unitId];
  if (state.airUnits && state.airUnits[unitId] !== undefined) return state.airUnits[unitId];
  if (state.missiles && state.missiles[unitId] !== undefined) return state.missiles[unitId];
  if (state.airDefense && state.airDefense[unitId] !== undefined) return state.airDefense[unitId];
  if (state.navalUnits && state.navalUnits[unitId] !== undefined) return state.navalUnits[unitId];
  const simpleKey = unitId.replace(/^wpn_/, '');
  if (state.groundUnits && state.groundUnits[simpleKey] !== undefined) return state.groundUnits[simpleKey];
  if (state.airUnits && state.airUnits[simpleKey] !== undefined) return state.airUnits[simpleKey];
  if (state.missiles && state.missiles[simpleKey] !== undefined) return state.missiles[simpleKey];
  if (state.airDefense && state.airDefense[simpleKey] !== undefined) return state.airDefense[simpleKey];
  if (state.navalUnits && state.navalUnits[simpleKey] !== undefined) return state.navalUnits[simpleKey];
  return 0;
}

async function upgradeArmyAi(countryId, seasonId) {
  const state = await getCountryState(countryId, seasonId);
  const currentLevel = state.armyAiLevel || 1;
  const upgradeCost = currentLevel * 50000000; // ۵۰ میلیون ضربدر سطح فعلی
  if ((state.treasury || 0) < upgradeCost) {
    throw new GameError(`سرمایه کافی نیست. هزینه ارتقای هوش مصنوعی به سطح ${currentLevel + 1}: ${upgradeCost.toLocaleString()}$ است.`);
  }

  const newLevel = currentLevel + 1;
  const newTreasury = (state.treasury || 0) - upgradeCost;
  const attackBonus = Math.floor((state.military?.attack || 1000) * 0.1);
  const defenseBonus = Math.floor((state.military?.defense || 1000) * 0.1);

  await updateCountryState(countryId, seasonId, {
    treasury: newTreasury,
    armyAiLevel: newLevel,
    'military.attack': (state.military?.attack || 0) + attackBonus,
    'military.defense': (state.military?.defense || 0) + defenseBonus,
  });

  return { currentLevel: newLevel, cost: upgradeCost, remainingTreasury: newTreasury };
}

async function buyMilitaryUnit(countryId, seasonId, unitKey, count = 1) {
  const dynamicUnit = await weaponService.get(unitKey);
  const unit = dynamicUnit || MILITARY_STORE[unitKey];
  if (!unit) throw new GameError('تجهیزات انتخاب‌شده نامعتبر است.');

  const validCount = Math.max(1, Math.floor(Number(count) || 1));
  const unitCost = Number(unit.price || unit.cost || 1000000);
  const totalCost = unitCost * validCount;

  const state = await getCountryState(countryId, seasonId);
  if ((state.treasury || 0) < totalCost) {
    throw new GameError(`سرمایه کافی نیست. هزینه خرید ${validCount.toLocaleString('fa-IR')} عدد: ${totalCost.toLocaleString()}$ و موجودی شما: ${(state.treasury || 0).toLocaleString()}$ می‌باشد.`);
  }

  // هوش مصنوعی ارتش یک ارتقای یکتا است: سطح جدید جایگزین سطح قبلی می‌شود.
  if ((unit.category || '').toLowerCase() === 'army_ai' || unit.level) {
    const requestedLevel = Math.max(1, Math.floor(Number(unit.level) || 1));
    const currentLevel = Math.max(0, Math.floor(Number(state.armyAiLevel) || 0));
    if (requestedLevel <= currentLevel) {
      throw new GameError(`هوش مصنوعی شما اکنون سطح ${currentLevel} است؛ فقط می‌توانید سطح بالاتری خریداری کنید.`);
    }
    if (validCount !== 1) throw new GameError('هوش مصنوعی ارتش ارتقای یکتا است و فقط یک عدد خریداری می‌شود.');
    const patch = {
      treasury: (state.treasury || 0) - totalCost,
      armyAiLevel: requestedLevel,
      armyAiWeaponId: unit.id,
      'military.attack': Math.floor((state.military?.attack || 0) * (1 + requestedLevel * 0.1) / (1 + currentLevel * 0.1)),
      'military.defense': Math.floor((state.military?.defense || 0) * (1 + requestedLevel * 0.1) / (1 + currentLevel * 0.1)),
    };
    const inventory = { ...(state.inventory || {}) };
    for (const id of Object.keys(inventory)) {
      if (/^wpn_ai_commander_[1-4]$/.test(id)) delete inventory[id];
    }
    inventory[unit.id] = 1;
    patch.inventory = inventory;
    await updateCountryState(countryId, seasonId, patch);
    return { unit, count: 1, totalCost, remainingTreasury: patch.treasury, upgradedFromLevel: currentLevel, upgradedToLevel: requestedLevel };
  }

  // بررسی الزامات هسته‌ای و اورانیوم غنی‌شده
  const reqTier = unit.nuclearTierRequired || (unit.category === 'nuclear_sub' ? 60 : unit.category === 'nuclear_warhead' ? 100 : (unit.name && (unit.name.includes('اتمی') || unit.name.includes('هسته‌ای')) ? 60 : null));
  const reqUraniumPerUnit = unit.enrichedUraniumRequired || (reqTier === 100 ? 100 : reqTier === 60 ? 50 : (reqTier ? 30 : 0));

  if (reqTier && reqUraniumPerUnit > 0) {
    const totalEnrichedNeeded = reqUraniumPerUnit * validCount;
    const enrichedStock = Number(state.enrichedUranium?.[`tier${reqTier}`] || 0);
    if (enrichedStock < totalEnrichedNeeded) {
      throw new GameError(`⚠️ برای خرید «${unit.name}»، کشور شما نیاز به ${totalEnrichedNeeded.toLocaleString()} کیلوگرم اورانیوم غنی‌شده ${reqTier}٪ دارد!\nموجودی فعلی شما: ${enrichedStock.toLocaleString()} کیلوگرم غنی‌شده ${reqTier}٪ می‌باشد.\n\nابتدا از بازار جهانی اورانیوم خام خریداری نموده و در برنامه هسته‌ای آن را غنی‌سازی کنید.`);
    }
  }

  const patch = { treasury: (state.treasury || 0) - totalCost };
  if (reqTier && reqUraniumPerUnit > 0) {
    const enrichedUranium = { ...(state.enrichedUranium || {}) };
    const tierKey = `tier${reqTier}`;
    enrichedUranium[tierKey] = Math.max(0, Number(enrichedUranium[tierKey] || 0) - (reqUraniumPerUnit * validCount));
    patch.enrichedUranium = enrichedUranium;
  }
  const addUnits = (unit.bundle || 1) * validCount;
  const powerBonus = Math.max(15, Number(unit.power) || 20) * validCount;

  // ذخیره در انبار کلی
  const inventory = { ...(state.inventory || {}) };
  inventory[unit.id] = (inventory[unit.id] || 0) + addUnits;
  patch.inventory = inventory;

  const cat = (unit.category || unit.type || 'tank').toLowerCase();
  const k = unit.key || unit.id || unitKey;

  const military = {
    attack: Number(state.military?.attack || 2124) + powerBonus,
    defense: Number(state.military?.defense || 2459) + Math.floor(powerBonus * 0.75),
    ground: Number(state.military?.ground || 74940),
    cyber: Number(state.military?.cyber || 33),
  };

  const groundUnits = { ...(state.groundUnits || {}) };
  const airUnits = { ...(state.airUnits || {}) };
  const missiles = { ...(state.missiles || {}) };
  const airDefense = { ...(state.airDefense || {}) };
  const navalUnits = { ...(state.navalUnits || {}) };

  if (['army', 'tank', 'armored_carrier', 'ground'].includes(cat)) {
    groundUnits[k] = (groundUnits[k] || 0) + addUnits;
    if (cat === 'tank' || unit.name.includes('تانک')) groundUnits.tank = (groundUnits.tank || 0) + validCount;
    if (cat === 'army' || unit.name.includes('پیاده') || unit.name.includes('کماندو')) groundUnits.infantry = (groundUnits.infantry || 0) + addUnits;
    if (cat === 'armored_carrier' || unit.name.includes('نفربر')) groundUnits.apc = (groundUnits.apc || 0) + validCount;
    patch.groundUnits = groundUnits;
    military.ground += powerBonus * 20;
  } else if (['fighter', 'cargo_plane', 'bomber', 'spy_drone', 'kamikaze_drone', 'air'].includes(cat)) {
    airUnits[k] = (airUnits[k] || 0) + validCount;
    if (unit.name.includes('کوثر')) airUnits.kowsar = (airUnits.kowsar || 0) + validCount;
    else airUnits.f16 = (airUnits.f16 || 0) + validCount;
    patch.airUnits = airUnits;
  } else if (cat === 'missile') {
    missiles[k] = (missiles[k] || 0) + validCount;
    missiles.fateh110 = (missiles.fateh110 || 0) + validCount;
    patch.missiles = missiles;
  } else if (cat === 'defense') {
    airDefense[k] = (airDefense[k] || 0) + validCount;
    if (unit.name.includes('S-300') || unit.name.includes('s300')) airDefense.s300 = (airDefense.s300 || 0) + validCount;
    else airDefense.khordad15 = (airDefense.khordad15 || 0) + validCount;
    patch.airDefense = airDefense;
    military.defense += powerBonus;
  } else if (['naval', 'aircraft_carrier', 'warship', 'boat', 'submarine', 'nuclear_sub', 'cargo_ship'].includes(cat)) {
    navalUnits[k] = (navalUnits[k] || 0) + validCount;
    patch.navalUnits = navalUnits;
  } else {
    const customArsenal = { ...(state.arsenal || {}) };
    customArsenal[k] = (customArsenal[k] || 0) + validCount;
    patch.arsenal = customArsenal;
  }

  patch.military = military;
  patch['military.attack'] = military.attack;
  patch['military.defense'] = military.defense;
  patch['military.ground'] = military.ground;

  await updateCountryState(countryId, seasonId, patch);
  return { unit, count: validCount, totalCost, remainingTreasury: patch.treasury, newAttack: military.attack, newDefense: military.defense };
}

// بررسی وضعیت سپر خواب و محافظت
function isShielded(state) {
  if (state.sleepShieldUntil) {
    const until = new Date(state.sleepShieldUntil);
    if (until.getTime() > Date.now()) return { shielded: true, type: 'sleep', until };
  }
  if (state.newbieProtectionUntil) {
    const until = new Date(state.newbieProtectionUntil);
    if (until.getTime() > Date.now()) return { shielded: true, type: 'newbie', until };
  }
  return { shielded: false };
}

// فعال‌سازی سپر خواب ۸ ساعته
async function activateSleepShield(countryId, seasonId) {
  const state = await getCountryState(countryId, seasonId);
  const shield = isShielded(state);
  if (shield.shielded && shield.type === 'sleep') {
    const remainMin = Math.ceil((shield.until.getTime() - Date.now()) / (60 * 1000));
    throw new GameError(`سپر خواب در حال حاضر فعال است و ${Math.floor(remainMin / 60)} ساعت و ${remainMin % 60} دقیقه باقی مانده است.`);
  }

  const eightHoursLater = new Date(Date.now() + 8 * 3600 * 1000);
  await updateCountryState(countryId, seasonId, { sleepShieldUntil: eightHoursLater });
  return eightHoursLater;
}

// غیرفعال‌سازی سپر خواب
async function deactivateSleepShield(countryId, seasonId) {
  await updateCountryState(countryId, seasonId, { sleepShieldUntil: null });
  return true;
}

// تغییر دین
const RELIGIONS = {
  zoroastrian: { name: 'زرتشت', emoji: '🔥', desc: 'افزایش پدافند و اصالت مرزها (+۱۰٪)، رضایت مردم (+۵٪)' },
  none: { name: 'بی‌دین (سکولار)', emoji: '🚫', desc: 'افزایش پیشرفت سایبری و علمی (+۱۵٪)، کاهش مشروعیت بین‌المللی (-۱۰٪)' },
  islam: { name: 'اسلام', emoji: '☪️', desc: 'افزایش روحیه ارتش و پیاده‌نظام (+۲۰٪)، افزایش مشروعیت در بلوک شرق (+۱۵٪)' },
  judaism: { name: 'یهودی', emoji: '✡️', desc: 'افزایش درآمد تجاری و مالیات (+۲۰٪)، افزایش هزینه نگهداری ارتش (+۱۰٪)' },
  christianity: { name: 'مسیحیت', emoji: '✝️', desc: 'تسهیل روابط دیپلماتیک و پیمان صلح (+۱۵٪)، رشد جمعیت (+۱۰٪)' },
  buddhism: { name: 'بودایی', emoji: '☸️', desc: 'افزایش شدید رضایت و آرامش مردم (+۲۵٪)، کاهش توان تهاجمی ارتش (-۱۵٪)' },
};

async function changeReligion(countryId, seasonId, religionKey) {
  if (!RELIGIONS[religionKey]) throw new GameError('دین انتخاب‌شده نامعتبر است.');
  await updateCountryState(countryId, seasonId, { religion: religionKey });
  return RELIGIONS[religionKey];
}

// تغییر حکومت
const GOVERNMENTS = {
  dictatorship: { name: 'دیکتاتوری', emoji: '🎖', desc: 'افزایش قدرت نظامی و سرعت سرکوب (+۳۰٪)، کاهش رضایت مردم (-۱۵٪)' },
  monarchy: { name: 'پادشاهی', emoji: '👑', desc: 'افزایش ثبات و مشروعیت سنتی (+۲۰٪)، هزینه تجملات دربار (-۱۰٪)' },
  republic: { name: 'جمهوری', emoji: '🏛️', desc: 'افزایش رضایت و انگیزه مردم (+۲۰٪)، سرعت متوسط تصمیم‌گیری نظامی' },
  communist: { name: 'کمونیستی', emoji: '🚩', desc: 'افزایش تولید منابع و نفت (+۲۵٪)، کاهش تجارت آزاد بین‌المللی' },
  theocracy: { name: 'تئوکراسی (حکومت دینی)', emoji: '🕌', desc: 'افزایش پایداری مرزها و ایمان سربازان (+۲۵٪)، ریسک تحریم تجاری' },
  fascism: { name: 'فاشیسم', emoji: '🦅', desc: 'افزایش توان تهاجمی ارتش (+۳۵٪) و انضباط نظامی، کاهش مشروعیت بین‌المللی (-۲۰٪)' },
};

async function changeGovernment(countryId, seasonId, govKey) {
  if (!GOVERNMENTS[govKey]) throw new GameError('نوع حکومت انتخاب‌شده نامعتبر است.');
  await updateCountryState(countryId, seasonId, { government: govKey });
  return GOVERNMENTS[govKey];
}

// ماموریت‌های روزانه با پاداش سکه شاهی و نفت جایزه
const DEFAULT_DAILY_MISSIONS = [
  {
    id: 'exp_oil_50k',
    title: 'صادرات ۵۰ هزار بشکه نفت',
    desc: 'صادرات و فروش حداقل ۵۰ هزار بشکه نفت در بازار جهانی یا محموله‌های کشتی',
    targetCount: 50000,
    unit: 'بشکه',
    rewardCash: 60000000,
    rewardShahi: 25,
    rewardOil: 2500,
    active: true,
  },
  {
    id: 'prod_power_10k',
    title: 'تولید ۱۰ هزار مگاوات برق',
    desc: 'تولید و تامین ۱۰ هزار مگاوات برق توسط نیروگاه‌های خورشیدی، بادی یا سدهای کشور',
    targetCount: 10000,
    unit: 'مگاوات',
    rewardCash: 50000000,
    rewardShahi: 20,
    rewardOil: 5000,
    active: true,
  },
  {
    id: 'military_readiness',
    title: 'تقویت آمادگی نظامی پادگان',
    desc: 'تجهیز پادگان و فعال‌سازی سامانه دفاع خودکار مرزها',
    targetCount: 1,
    unit: 'عملیات',
    rewardCash: 35000000,
    rewardShahi: 15,
    rewardOil: 1500,
    active: true,
  },
  {
    id: 'clean_infiltrators',
    title: 'پاکسازی نفوذی‌ها و امنیت ملی',
    desc: 'عملیات رصد اطلاعاتی و پاکسازی مهره‌های نفوذی در مرزها',
    targetCount: 1,
    unit: 'عملیات',
    rewardCash: 25000000,
    rewardShahi: 10,
    rewardOil: 1000,
    active: true,
  },
];

async function getDailyMissions() {
  const custom = await settingsService.get('daily_missions', null);
  if (Array.isArray(custom) && custom.length > 0) {
    return custom.filter((m) => m && m.active !== false);
  }
  return DEFAULT_DAILY_MISSIONS;
}

async function getShahiExchangeRate() {
  const rate = await settingsService.get('shahiToDollarRate', 10000000);
  const n = Number(rate);
  return Number.isFinite(n) && n > 0 ? n : 10000000;
}

async function getUserMissions(userId) {
  const today = new Date().toISOString().slice(0, 10);
  const ref = col('user_missions').doc(`${userId}_${today}`);
  const s = await ref.get();
  if (s.exists) return snap(s);
  const initial = {
    userId,
    date: today,
    completed: {},
    claimed: {},
  };
  await ref.set(initial);
  return initial;
}

async function claimMission(userId, countryId, seasonId, missionId) {
  const missions = await getDailyMissions();
  const m = missions.find((x) => x.id === missionId);
  if (!m) throw new GameError('ماموریت نامعتبر است.');
  const userMissions = await getUserMissions(userId);
  if (userMissions.claimed && userMissions.claimed[missionId]) {
    throw new GameError('پاداش این ماموریت امروز قبلاً دریافت شده است.');
  }

  const rewardShahi = Number(m.rewardShahi || m.rewardCoin || 1);
  const rewardCash = Number(m.rewardCash || 0);
  const rewardOil = Number(m.rewardOil || 0);

  // ثبت پاداش به حساب کاربر و کشور (خزانه دلاری + سکه شاهی + نفت جایزه)
  const state = await getCountryState(countryId, seasonId);
  const newTreasury = (state.treasury || 0) + rewardCash;
  const newCountryShahi = (state.shahiCoins || 0) + rewardShahi;
  const newOil = (state.oil || 0) + rewardOil;

  await updateCountryState(countryId, seasonId, {
    treasury: newTreasury,
    shahiCoins: newCountryShahi,
    oil: newOil,
  });

  const userRef = col('users').doc(String(userId));
  const userSnap = await userRef.get();
  const currentUserShahi = (userSnap.exists && (userSnap.data().shahiCoins ?? userSnap.data().awCoins)) || 0;
  const nextUserShahi = currentUserShahi + rewardShahi;
  await userRef.set({ shahiCoins: nextUserShahi }, { merge: true });

  const today = new Date().toISOString().slice(0, 10);
  const ref = col('user_missions').doc(`${userId}_${today}`);
  const claimed = { ...(userMissions.claimed || {}), [missionId]: true };
  const completed = { ...(userMissions.completed || {}), [missionId]: true };
  await ref.set({ claimed, completed }, { merge: true });

  return { mission: m, newTreasury, newShahiCoins: newCountryShahi, newOil, rewardShahi, rewardOil };
}

// ثبت خودکار پیشرفت ماموریت روزانه و واریز آنی بدون نیاز به دکمه دستی
async function recordMissionProgressAndAutoClaim(userId, countryId, seasonId, missionId, increment = 1, telegram = null) {
  if (!userId || !countryId || !seasonId || !missionId) return null;
  const { acquireLock, releaseLock } = require('../db/locks');
  const today = new Date().toISOString().slice(0, 10);
  const lockKey = `mission_claim:${userId}:${today}:${missionId}`;
  const locked = await acquireLock(lockKey, 8000);
  if (!locked) return null;

  try {
    const missions = await getDailyMissions();
    const m = missions.find((x) => x.id === missionId);
    if (!m) return null;

    const ref = col('user_missions').doc(`${userId}_${today}`);
    const snapDoc = await ref.get();
    const data = snapDoc.exists ? snapDoc.data() : { userId, date: today, completed: {}, claimed: {}, progress: {} };
    const claimed = data.claimed || {};
    if (claimed[missionId]) return null; // قبلاً دریافت شده

    const progress = data.progress || {};
    const curVal = Number(progress[missionId] || 0) + Number(increment);
    progress[missionId] = curVal;

    const target = Number(m.targetCount || 1);
    if (curVal >= target) {
      claimed[missionId] = true;
      const completed = data.completed || {};
      completed[missionId] = true;

      const rewardShahi = Number(m.rewardShahi || m.rewardCoin || 1);
      const rewardCash = Number(m.rewardCash || 0);
      const rewardOil = Number(m.rewardOil || 0);

      const state = await getCountryState(countryId, seasonId);
      const newTreasury = (state.treasury || 0) + rewardCash;
      const newCountryShahi = (state.shahiCoins || 0) + rewardShahi;
      const newOil = (state.oil || 0) + rewardOil;

      await updateCountryState(countryId, seasonId, {
        treasury: newTreasury,
        shahiCoins: newCountryShahi,
        oil: newOil,
      });

      const userRef = col('users').doc(String(userId));
      const userSnap = await userRef.get();
      const currentUserShahi = (userSnap.exists && (userSnap.data().shahiCoins ?? userSnap.data().awCoins)) || 0;
      await userRef.set({ shahiCoins: currentUserShahi + rewardShahi }, { merge: true });

      await ref.set({ progress, claimed, completed, userId, date: today, updatedAt: new Date() }, { merge: true });

      if (telegram) {
        const notifications = require('./notificationService');
        const { fmtNum } = require('../utils/text');
        const alertMsg = `🎉 <b>ماموریت روزانه تکمیل شد!</b>\n🎯 «${m.title}» انجام شد و پاداش <b>${fmtNum(rewardCash)}$ + ${rewardShahi} سکه شاهی</b> به صورت خودکار به خزانه‌تان واریز گردید.`;
        await notifications.safeSend(telegram, userId, alertMsg).catch(() => {});
      }

      return { completed: true, claimed: true, rewardCash, rewardShahi, rewardOil };
    } else {
      await ref.set({ progress, userId, date: today, updatedAt: new Date() }, { merge: true });
      return { completed: false, progress: curVal, target };
    }
  } finally {
    await releaseLock(lockKey);
  }
}

// درخت ۴ مرحله‌ای غنی‌سازی هسته‌ای (۲۰٪، ۴۰٪، ۶۰٪، ۱۰۰٪)
const NUCLEAR_TIERS = [
  { tier: 20, percent: '۲۰٪', title: 'غنی‌سازی پایه پژوهشی و رادیودارو (۲۰٪)', cost: 150000000, desc: 'تولید ایزوتوپ‌های پزشکی و تحقیقات علمی اولیه.' },
  { tier: 40, percent: '۴۰٪', title: 'غنی‌سازی صنعتی و سوخت راکتور (۴۰٪)', cost: 350000000, desc: 'تامین سوخت نیروگاه‌های برق اتمی و زیردریایی‌ها.' },
  { tier: 60, percent: '۶۰٪', title: 'غنی‌سازی با خلوص بالا و آستانه هسته‌ای (۶۰٪)', cost: 600000000, desc: 'رسیدن به مرز توان بازدارندگی و تولید مواد شکافت‌پذیر.' },
  { tier: 100, percent: '۱۰۰٪', title: 'غنی‌سازی تسلیحاتی کامل (۱۰۰٪)', cost: 1200000000, desc: 'ساخت کلاهک اتمی استراتژیک و بازدارندگی نهایی.' },
];

async function upgradeNuclearTier(countryId, seasonId, targetTier) {
  const t = Number(targetTier);
  const tierDef = NUCLEAR_TIERS.find((x) => x.tier === t);
  if (!tierDef) throw new GameError('مرحله غنی‌سازی نامعتبر است.');

  const { acquireLock, releaseLock } = require('../db/locks');
  const lockKey = `nuclear_upgrade:${countryId}`;
  const locked = await acquireLock(lockKey, 10000);
  if (!locked) throw new GameError('ارتقای هسته‌ای در حال پردازش است.');

  try {
    const state = await getCountryState(countryId, seasonId);
    const licenses = state.nuclearLicenses || [];
    if (!licenses.includes(t)) {
      throw new GameError(`مجوز رسمی سازمان ملل برای غنی‌سازی ${tierDef.percent} صادر نشده است! ابتدا باید در سازمان ملل درخواست مجوز ثبت نمایید.`);
    }

    const currentTier = Number(state.nuclearTier || 0);
    if (currentTier >= t) {
      throw new GameError(`کشور شما هم‌اکنون دارای فناوری غنی‌سازی ${tierDef.percent} یا بالاتر است.`);
    }

    // رعایت تقدم مراحل (۲۰ -> ۴۰ -> ۶۰ -> ۱۰۰)
    if (t === 40 && currentTier < 20) throw new GameError('ابتدا باید فناوری غنی‌سازی ۲۰٪ را فعال کنید.');
    if (t === 60 && currentTier < 40) throw new GameError('ابتدا باید فناوری غنی‌سازی ۴۰٪ را فعال کنید.');
    if (t === 100 && currentTier < 60) throw new GameError('ابتدا باید فناوری غنی‌سازی ۶۰٪ را فعال کنید.');

    const cost = tierDef.cost;
    if ((state.treasury || 0) < cost) {
      throw new GameError(`موجودی خزانه کافی نیست. هزینه فعال‌سازی این سطح ${cost.toLocaleString()}$ است.`);
    }

    const newTreasury = (state.treasury || 0) - cost;
    await updateCountryState(countryId, seasonId, {
      nuclearTier: t,
      treasury: newTreasury,
      nuclearUpgradedAt: new Date(),
    });

    return { tier: t, percent: tierDef.percent, newTreasury, title: tierDef.title };
  } finally {
    await releaseLock(lockKey);
  }
}

/**
 * غنی‌سازی دلخواه اورانیوم خام خریداری‌شده از بازار جهانی
 */
async function enrichUranium(countryId, seasonId, targetTier, quantity) {
  const qty = Math.max(1, Math.floor(Number(quantity) || 1));
  const t = Number(targetTier);
  const tierDef = NUCLEAR_TIERS.find((x) => x.tier === t);
  if (!tierDef) throw new GameError('درصد غنی‌سازی انتخاب‌شده نامعتبر است.');

  const { acquireLock, releaseLock } = require('../db/locks');
  const lockKey = `nuclear_enrich:${countryId}`;
  const locked = await acquireLock(lockKey, 10000);
  if (!locked) throw new GameError('عملیات غنی‌سازی در حال پردازش است. لطفاً کمی شکیبا باشید.');

  try {
    const state = await getCountryState(countryId, seasonId);
    const licenses = state.nuclearLicenses || [];
    if (!licenses.includes(t)) {
      throw new GameError(`مجوز رسمی سازمان ملل برای غنی‌سازی ${tierDef.percent} صادر نشده است! ابتدا باید در سازمان ملل تقاضای مجوز ثبت نمایید.`);
    }

    const inventory = { ...(state.inventory || {}) };
    const currentRaw = Number(inventory.uranium || 0);
    if (currentRaw < qty) {
      throw new GameError(`موجودی اورانیوم خام کافی نیست! موجودی کشور شما: ${currentRaw.toLocaleString()} کیلوگرم و مقدار درخواستی: ${qty.toLocaleString()} کیلوگرم است. می‌توانید از «بازار جهانی کالا» اورانیوم خام خریداری کنید.`);
    }

    const processingCostPerKg = 2500;
    const totalProcessingCost = qty * processingCostPerKg;
    if ((state.treasury || 0) < totalProcessingCost) {
      throw new GameError(`موجودی خزانه برای راه‌اندازی فرآیند سانتریفیوژ و غنی‌سازی کافی نیست. هزینه فرآیند: ${totalProcessingCost.toLocaleString()}$ است.`);
    }

    inventory.uranium = currentRaw - qty;
    const enrichedUranium = { ...(state.enrichedUranium || {}) };
    const tierKey = `tier${t}`;
    enrichedUranium[tierKey] = Number(enrichedUranium[tierKey] || 0) + qty;
    const newTreasury = (state.treasury || 0) - totalProcessingCost;

    await updateCountryState(countryId, seasonId, {
      treasury: newTreasury,
      inventory,
      enrichedUranium,
      nuclearTier: Math.max(Number(state.nuclearTier || 0), t),
    });

    return {
      tier: t,
      percent: tierDef.percent,
      qty,
      remainingRaw: inventory.uranium,
      totalEnriched: enrichedUranium[tierKey],
      totalCost: totalProcessingCost,
      newTreasury,
    };
  } finally {
    await releaseLock(lockKey);
  }
}

// اعتبارسنجی مجدد و کسر قطعی تجهیزات و نفت در لحظه صدور نهایی فرمان حمله
async function validateAndDeductAttackUnits(countryId, seasonId, selectedUnits = []) {
  const { acquireLock, releaseLock } = require('../db/locks');
  const lockKey = `attack_launch_units:${countryId}`;
  const locked = await acquireLock(lockKey, 10000);
  if (!locked) throw new GameError('عملیات اعزام در حال پردازش است. لطفاً کمی شکیبا باشید.');

  try {
    const state = await getCountryState(countryId, seasonId);
    const categoryOilRates = { army: 2, tank: 18, fighter: 45, missile: 8, defense: 12, spy_drone: 3, kamikaze_drone: 2, armored_carrier: 10, army_ai: 5, aircraft_carrier: 180, warship: 90, boat: 12, submarine: 70, cargo_plane: 65, nuclear_sub: 120, bomber: 110, cargo_ship: 55 };
    let operationOil = 0;

    const inventory = { ...(state.inventory || {}) };
    const groundUnits = { ...(state.groundUnits || {}) };
    const airUnits = { ...(state.airUnits || {}) };
    const missiles = { ...(state.missiles || {}) };
    const airDefense = { ...(state.airDefense || {}) };
    const navalUnits = { ...(state.navalUnits || {}) };

    for (const unit of selectedUnits) {
      const uid = unit.id;
      const count = Math.max(0, Math.floor(Number(unit.count) || 1));
      if (count <= 0) continue;

      const available = getCountryUnitCount(state, uid);
      if (available < count) {
        throw new GameError(`موجودی واحد «${unit.name || uid}» کافی نیست! موجودی فعلی: ${available.toLocaleString()} واحد، درخواست اعزام: ${count.toLocaleString()} واحد.`);
      }

      const rate = categoryOilRates[unit.category] || 5;
      operationOil += rate * count;

      const simpleKey = uid.replace(/^wpn_/, '');
      if (inventory[uid] !== undefined) {
        inventory[uid] = Math.max(0, inventory[uid] - count);
      } else if (groundUnits[uid] !== undefined || groundUnits[simpleKey] !== undefined) {
        const k = groundUnits[uid] !== undefined ? uid : simpleKey;
        groundUnits[k] = Math.max(0, groundUnits[k] - count);
      } else if (airUnits[uid] !== undefined || airUnits[simpleKey] !== undefined) {
        const k = airUnits[uid] !== undefined ? uid : simpleKey;
        airUnits[k] = Math.max(0, airUnits[k] - count);
      } else if (missiles[uid] !== undefined || missiles[simpleKey] !== undefined) {
        const k = missiles[uid] !== undefined ? uid : simpleKey;
        missiles[k] = Math.max(0, missiles[k] - count);
      } else if (navalUnits[uid] !== undefined || navalUnits[simpleKey] !== undefined) {
        const k = navalUnits[uid] !== undefined ? uid : simpleKey;
        navalUnits[k] = Math.max(0, navalUnits[k] - count);
      } else {
        inventory[uid] = Math.max(0, (inventory[uid] || available) - count);
      }
    }

    operationOil = Math.ceil(operationOil);
    if ((state.oil || 0) < operationOil) {
      throw new GameError(`نفت کافی برای حرکت کاروان ندارید. نیاز به ${operationOil.toLocaleString()} بشکه و موجودی ${(state.oil || 0).toLocaleString()} بشکه است.`);
    }

    const newOil = Math.max(0, (state.oil || 0) - operationOil);
    await updateCountryState(countryId, seasonId, {
      inventory,
      groundUnits,
      airUnits,
      missiles,
      airDefense,
      navalUnits,
      oil: newOil,
    });

    return { operationOil, newOil };
  } finally {
    await releaseLock(lockKey);
  }
}

// تبدیل سکه شاهی به دلار طبق نرخ معین ادمین
async function convertShahiToDollars(countryId, seasonId, count, userId) {
  const shahiAmount = Math.max(1, Math.floor(Number(count) || 1));
  const state = await getCountryState(countryId, seasonId);
  const countryShahi = Number(state.shahiCoins || 0);
  if (countryShahi < shahiAmount) {
    throw new GameError(`سکه شاهی کافی ندارید. موجودی شما ${countryShahi} سکه شاهی است؛ درخواست تبدیل ${shahiAmount} سکه داده‌اید.`);
  }

  const rate = await getShahiExchangeRate();
  const addedDollars = shahiAmount * rate;
  const newShahi = countryShahi - shahiAmount;
  const newTreasury = (state.treasury || 0) + addedDollars;

  await updateCountryState(countryId, seasonId, {
    shahiCoins: newShahi,
    treasury: newTreasury,
  });

  if (userId) {
    const userRef = col('users').doc(String(userId));
    const userSnap = await userRef.get();
    if (userSnap.exists) {
      const uShahi = Math.max(0, Number(userSnap.data().shahiCoins || 0) - shahiAmount);
      await userRef.set({ shahiCoins: uShahi }, { merge: true });
    }
  }

  return {
    convertedShahi: shahiAmount,
    rate,
    addedDollars,
    newTreasury,
    newShahiCoins: newShahi,
  };
}

// اعطای مستقیم سکه شاهی به کشور توسط ادمین
async function grantShahiCoins(countryId, seasonId, amount, note = '') {
  const shahiAmount = Math.floor(Number(amount) || 0);
  if (shahiAmount === 0) throw new GameError('تعداد سکه شاهی نامعتبر است.');
  const state = await getCountryState(countryId, seasonId);
  const newShahi = Math.max(0, (state.shahiCoins || 0) + shahiAmount);
  await updateCountryState(countryId, seasonId, { shahiCoins: newShahi });
  return { countryId, amount: shahiAmount, newShahiCoins: newShahi, note };
}

// ثبت شکایت یا پشتیبانی
async function submitComplaint({ userId, userDisplayName, username, againstCountry, text, photoFileId = null }) {
  const ref = col('complaints').doc();
  const complaint = {
    id: ref.id,
    userId,
    userDisplayName,
    username,
    againstCountry: againstCountry || 'بازی / کلی',
    text,
    photoFileId,
    status: 'pending',
    createdAt: new Date(),
  };
  await ref.set(complaint);
  return complaint;
}

// حمله به کشور دیگر با سیستم پیشرفته انتخاب تجهیزات، محدودیت‌های جغرافیایی و سرعت اعزام
async function executeAttack({
  attackerCountryId,
  defenderCountryId,
  seasonId,
  attackType = 'ground',
  selectedUnits = [], // [{ id, count, power, category, name }]
  targetProvinceId = null,
}) {
  if (String(attackerCountryId) === String(defenderCountryId)) throw new GameError('نمی‌توانید به کشور خودتان حمله کنید!');
  const activeWars = await warService.listWars(seasonId);
  const legalWar = activeWars.some((war) => {
    if (!['active', 'approved'].includes(war.status)) return false;

    const attackerId = String(attackerCountryId);
    const defenderId = String(defenderCountryId);
    const warAttackerId = String(war.attackerCountryId);
    const warDefenderId = String(war.defenderCountryId);

    // The two original countries can fight each other in either direction.
    if ((attackerId === warAttackerId && defenderId === warDefenderId) ||
        (attackerId === warDefenderId && defenderId === warAttackerId)) return true;

    // A third country that joined a side through the channel vote is a combatant:
    // attacker-side allies may attack the war's defender, and defender-side allies
    // may attack the war's attacker.
    const sideVote = (war.sideVotes || {})[attackerId];
    if (!sideVote) return false;
    if (sideVote.side === 'attacker' && defenderId === warDefenderId) return true;
    if (sideVote.side === 'defender' && defenderId === warAttackerId) return true;
    return false;
  });
  if (!legalWar) throw new GameError('حمله ممکن نیست؛ ابتدا باید میان دو کشور اعلان جنگ معتبر و فعال ثبت شده باشد، یا کشور شما با رأی‌گیری به یکی از جبهه‌های این جنگ پیوسته باشد.');
  const attackerState = await getCountryState(attackerCountryId, seasonId);
  const defenderState = await getCountryState(defenderCountryId, seasonId);
  if (defenderState.fallen) throw new GameError('این کشور سقوط کرده و دیگر هدف نظامی فعالی نیست.');
  if (attackerState.fallen) throw new GameError('کشور شما سقوط کرده و دیگر امکان عملیات نظامی ندارد.');

  // بررسی سپر خواب مهاجم
  const attShield = isShielded(attackerState);
  if (attShield.shielded && attShield.type === 'sleep') {
    throw new GameError('سپر خواب شما فعال است! تا زمان اتمام یا لغو سپر خواب نمی‌توانید حمله کنید.');
  }

  // اگر مهاجم دارای محافظت تازه‌واردی باشد، با اقدام به حمله سپر او فوراً می‌شکند
  let shieldBroken = false;
  if (attackerState.newbieProtectionUntil && new Date(attackerState.newbieProtectionUntil).getTime() > Date.now()) {
    await updateCountryState(attackerCountryId, seasonId, { newbieProtectionUntil: null });
    shieldBroken = true;
  }

  // بررسی سپر مدافع
  const defShield = isShielded(defenderState);
  if (defShield.shielded) {
    if (defShield.type === 'sleep') throw new GameError('کشور هدف در حالت «سپر خواب» است و قابل حمله نیست!');
    if (defShield.type === 'newbie') throw new GameError('کشور هدف تحت «محافظت تازه‌واردین» است و هنوز قابل تهاجم نیست!');
  }

  const attackerCountry = await countryService.get(attackerCountryId);
  const defenderCountry = await countryService.get(defenderCountryId);
  if (!attackerCountry || !defenderCountry) throw new GameError('کشور مهاجم یا مدافع پیدا نشد.');
  const defenderProvinces = normalizeProvinces(defenderState.provinces, defenderCountry.name);
  if (!defenderProvinces.length) throw new GameError('کشور هدف هیچ استان قابل تصرفی ندارد.');
  const targetProvince = targetProvinceId
    ? defenderProvinces.find((p) => String(p.id) === String(targetProvinceId))
    : (defenderProvinces.find((p) => !p.isCapital) || defenderProvinces[0]);
  if (!targetProvince) throw new GameError('استان هدف پیدا نشد یا پیش‌تر تصرف شده است.');

  const attGeo = attackerCountry.geography || countryService.getCountryGeography(attackerCountry.name);
  const defGeo = defenderCountry.geography || countryService.getCountryGeography(defenderCountry.name);

  // محدودیت ۱: کشور مقصد جزیره است -> حمله صرفاً زمینی بدون ناو ممنوع است
  const groundInvolved = attackType === 'ground' || attackType === 'combined' || selectedUnits.some((u) => ['army', 'tank'].includes(u.category));
  if (defGeo === 'island' && groundInvolved) {
    const hasNavalCarrier = selectedUnits.some((u) => ['cargo_ship', 'warship', 'aircraft_carrier'].includes(u.category));
    if (!hasNavalCarrier) {
      throw new GameError(`⚠️ کشور مقصد (${defenderCountry.name}) یک «کشور جزیره‌ای» است! انتقال پیاده‌نظام و تانک‌ها به جزیره بدون ترابری دریایی غیرممکن است. باید حداقل یک «ناو تجهیزات‌بر»، «ناو جنگی» یا «ناو هواپیمابر» انتخاب کنید یا از شیوه حمله دریایی/هوایی استفاده نمایید.`);
    }
  }

  // محدودیت ۲: کشورهای محصور در خشکی -> حمله دریایی ندارند
  if ((attGeo === 'landlocked' || defGeo === 'landlocked') && attackType === 'naval') {
    const landlockedName = attGeo === 'landlocked' ? attackerCountry.name : defenderCountry.name;
    throw new GameError(`⚠️ کشور ${landlockedName} به دریا و آب‌های آزاد دسترسی ندارد و امکان حمله دریایی به آن یا از سوی آن وجود ندارد! لطفاً شیوه حمله زمینی، هوایی یا موشکی را انتخاب کنید.`);
  }

  // سیستم سرعت و زمان مبارزه (کاهش با زره‌بر و هواپیمای انتقال تجهیزات)
  const hasArmoredCarrier = selectedUnits.some((u) => u.category === 'armored_carrier');
  const hasCargoPlane = selectedUnits.some((u) => u.category === 'cargo_plane');

  let travelSeconds = 600; // زمان پایه: ۱۰ دقیقه
  let speedBonusPercent = 0;
  if (hasArmoredCarrier) {
    travelSeconds = Math.floor(travelSeconds * 0.65); // ۳۵٪ کاهش
    speedBonusPercent += 35;
  }
  if (hasCargoPlane) {
    travelSeconds = Math.floor(travelSeconds * 0.45); // ۵۵٪ کاهش
    speedBonusPercent += 55;
  }
  if (hasArmoredCarrier && hasCargoPlane) {
    travelSeconds = Math.max(35, Math.floor(travelSeconds * 0.7));
    speedBonusPercent = 75;
  }

  // مصرف نفت عملیاتی: نرخ هر تجهیز به‌ازای یک ساعت فعالیت، متناسب با تعداد انتخابی.
  const categoryOilRates = { army: 2, tank: 18, fighter: 45, missile: 8, defense: 12, spy_drone: 3, kamikaze_drone: 2, armored_carrier: 10, army_ai: 5, aircraft_carrier: 180, warship: 90, boat: 12, submarine: 70, cargo_plane: 65, nuclear_sub: 120, bomber: 110, cargo_ship: 55 };
  let operationOil = 0;
  for (const selected of selectedUnits) {
    const qty = Math.max(0, Math.floor(Number(selected.count) || 1));
    const fullWeapon = selected.id ? await weaponService.get(selected.id) : null;
    const rate = Math.max(0, Number(fullWeapon?.oilUse ?? selected.oilUse ?? categoryOilRates[selected.category] ?? 5));
    operationOil += rate * qty;
  }
  operationOil = Math.ceil(operationOil);
  if ((attackerState.oil || 0) < operationOil) {
    throw new GameError(`نفت کافی برای عملیات ندارید. مصرف این عملیات ${operationOil.toLocaleString()} بشکه و ذخیره فعلی ${(attackerState.oil || 0).toLocaleString()} بشکه است.`);
  }

  // محاسبه قدرت تهاجمی بر اساس ادوات انتخابی
  let selectedUnitsPower = 0;
  for (const u of selectedUnits) {
    selectedUnitsPower += (Number(u.power) || 20) * (Number(u.count) || 1);
  }

  let attPower = (attackerState.military?.attack || 1000) + selectedUnitsPower;

  // اعمال ضریب سطح هوش مصنوعی ارتش (هر لول +۱۰٪ به کل قدرت حمله)
  const armyAiLevel = attackerState.armyAiLevel || 1;
  if (armyAiLevel > 1) {
    attPower = Math.floor(attPower * (1 + (armyAiLevel - 1) * 0.1));
  }

  // اثر پهپاد جاسوسی: افزایش دقت و ضریب برتری
  const hasSpyDrone = selectedUnits.some((u) => u.category === 'spy_drone');
  const spyBonus = hasSpyDrone ? 1.2 : 1.0;

  // اثر پهپاد انتحاری: تضعیف دفاع پدافند دشمن
  const hasKamikazeDrone = selectedUnits.some((u) => u.category === 'kamikaze_drone');
  const defSuppression = hasKamikazeDrone ? 0.85 : 1.0;

  if (attackType === 'missile') attPower += (attackerState.missiles?.fateh110 || 0) * 150;
  if (attackType === 'naval') attPower += Math.floor(attPower * 0.8);

  const provinceDefensePercent = Math.max(10, Number(targetProvince.defense) || 100);
  const defPower = Math.floor((defenderState.military?.defense || 1000) * defSuppression * provinceDefensePercent / 100);
  const roll = (Math.random() * 0.4 + 0.8) * spyBonus; // ضریب تصادفی با مزیت تاکتیکی پهپاد جاسوسی
  const outcomeScore = (attPower * roll) - defPower;

  const isVictory = outcomeScore > 0;
  let lootCash = 0;
  let lootOil = 0;
  let borderDamage = 0;
  let conquered = false;
  let fallenUserId = null;
  let capturedProvinceName = null;

  if (isVictory) {
    // هر پیروزی یک استان را تصرف می‌کند؛ فقط تصرف استان پایتخت موجب سقوط کشور می‌شود.
    lootCash = Math.floor((defenderState.treasury || 0) * 0.1);
    lootOil = Math.floor((defenderState.oil || 0) * 0.15);
    borderDamage = Math.floor(1500 + Math.random() * 1000);
    capturedProvinceName = targetProvince.name;

    const currentBorder = Number(defenderState.border?.current ?? 12500);
    const remainingBorder = Math.max(0, currentBorder - borderDamage);
    const isCapitalCapture = Boolean(targetProvince.isCapital);
    conquered = isCapitalCapture;
    if (isCapitalCapture) {
      lootCash = Number(defenderState.treasury || 0);
      lootOil = Number(defenderState.oil || 0);
    }

    const attackerProvinces = normalizeProvinces(attackerState.provinces, attackerCountry.name);
    const provincesToTransfer = isCapitalCapture
      ? defenderProvinces
      : [targetProvince];
    const transferredProvinces = provincesToTransfer.map((province) => ({
      ...province,
      id: `conq_${defenderCountryId}_${province.id}_${Date.now()}_${Math.floor(Math.random() * 10000)}`,
      originCountryId: province.originCountryId || defenderCountryId,
      originCountryName: province.originCountryName || defenderCountry.name,
      direction: 'تسخیرشده',
      status: 'تحت تسلط',
      isCapital: false,
    }));
    const remainingDefenderProvinces = isCapitalCapture
      ? []
      : defenderProvinces.filter((p) => String(p.id) !== String(targetProvince.id));

    let attackerTreasury;
    let attackerOil;
    let attackerOilReserve;
    let attackerOilReserveBonus;
    let defenderPatch;
    const attackerCapacity = calculateOilReserveCapacity(attackerState, attackerCountry);
    const defenderCapacity = calculateOilReserveCapacity(defenderState, defenderCountry);
    if (isCapitalCapture) {
      // سقوط کشور: تمام استان‌های باقی‌مانده، خزانه و ذخیره نفت آن منتقل می‌شوند.
      attackerTreasury = (attackerState.treasury || 0) + (defenderState.treasury || 0);
      attackerOil = Math.max(0, (attackerState.oil || 0) - operationOil) + (defenderState.oil || 0);
      attackerOilReserve = attackerCapacity.total + defenderCapacity.total;
      attackerOilReserveBonus = Math.max(0, attackerOilReserve - attackerCapacity.base);
      defenderPatch = {
        treasury: 0,
        oil: 0,
        oilReserve: 0,
        oilReserveBonus: 0,
        incomeDaily: 0,
        provinces: [],
        fallen: true,
        fallenAt: new Date(),
        conqueredBy: attackerCountry.name,
        conqueredByCountryId: attackerCountryId,
        border: { ...(defenderState.border || {}), current: 0, max: defenderState.border?.max || 12500 },
      };
      const formerOwner = await ownershipService.getOwnerOfCountry(defenderCountryId, seasonId).catch(() => null);
      fallenUserId = formerOwner?.userId || null;
      if (formerOwner) {
        await ownershipService.releaseOwnership({
          countryId: defenderCountryId,
          seasonId,
          reason: `capital_captured_by:${attackerCountryId}`,
          status: 'conquered',
        });
      }
    } else {
      attackerTreasury = (attackerState.treasury || 0) + lootCash;
      attackerOil = Math.max(0, (attackerState.oil || 0) - operationOil) + lootOil;
      attackerOilReserve = attackerCapacity.total;
      attackerOilReserveBonus = attackerCapacity.bonus;
      defenderPatch = {
        treasury: Math.max(0, (defenderState.treasury || 0) - lootCash),
        oil: Math.max(0, (defenderState.oil || 0) - lootOil),
        border: { ...(defenderState.border || {}), current: remainingBorder },
        provinces: remainingDefenderProvinces,
      };
    }

    await updateCountryState(attackerCountryId, seasonId, {
      treasury: attackerTreasury,
      oil: attackerOil,
      oilReserve: attackerOilReserve,
      oilReserveBonus: attackerOilReserveBonus,
      xp: (attackerState.xp || 0) + (conquered ? 500 : 120),
      provinces: [...attackerProvinces, ...transferredProvinces],
    });
    await updateCountryState(defenderCountryId, seasonId, defenderPatch);
  } else {
    // شکست در حمله
    const lossUnits = Math.min(10, attackerState.groundUnits?.infantry || 0);
    await updateCountryState(attackerCountryId, seasonId, {
      'groundUnits.infantry': Math.max(0, (attackerState.groundUnits?.infantry || 0) - lossUnits),
      oil: Math.max(0, (attackerState.oil || 0) - operationOil),
    });
  }

  return {
    isVictory,
    attacker: attackerCountry,
    defender: defenderCountry,
    attackType,
    attPower,
    defPower,
    lootCash,
    lootOil,
    borderDamage,
    conquered,
    targetProvince: targetProvince ? { id: targetProvince.id, name: targetProvince.name, isCapital: Boolean(targetProvince.isCapital) } : null,
    capturedProvinceName,
    fallenUserId,
    shieldBroken,
    travelSeconds,
    operationOil,
    speedBonusPercent,
    hasArmoredCarrier,
    hasCargoPlane,
    hasSpyDrone,
    hasKamikazeDrone,
    armyAiLevel,
  };
}

// خرید کارگر نفتی (هر ۵۰ کارگر = ۲,۰۰۰,۰۰۰ دلار)
async function buyWorker(countryId, seasonId, count = 50) {
  const state = await getCountryState(countryId, seasonId);
  const cost = count * 40000;
  if (state.treasury < cost) throw new GameError(`سرمایه کافی نیست. نیاز به ${cost.toLocaleString()}$ دارید.`);
  const newTreasury = state.treasury - cost;
  const newWorkers = (state.workers || 0) + count;
  const newDaily = (state.incomeDaily || 0) + count * 50000;
  await updateCountryState(countryId, seasonId, { treasury: newTreasury, workers: newWorkers, incomeDaily: newDaily });
  return { count, cost, currentWorkers: newWorkers, remainingTreasury: newTreasury };
}

// استخراج دستی نفت
async function manualExtractOil(countryId, seasonId) {
  const [state, country] = await Promise.all([getCountryState(countryId, seasonId), countryService.get(countryId)]);
  if (state.fallen) throw new GameError('کشور سقوط کرده و دیگر امکان استخراج نفت ندارد.');
  const rigs = state.oilRigs || 5;
  const requested = Math.floor(50 + rigs * 10 + Math.random() * 20);
  const capacity = calculateOilReserveCapacity(state, country);
  const reserve = capacity.total;
  const remaining = Math.max(0, reserve - Number(state.oil || 0));
  const extracted = Math.min(requested, remaining);
  if (extracted <= 0) throw new GameError('مخزن نفت کشور به سقف تعیین‌شده رسیده است؛ ابتدا اکتشاف نفت انجام دهید.');
  const newOil = (state.oil || 0) + extracted;
  await updateCountryState(countryId, seasonId, { oil: newOil, oilReserve: reserve, oilReserveBonus: capacity.bonus });
  return { extracted, currentOil: newOil, oilReserve: reserve };
}

// سوئیچ حالت خودکار استخراج و فروش
async function toggleAutoMode(countryId, seasonId) {
  const state = await getCountryState(countryId, seasonId);
  const nextVal = !state.autoMode;
  await updateCountryState(countryId, seasonId, { autoMode: nextVal });
  return nextVal;
}

// واریز به صندوق امن (ضد هک)
async function depositToSafeVault(countryId, seasonId, amount = 10000000) {
  const state = await getCountryState(countryId, seasonId);
  if (state.treasury < amount) throw new GameError(`موجودی خزانه کافی نیست. نیاز به ${amount.toLocaleString()}$ دارید.`);
  const newTreasury = state.treasury - amount;
  const newVault = (state.safeVault || 0) + amount;
  await updateCountryState(countryId, seasonId, { treasury: newTreasury, safeVault: newVault });
  return { amount, newTreasury, newVault };
}

// تنظیم انتخاب پرچم پویا (دین یا ایدئولوژی یا پیش‌فرض یا سفارشی)
async function setFlagChoice(countryId, seasonId, choice) {
  if (!['default', 'religion', 'ideology', 'custom'].includes(choice)) throw new GameError('انتخاب نامعتبر است.');
  const patch = { flagChoice: choice };
  if (choice === 'default') {
    patch.customFlag = null;
    patch.customFlagName = null;
  }
  const updatedState = await updateCountryState(countryId, seasonId, patch);
  const country = await countryService.get(countryId);
  const activeFlag = countryService.getDynamicFlag(country, updatedState);
  await col('countries').doc(String(countryId)).update({
    flag: activeFlag,
    activeFlagSource: choice,
  }).catch(() => {});
  return { choice, activeFlag };
}

// سوییچ مستقیم پرچم حکومت (انتخاب از بین چندین پرچم پادشاهی، کمونیستی، دینی، کاویانی، نظامی و...)
async function setCustomFlag(countryId, seasonId, flag, regimeName) {
  if (!flag) throw new GameError('پرچم معتبر نیست.');
  await updateCountryState(countryId, seasonId, {
    customFlag: flag,
    customFlagName: regimeName || 'سفارشی',
    flagChoice: 'custom',
  });
  // به‌روزرسانی آنی و قطعی در دیتابیس اصلی کشورها
  await col('countries').doc(String(countryId)).update({
    flag: flag,
    customFlag: flag,
    activeFlagSource: 'custom',
  }).catch(() => {});
  return { flag, regimeName };
}

// سوئیچ سامانه دفاع خودکار کشور (آمادگی کامل و +۲۵٪ بونوس پدافند)
async function toggleAutoDefense(countryId, seasonId) {
  const state = await getCountryState(countryId, seasonId);
  const nextVal = !Boolean(state.autoDefense);
  await updateCountryState(countryId, seasonId, { autoDefense: nextVal });
  return nextVal;
}

// ریست کامل دارایی‌های کشور (خزانه ۴۰۰M، نفت ۱۵۰۰، نیروهای نظامی پایه)
async function resetCountryAssets(countryId, seasonId) {
  const country = await countryService.get(countryId);
  if (!country) return null;
  const initial = defaultCountryState(country);
  initial.treasury = 400000000;
  initial.oil = 1500;
  initial.autoDefense = false;
  initial.customFlag = null;
  initial.customFlagName = null;
  initial.flagChoice = 'default';

  const ref = col('country_states').doc(`${seasonId}_${countryId}`);
  await ref.set(initial);

  // ریست پرچم در کشور به پرچم اصیل
  const baseFlag = country.flag || countryService.KNOWN_FLAGS[country.name] || '🏳️';
  await col('countries').doc(String(countryId)).update({
    flag: baseFlag,
    customFlag: null,
    activeFlagSource: 'default',
  }).catch(() => {});

  return initial;
}

// اعطای بودجه و کمک بشردوستانه (تنها از محل ذخایر موجود در بانک مرکزی)
async function grantBudget({ countryId, seasonId, amount, donor = 'بانک مرکزی و سازمان بین‌المللی صلح', note = '' }) {
  const numericAmount = Math.max(1, Math.floor(Number(amount) || 0));
  // ادمین فقط از مقدار پول موجود در بانک مرکزی می‌تواند کمک کند
  await centralBankService.deductCentralBankBudget(numericAmount, `اعطای بودجه به کشور ${countryId}`);
  const state = await getCountryState(countryId, seasonId);
  const newTreasury = (state.treasury || 0) + numericAmount;
  await updateCountryState(countryId, seasonId, { treasury: newTreasury });
  return { countryId, amount: numericAmount, newTreasury, donor, note };
}

// تجارت و خرید و فروش با بودجه ملی
async function tradeCommodity({ countryId, seasonId, item, action, quantity = 100 }) {
  const state = await getCountryState(countryId, seasonId);
  const qty = Math.max(1, Math.floor(Number(quantity) || 1));
  let patch = {};
  let msg = '';

  if (item === 'food') {
    const pricePerTon = 5000;
    const totalCost = qty * pricePerTon;
    if (action === 'buy') {
      if ((state.treasury || 0) < totalCost) {
        throw new GameError(`بودجه خزانه کافی نیست. نیاز به ${totalCost.toLocaleString()}$ دارید.`);
      }
      patch.treasury = (state.treasury || 0) - totalCost;
      patch.food = (state.food || 0) + qty;
      msg = `✅ ${qty.toLocaleString()} تن غذا به ارزش ${totalCost.toLocaleString()}$ خریداری و به سیلوهای کشور منتقل شد.`;
    } else {
      if ((state.food || 0) < qty) {
        throw new GameError(`ذخایر غذایی کافی برای فروش ندارید. موجودی: ${(state.food || 0).toLocaleString()} تن`);
      }
      patch.food = (state.food || 0) - qty;
      patch.treasury = (state.treasury || 0) + totalCost;
      msg = `✅ ${qty.toLocaleString()} تن غذا فروخته شد و مبلغ ${totalCost.toLocaleString()}$ به خزانه واریز گردید.`;
    }
  } else if (item === 'coin') {
    const costPerCoin = 10000000;
    const totalCost = qty * costPerCoin;
    if ((state.treasury || 0) < totalCost) {
      throw new GameError(`بودجه کافی ندارید. خرید ${qty} سکه نیاز به ${totalCost.toLocaleString()}$ دارد.`);
    }
    patch.treasury = (state.treasury || 0) - totalCost;
    msg = `✅ ${qty} سکه A-W Coin به ارزش ${totalCost.toLocaleString()}$ با موفقیت خریداری شد.`;
  }
  await updateCountryState(countryId, seasonId, patch);
  return { success: true, msg, patch, state: await getCountryState(countryId, seasonId) };
}

// اعمال جریمه به کشور متخلف
async function applyCountryPenalty({ countryId, seasonId, amount, reason, legitimacyLoss = 15, satisfactionLoss = 10, adminId = 'admin' }) {
  const state = await getCountryState(countryId, seasonId);
  const penaltyAmount = Math.max(0, Number(amount) || 0);
  const newTreasury = Math.max(0, (state.treasury || 0) - penaltyAmount);
  const newLegitimacy = Math.max(0, (state.legitimacy || 100) - legitimacyLoss);
  const newSatisfaction = Math.max(0, (state.satisfaction || 56) - satisfactionLoss);

  await updateCountryState(countryId, seasonId, {
    treasury: newTreasury,
    legitimacy: newLegitimacy,
    satisfaction: newSatisfaction,
  });

  return {
    countryId,
    penaltyAmount,
    newTreasury,
    newLegitimacy,
    newSatisfaction,
    reason,
    adminId,
  };
}


async function getOilExplorationCost() {
  const custom = await settingsService.get('oilExplorationCost', 450000000);
  const n = Number(custom);
  return Number.isFinite(n) && n > 0 ? Math.floor(n) : 450000000;
}

async function exploreOil(countryId, seasonId) {
  const [state, country] = await Promise.all([getCountryState(countryId, seasonId), countryService.get(countryId)]);
  if (!country) throw new GameError('کشور یافت نشد.');
  if (state.fallen) throw new GameError('کشور سقوط کرده و دیگر امکان اکتشاف نفت ندارد.');
  const cost = await getOilExplorationCost();
  if ((state.treasury || 0) < cost) throw new GameError(`برای اعزام تیم اکتشاف به ${cost.toLocaleString()} دلار نیاز دارید.`);
  // درصد نفت‌خیزی و ظرفیت پایه از رکورد کشور و ظرفیت اضافه از اکتشاف‌های قبلی خوانده می‌شود.
  const richness = Math.max(0, Math.min(100, Number(country.oilRichness ?? state.oilRichness ?? 50)));
  const capacity = calculateOilReserveCapacity(state, country);
  const chance = richness / 100;
  const found = Math.random() < chance;
  let bonus = capacity.bonus;
  let added = 0;
  if (found) {
    added = Math.floor(500 + richness * 100 + Math.random() * Math.max(1, richness * 50));
    bonus += added;
  }
  const oilReserve = capacity.base + bonus;
  const patch = {
    treasury: state.treasury - cost,
    oilRichness: richness,
    oilReserve,
    oilReserveBonus: bonus,
    oilExplorationAt: new Date(),
    oilExplorationFound: found,
  };
  if (found) patch.oilReserveAdded = added;
  await updateCountryState(countryId, seasonId, patch);
  return { found, added, oilReserve, treasury: patch.treasury, chance, richness };
}

async function changeCapitalProvince(countryId, seasonId, provinceId) {
  const [state, country] = await Promise.all([getCountryState(countryId, seasonId), countryService.get(countryId)]);
  if (!country) throw new GameError('کشور یافت نشد.');
  if (state.fallen) throw new GameError('کشور سقوط کرده و دیگر امکان تغییر پایتخت ندارد.');
  const provinces = normalizeProvinces(state.provinces, country.name);
  if (!provinces.length) throw new GameError('هیچ استانی برای انتخاب پایتخت وجود ندارد.');
  const target = provinces.find((p) => String(p.id) === String(provinceId));
  if (!target) throw new GameError('استان موردنظر در قلمرو شما نیست.');
  if (target.isCapital) throw new GameError('این استان هم‌اکنون پایتخت ملی کشور شماست.');

  const configuredCost = await settingsService.get('capitalChangeCost', 250000000);
  const parsedCost = Number(configuredCost);
  const cost = Number.isFinite(parsedCost) && parsedCost >= 0 ? Math.floor(parsedCost) : 250000000;
  const treasury = Math.max(0, Number(state.treasury || 0));
  if (treasury < cost) throw new GameError(`برای انتقال پایتخت به ${target.name} به ${cost.toLocaleString()} دلار نیاز دارید؛ موجودی خزانه ${treasury.toLocaleString()} دلار است.`);

  const updated = provinces.map((p) => ({ ...p, isCapital: String(p.id) === String(target.id) }));
  await updateCountryState(countryId, seasonId, {
    treasury: treasury - cost,
    provinces: updated,
    nationalCapitalProvinceId: target.id,
    nationalCapitalProvinceName: target.name,
    nationalCapitalChangedAt: new Date(),
    nationalCapitalChangeCostPaid: cost,
  });
  return { province: updated.find((p) => String(p.id) === String(target.id)), cost, treasury: treasury - cost };
}

async function renameProvince(countryId, seasonId, provinceId, name, capitalName) {
  const state = await getCountryState(countryId, seasonId);
  const country = await countryService.get(countryId);
  if (state.fallen) throw new GameError('کشور سقوط کرده و دیگر امکان ویرایش استان‌ها را ندارد.');
  const provinces = normalizeProvinces(state.provinces, country ? country.name : 'کشور');
  const province = provinces.find((p) => String(p.id) === String(provinceId));
  if (!province) throw new GameError('استان موردنظر پیدا نشد.');
  const clean = String(name || '').trim();
  if (!clean || clean.length > 50) throw new GameError('نام استان باید بین ۱ تا ۵۰ نویسه باشد.');
  province.name = clean;
  if (capitalName !== undefined) {
    const cap = String(capitalName || '').trim();
    if (!cap || cap.length > 50) throw new GameError('نام پایتخت استان باید بین ۱ تا ۵۰ نویسه باشد.');
    province.capital = cap;
  }
  await updateCountryState(countryId, seasonId, { provinces });
  return province;
}

// -------------------------------------------------------------
// وام بین کشورها (با بازپرداخت خودکار ۸۰٪ از هر واریز درآمد)
// -------------------------------------------------------------
// وام بین کشورها (ثبت درخواست اولیه + تایید توسط کشور وام‌دهنده + بازپرداخت خودکار ۸۰٪)
// -------------------------------------------------------------
async function requestBilateralLoan({ lenderCountryId, borrowerCountryId, amount, seasonId, borrowerUserId }) {
  const numericAmount = Math.max(1, Math.floor(Number(amount) || 0));
  if (numericAmount <= 0) throw new GameError('مبلغ وام نامعتبر است.');
  if (String(lenderCountryId) === String(borrowerCountryId)) throw new GameError('امکان دریافت وام از کشور خودتان وجود ندارد.');

  const [lenderState, borrowerState, lenderCountry, borrowerCountry] = await Promise.all([
    getCountryState(lenderCountryId, seasonId),
    getCountryState(borrowerCountryId, seasonId),
    countryService.get(lenderCountryId),
    countryService.get(borrowerCountryId),
  ]);

  if (!lenderCountry) throw new GameError('کشور وام‌دهنده یافت نشد.');
  if (!borrowerCountry) throw new GameError('کشور وام‌گیرنده یافت نشد.');

  if ((lenderState.treasury || 0) < numericAmount) {
    throw new GameError(`خزانه کشور ${lenderCountry.name} در حال حاضر موجودی کافی برای پرداخت این وام را ندارد.`);
  }

  // بررسی عدم ثبت درخواست تکراری در حالت انتظار
  const pendingCheck = await col('bilateral_loans')
    .where('borrowerCountryId', '==', String(borrowerCountryId))
    .where('lenderCountryId', '==', String(lenderCountryId))
    .where('seasonId', '==', String(seasonId))
    .where('status', '==', 'pending')
    .limit(1)
    .get();

  if (!pendingCheck.empty) {
    throw new GameError(`شما هم‌اکنون یک درخواست وام در انتظار پاسخ نزد کشور ${lenderCountry.name} دارید.`);
  }

  const loanRef = col('bilateral_loans').doc();
  const loan = {
    id: loanRef.id,
    lenderCountryId: String(lenderCountryId),
    borrowerCountryId: String(borrowerCountryId),
    borrowerUserId: String(borrowerUserId || ''),
    amount: numericAmount,
    initialAmount: numericAmount,
    remainingDebt: numericAmount,
    status: 'pending',
    seasonId: String(seasonId),
    createdAt: new Date(),
  };
  await loanRef.set(loan);
  return { loan, lenderCountry, borrowerCountry, lenderState };
}

// تایید رسمی وام توسط رهبر کشور وام‌دهنده (کسر از وام‌دهنده و واریز به وام‌گیرنده)
async function approveBilateralLoan({ loanId, lenderUserId, seasonId }) {
  const locks = require('../db/locks');
  const lockKey = `loan:${loanId}`;
  const locked = await locks.acquireLock(lockKey, 10000);
  if (!locked) throw new GameError('عملیات تایید وام در حال انجام است؛ لطفاً شکیبا باشید.');

  try {
    const loanRef = col('bilateral_loans').doc(String(loanId));
    const loan = snap(await loanRef.get());
    if (!loan || loan.status !== 'pending') {
      throw new GameError('این درخواست وام دیگر در انتظار تایید نیست یا قبلاً بررسی شده است.');
    }

    const [lenderCountry, borrowerCountry] = await Promise.all([
      countryService.get(loan.lenderCountryId),
      countryService.get(loan.borrowerCountryId),
    ]);

    const lenderState = await getCountryState(loan.lenderCountryId, seasonId);
    if ((lenderState.treasury || 0) < loan.amount) {
      throw new GameError(`موجودی خزانه کشور شما (${fmtNum(lenderState.treasury || 0)}$) برای اعطای وام ${fmtNum(loan.amount)}$ کافی نیست.`);
    }

    const borrowerState = await getCountryState(loan.borrowerCountryId, seasonId);

    // کسر از وام‌دهنده و افزایش خزانه وام‌گیرنده
    await updateCountryState(loan.lenderCountryId, seasonId, {
      treasury: Math.max(0, (lenderState.treasury || 0) - loan.amount),
    });
    await updateCountryState(loan.borrowerCountryId, seasonId, {
      treasury: (borrowerState.treasury || 0) + loan.amount,
    });

    await loanRef.update({
      status: 'active',
      approvedAt: new Date(),
      approvedByUserId: String(lenderUserId),
    });

    return {
      loan: { ...loan, status: 'active' },
      lenderCountry,
      borrowerCountry,
      amount: loan.amount,
      borrowerUserId: loan.borrowerUserId,
    };
  } finally {
    await locks.releaseLock(lockKey);
  }
}

// رد درخواست وام توسط کشور وام‌دهنده
async function rejectBilateralLoan({ loanId, lenderUserId, seasonId }) {
  const loanRef = col('bilateral_loans').doc(String(loanId));
  const loan = snap(await loanRef.get());
  if (!loan || loan.status !== 'pending') {
    throw new GameError('این درخواست وام دیگر معتبر نیست یا قبلاً بررسی شده است.');
  }

  const [lenderCountry, borrowerCountry] = await Promise.all([
    countryService.get(loan.lenderCountryId),
    countryService.get(loan.borrowerCountryId),
  ]);

  await loanRef.update({
    status: 'rejected',
    rejectedAt: new Date(),
    rejectedByUserId: String(lenderUserId),
  });

  return { loan, lenderCountry, borrowerCountry, borrowerUserId: loan.borrowerUserId };
}

// لغو درخواست وام توسط کشور درخواست‌کننده
async function cancelBilateralLoan({ loanId, borrowerUserId }) {
  const loanRef = col('bilateral_loans').doc(String(loanId));
  const loan = snap(await loanRef.get());
  if (!loan || loan.status !== 'pending') {
    throw new GameError('این درخواست وام دیگر در وضعیت انتظار قرار ندارد.');
  }
  if (String(loan.borrowerUserId) !== String(borrowerUserId)) {
    throw new GameError('تنها درخواست‌دهنده می‌تواند این درخواست وام را لغو کند.');
  }

  await loanRef.update({
    status: 'cancelled',
    cancelledAt: new Date(),
  });

  return loan;
}

// سازگاری با کدهای پیشین
async function createBilateralLoan(opts) {
  return requestBilateralLoan(opts);
}

async function listLoansForCountry(countryId, seasonId) {
  const [borrowedSnap, lentSnap, incomingPendingSnap, outgoingPendingSnap] = await Promise.all([
    col('bilateral_loans').where('borrowerCountryId', '==', String(countryId)).where('seasonId', '==', String(seasonId)).where('status', '==', 'active').get(),
    col('bilateral_loans').where('lenderCountryId', '==', String(countryId)).where('seasonId', '==', String(seasonId)).where('status', '==', 'active').get(),
    col('bilateral_loans').where('lenderCountryId', '==', String(countryId)).where('seasonId', '==', String(seasonId)).where('status', '==', 'pending').get(),
    col('bilateral_loans').where('borrowerCountryId', '==', String(countryId)).where('seasonId', '==', String(seasonId)).where('status', '==', 'pending').get(),
  ]);
  return {
    borrowed: docs(borrowedSnap),
    lent: docs(lentSnap),
    incomingPending: docs(incomingPendingSnap),
    outgoingPending: docs(outgoingPendingSnap),
  };
}

async function repayLoanFromIncome(countryId, seasonId, incomeAmount) {
  const income = Math.max(0, Math.floor(Number(incomeAmount) || 0));
  if (income <= 0) return { netIncome: 0, totalRepaid: 0 };

  const loansSnap = await col('bilateral_loans')
    .where('borrowerCountryId', '==', String(countryId))
    .where('seasonId', '==', String(seasonId))
    .where('status', '==', 'active')
    .get();

  const activeLoans = docs(loansSnap);
  if (!activeLoans.length) return { netIncome: income, totalRepaid: 0 };

  // قانون دقیق: کسر ۸۰ درصد از درآمد و واریز به حساب کشور وام‌دهنده تا تسویه بدهی
  let maxDeductionAllowed = Math.floor(income * 0.80);
  let totalRepaid = 0;

  for (const loan of activeLoans) {
    if (maxDeductionAllowed <= 0) break;
    const remaining = Number(loan.remainingDebt || 0);
    if (remaining <= 0) continue;

    const repayment = Math.min(remaining, maxDeductionAllowed);
    maxDeductionAllowed -= repayment;
    totalRepaid += repayment;
    const newRemaining = remaining - repayment;

    await col('bilateral_loans').doc(loan.id).set({
      remainingDebt: newRemaining,
      status: newRemaining <= 0 ? 'repaid' : 'active',
      lastRepaidAt: new Date(),
    }, { merge: true });

    // واریز به خزانه کشور وام‌دهنده
    const lenderState = await getCountryState(loan.lenderCountryId, seasonId);
    await updateCountryState(loan.lenderCountryId, seasonId, {
      treasury: (lenderState.treasury || 0) + repayment,
    });
  }

  const netIncome = income - totalRepaid;
  return { netIncome, totalRepaid };
}

// -------------------------------------------------------------
// بخش فروش نفت به کشورها (P2P با کارمزد ۱.۵٪ به بانک مرکزی)
// -------------------------------------------------------------
async function postCountryOilOffer({ countryId, seasonId, barrels, pricePerBarrel }) {
  const qty = Math.max(1, Math.floor(Number(barrels) || 0));
  const price = Math.max(1, Math.floor(Number(pricePerBarrel) || 0));
  const state = await getCountryState(countryId, seasonId);
  const country = await countryService.get(countryId);

  if ((state.oil || 0) < qty) {
    throw new GameError(`موجودی نفت کافی نیست! موجودی شما: ${(state.oil || 0).toLocaleString()} بشکه و مقدار فروش: ${qty.toLocaleString()} بشکه است.`);
  }

  // رزرو نفت در پیشنهاد فروش
  await updateCountryState(countryId, seasonId, { oil: (state.oil || 0) - qty });

  const ref = col('country_oil_offers').doc();
  const offer = {
    id: ref.id,
    countryId: String(countryId),
    countryName: country ? country.name : 'نامشخص',
    countryFlag: country ? country.flag : '🏳️',
    barrels: qty,
    initialBarrels: qty,
    pricePerBarrel: price,
    seasonId: String(seasonId),
    status: 'active',
    createdAt: new Date(),
  };
  await ref.set(offer);
  return offer;
}

async function listCountryOilOffers(seasonId) {
  const q = await col('country_oil_offers')
    .where('seasonId', '==', String(seasonId))
    .where('status', '==', 'active')
    .get();
  return docs(q);
}

async function buyCountryOilOffer({ buyerCountryId, offerId, barrelsToBuy, seasonId }) {
  const reqQty = Math.max(1, Math.floor(Number(barrelsToBuy) || 0));
  const ref = col('country_oil_offers').doc(offerId);
  const snapDoc = await ref.get();
  if (!snapDoc.exists) throw new GameError('پیشنهاد فروش نفت یافت نشد.');
  const offer = snapDoc.data();
  if (offer.status !== 'active' || offer.barrels < reqQty) {
    throw new GameError(`تنها ${offer.barrels.toLocaleString()} بشکه در این پیشنهاد موجود است.`);
  }
  if (String(offer.countryId) === String(buyerCountryId)) {
    throw new GameError('نمی‌توانید نفت پیشنهادی کشور خودتان را بخرید.');
  }

  const [buyerState, buyerCountry, sellerState] = await Promise.all([
    getCountryState(buyerCountryId, seasonId),
    countryService.get(buyerCountryId),
    getCountryState(offer.countryId, seasonId),
  ]);

  const totalCost = reqQty * offer.pricePerBarrel;
  if ((buyerState.treasury || 0) < totalCost) {
    throw new GameError(`خزانه کافی نیست. هزینه خرید: ${totalCost.toLocaleString()}$ | موجودی شما: ${(buyerState.treasury || 0).toLocaleString()}$`);
  }

  // بررسی سقف مخزن نفت خریدار
  const capacity = calculateOilReserveCapacity(buyerState, buyerCountry);
  const remainingCap = Math.max(0, capacity.total - Number(buyerState.oil || 0));
  if (remainingCap < reqQty) {
    throw new GameError(`مخزن نفت شما گنجایش این مقدار را ندارد! گنجایش خالی: ${remainingCap.toLocaleString()} بشکه`);
  }

  // کارمزد ۱.۵ درصدی به بانک مرکزی طبق دستور
  const tax = Math.floor(totalCost * 0.015);
  await centralBankService.addCentralBankTax(tax, 'کارمزد ۱.۵٪ فروش نفت بین کشورها');
  const netSellerPayout = totalCost - tax;

  // اعمال انتقالات
  await updateCountryState(buyerCountryId, seasonId, {
    treasury: (buyerState.treasury || 0) - totalCost,
    oil: (buyerState.oil || 0) + reqQty,
  });

  await updateCountryState(offer.countryId, seasonId, {
    treasury: (sellerState.treasury || 0) + netSellerPayout,
  });

  const remainingBarrels = offer.barrels - reqQty;
  await ref.set({
    barrels: remainingBarrels,
    status: remainingBarrels <= 0 ? 'sold' : 'active',
  }, { merge: true });

  return { reqQty, totalCost, tax, netSellerPayout, remainingBarrels };
}

// -------------------------------------------------------------
// قراردادهای نفتی بین کشورها (تامین منظم نفت)
// -------------------------------------------------------------
async function createOilContract({ buyerCountryId, sellerCountryId, dailyBarrels, dailyDollars, seasonId }) {
  const barrels = Math.max(1, Math.floor(Number(dailyBarrels) || 0));
  const dollars = Math.max(1, Math.floor(Number(dailyDollars) || 0));
  const [buyer, seller] = await Promise.all([countryService.get(buyerCountryId), countryService.get(sellerCountryId)]);
  if (!buyer || !seller) throw new GameError('کشورها معتبر نیستند.');

  const ref = col('oil_contracts').doc();
  const contract = {
    id: ref.id,
    buyerCountryId: String(buyerCountryId),
    sellerCountryId: String(sellerCountryId),
    dailyBarrels: barrels,
    dailyDollars: dollars,
    seasonId: String(seasonId),
    status: 'pending',
    createdAt: new Date(),
  };
  await ref.set(contract);
  return { contract, buyer, seller };
}

async function listOilContracts(countryId, seasonId) {
  const [bSnap, sSnap] = await Promise.all([
    col('oil_contracts').where('buyerCountryId', '==', String(countryId)).where('seasonId', '==', String(seasonId)).get(),
    col('oil_contracts').where('sellerCountryId', '==', String(countryId)).where('seasonId', '==', String(seasonId)).get(),
  ]);
  return docs(bSnap).concat(docs(sSnap));
}

async function respondOilContract(contractId, accept) {
  const ref = col('oil_contracts').doc(contractId);
  const snapDoc = await ref.get();
  if (!snapDoc.exists) throw new GameError('قرارداد یافت نشد.');
  const contract = snapDoc.data();
  const newStatus = accept ? 'active' : 'rejected';
  await ref.set({ status: newStatus, respondedAt: new Date() }, { merge: true });
  return { ...contract, status: newStatus };
}

// -------------------------------------------------------------
// بازار جهانی (منابع پایه با قیمت ثابت و تعیین توسط ادمین)
// -------------------------------------------------------------
const DEFAULT_GLOBAL_PRICES = {
  wood: { name: 'چوب', unit: 'تن', price: 1200 },
  cement: { name: 'سیمان', unit: 'تن', price: 2500 },
  steel: { name: 'فولاد', unit: 'تن', price: 8000 },
  iron: { name: 'آهن', unit: 'تن', price: 6500 },
  wheat: { name: 'گندم', unit: 'تن', price: 950 },
  copper: { name: 'مس', unit: 'تن', price: 11000 },
  uranium: { name: 'اورانیوم خام', unit: 'کیلوگرم', price: 25000 },
};

async function getGlobalMarketPrices() {
  const custom = await settingsService.get('global_market_prices', null);
  return custom || DEFAULT_GLOBAL_PRICES;
}

async function setGlobalMarketPrice(itemKey, newPrice) {
  const prices = await getGlobalMarketPrices();
  if (!prices[itemKey]) throw new GameError('کالای موردنظر در بازار جهانی تعریف نشده است.');
  prices[itemKey].price = Math.max(1, Math.floor(Number(newPrice) || 1));
  await settingsService.set('global_market_prices', prices);
  return prices;
}

async function buyFromGlobalMarket(countryId, seasonId, itemKey, quantity) {
  const qty = Math.max(1, Math.floor(Number(quantity) || 1));
  const prices = await getGlobalMarketPrices();
  const item = prices[itemKey];
  if (!item) throw new GameError('کالای انتخاب‌شده نامعتبر است.');

  const totalCost = qty * item.price;
  const state = await getCountryState(countryId, seasonId);
  if ((state.treasury || 0) < totalCost) {
    throw new GameError(`خزانه کشور کافی نیست. نیاز به ${totalCost.toLocaleString()}$ دارید.`);
  }

  const inventory = state.inventory || {};
  const currentItem = Number(inventory[itemKey] || 0);
  inventory[itemKey] = currentItem + qty;

  await updateCountryState(countryId, seasonId, {
    treasury: (state.treasury || 0) - totalCost,
    inventory,
  });

  return { item, qty, totalCost, remainingTreasury: (state.treasury || 0) - totalCost };
}

async function sellToGlobalMarket(countryId, seasonId, itemKey, quantity) {
  const qty = Math.max(1, Math.floor(Number(quantity) || 1));
  const prices = await getGlobalMarketPrices();
  const item = prices[itemKey];
  if (!item) throw new GameError('کالای انتخاب‌شده نامعتبر است.');

  const state = await getCountryState(countryId, seasonId);
  const inventory = state.inventory || {};
  const currentItem = Number(inventory[itemKey] || 0);
  if (currentItem < qty) {
    throw new GameError(`موجودی انبار کافی نیست! موجودی شما: ${currentItem.toLocaleString()} ${item.unit} است.`);
  }

  const revenue = qty * item.price;
  inventory[itemKey] = currentItem - qty;

  await updateCountryState(countryId, seasonId, {
    treasury: (state.treasury || 0) + revenue,
    inventory,
  });

  return { item, qty, revenue, newTreasury: (state.treasury || 0) + revenue };
}

// -------------------------------------------------------------
// بازار عمومی بازیکنان (P2P با کارمزد ۳٪ به بانک مرکزی)
// -------------------------------------------------------------
async function postPublicMarketOffer({ countryId, itemKey, quantity, pricePerUnit, seasonId }) {
  const qty = Math.max(1, Math.floor(Number(quantity) || 1));
  const unitPrice = Math.max(1, Math.floor(Number(pricePerUnit) || 1));
  const state = await getCountryState(countryId, seasonId);
  const country = await countryService.get(countryId);

  const inventory = state.inventory || {};
  const inStock = Number(inventory[itemKey] || 0);
  if (inStock < qty) {
    throw new GameError(`موجودی این کالا در انبار کشور کافی نیست! موجودی فعلی: ${inStock}`);
  }

  inventory[itemKey] = inStock - qty;
  await updateCountryState(countryId, seasonId, { inventory });

  const ref = col('public_market_offers').doc();
  const offer = {
    id: ref.id,
    countryId: String(countryId),
    countryName: country?.name || 'کشور',
    countryFlag: country?.flag || '🏳️',
    itemKey,
    quantity: qty,
    pricePerUnit: unitPrice,
    seasonId: String(seasonId),
    status: 'active',
    createdAt: new Date(),
  };
  await ref.set(offer);
  return offer;
}

async function listPublicMarketOffers(seasonId) {
  const q = await col('public_market_offers')
    .where('seasonId', '==', String(seasonId))
    .where('status', '==', 'active')
    .get();
  return docs(q);
}

async function buyPublicMarketOffer({ buyerCountryId, offerId, quantityToBuy, seasonId }) {
  const reqQty = Math.max(1, Math.floor(Number(quantityToBuy) || 1));
  const ref = col('public_market_offers').doc(offerId);
  const snapDoc = await ref.get();
  if (!snapDoc.exists) throw new GameError('پیشنهاد فروش یافت نشد.');
  const offer = snapDoc.data();
  if (offer.status !== 'active' || offer.quantity < reqQty) {
    throw new GameError(`تنها ${offer.quantity.toLocaleString()} واحد از این کالا موجود است.`);
  }
  if (String(offer.countryId) === String(buyerCountryId)) {
    throw new GameError('امکان خرید کالای کشور خودتان وجود ندارد.');
  }

  const totalCost = reqQty * offer.pricePerUnit;
  const [buyerState, sellerState] = await Promise.all([
    getCountryState(buyerCountryId, seasonId),
    getCountryState(offer.countryId, seasonId),
  ]);

  if ((buyerState.treasury || 0) < totalCost) {
    throw new GameError(`موجودی خزانه کافی نیست. نیاز به ${totalCost.toLocaleString()}$ دارید.`);
  }

  // کارمزد ۳٪ به بانک مرکزی
  const tax = Math.floor(totalCost * 0.03);
  await centralBankService.addCentralBankTax(tax, 'کارمزد ۳٪ معاملات بازار عمومی بین کشورها');
  const netSellerPayout = totalCost - tax;

  const buyerInventory = buyerState.inventory || {};
  buyerInventory[offer.itemKey] = Number(buyerInventory[offer.itemKey] || 0) + reqQty;

  await updateCountryState(buyerCountryId, seasonId, {
    treasury: (buyerState.treasury || 0) - totalCost,
    inventory: buyerInventory,
  });

  await updateCountryState(offer.countryId, seasonId, {
    treasury: (sellerState.treasury || 0) + netSellerPayout,
  });

  const remaining = offer.quantity - reqQty;
  await ref.set({
    quantity: remaining,
    status: remaining <= 0 ? 'sold' : 'active',
  }, { merge: true });

  return { reqQty, totalCost, tax, netSellerPayout, remaining };
}

module.exports = {
  getOilMarketPrice,
  getCountryState,
  updateCountryState,
  buyOil,
  buyOilRig,
  sellOilMarket,
  buyWorker,
  manualExtractOil,
  exploreOil,
  getOilExplorationCost,
  renameProvince,
  changeCapitalProvince,
  toggleAutoMode,
  depositToSafeVault,
  setFlagChoice,
  setCustomFlag,
  buyMilitaryUnit,
  MILITARY_STORE,
  isShielded,
  activateSleepShield,
  deactivateSleepShield,
  RELIGIONS,
  changeReligion,
  GOVERNMENTS,
  changeGovernment,
  DAILY_MISSIONS: DEFAULT_DAILY_MISSIONS,
  DEFAULT_DAILY_MISSIONS,
  getDailyMissions,
  getShahiExchangeRate,
  convertShahiToDollars,
  grantShahiCoins,
  getUserMissions,
  claimMission,
  submitComplaint,
  executeAttack,
  normalizeProvinces,
  calculateOilReserveCapacity,
  grantBudget,
  tradeCommodity,
  applyCountryPenalty,
  processPendingOilShipments,
  getCountryUnitCount,
  upgradeArmyAi,
  // قابلیت‌های جدید وام، بازار جهانی، بازار عمومی، قراردادها و فروش نفت
  requestBilateralLoan,
  createBilateralLoan,
  approveBilateralLoan,
  rejectBilateralLoan,
  cancelBilateralLoan,
  listLoansForCountry,
  repayLoanFromIncome,
  postCountryOilOffer,
  listCountryOilOffers,
  buyCountryOilOffer,
  createOilContract,
  listOilContracts,
  respondOilContract,
  getGlobalMarketPrices,
  setGlobalMarketPrice,
  buyFromGlobalMarket,
  sellToGlobalMarket,
  postPublicMarketOffer,
  listPublicMarketOffers,
  buyPublicMarketOffer,
  DEFAULT_GLOBAL_PRICES,
  // سیستم خدمات عمومی، نیروگاه‌ها، قطعی و شورش
  getCountryUtilities: (countryId, seasonId) => require('./peopleService').getCountryUtilities(countryId, seasonId, module.exports),
  buyUtilityPlant: (countryId, seasonId, category, plantKey) => require('./peopleService').buyUtilityPlant(countryId, seasonId, category, plantKey, module.exports),
  setUtilityOutage: (countryId, seasonId, category, hours) => require('./peopleService').setUtilityOutage(countryId, seasonId, category, hours, module.exports),
  quellRebellion: (countryId, seasonId, method) => require('./peopleService').quellRebellion(countryId, seasonId, method, module.exports),
  get DEFAULT_UTILITY_PLANTS() {
    const ps = require('./peopleService');
    return ps.DEFAULT_UTILITY_PLANTS || {};
  },
  // سیستم ساخت‌وساز، بورس سهام، شرکت‌ها، مگاپروژه‌ها و رسانه
  getStockMarket: (seasonId) => require('./constructionService').getStockMarket(seasonId),
  buyStockShares: (countryId, seasonId, stockKey, quantity) => require('./constructionService').buyStockShares(countryId, seasonId, stockKey, quantity, module.exports),
  createCustomEnterprise: (countryId, seasonId, data) => require('./constructionService').createCustomEnterprise(countryId, seasonId, data, module.exports),
  upgradeEnterprise: (countryId, seasonId, enterpriseId) => require('./constructionService').upgradeEnterprise(countryId, seasonId, enterpriseId, module.exports),
  buildMegaproject: (countryId, seasonId, projectKey) => require('./constructionService').buildMegaproject(countryId, seasonId, projectKey, module.exports),
  upgradeInternet: (countryId, seasonId) => require('./constructionService').upgradeInternet(countryId, seasonId, module.exports),
  createTelecomOperator: (countryId, seasonId, data) => require('./constructionService').createTelecomOperator(countryId, seasonId, data, module.exports),
  submitMediaPost: (countryId, seasonId, data) => require('./constructionService').submitMediaPost(countryId, seasonId, data),
  get MEGAPROJECTS() {
    const cs = require('./constructionService');
    return cs.MEGAPROJECTS || cs.DEFAULT_MEGAPROJECTS || {};
  },
  get ENTERPRISE_CATEGORIES() {
    const cs = require('./constructionService');
    return cs.ENTERPRISE_CATEGORIES || {};
  },
  controlStockEnterprise: (countryId, seasonId, stockKey, data) => require('./constructionService').controlStockEnterprise(countryId, seasonId, stockKey, data, module.exports),
  toggleAutoDefense,
  resetCountryAssets,
  defaultCountryState,
  recordMissionProgressAndAutoClaim,
  validateAndDeductAttackUnits,
  NUCLEAR_TIERS,
  upgradeNuclearTier,
  enrichUranium,
};

