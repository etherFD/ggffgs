'use strict';
const { Telegraf, Markup } = require('telegraf');
const { config } = require('../config');
const settings = require('./settingsService');
const logger = require('../utils/logger');
const warService = require('./warService');
const countryService = require('./countryService');
const userService = require('./userService');
const gameService = require('./gameService');
const actions = require('./adminActions');
const selection = require('./selectionService');
const ownership = require('./ownershipService');
const seasonService = require('./seasonService');
const { col, docs } = require('../db/firestore');
const { esc, fmtNum } = require('../utils/text');

const centralBankService = require('./centralBankService');

let adminBotInstance = null;
let currentBotToken = null;
let savedMainTelegram = null;
const adminDmFlows = new Map();
const adminBudgetFlows = new Map();
const adminShahiFlows = new Map();
const adminPenaltyFlows = new Map();
const adminRevokeFlows = new Map();
const adminSeasonBanFlows = new Map();
const adminExplorationCostFlows = new Map();

const cb = (text, data, style = 'primary') => ({ text, callback_data: data, style });

async function getAdminBotToken() {
  const custom = await settings.get('adminBotToken', '');
  return (custom || process.env.ADMIN_BOT_TOKEN || process.env.adminBotToken || '').trim();
}

async function getAdminChatId() {
  const custom = await settings.get('adminChatId', '');
  return (custom || process.env.ADMIN_CHAT_ID || process.env.adminChatId || (config.adminIds[0] ? String(config.adminIds[0]) : '')).trim();
}

let cacheData = {
  time: 0,
  season: null,
  activeOwnerships: [],
  countriesMap: new Map(),
  usersCount: 0,
  openRequests: [],
  pendingWars: [],
  complaints: [],
  botDisabled: false,
};

function invalidateAdminCache() {
  cacheData.time = 0;
}

async function buildDashboardData(forceRefresh = false) {
  const now = Date.now();
  if (!forceRefresh && now - cacheData.time < 20000 && cacheData.season) {
    return cacheData;
  }
  const season = await seasonService.getActiveSeason();
  const [usersSnap, openReqs, pendingWars, complaintsSnap, countries, centralBankBudget] = await Promise.all([
    col('users').limit(150).get().catch(() => ({ docs: [] })),
    selection.listOpenRequests().catch(() => []),
    season ? warService.listWars(season.id, 'pending').catch(() => []) : [],
    col('complaints').where('status', '==', 'pending').limit(20).get().catch(() => ({ docs: [] })),
    countryService.list().catch(() => []),
    centralBankService.getCentralBankBudget().catch(() => 500000000),
  ]);

  const activeOwnerships = season ? await ownership.listActive(season.id).catch(() => []) : [];
  const countriesMap = new Map();
  for (const c of countries) countriesMap.set(String(c.id), c);

  cacheData = {
    time: now,
    season,
    usersCount: usersSnap.docs.length,
    activeCountriesCount: activeOwnerships.length,
    activeOwnerships,
    openRequests: openReqs,
    pendingWars,
    complaints: docs(complaintsSnap),
    countriesMap,
    centralBankBudget,
    botDisabled: await settings.isBotDisabled().catch(() => false),
  };
  return cacheData;
}

function dashboardKeyboard(data) {
  return {
    reply_markup: {
      inline_keyboard: [
        [
          cb(`📥 درخواست‌ها (${fmtNum(data.openRequests.length)})`, 'adbot:req:list', 'primary'),
          cb(`⚔️ مجوزهای جنگ (${fmtNum(data.pendingWars.length)})`, 'adbot:war:list', 'danger'),
        ],
        [
          cb(`⚖️ شکایات کاربران (${fmtNum(data.complaints.length)})`, 'adbot:cmp:list', 'danger'),
          cb('🛢️ تنظیم درصد نفت‌خیزی', 'adbot:oilrichness:list', 'primary'),
        ],
        [
          cb('🔬 تنظیم قیمت اکتشاف نفت', 'adbot:oilexplorecost:menu', 'primary'),
          cb('🏛️ هزینه تغییر پایتخت', 'adbot:capitalcost:list', 'primary'),
        ],
        [
          cb('💰 اعطای بودجه به کشور (بانک مرکزی)', 'adbot:budget:list', 'success'),
          cb('👑 نرخ و اعطای سکه شاهی', 'adbot:shahi:menu', 'success'),
        ],
        [
          cb('⚖️ انضباطی (جریمه، حذف، بن)', 'adbot:discipline:menu', 'danger'),
          cb('📨 پیام به بازیکن (انتخاب کشور)', 'adbot:dm:start', 'primary'),
        ],
        [
          cb('🎯 ماموریت‌های روزانه', 'adbot:missions:menu', 'primary'),
          cb('❄️ تنظیم و انجماد واریزها', 'adbot:payouts:menu', 'primary'),
        ],
        [
          cb('👥 فهرست بازیکنان فعال', 'adbot:users:list', 'primary'),
          cb(data.botDisabled ? '🟢 روشن کردن ربات اصلی' : '🔴 خاموش کردن ربات اصلی', data.botDisabled ? 'adbot:bot:toggle:enable' : 'adbot:bot:toggle:disable', data.botDisabled ? 'success' : 'danger'),
        ],
        [cb('⚡ بروزرسانی سریع داشبورد', 'adbot:dashboard:refresh', 'primary')],
      ],
    },
  };
}

async function renderAdminDashboard(ctx, isEdit = false, forceRefresh = false) {
  const data = await buildDashboardData(forceRefresh);
  const text = [
    '🛡️ <b>مرکز فرماندهی و داشبورد فوق‌العاده سریع ادمین</b>',
    '<b>WORLD WAR FIRE — Admin Operations</b>',
    '– – – – – – – – – –',
    `📅 سیزن فعال: <b>${data.season ? esc(data.season.name) : 'هیچ سیزنی فعال نیست'}</b>`,
    `👥 کل بازیکنان ثبت‌شده: <b>${fmtNum(data.usersCount)} نفر</b>`,
    `🌍 کشورهای دارای رهبر: <b>${fmtNum(data.activeCountriesCount)} کشور</b>`,
    `🏦 <b>موجودی در دسترس بانک مرکزی:</b> <b>${fmtNum(data.centralBankBudget || 0)}$</b>`,
    '– – – – – – – – – –',
    `📥 درخواست‌های در انتظار کشور: <b>${fmtNum(data.openRequests.length)} مورد</b>`,
    `⚔️ درخواست‌های مجوز جنگ: <b>${fmtNum(data.pendingWars.length)} مورد</b>`,
    `⚖️ شکایات در انتظار داوری: <b>${fmtNum(data.complaints.length)} مورد</b>`,
    `⚡ وضعیت ربات اصلی: <b>${data.botDisabled ? '🔴 خاموش' : '🟢 روشن'}</b>`,
    '',
    '👇 جهت مدیریت عملیات و ارسال پیام از دکمه‌های زیر استفاده کنید:',
  ].join('\n');

  const kb = dashboardKeyboard(data);
  if (isEdit && ctx.callbackQuery) {
    await ctx.editMessageText(text, { parse_mode: 'HTML', reply_markup: kb.reply_markup }).catch(() => {});
  } else {
    await ctx.reply(text, { parse_mode: 'HTML', ...kb });
  }
}

async function initAdminBot(mainTelegram) {
  if (mainTelegram) savedMainTelegram = mainTelegram;
  try {
    const token = await getAdminBotToken();
    if (!token) {
      if (adminBotInstance) {
        try { adminBotInstance.stop(); } catch (_) {}
        adminBotInstance = null;
      }
      return null;
    }

    if (adminBotInstance && currentBotToken === token) {
      return adminBotInstance;
    }

    if (adminBotInstance) {
      try { adminBotInstance.stop(); } catch (_) {}
    }

    const bot = new Telegraf(token, { handlerTimeout: 25000 });
    currentBotToken = token;
    const allowedAdminIds = new Set((config.adminIds || []).map((id) => String(id)));
    bot.use(async (ctx, next) => {
      if (ctx.callbackQuery) {
        ctx.answerCbQuery().catch(() => {});
      }
      if (!ctx.from || !allowedAdminIds.has(String(ctx.from.id))) {
        if (ctx.callbackQuery) await ctx.answerCbQuery('این ربات فقط برای مدیران مجاز است.', { show_alert: true }).catch(() => {});
        else if (ctx.message) await ctx.reply('⛔ دسترسی به ربات ادمین مجاز نیست.').catch(() => {});
        return;
      }
      return next();
    });

    // استارت و داشبورد اصلی
    bot.start(async (ctx) => {
      await renderAdminDashboard(ctx, false);
    });
    bot.command(['dashboard', 'admin', 'menu', 'panel'], async (ctx) => {
      await renderAdminDashboard(ctx, false);
    });
    bot.action(['adbot:dashboard', 'adbot:dashboard:refresh'], async (ctx) => {
      await renderAdminDashboard(ctx, true, true);
    });

    bot.action(/^adbot:bot:toggle:(enable|disable)$/, async (ctx) => {
      await ctx.answerCbQuery().catch(() => {});
      const enable = ctx.match[1] === 'enable';
      await settings.setBotDisabled(!enable, ctx.from.id);
      await ctx.reply(enable ? '🟢 ربات اصلی بازی روشن شد.' : '🔴 ربات اصلی بازی خاموش شد. ربات ادمین مستقل و فعال می‌ماند.');
      await renderAdminDashboard(ctx, false);
    });

    // ۱. فهرست درخواست‌های کشور
    bot.action('adbot:req:list', async (ctx) => {
      await ctx.answerCbQuery().catch(() => {});
      const reqs = await selection.listOpenRequests().catch(() => []);
      if (!reqs.length) {
        return ctx.editMessageText('📭 هیچ درخواست بازی برای انتخاب کشور وجود ندارد.', {
          parse_mode: 'HTML',
          reply_markup: Markup.inlineKeyboard([[Markup.button.callback('🔙 بازگشت به داشبورد', 'adbot:dashboard')]]).reply_markup,
        });
      }

      const rows = [];
      for (const r of reqs.slice(0, 10)) {
        const flag = r.country ? r.country.flag : '🏳️';
        const cname = r.country ? r.country.name : 'نامشخص';
        rows.push([
          Markup.button.callback(`✅ تأیید ${flag} ${cname}`, `adbot:req:ok:${r.id}`),
          Markup.button.callback('❌ رد', `adbot:req:no:${r.id}`),
        ]);
      }
      rows.push([Markup.button.callback('🔙 بازگشت به داشبورد', 'adbot:dashboard')]);

      const lines = [
        '📥 <b>درخواست‌های در انتظار تخصیص کشور</b>',
        '– – – – – – – – – –',
        ...reqs.slice(0, 10).map((r, i) => `${i + 1}. ${r.country?.flag || ''} <b>${esc(r.country?.name || '')}</b> توسط <b>${esc(r.displayName)}</b> (@${esc(r.username || '—')})`),
        '',
        'برای اقدام روی دکمه‌های زیر کلیک کنید:',
      ].join('\n');

      await ctx.editMessageText(lines, { parse_mode: 'HTML', reply_markup: Markup.inlineKeyboard(rows).reply_markup }).catch(() => {});
    });

    // تایید کشور
    bot.action(/^adbot:req:ok:(.+)$/, async (ctx) => {
      await ctx.answerCbQuery().catch(() => {});
      const reqId = ctx.match[1];
      try {
        const tg = savedMainTelegram || bot.telegram;
        const res = await actions.assignRequest(tg, reqId, ctx.from.id, 'admin_bot');
        await ctx.reply(`✅ کشور ${res.countryId} با موفقیت به بازیکن تخصیص داده شد و در کانال اعلام گردید.`);
        await renderAdminDashboard(ctx, false);
      } catch (err) {
        await ctx.reply(`⚠️ خطا در تخصیص کشور: ${err.message}`);
      }
    });

    // رد کشور
    bot.action(/^adbot:req:no:(.+)$/, async (ctx) => {
      await ctx.answerCbQuery().catch(() => {});
      const reqId = ctx.match[1];
      try {
        const tg = savedMainTelegram || bot.telegram;
        await actions.rejectRequest(tg, reqId, ctx.from.id, 'عدم موافقت مدیریت', 'admin_bot');
        await ctx.reply('❌ درخواست انتخاب کشور رد شد و به کاربر اطلاع داده شد.');
        await renderAdminDashboard(ctx, false);
      } catch (err) {
        await ctx.reply(`⚠️ خطا: ${err.message}`);
      }
    });

    // ۲. فهرست درخواست‌های مجوز جنگ
    bot.action('adbot:war:list', async (ctx) => {
      await ctx.answerCbQuery().catch(() => {});
      const season = await seasonService.getActiveSeason();
      const wars = season ? await warService.listWars(season.id, 'pending').catch(() => []) : [];

      if (!wars.length) {
        return ctx.editMessageText('🕊 در حال حاضر هیچ درخواست اعلان جنگی در انتظار تایید وجود ندارد.', {
          parse_mode: 'HTML',
          reply_markup: Markup.inlineKeyboard([[Markup.button.callback('🔙 بازگشت به داشبورد', 'adbot:dashboard')]]).reply_markup,
        });
      }

      const rows = [];
      for (const w of wars.slice(0, 8)) {
        rows.push([
          Markup.button.callback(`✅ صدور مجوز: ${w.attackerFlag} به ${w.defenderFlag}`, `adbot:war:appr:${w.id}`),
          Markup.button.callback(`❌ رد جنگ`, `adbot:war:rejc:${w.id}`),
        ]);
      }
      rows.push([Markup.button.callback('🔙 بازگشت به داشبورد', 'adbot:dashboard')]);

      const lines = [
        '⚔️ <b>درخواست‌های در انتظار مجوز جنگ</b>',
        '– – – – – – – – – –',
        ...wars.slice(0, 8).map((w, i) => `${i + 1}. متقاضی: <b>${w.attackerFlag} ${esc(w.attackerName)}</b>\n   🎯 هدف: <b>${w.defenderFlag} ${esc(w.defenderName)}</b>\n   📜 دلیل: «<i>${esc(w.reason)}</i>»`),
        '',
        'جهت تصمیم‌گیری دکمه مورد نظر را فشار دهید:',
      ].join('\n');

      await ctx.editMessageText(lines, { parse_mode: 'HTML', reply_markup: Markup.inlineKeyboard(rows).reply_markup }).catch(() => {});
    });

    // تایید مجوز جنگ از درون ربات اختصاصی ادمین
    bot.action(/^adbot:war:appr:(.+)$/, async (ctx) => {
      await ctx.answerCbQuery().catch(() => {});
      const warId = ctx.match[1];
      try {
        const war = await warService.approveWar(warId, ctx.from.id);
        const season = await seasonService.getActiveSeason();

        const attState = await gameService.getCountryState(war.attackerCountryId, season ? season.id : '1');
        await gameService.updateCountryState(war.attackerCountryId, season ? season.id : '1', {
          legitimacy: Math.min(100, (attState.legitimacy || 100) + 10),
        });

        const notifications = require('./notificationService');
        const channelText = [
          '⚔️ <b>اعلان جنگ رسمی و قانونی!</b>',
          '– – – – – – – – – –',
          `شورای عالی نظارت با درخواست اعلان جنگ کشور <b>${war.attackerFlag} ${war.attackerName}</b> علیه <b>${war.defenderFlag} ${war.defenderName}</b> موافقت کرد.`,
          '',
          `📜 دلیل احراز شده: «<i>${war.reason}</i>»`,
          '',
          '⚖️ این جنگ با مجوز رسمی آغاز شده و مشروعیت بین‌المللی دارد.',
          '⏳ مهلت پیوستن کشورها به جبهه‌ها: فقط ۲ دقیقه.',
          '',
          warService.formatWarFrontsText(war, [{ id: war.attackerCountryId, flag: war.attackerFlag, name: war.attackerName }, { id: war.defenderCountryId, flag: war.defenderFlag, name: war.defenderName }]),
        ].join('\n');
        const tg = savedMainTelegram || bot.telegram;
        await notifications.publishToChannel(tg, 'war_news', channelText, {
          reply_markup: { inline_keyboard: [[
            { text: '⚪ بی‌طرف', callback_data: `war:side:${war.id}:neutral` },
            { text: '🔴 تیم مهاجم', callback_data: `war:side:${war.id}:attacker` },
            { text: '🟢 تیم مدافع', callback_data: `war:side:${war.id}:defender` },
          ]] },
        }).catch(() => {});

        if (war.userId) {
          await notifications.safeSend(tg, war.userId, `✅ <b>مجوز جنگ صادر شد!</b>\nدرخواست اعلان جنگ شما علیه ${war.defenderFlag} ${war.defenderName} توسط مدیریت تایید و در کانال اعلام شد.`);
        }

        await ctx.reply(`✅ <b>مجوز جنگ تایید شد!</b>\nمهاجم: ${war.attackerFlag} ${war.attackerName}\nمدافع: ${war.defenderFlag} ${war.defenderName}`, { parse_mode: 'HTML' }).catch(() => {});
        await renderAdminDashboard(ctx, false);
      } catch (err) {
        await ctx.reply(`⚠️ خطا در تایید جنگ: ${err.message}`);
      }
    });

    // رد مجوز جنگ از ربات ادمین
    bot.action(/^adbot:war:rejc:(.+)$/, async (ctx) => {
      await ctx.answerCbQuery().catch(() => {});
      const warId = ctx.match[1];
      try {
        const war = await warService.rejectWar(warId, ctx.from.id, 'عدم کفایت دلایل و مستندات');
        const notifications = require('./notificationService');
        const tg = savedMainTelegram || bot.telegram;
        if (war.userId) {
          await notifications.safeSend(tg, war.userId, `❌ <b>درخواست جنگ رد شد</b>\nدرخواست اعلان جنگ شما علیه ${war.defenderFlag} ${war.defenderName} به دلیل عدم کفایت دلایل رد شد.`);
        }
        await ctx.reply(`❌ <b>درخواست جنگ رد شد.</b>\nمهاجم: ${war.attackerFlag} ${war.attackerName}`, { parse_mode: 'HTML' }).catch(() => {});
        await renderAdminDashboard(ctx, false);
      } catch (err) {
        await ctx.reply(`⚠️ خطا در رد جنگ: ${err.message}`);
      }
    });

    // پیام خصوصی فقط برای یک شناسه مشخص؛ هیچ قابلیت ارسال گروهی وجود ندارد.
    bot.action('adbot:dm:start', async (ctx) => {
      await ctx.answerCbQuery().catch(() => {});
      adminDmFlows.set(String(ctx.from.id), { step: 'target' });
      await ctx.reply('✉️ فقط یک مقصد انتخاب کنید: آیدی عددی یک بازیکن یا نام دقیق یک کشور (مثلاً ایران). برای لغو /cancel را بزنید.');
    });
    bot.command('cancel', async (ctx) => {
      const hadFlow = adminDmFlows.delete(String(ctx.from.id));
      await ctx.reply(hadFlow ? 'ارسال پیام خصوصی لغو شد.' : 'عملیات فعالی برای لغو وجود ندارد.');
    });
    bot.on('text', async (ctx, next) => {
      const flow = adminDmFlows.get(String(ctx.from.id));
      if (!flow) return next();
      const content = String(ctx.message.text || '').trim();
      if (!content) return ctx.reply('متن خالی است؛ لطفاً دوباره ارسال کنید یا /cancel بزنید.');
      if (flow.step === 'target') {
        let targetId = '';
        let targetLabel = content;
        if (/^\d{1,20}$/.test(content) && Number(content) > 0) {
          targetId = content;
          targetLabel = `بازیکن با آیدی ${content}`;
        } else {
          const exactName = content.toLocaleLowerCase('fa-IR');
          const countries = docs(await col('countries').get());
          const targetCountry = countries.find((c) => String(c.name || '').trim().toLocaleLowerCase('fa-IR') === exactName);
          if (!targetCountry) return ctx.reply('کشوری با این نام دقیق پیدا نشد. نام دقیق کشور یا آیدی عددی بازیکن را بفرستید؛ برای لغو /cancel را بزنید.');
          const season = await seasonService.getActiveSeason();
          const targetOwnership = season ? await ownership.getOwnerOfCountry(targetCountry.id, season.id) : null;
          if (!targetOwnership || targetOwnership.status !== 'active') return ctx.reply('این کشور در سیزن فعلی رهبر فعال ندارد؛ یک کشور دیگر یا آیدی بازیکن را وارد کنید.');
          targetId = String(targetOwnership.userId);
          targetLabel = `${targetCountry.flag || '🏳️'} ${targetCountry.name}`;
        }
        adminDmFlows.set(String(ctx.from.id), { step: 'message', targetId, targetLabel });
        return ctx.reply(`مقصد انتخاب‌شده: ${targetLabel} (آیدی ${targetId})\nحالا متن پیام را بنویسید. ارسال فقط به همین یک مقصد انجام می‌شود.`);
      }
      const targetId = flow.targetId;
      try {
        const tg = savedMainTelegram || bot.telegram;
        await tg.sendMessage(targetId, `📩 پیام مدیریت بازی:\n\n${content}`);
        adminDmFlows.delete(String(ctx.from.id));
        return ctx.reply(`✅ پیام خصوصی با موفقیت فقط برای ${flow.targetLabel || `شناسه ${targetId}`} ارسال شد.`);
      } catch (err) {
        adminDmFlows.delete(String(ctx.from.id));
        return ctx.reply(`⚠️ پیام ارسال نشد. ممکن است بازیکن هنوز ربات اصلی را شروع نکرده باشد. علت: ${err.description || err.message}`);
      }
    });

    // ۳. فهرست شکایات کاربران
    bot.action('adbot:cmp:list', async (ctx) => {
      await ctx.answerCbQuery().catch(() => {});
      const q = await col('complaints').where('status', '==', 'pending').limit(10).get();
      const list = docs(q);

      if (!list.length) {
        return ctx.editMessageText('⚖️ هیچ شکایت بررسی‌نشده‌ای وجود ندارد.', {
          parse_mode: 'HTML',
          reply_markup: Markup.inlineKeyboard([[Markup.button.callback('🔙 بازگشت به داشبورد', 'adbot:dashboard')]]).reply_markup,
        });
      }

      const rows = list.map((c) => [
        Markup.button.callback(`⚖️ ${c.userDisplayName} علیه ${c.againstCountry}`.slice(0, 40), `adbot:cmp:view:${c.id}`),
      ]);
      rows.push([Markup.button.callback('🔙 بازگشت به داشبورد', 'adbot:dashboard')]);

      await ctx.editMessageText(`⚖️ <b>فهرست آخرین شکایات کاربران</b> (${list.length}):`, {
        parse_mode: 'HTML',
        reply_markup: Markup.inlineKeyboard(rows).reply_markup,
      }).catch(() => {});
    });

    bot.action(/^adbot:cmp:view:(.+)$/, async (ctx) => {
      await ctx.answerCbQuery().catch(() => {});
      const id = ctx.match[1];
      const snap = await col('complaints').doc(id).get();
      if (!snap.exists) return ctx.reply('شکایت یافت نشد.');
      const c = { id: snap.id, ...snap.data() };

      const text = [
        `⚖️ <b>بررسی شکایت #${c.id.slice(-6)}</b>`,
        '– – – – – – – – – –',
        `👤 شاکی: ${esc(c.userDisplayName)} (آیدی: <code>${c.userId}</code>)`,
        `🎯 طرف شکایت: <b>${esc(c.againstCountry)}</b>`,
        '',
        `📝 شرح شکایت:\n« ${esc(c.text)} »`,
      ].join('\n');

      const kb = Markup.inlineKeyboard([
        [Markup.button.callback('✅ تایید شدن', `cmp:approve:${c.id}`), Markup.button.callback('❌ رد شد', `cmp:reject:${c.id}`)],
        [Markup.button.callback('🔙 بازگشت به شکایات', 'adbot:cmp:list')],
      ]);

      if (c.photoFileId) {
        await ctx.replyWithPhoto(c.photoFileId, { caption: text, parse_mode: 'HTML', ...kb });
      } else {
        await ctx.editMessageText(text, { parse_mode: 'HTML', reply_markup: kb.reply_markup }).catch(() => ctx.reply(text, { parse_mode: 'HTML', ...kb }));
      }
    });

    bot.action(/^cmp:(approve|reject):(.+)$/, async (ctx) => {
      await ctx.answerCbQuery().catch(() => {});
      const decision = ctx.match[1] === 'approve' ? 'approved' : 'rejected';
      const complaintId = ctx.match[2];
      const ref = col('complaints').doc(complaintId);
      const current = await ref.get();
      if (!current.exists) return ctx.reply('شکایت یافت نشد.');
      const c = { id: current.id, ...current.data() };
      if (c.status !== 'pending') return ctx.reply(`این شکایت قبلاً بررسی شده است (وضعیت: ${c.status}).`);
      await ref.set({ status: decision, reviewedAt: new Date(), reviewedBy: ctx.from.id }, { merge: true });
      const notifications = require('./notificationService');
      const tg = savedMainTelegram || bot.telegram;
      const privateText = decision === 'approved'
        ? `✅ <b>پاسخ به شکایت شما (کد: ${c.id})</b>\nشکایت شما توسط مدیریت تایید شدن و مورد پیگیری قرار گرفت.`
        : `❌ <b>پاسخ به شکایت شما (کد: ${c.id})</b>\nشکایت شما توسط مدیریت رد شد.`;
      const sent = await notifications.safeSend(tg, c.userId, privateText);
      await ctx.reply(`${decision === 'approved' ? '✅ شکایت تایید شد.' : '❌ شکایت رد شد.'}\n${sent ? 'نتیجه به پیوی کاربر ارسال شد.' : 'ارسال به پیوی ممکن نشد؛ ممکن است بازیکن ربات را استارت نکرده باشد.'}`);
      await renderAdminDashboard(ctx, false);
    });

    bot.action(/^adbot:cmp:close:(.+)$/, async (ctx) => {
      await ctx.answerCbQuery().catch(() => {});
      const ref = col('complaints').doc(ctx.match[1]);
      const current = await ref.get();
      if (!current.exists) return ctx.reply('شکایت یافت نشد.');
      const c = current.data();
      if (c.status === 'pending') {
        await ref.set({ status: 'rejected', reviewedAt: new Date(), reviewedBy: ctx.from.id }, { merge: true });
        const notifications = require('./notificationService');
        await notifications.safeSend(savedMainTelegram || bot.telegram, c.userId, `❌ شکایت شما با کد ${ctx.match[1]} توسط مدیریت رد شد.`);
      }
      await ctx.reply('شکایت خاتمه یافت.');
      await renderAdminDashboard(ctx, false);
    });

    // ۴. اعطای بودجه به کشور از محل ذخایر بانک مرکزی (با ارسال رقم و رتبه توسط ادمین)
    bot.action('adbot:budget:list', async (ctx) => {
      await ctx.answerCbQuery().catch(() => {});
      const season = await seasonService.getActiveSeason();
      if (!season) return ctx.reply('سیزنی فعال نیست.');

      const activeOwnerships = await ownership.listActive(season.id).catch(() => []);
      if (!activeOwnerships.length) {
        return ctx.editMessageText('🌍 هیچ کشور فعالی برای اعطای بودجه در سیزن وجود ندارد.', {
          parse_mode: 'HTML',
          reply_markup: { inline_keyboard: [[cb('🔙 بازگشت به داشبورد', 'adbot:dashboard', 'danger')]] },
        });
      }

      const cbBudget = await centralBankService.getCentralBankBudget();
      const rows = [];
      for (const o of activeOwnerships) {
        const c = await countryService.get(o.countryId);
        if (c) {
          rows.push([cb(`💰 اعطای بودجه به ${c.flag} ${c.name}`, `adbot:bg:prompt:${c.id}`, 'success')]);
        }
      }
      rows.push([cb('🔙 بازگشت به داشبورد', 'adbot:dashboard', 'danger')]);

      const text = [
        '💰 <b>اعطای بودجه به کشور (از محل بانک مرکزی)</b>',
        '– – – – – – – – – –',
        `🏦 <b>موجودی در دسترس بانک مرکزی:</b> <b>${fmtNum(cbBudget)}$</b>`,
        '<i>(ادمین تنها می‌تواند تا سقف موجودی تجمیع‌شده در بانک مرکزی کمک اعطا کند)</i>',
        '',
        'کشور مقصد را انتخاب کنید تا مبلغ دلخواه و رتبه/علت اعطا را ارسال نمایید:',
      ].join('\n');

      await ctx.editMessageText(text, { parse_mode: 'HTML', reply_markup: { inline_keyboard: rows } }).catch(() => {});
    });

    bot.action(/^adbot:bg:prompt:(.+)$/, async (ctx) => {
      await ctx.answerCbQuery().catch(() => {});
      const countryId = ctx.match[1];
      const country = await countryService.get(countryId);
      if (!country) return ctx.reply('کشور یافت نشد.');

      const cbBudget = await centralBankService.getCentralBankBudget();
      adminBudgetFlows.set(String(ctx.from.id), {
        countryId,
        countryName: country.name,
        flag: country.flag || '🏳️',
      });

      const text = [
        `✍️ <b>اعطای بودجه به ${country.flag} ${esc(country.name)}</b>`,
        '– – – – – – – – – –',
        `🏦 موجودی در دسترس بانک مرکزی: <b>${fmtNum(cbBudget)}$</b>`,
        '',
        'لطفاً <b>مبلغ عددی (دلار)</b> و <b>رتبه یا علت اعطا</b> را در یک خط بفرستید:',
        '<i>مثال: 50000000 رتبه اول لیدربرد جهانی</i>',
        '<i>یا فقط رقم: 85000000</i>',
        '',
        'برای انصراف عبارت /cancel را ارسال کنید.',
      ].join('\n');

      await ctx.reply(text, { parse_mode: 'HTML' });
    });

    // ۵. تنظیم درصد نفت‌خیزی کشورها توسط ادمین
    bot.action('adbot:oilrichness:list', async (ctx) => {
      await ctx.answerCbQuery().catch(() => {});
      const countries = await countryService.list();
      const season = await seasonService.getActiveSeason();
      const activeOwnerships = season ? await ownership.listActive(season.id).catch(() => []) : [];
      const activeMap = new Set(activeOwnerships.map((o) => String(o.countryId)));

      const sorted = [...countries].sort((a, b) => {
        const aActive = activeMap.has(String(a.id)) ? 1 : 0;
        const bActive = activeMap.has(String(b.id)) ? 1 : 0;
        return bActive - aActive || a.name.localeCompare(b.name, 'fa');
      });

      const rows = [];
      for (const c of sorted.slice(0, 20)) {
        const activeMarker = activeMap.has(String(c.id)) ? '👑 ' : '';
        const richness = c.oilRichness !== undefined ? c.oilRichness : 50;
        rows.push([
          Markup.button.callback(`${activeMarker}${c.flag || '🏳️'} ${c.name} (${richness}%)`, `adbot:oilr:view:${c.id}`),
        ]);
      }
      rows.push([Markup.button.callback('🔙 بازگشت به داشبورد', 'adbot:dashboard')]);

      const text = [
        '🛢️ <b>تنظیم درصد نفت‌خیزی کشورها توسط ادمین</b>',
        '– – – – – – – – – –',
        'احتمال موفقیت اکتشاف ۴۵۰ میلیونی بر اساس همین درصد محاسبه می‌شود.',
        'کشور مورد نظر را انتخاب کنید:',
      ].join('\n');

      await ctx.editMessageText(text, {
        parse_mode: 'HTML',
        reply_markup: Markup.inlineKeyboard(rows).reply_markup,
      }).catch(() => {});
    });

    bot.action(/^adbot:oilr:view:(.+)$/, async (ctx) => {
      await ctx.answerCbQuery().catch(() => {});
      const countryId = ctx.match[1];
      const country = await countryService.get(countryId);
      if (!country) return ctx.reply('کشور یافت نشد.');

      const current = country.oilRichness !== undefined ? country.oilRichness : 50;
      const text = [
        `🛢️ <b>تعیین درصد نفت‌خیزی ${country.flag} ${esc(country.name)}</b>`,
        '– – – – – – – – – –',
        `درصد ثبت‌شده فعلی: <b>${current}٪</b>`,
        '',
        '👇 درصد جدید را انتخاب کنید:',
      ].join('\n');

      const rows = [
        [Markup.button.callback('۱۰٪', `adbot:oilr:set:${country.id}:10`), Markup.button.callback('۲۵٪', `adbot:oilr:set:${country.id}:25`), Markup.button.callback('۴۰٪', `adbot:oilr:set:${country.id}:40`)],
        [Markup.button.callback('۵۵٪', `adbot:oilr:set:${country.id}:55`), Markup.button.callback('۷۰٪', `adbot:oilr:set:${country.id}:70`), Markup.button.callback('۸۵٪', `adbot:oilr:set:${country.id}:85`)],
        [Markup.button.callback('۹۵٪', `adbot:oilr:set:${country.id}:95`), Markup.button.callback('۱۰۰٪ (تضمینی)', `adbot:oilr:set:${country.id}:100`)],
        [Markup.button.callback('🔙 فهرست کشورها', 'adbot:oilrichness:list'), Markup.button.callback('🏠 داشبورد', 'adbot:dashboard')],
      ];

      await ctx.editMessageText(text, {
        parse_mode: 'HTML',
        reply_markup: Markup.inlineKeyboard(rows).reply_markup,
      }).catch(() => {});
    });

    bot.action(/^adbot:oilr:set:(.+):(\d+)$/, async (ctx) => {
      await ctx.answerCbQuery().catch(() => {});
      const [countryId, percentStr] = [ctx.match[1], ctx.match[2]];
      const percent = Number(percentStr);
      const country = await countryService.get(countryId);
      if (!country) return ctx.reply('کشور یافت نشد.');

      await col('countries').doc(countryId).set({ oilRichness: percent }, { merge: true });
      const season = await seasonService.getActiveSeason();
      if (season) {
        await gameService.updateCountryState(countryId, season.id, { oilRichness: percent }).catch(() => {});
      }

      await ctx.reply(`✅ <b>درصد نفت‌خیزی کشور ${country.flag} ${country.name} با موفقیت به ${percent}٪ تنظیم شد.</b>`, { parse_mode: 'HTML' });
      await renderAdminDashboard(ctx, false);
    });

    // ۶. تنظیم هزینه تغییر پایتخت توسط ادمین
    bot.action('adbot:capitalcost:list', async (ctx) => {
      await ctx.answerCbQuery().catch(() => {});
      const currentCost = await settings.get('capitalChangeCost', 250000000);
      const text = [
        '🏛️ <b>تنظیم هزینه تغییر پایتخت استان‌ها توسط ادمین</b>',
        '– – – – – – – – – –',
        `هزینه فعلی انتقال پایتخت: <b>${fmtNum(currentCost)}$</b>`,
        '',
        '👇 برای تغییر هزینه یکی از مقادیر زیر را انتخاب کنید:',
      ].join('\n');

      const rows = [
        [Markup.button.callback('۵۰ میلیون $', 'adbot:capcost:set:50000000'), Markup.button.callback('۱۰۰ میلیون $', 'adbot:capcost:set:100000000')],
        [Markup.button.callback('۲۵۰ میلیون $', 'adbot:capcost:set:250000000'), Markup.button.callback('۵۰۰ میلیون $', 'adbot:capcost:set:500000000')],
        [Markup.button.callback('۱ میلیارد $', 'adbot:capcost:set:1000000000'), Markup.button.callback('۲ میلیارد $', 'adbot:capcost:set:2000000000')],
        [Markup.button.callback('🔙 بازگشت به داشبورد', 'adbot:dashboard')],
      ];

      await ctx.editMessageText(text, {
        parse_mode: 'HTML',
        reply_markup: Markup.inlineKeyboard(rows).reply_markup,
      }).catch(() => {});
    });

    bot.action(/^adbot:capcost:set:(\d+)$/, async (ctx) => {
      await ctx.answerCbQuery().catch(() => {});
      const newCost = Number(ctx.match[1]);
      await settings.set('capitalChangeCost', newCost);
      await ctx.reply(`✅ <b>هزینه تغییر پایتخت با موفقیت به ${fmtNum(newCost)}$ تنظیم گردید.</b>`, { parse_mode: 'HTML' });
      await renderAdminDashboard(ctx, false);
    });

    // تنظیم قیمت اکتشاف نفت
    bot.action('adbot:oilexplorecost:menu', async (ctx) => {
      await ctx.answerCbQuery().catch(() => {});
      const currentCost = await settings.get('oilExplorationCost', 450000000);
      const text = [
        '🔬 <b>تنظیم قیمت اعزام تیم اکتشاف نفت</b>',
        '– – – – – – – – – –',
        `هزینه فعلی اعزام تیم اکتشاف: <b>${fmtNum(currentCost)}$</b>`,
        '',
        '👇 گزینه مورد نظر را انتخاب یا عدد دلخواه وارد کنید:',
      ].join('\n');

      const rows = [
        [Markup.button.callback('۱۰۰ میلیون $', 'adbot:oilexplore:set:100000000'), Markup.button.callback('۲۵۰ میلیون $', 'adbot:oilexplore:set:250000000')],
        [Markup.button.callback('۴۵۰ میلیون $ (پیش‌فرض)', 'adbot:oilexplore:set:450000000'), Markup.button.callback('۷۵۰ میلیون $', 'adbot:oilexplore:set:750000000')],
        [Markup.button.callback('۱ میلیارد $', 'adbot:oilexplore:set:1000000000'), Markup.button.callback('✍️ ارسال عدد دلخواه', 'adbot:oilexplore:prompt')],
        [Markup.button.callback('🔙 بازگشت به داشبورد', 'adbot:dashboard')],
      ];

      await ctx.editMessageText(text, { parse_mode: 'HTML', reply_markup: Markup.inlineKeyboard(rows).reply_markup }).catch(() => {});
    });

    bot.action('adbot:oilexplore:prompt', async (ctx) => {
      await ctx.answerCbQuery().catch(() => {});
      adminExplorationCostFlows.set(String(ctx.from.id), true);
      await ctx.reply('✍️ لطفاً مبلغ عددی جدید اعزام تیم اکتشاف نفت (به دلار) را ارسال فرمایید:\n(جهت لغو: /cancel)');
    });

    bot.action(/^adbot:oilexplore:set:(\d+)$/, async (ctx) => {
      await ctx.answerCbQuery().catch(() => {});
      const newCost = Number(ctx.match[1]);
      await settings.set('oilExplorationCost', newCost);
      await ctx.reply(`✅ <b>هزینه اعزام تیم اکتشاف نفت با موفقیت به ${fmtNum(newCost)}$ تنظیم شد.</b>`, { parse_mode: 'HTML' });
      await renderAdminDashboard(ctx, false);
    });

    // نرخ و اعطای سکه شاهی به صورت دلخواه
    bot.action('adbot:shahi:menu', async (ctx) => {
      await ctx.answerCbQuery().catch(() => {});
      const season = await seasonService.getActiveSeason();
      if (!season) return ctx.reply('سیزنی فعال نیست.');
      const activeOwnerships = await ownership.listActive(season.id).catch(() => []);
      if (!activeOwnerships.length) return ctx.reply('هیچ کشور فعالی وجود ندارد.');
      const rows = [];
      for (const o of activeOwnerships) {
        const c = await countryService.get(o.countryId);
        if (c) rows.push([cb(`👑 اعطای سکه شاهی به ${c.flag} ${c.name}`, `adbot:shahi:prompt:${c.id}`, 'success')]);
      }
      rows.push([cb('🔙 بازگشت به داشبورد', 'adbot:dashboard', 'danger')]);
      await ctx.editMessageText('👑 <b>اعطای سفارشی سکه شاهی</b>\nکشور مورد نظر را انتخاب کنید:', {
        parse_mode: 'HTML',
        reply_markup: { inline_keyboard: rows },
      }).catch(() => {});
    });

    bot.action(/^adbot:shahi:prompt:(.+)$/, async (ctx) => {
      await ctx.answerCbQuery().catch(() => {});
      const countryId = ctx.match[1];
      const country = await countryService.get(countryId);
      adminShahiFlows.set(String(ctx.from.id), { countryId, countryName: country?.name, flag: country?.flag || '🏳️' });
      await ctx.reply([
        `👑 <b>اعطای سکه شاهی و پاداش به ${country?.flag} ${country?.name}</b>`,
        '– – – – – – – – – –',
        'لطفاً <b>تعداد سکه شاهی</b>، <b>مبلغ دلار (اختیاری)</b> و <b>رتبه/عنوان (اختیاری)</b> را ارسال کنید:',
        '<i>مثال: 10 50000000 پاداش ویژه عملکرد عالی</i>',
        '<i>یا فقط تعداد سکه: 5</i>',
        '',
        'جهت لغو: /cancel',
      ].join('\n'), { parse_mode: 'HTML' });
    });

    // منوی امور انضباطی بازیکنان (جریمه، خلع ید، بن از سیزن)
    bot.action('adbot:discipline:menu', async (ctx) => {
      await ctx.answerCbQuery().catch(() => {});
      const text = [
        '⚖️ <b>مرکز رسیدگی به تخلفات و امور انضباطی بازیکنان</b>',
        '– – – – – – – – – –',
        'از این بخش می‌توانید متخلفین را جریمه نقدی نمایید، مالکیت کشور را از آن‌ها سلب کنید، یا آن‌ها را از سیزن جاری محروم سازید.',
        '',
        'اقدام مورد نظر را انتخاب نمایید:',
      ].join('\n');

      const rows = [
        [Markup.button.callback('⚖️ جریمه نقدی یا کسر سکه بازیکن', 'adbot:disc:fine:list')],
        [Markup.button.callback('🚫 خلع ید و حذف مالکیت از کشور', 'adbot:disc:revoke:list')],
        [Markup.button.callback('🔨 محرومیت (بن) بازیکن از سیزن جاری', 'adbot:disc:ban:list')],
        [Markup.button.callback('🔄 ریست کامل دارایی‌های بازیکن', 'adbot:disc:reset:list')],
        [Markup.button.callback('🔙 بازگشت به داشبورد', 'adbot:dashboard')],
      ];

      await ctx.editMessageText(text, { parse_mode: 'HTML', reply_markup: Markup.inlineKeyboard(rows).reply_markup }).catch(() => {});
    });

    bot.action('adbot:disc:fine:list', async (ctx) => {
      await ctx.answerCbQuery().catch(() => {});
      const season = await seasonService.getActiveSeason();
      if (!season) return ctx.reply('سیزنی فعال نیست.');
      const activeOwnerships = await ownership.listActive(season.id).catch(() => []);
      const rows = [];
      for (const o of activeOwnerships) {
        const c = await countryService.get(o.countryId);
        if (c) rows.push([Markup.button.callback(`⚖️ جریمه کشور: ${c.flag} ${c.name}`, `adbot:disc:fine:prompt:${c.id}`)]);
      }
      rows.push([Markup.button.callback('🔙 بازگشت به منوی انضباطی', 'adbot:discipline:menu')]);
      await ctx.editMessageText('کشور مورد نظر برای جریمه نقدی/سکه را انتخاب کنید:', {
        reply_markup: Markup.inlineKeyboard(rows).reply_markup,
      }).catch(() => {});
    });

    bot.action(/^adbot:disc:fine:prompt:(.+)$/, async (ctx) => {
      await ctx.answerCbQuery().catch(() => {});
      const countryId = ctx.match[1];
      const country = await countryService.get(countryId);
      adminPenaltyFlows.set(String(ctx.from.id), { countryId, countryName: country?.name, flag: country?.flag || '🏳️' });
      await ctx.reply([
        `⚖️ <b>جریمه کشور ${country?.flag} ${country?.name}</b>`,
        '– – – – – – – – – –',
        'لطفاً <b>مبلغ جریمه دلاری</b>، <b>جریمه سکه شاهی</b> و <b>دلیل جریمه</b> را با فاصله ارسال نمایید:',
        '<i>مثال: 50000000 2 نقض آتش‌بس بین‌المللی</i>',
        '<i>یا فقط مبلغ دلاری: 25000000 تخلف مرزی</i>',
        '',
        'جهت لغو: /cancel',
      ].join('\n'), { parse_mode: 'HTML' });
    });

    bot.action('adbot:disc:revoke:list', async (ctx) => {
      await ctx.answerCbQuery().catch(() => {});
      const season = await seasonService.getActiveSeason();
      if (!season) return ctx.reply('سیزنی فعال نیست.');
      const activeOwnerships = await ownership.listActive(season.id).catch(() => []);
      const rows = [];
      for (const o of activeOwnerships) {
        const c = await countryService.get(o.countryId);
        if (c) rows.push([Markup.button.callback(`🚫 حذف مالکیت: ${c.flag} ${c.name}`, `adbot:disc:revoke:confirm:${c.id}`)]);
      }
      rows.push([Markup.button.callback('🔙 بازگشت به منوی انضباطی', 'adbot:discipline:menu')]);
      await ctx.editMessageText('کشوری که می‌خواهید مالکیت آن لغو و آزاد شود را انتخاب کنید:', {
        reply_markup: Markup.inlineKeyboard(rows).reply_markup,
      }).catch(() => {});
    });

    bot.action(/^adbot:disc:revoke:confirm:(.+)$/, async (ctx) => {
      await ctx.answerCbQuery().catch(() => {});
      const countryId = ctx.match[1];
      const country = await countryService.get(countryId);
      const text = `⚠️ آیا مطمئنید می‌خواهید مالکیت کشور ${country?.flag} ${country?.name} را از بازیکن فعلی لغو کرده و کشور را آزاد نمایید؟`;
      const kb = Markup.inlineKeyboard([
        [Markup.button.callback('✅ بله، خلع ید و آزاد شود', `adbot:disc:revoke:do:${countryId}`)],
        [Markup.button.callback('🔙 انصراف', 'adbot:disc:revoke:list')],
      ]);
      await ctx.editMessageText(text, { reply_markup: kb.reply_markup }).catch(() => {});
    });

    bot.action(/^adbot:disc:revoke:do:(.+)$/, async (ctx) => {
      await ctx.answerCbQuery().catch(() => {});
      const countryId = ctx.match[1];
      try {
        const res = await actions.removeCountryOwnership(savedMainTelegram || bot.telegram, countryId, 'سلب مالکیت توسط مدیریت', ctx.from.id);
        await ctx.reply(`✅ <b>مالکیت کشور ${res.country?.flag} ${res.country?.name} با موفقیت لغو شد و کشور آزاد گردید.</b>`, { parse_mode: 'HTML' });
        await renderAdminDashboard(ctx, false);
      } catch (e) {
        await ctx.reply(`⚠️ خطا: ${e.message}`);
      }
    });

    bot.action('adbot:disc:ban:list', async (ctx) => {
      await ctx.answerCbQuery().catch(() => {});
      const season = await seasonService.getActiveSeason();
      if (!season) return ctx.reply('سیزنی فعال نیست.');
      const activeOwnerships = await ownership.listActive(season.id).catch(() => []);
      const rows = [];
      for (const o of activeOwnerships) {
        const c = await countryService.get(o.countryId);
        if (c) rows.push([Markup.button.callback(`🔨 بن از سیزن: ${c.flag} ${c.name}`, `adbot:disc:ban:prompt:${c.id}`)]);
      }
      rows.push([Markup.button.callback('🔙 بازگشت به منوی انضباطی', 'adbot:discipline:menu')]);
      await ctx.editMessageText('کشور بازیکنی که می‌خواهید از این سیزن بن شود را انتخاب کنید:', {
        reply_markup: Markup.inlineKeyboard(rows).reply_markup,
      }).catch(() => {});
    });

    bot.action(/^adbot:disc:ban:prompt:(.+)$/, async (ctx) => {
      await ctx.answerCbQuery().catch(() => {});
      const countryId = ctx.match[1];
      const country = await countryService.get(countryId);
      adminSeasonBanFlows.set(String(ctx.from.id), { countryId, countryName: country?.name, flag: country?.flag || '🏳️' });
      await ctx.reply([
        `🔨 <b>محرومیت (بن) از سیزن: کشور ${country?.flag} ${country?.name}</b>`,
        '– – – – – – – – – –',
        'لطفاً <b>دلیل بن شدن بازیکن از این سیزن</b> را ارسال نمایید:',
        '<i>(جهت لغو: /cancel)</i>',
      ].join('\n'), { parse_mode: 'HTML' });
    });

    // ۷. مشاهده بازیکنان فعال
    bot.action('adbot:users:list', async (ctx) => {
      await ctx.answerCbQuery().catch(() => {});
      const season = await seasonService.getActiveSeason();
      const activeOwnerships = season ? await ownership.listActive(season.id).catch(() => []) : [];
      const lines = [
        '👥 <b>فهرست بازیکنان فعال بازی</b>',
        '– – – – – – – – – –',
      ];

      for (const o of activeOwnerships.slice(0, 15)) {
        const c = await countryService.get(o.countryId);
        const u = await userService.getById(o.userId);
        lines.push(`• <b>${c?.flag || '🏳️'} ${esc(c?.name || '—')}</b> | رهبر: ${esc(u?.displayName || '—')} (<code>${o.userId}</code>)`);
      }

      if (!activeOwnerships.length) {
        lines.push('هنوز بازیکنی دارای کشور فعال در این سیزن نیست.');
      }

      await ctx.editMessageText(lines.join('\n'), {
        parse_mode: 'HTML',
        reply_markup: Markup.inlineKeyboard([[Markup.button.callback('🔙 بازگشت به داشبورد', 'adbot:dashboard')]]).reply_markup,
      }).catch(() => {});
    });

    // ۸. ارسال پیام به بازیکن از طریق انتخاب کشور (Country Selection Dropdown)
    bot.action('adbot:dm:start', async (ctx) => {
      await ctx.answerCbQuery().catch(() => {});
      const season = await seasonService.getActiveSeason();
      if (!season) return ctx.reply('سیزنی فعال نیست.');

      const activeOwnerships = await ownership.listActive(season.id).catch(() => []);
      if (!activeOwnerships.length) {
        return ctx.editMessageText('🌍 هیچ کشوری با بازیکن فعال در این سیزن برای ارسال پیام یافت نشد.', {
          parse_mode: 'HTML',
          reply_markup: Markup.inlineKeyboard([[Markup.button.callback('🔙 بازگشت به داشبورد', 'adbot:dashboard')]]).reply_markup,
        });
      }

      const rows = [];
      for (const o of activeOwnerships) {
        const c = await countryService.get(o.countryId);
        if (c) {
          rows.push([Markup.button.callback(`✉️ پیام به ${c.flag || '🏳️'} ${c.name}`, `adbot:dm:country:${c.id}`)]);
        }
      }
      rows.push([Markup.button.callback('🔙 بازگشت به داشبورد', 'adbot:dashboard')]);

      const text = [
        '📨 <b>ارسال پیام اختصاصی ادمین به بازیکن (انتخاب کشور)</b>',
        '– – – – – – – – – –',
        'کشور مقصد را انتخاب کنید تا پیام مستقیماً به پیوی تلگرام بازیکن ارسال شود:',
      ].join('\n');

      await ctx.editMessageText(text, {
        parse_mode: 'HTML',
        reply_markup: Markup.inlineKeyboard(rows).reply_markup,
      }).catch(() => {});
    });

    bot.action(/^adbot:dm:country:(.+)$/, async (ctx) => {
      await ctx.answerCbQuery().catch(() => {});
      const countryId = ctx.match[1];
      const season = await seasonService.getActiveSeason();
      if (!season) return ctx.reply('سیزنی فعال نیست.');

      const [country, owner] = await Promise.all([
        countryService.get(countryId),
        ownership.getOwnerOfCountry(countryId, season.id),
      ]);

      if (!country || !owner) {
        return ctx.reply('این کشور یا بازیکن فعال آن یافت نشد.');
      }

      adminDmFlows.set(String(ctx.from.id), {
        countryId,
        countryName: country.name,
        flag: country.flag || '🏳️',
        userId: owner.userId,
      });

      const text = [
        `✍️ <b>آماده ارسال پیام به رهبر ${country.flag} ${esc(country.name)}</b>`,
        '– – – – – – – – – –',
        `👤 شناسه بازیکن: <code>${owner.userId}</code>`,
        '',
        'لطفاً متن پیامی که می‌خواهید برای این بازیکن ارسال شود را بنویسید و بفرستید:',
        '<i>(جهت انصراف عبارت /cancel را بفرستید)</i>',
      ].join('\n');

      await ctx.reply(text, { parse_mode: 'HTML' });
    });

    // ۹. مدیریت نرخ تبدیل و اعطای سکه شاهی (واحد ارزی غیر بازی) و قیمت تومانی VIP
    bot.action('adbot:shahi:menu', async (ctx) => {
      await ctx.answerCbQuery().catch(() => {});
      const rate = await gameService.getShahiExchangeRate();
      const realPriceToman = await settings.get('shahi_coin_real_price_toman', 50000);

      // بررسی تعداد فیش‌های منتظر تایید
      const pendingOrdersSnap = await col('shahi_orders').where('status', '==', 'pending_admin').get().catch(() => ({ docs: [] }));
      const pendingCount = pendingOrdersSnap.docs ? pendingOrdersSnap.docs.length : 0;

      const text = [
        '👑 <b>مدیریت ارزی سکه شاهی (VIP و درون‌بازی)</b>',
        '– – – – – – – – – –',
        `💰 <b>قیمت خرید واقعی هر ۱ سکه (تومان):</b> <b>${fmtNum(realPriceToman)} تومان</b>`,
        `💵 <b>نرخ تبدیل هر سکه به دلار بازی:</b> <b>${fmtNum(rate)}$</b>`,
        '',
        `🧾 فیش‌های در انتظار بررسی: <b>${fmtNum(pendingCount)} سفارش</b>`,
        '– – – – – – – – – –',
        '👇 جهت تنظیم قیمت، اعطا یا بررسی فیش‌های واریزی انتخاب کنید:',
      ].join('\n');

      const rows = [
        [
          Markup.button.callback('💳 بررسی فیش‌های VIP (' + pendingCount + ')', 'adbot:shahi:orders'),
        ],
        [
          Markup.button.callback('💵 قیمت: ۲۰ هزار ت', 'adbot:shahi:toman:20000'),
          Markup.button.callback('💵 قیمت: ۵۰ هزار ت', 'adbot:shahi:toman:50000'),
        ],
        [
          Markup.button.callback('💵 ۱۰۰ هزار ت', 'adbot:shahi:toman:100000'),
          Markup.button.callback('💵 ۲۰۰ هزار ت', 'adbot:shahi:toman:200000'),
          Markup.button.callback('✏️ نرخ تومانی دلخواه', 'adbot:shahi:toman:custom'),
        ],
        [
          Markup.button.callback('تبدیل به ۵M $', 'adbot:shahi:rate:set:5000000'),
          Markup.button.callback('تبدیل به ۱۰M $', 'adbot:shahi:rate:set:10000000'),
          Markup.button.callback('تبدیل به ۲۵M $', 'adbot:shahi:rate:set:25000000'),
        ],
        [
          Markup.button.callback('🎁 اعطای مستقیم سکه شاهی به کشور', 'adbot:shahi:grant:list'),
        ],
        [Markup.button.callback('🔙 بازگشت به داشبورد', 'adbot:dashboard')],
      ];

      await ctx.editMessageText(text, {
        parse_mode: 'HTML',
        reply_markup: Markup.inlineKeyboard(rows).reply_markup,
      }).catch(() => {});
    });

    bot.action(/^adbot:shahi:toman:(\d+)$/, async (ctx) => {
      await ctx.answerCbQuery().catch(() => {});
      const newPrice = Number(ctx.match[1]);
      await settings.set('shahi_coin_real_price_toman', newPrice);
      await ctx.reply(`✅ <b>قیمت خرید واقعی هر سکه شاهی به ${fmtNum(newPrice)} تومان تنظیم گردید.</b>`, { parse_mode: 'HTML' });
      await renderAdminDashboard(ctx, false);
    });

    bot.action('adbot:shahi:toman:custom', async (ctx) => {
      await ctx.answerCbQuery().catch(() => {});
      await userService.setFlow(ctx.from.id, 'adbot:shahi:set_custom_toman');
      await ctx.reply('✍️ لطفاً <b>قیمت جدید هر ۱ عدد سکه شاهی به تومان</b> را ارسال فرمایید:\n(مثال: 65000 یا 80000)\nجهت انصراف: /cancel', {
        parse_mode: 'HTML',
      });
    });

    // مدیریت فیش‌های واریزی سکه شاهی
    bot.action('adbot:shahi:orders', async (ctx) => {
      await ctx.answerCbQuery().catch(() => {});
      const snap = await col('shahi_orders').where('status', '==', 'pending_admin').limit(15).get().catch(() => ({ docs: [] }));
      const orders = docs(snap) || [];

      if (orders.length === 0) {
        return ctx.reply('✅ در حال حاضر هیچ فیش واریزی در انتظار تاییدی برای سکه شاهی وجود ندارد.');
      }

      const rows = [];
      for (const ord of orders) {
        rows.push([
          Markup.button.callback(`🧾 ${ord.coinsCount} سکه | ${ord.displayName} (${fmtNum(ord.totalPriceToman)} ت)`, `adbot:shahi:view:${ord.id}`),
        ]);
      }
      rows.push([Markup.button.callback('🔙 بازگشت به منوی سکه شاهی', 'adbot:shahi:menu')]);

      await ctx.editMessageText(`📥 <b>فهرست سفارشات خرید سکه شاهی VIP (در انتظار بررسی):</b>\nتعداد: <b>${orders.length} مورد</b>`, {
        parse_mode: 'HTML',
        reply_markup: Markup.inlineKeyboard(rows).reply_markup,
      }).catch(() => {});
    });

    bot.action(/^adbot:shahi:view:(.+)$/, async (ctx) => {
      await ctx.answerCbQuery().catch(() => {});
      const orderId = ctx.match[1];
      const snap = await col('shahi_orders').doc(orderId).get();
      if (!snap.exists) return ctx.reply('سفارش یافت نشد.');
      const ord = snap.data();

      const lines = [
        `🧾 <b>بررسی سفارش خرید سکه شاهی VIP</b>`,
        '– – – – – – – – – –',
        `👤 کاربر: <b>${esc(ord.displayName)}</b> (<code>${ord.telegramId}</code>)`,
        ord.countryName ? `🌍 کشور: <b>${ord.countryFlag} ${esc(ord.countryName)}</b>` : '',
        `💎 تعداد سکه درخواستی: <b>${fmtNum(ord.coinsCount)} سکه شاهی</b>`,
        `💰 مبلغ پرداختی: <b>${fmtNum(ord.totalPriceToman)} تومان</b>`,
        `⏱ زمان ثبت: <b>${fmtDate(ord.createdAt)}</b>`,
        '',
        ord.receipt?.text ? `📝 متن/کد ارسالی خریدار:\n<code>${esc(ord.receipt.text)}</code>` : '',
      ].filter(Boolean);

      const rows = [
        [
          Markup.button.callback(`✅ تایید و واریز ${ord.coinsCount} سکه شاهی`, `adbot:shahi:approve:${orderId}`),
          Markup.button.callback('❌ رد فیش و لغو', `adbot:shahi:reject:${orderId}`),
        ],
        [Markup.button.callback('🔙 بازگشت به سفارشات', 'adbot:shahi:orders')],
      ];

      if (ord.receipt?.type === 'photo' && ord.receipt.fileId) {
        await ctx.replyWithPhoto(ord.receipt.fileId, {
          caption: lines.join('\n'),
          parse_mode: 'HTML',
          ...Markup.inlineKeyboard(rows),
        }).catch(async () => {
          await ctx.reply(lines.join('\n'), { parse_mode: 'HTML', ...Markup.inlineKeyboard(rows) });
        });
      } else {
        await ctx.reply(lines.join('\n'), { parse_mode: 'HTML', ...Markup.inlineKeyboard(rows) });
      }
    });

    bot.action(/^adbot:shahi:approve:(.+)$/, async (ctx) => {
      await ctx.answerCbQuery().catch(() => {});
      const orderId = ctx.match[1];
      const orderRef = col('shahi_orders').doc(orderId);
      const snap = await orderRef.get();
      if (!snap.exists) return ctx.reply('سفارش یافت نشد.');
      const ord = snap.data();

      if (ord.status === 'approved') return ctx.reply('این سفارش قبلاً تایید و واریز شده است.');

      const season = await seasonService.getActiveSeason();
      if (season && ord.countryId) {
        await gameService.grantShahiCoins(ord.countryId, season.id, ord.coinsCount, 'خرید رسمی VIP سکه شاهی');
      }

      // افزودن سکه به کاربر
      const userRef = col('users').doc(String(ord.telegramId));
      const uSnap = await userRef.get();
      const curCoins = uSnap.exists ? Number(uSnap.data().shahiCoins || 0) : 0;
      await userRef.set({ shahiCoins: curCoins + ord.coinsCount }, { merge: true });

      await orderRef.update({
        status: 'approved',
        reviewedAt: new Date(),
        reviewedBy: String(ctx.from.id),
      });

      // پیام تبریک به خریدار
      const notifications = require('./notificationService');
      await notifications.safeSend(
        savedMainTelegram || bot.telegram,
        ord.telegramId,
        [
          '🎉 <b>واریز موفقیت‌آمیز سکه شاهی VIP!</b>',
          '– – – – – – – – – –',
          `فیش واریزی شما توسط مدیریت بازی بررسی و تایید گردید.`,
          `💎 تعداد <b>${fmtNum(ord.coinsCount)} سکه شاهی</b> مستقیماً به حسابتان واریز شد.`,
          'از حمایت شما سپاسگزاریم!',
        ].join('\n')
      ).catch(() => {});

      await ctx.reply(`✅ <b>سفارش #${orderId.slice(-6)} با موفقیت تایید و ${ord.coinsCount} سکه شاهی واریز شد.</b>`, { parse_mode: 'HTML' });
      await renderAdminDashboard(ctx, false);
    });

    bot.action(/^adbot:shahi:reject:(.+)$/, async (ctx) => {
      await ctx.answerCbQuery().catch(() => {});
      const orderId = ctx.match[1];
      const orderRef = col('shahi_orders').doc(orderId);
      const snap = await orderRef.get();
      if (!snap.exists) return ctx.reply('سفارش یافت نشد.');
      const ord = snap.data();

      await orderRef.update({
        status: 'rejected',
        reviewedAt: new Date(),
        reviewedBy: String(ctx.from.id),
      });

      const notifications = require('./notificationService');
      await notifications.safeSend(
        savedMainTelegram || bot.telegram,
        ord.telegramId,
        `❌ <b>اطلاعیه خرید سکه شاهی:</b> فیش ارسالی شما برای سفارش خرید ${ord.coinsCount} سکه شاهی تایید نگردید. در صورت وجود هرگونه مغایرت می‌توانید با پشتیبانی در ارتباط باشید.`
      ).catch(() => {});

      await ctx.reply(`❌ سفارش #${orderId.slice(-6)} رد شد و پیام اطلاع‌رسانی برای خریدار ارسال گردید.`);
      await renderAdminDashboard(ctx, false);
    });

    bot.action(/^adbot:shahi:rate:set:(\d+)$/, async (ctx) => {
      await ctx.answerCbQuery().catch(() => {});
      const newRate = Number(ctx.match[1]);
      await settings.set('shahiToDollarRate', newRate);
      await ctx.reply(`✅ <b>نرخ تبدیل سکه شاهی به ${fmtNum(newRate)}$ برای هر ۱ سکه تنظیم شد.</b>`, { parse_mode: 'HTML' });
      await renderAdminDashboard(ctx, false);
    });


    bot.action('adbot:shahi:grant:list', async (ctx) => {
      await ctx.answerCbQuery().catch(() => {});
      const season = await seasonService.getActiveSeason();
      if (!season) return ctx.reply('سیزنی فعال نیست.');
      const activeOwnerships = await ownership.listActive(season.id).catch(() => []);

      const rows = [];
      for (const o of activeOwnerships.slice(0, 10)) {
        const c = await countryService.get(o.countryId);
        if (c) {
          rows.push([
            Markup.button.callback(`👑 +۵ سکه به ${c.flag} ${c.name}`, `adbot:shahi:grant:do:${c.id}:5`),
            Markup.button.callback(`👑 +۱۰ سکه`, `adbot:shahi:grant:do:${c.id}:10`),
          ]);
        }
      }
      rows.push([Markup.button.callback('🔙 بازگشت به منوی سکه شاهی', 'adbot:shahi:menu')]);

      const text = [
        '🎁 <b>اعطای مستقیم سکه شاهی به کشورها توسط ادمین</b>',
        '– – – – – – – – – –',
        'کشور و مقدار مورد نظر را انتخاب کنید:',
      ].join('\n');

      await ctx.editMessageText(text, {
        parse_mode: 'HTML',
        reply_markup: Markup.inlineKeyboard(rows).reply_markup,
      }).catch(() => {});
    });

    bot.action(/^adbot:shahi:grant:do:(.+):(\d+)$/, async (ctx) => {
      await ctx.answerCbQuery().catch(() => {});
      const [countryId, amountStr] = [ctx.match[1], ctx.match[2]];
      const amount = Number(amountStr);
      const season = await seasonService.getActiveSeason();
      if (!season) return ctx.reply('سیزنی فعال نیست.');

      const [country, owner] = await Promise.all([
        countryService.get(countryId),
        ownership.getOwnerOfCountry(countryId, season.id),
      ]);
      if (!country) return ctx.reply('کشور یافت نشد.');

      await gameService.grantShahiCoins(countryId, season.id, amount, 'اعطای ویژه توسط مدیریت');
      if (owner) {
        const notifications = require('./notificationService');
        await notifications.safeSend(
          savedMainTelegram || bot.telegram,
          owner.userId,
          `👑 <b>پاداش ویژه مدیریت بازی!</b>\nتعداد <b>${amount} سکه شاهی</b> توسط ادمین به کشور شما اهدا گردید.\nمی‌توانید آن را در بخش تبدیل سکه به دلار تبدیل کنید.`
        );
      }

      await ctx.reply(`✅ تعداد ${amount} سکه شاهی با موفقیت به ${country.flag} ${country.name} اهدا گردید.`);
      await renderAdminDashboard(ctx, false);
    });

    // ۱۰. مدیریت ماموریت‌های روزانه توسط ادمین
    bot.action('adbot:missions:menu', async (ctx) => {
      await ctx.answerCbQuery().catch(() => {});
      const missions = await gameService.getDailyMissions();
      const lines = [
        '🎯 <b>مدیریت ماموریت‌های روزانه با پاداش سکه شاهی</b>',
        '– – – – – – – – – –',
        'بازیکنان با تکمیل این ماموریت‌ها سکه شاهی دریافت می‌کنند:',
        '',
        ...missions.map((m, i) => `${i + 1}. <b>${esc(m.title)}</b>\n   🎯 هدف: ${fmtNum(m.targetCount || 1)} بار | 👑 پاداش: <b>${m.rewardShahi || m.rewardCoin || 1} سکه شاهی</b> + ${fmtNum(m.rewardCash || 0)}$`),
      ];

      const rows = [
        [Markup.button.callback('🔄 بازنشانی به ماموریت‌های استاندارد', 'adbot:mission:reset')],
        [Markup.button.callback('🔙 بازگشت به داشبورد', 'adbot:dashboard')],
      ];

      await ctx.editMessageText(lines.join('\n'), {
        parse_mode: 'HTML',
        reply_markup: Markup.inlineKeyboard(rows).reply_markup,
      }).catch(() => {});
    });

    bot.action('adbot:mission:reset', async (ctx) => {
      await ctx.answerCbQuery().catch(() => {});
      await settings.set('daily_missions', gameService.DEFAULT_DAILY_MISSIONS);
      await ctx.reply('✅ ماموریت‌های روزانه به حالت استاندارد بازنشانی شدند.');
      await renderAdminDashboard(ctx, false);
    });

    // ۱۱. ریست کامل دارایی‌های بازیکن توسط ادمین
    bot.action('adbot:disc:reset:list', async (ctx) => {
      await ctx.answerCbQuery().catch(() => {});
      const season = await seasonService.getActiveSeason();
      if (!season) return ctx.reply('سیزنی فعال نیست.');
      const activeOwnerships = await ownership.listActive(season.id).catch(() => []);
      const rows = [];
      for (const o of activeOwnerships) {
        const c = await countryService.get(o.countryId);
        if (c) rows.push([Markup.button.callback(`🔄 ریست دارایی‌ها: ${c.flag} ${c.name}`, `adbot:disc:reset:confirm:${c.id}`)]);
      }
      rows.push([Markup.button.callback('🔙 بازگشت به منوی انضباطی', 'adbot:discipline:menu')]);
      await ctx.editMessageText('کشوری که می‌خواهید دارایی‌ها، منابع و تسلیحات آن کاملاً ریست و پایه شود را انتخاب کنید:', {
        reply_markup: Markup.inlineKeyboard(rows).reply_markup,
      }).catch(() => {});
    });

    bot.action(/^adbot:disc:reset:confirm:(.+)$/, async (ctx) => {
      await ctx.answerCbQuery().catch(() => {});
      const countryId = ctx.match[1];
      const country = await countryService.get(countryId);
      const text = `⚠️ <b>هشدار:</b> آیا مطمئن هستید که می‌خواهید کلیه موجودی خزانه، سکه‌ها، سهام، پروژه‌ها و تجهیزات نظامی کشور <b>${country?.flag} ${country?.name}</b> ریست شده و به مقادیر پایه اولیه بازگردانده شود؟`;
      const kb = Markup.inlineKeyboard([
        [Markup.button.callback('💥 بله، ریست کامل شود', `adbot:disc:reset:do:${countryId}`)],
        [Markup.button.callback('🔙 انصراف', 'adbot:disc:reset:list')],
      ]);
      await ctx.editMessageText(text, { parse_mode: 'HTML', reply_markup: kb.reply_markup }).catch(() => {});
    });

    bot.action(/^adbot:disc:reset:do:(.+)$/, async (ctx) => {
      await ctx.answerCbQuery().catch(() => {});
      const countryId = ctx.match[1];
      try {
        const res = await actions.resetPlayerAssets(savedMainTelegram || bot.telegram, countryId, 'ریست دارایی‌ها توسط مدیریت ربات ادمین', ctx.from.id);
        await ctx.reply(`✅ <b>کلیه دارایی‌های کشور ${res.country?.flag} ${res.country?.name} با موفقیت ریست شد و پیام اخطار به پیوی بازیکن ارسال گردید.</b>`, { parse_mode: 'HTML' });
        await renderAdminDashboard(ctx, false);
      } catch (e) {
        await ctx.reply(`⚠️ خطا در ریست دارایی‌ها: ${e.message}`);
      }
    });

    // ۱۲. تنظیم و انجماد واریزها (Payouts)
    bot.action('adbot:payouts:menu', async (ctx) => {
      await ctx.answerCbQuery().catch(() => {});
      const [isFrozen, interval] = await Promise.all([
        settings.isPayoutsFrozen(),
        settings.getPayoutInterval(),
      ]);

      const text = [
        '❄️ <b>تنظیمات پیشرفته سیستم واریز سود و حقوق (Payouts)</b>',
        '– – – – – – – – – –',
        `وضعیت فعلی واریزها: <b>${isFrozen ? '🔴 منجمد (متوقف شده)' : '🟢 فعال و روان'}</b>`,
        `فاصله زمانی دوره‌های واریز: <b>هر ${fmtNum(interval)} دقیقه</b>`,
        '',
        'از گزینه‌های زیر جهت انجماد یا تغییر چرخه واریزها استفاده فرمایید:',
      ].join('\n');

      const rows = [
        [Markup.button.callback(isFrozen ? '🟢 رفع انجماد واریزها (فعال‌سازی)' : '❄️ انجماد موقت کلیه واریزها', 'adbot:payouts:toggle')],
        [
          Markup.button.callback('⏱️ ۵ دقیقه', 'adbot:payouts:interval:5'),
          Markup.button.callback('⏱️ ۱۰ دقیقه', 'adbot:payouts:interval:10'),
          Markup.button.callback('⏱️ ۱۵ دقیقه', 'adbot:payouts:interval:15'),
        ],
        [
          Markup.button.callback('⏱️ ۳۰ دقیقه', 'adbot:payouts:interval:30'),
          Markup.button.callback('⏱️ ۶۰ دقیقه', 'adbot:payouts:interval:60'),
        ],
        [Markup.button.callback('🔙 بازگشت به داشبورد', 'adbot:dashboard')],
      ];

      await ctx.editMessageText(text, { parse_mode: 'HTML', reply_markup: Markup.inlineKeyboard(rows).reply_markup }).catch(() => {});
    });

    bot.action('adbot:payouts:toggle', async (ctx) => {
      await ctx.answerCbQuery().catch(() => {});
      const res = await actions.togglePayoutFreeze(ctx.from.id, null, 'admin_bot');
      await ctx.reply(res.frozen ? '❄️ <b>کلیه واریزهای سود و درآمدها منجمد و متوقف شدند.</b>' : '🟢 <b>انجماد واریزها برداشته شد و چرخه پرداخت فعال گردید.</b>', { parse_mode: 'HTML' });
      await renderAdminDashboard(ctx, false);
    });

    bot.action(/^adbot:payouts:interval:(\d+)$/, async (ctx) => {
      await ctx.answerCbQuery().catch(() => {});
      const mins = Number(ctx.match[1]);
      await actions.setPayoutIntervalMinutes(ctx.from.id, mins, 'admin_bot');
      await ctx.reply(`✅ <b>فاصله زمانی چرخه‌های واریز به هر ${mins} دقیقه تنظیم شد.</b>`, { parse_mode: 'HTML' });
      await renderAdminDashboard(ctx, false);
    });

    // شنونده پیام‌های متنی برای چت و ارسال به بازیکن و تنظیمات ادمین
    bot.on('text', async (ctx, next) => {
      const adminId = String(ctx.from.id);
      const userFlow = await userService.getFlow(ctx.from.id);

      if (userFlow && userFlow.name === 'adbot:shahi:set_custom_toman') {
        const raw = String(ctx.message.text || '').trim();
        if (raw === '/cancel') {
          await userService.clearFlow(ctx.from.id);
          return ctx.reply('❌ تنظیم قیمت لغو شد.');
        }
        const cleanPrice = parseInt(raw.replace(/[۰-۹]/g, (d) => String(d.charCodeAt(0) - 0x06f0)).replace(/[,٬]/g, ''), 10);
        if (Number.isFinite(cleanPrice) && cleanPrice > 0) {
          await settings.set('shahi_coin_real_price_toman', cleanPrice);
          await userService.clearFlow(ctx.from.id);
          await ctx.reply(`✅ <b>قیمت هر ۱ عدد سکه شاهی به ${fmtNum(cleanPrice)} تومان تنظیم گردید.</b>`, { parse_mode: 'HTML' });
          return renderAdminDashboard(ctx, false);
        } else {
          return ctx.reply('⚠️ لطفاً یک مبلغ معتبر به تومان وارد فرمایید (مثال: 75000)');
        }
      }

      if (adminDmFlows.has(adminId)) {
        const target = adminDmFlows.get(adminId);
        adminDmFlows.delete(adminId);

        if (ctx.message.text.trim() === '/cancel') {
          return ctx.reply('❌ ارسال پیام اختصاصی لغو شد.');
        }

        const msgText = ctx.message.text.trim();

        const formatted = [
          '👑 <b>پیام رسمی مدیریت کل بازی WORLD WAR FIRE</b>',
          '– – – – – – – – – –',
          `🌍 به رهبر کشور: <b>${target.flag} ${esc(target.countryName)}</b>`,
          '',
          `« <i>${esc(msgText)}</i> »`,
          '',
          '🏛 <i>این پیام مستقیماً از طریق پنل فرماندهی ادمین به پیوی شما ارسال شده است.</i>',
        ].join('\n');

        const notifications = require('./notificationService');
        const sent = await notifications.safeSend(savedMainTelegram || bot.telegram, target.userId, formatted);
        if (sent) {
          await ctx.reply(`✅ <b>پیام شما با موفقیت به پیوی رهبر کشور ${target.flag} ${target.countryName} ارسال گردید.</b>`, { parse_mode: 'HTML' });
        } else {
          await ctx.reply(`⚠️ ارسال پیام به پیوی بازیکن ممکن نشد (احتمالاً ربات توسط کاربر مسدود شده است).`);
        }
        return renderAdminDashboard(ctx, false);
      }

      // ۲. تنظیم قیمت اکتشاف نفت
      if (adminExplorationCostFlows.has(adminId)) {
        adminExplorationCostFlows.delete(adminId);
        if (ctx.message.text.trim() === '/cancel') return ctx.reply('❌ لغو شد.');
        const rawNum = Number(String(ctx.message.text.trim()).replace(/[^0-9]/g, ''));
        if (!rawNum || rawNum <= 0) return ctx.reply('⚠️ لطفاً یک رقم عددی معتبر ارسال کنید.');
        await settings.set('oilExplorationCost', rawNum);
        await ctx.reply(`✅ <b>هزینه اعزام تیم اکتشاف با موفقیت به ${fmtNum(rawNum)}$ تنظیم گردید.</b>`, { parse_mode: 'HTML' });
        return renderAdminDashboard(ctx, false);
      }

      // ۳. اعطای بودجه از بانک مرکزی به همراه رتبه/عنوان
      if (adminBudgetFlows.has(adminId)) {
        const target = adminBudgetFlows.get(adminId);
        adminBudgetFlows.delete(adminId);
        if (ctx.message.text.trim() === '/cancel') return ctx.reply('❌ لغو شد.');
        const rawText = ctx.message.text.trim();
        const parts = rawText.split(/\s+/);
        const amountNum = Number(parts[0].replace(/[^0-9]/g, ''));
        const rankOrReason = parts.slice(1).join(' ') || 'کمک توسعه اقتصادی مدیریت';
        if (!amountNum || amountNum <= 0) return ctx.reply('⚠️ لطفاً یک مبلغ عددی معتبر ارسال کنید.');

        try {
          await centralBankService.deductCentralBankBudget(amountNum, `اعطای بودجه به ${target.countryName}`);
          const season = await seasonService.getActiveSeason();
          const state = await gameService.getCountryState(target.countryId, season.id);
          const newTreasury = (state.treasury || 0) + amountNum;
          await gameService.updateCountryState(target.countryId, season.id, { treasury: newTreasury });

          const owner = await ownership.getOwnerOfCountry(target.countryId, season.id);
          if (owner) {
            const notifications = require('./notificationService');
            await notifications.safeSend(
              savedMainTelegram || bot.telegram,
              owner.userId,
              `🏛 <b>اعطای بودجه دولتی از بانک مرکزی!</b>\nمبلغ <b>+${fmtNum(amountNum)}$</b> با رتبه/عنوان «<b>${esc(rankOrReason)}</b>» توسط ادمین به خزانه کشور شما واریز شد.\nموجودی جدید: <b>${fmtNum(newTreasury)}$</b>`
            );
          }
          await ctx.reply(`✅ مبلغ ${fmtNum(amountNum)}$ با عنوان «${rankOrReason}» از بانک مرکزی به ${target.flag} ${target.countryName} واریز شد.`);
          return renderAdminDashboard(ctx, false);
        } catch (e) {
          return ctx.reply(`⚠️ خطا: ${e.message}`);
        }
      }

      // اعطای سفارشی سکه شاهی
      if (adminShahiFlows.has(adminId)) {
        const target = adminShahiFlows.get(adminId);
        adminShahiFlows.delete(adminId);
        const { toLatinDigits } = require('../utils/text');
        const textClean = toLatinDigits(ctx.message.text.trim());
        if (textClean === '/cancel') return ctx.reply('❌ لغو شد.');
        const parts = textClean.split(/\s+/);
        const shahiAmount = Number(parts[0]?.replace(/[^0-9]/g, '') || 0);
        let dollarAmount = 0;
        let rankText = 'اعطای ویژه سکه شاهی توسط مدیریت';
        if (parts.length >= 2 && /^\d+$/.test(parts[1])) {
          dollarAmount = Number(parts[1].replace(/[^0-9]/g, '') || 0);
          rankText = parts.slice(2).join(' ') || rankText;
        } else if (parts.length >= 2) {
          rankText = parts.slice(1).join(' ');
        }

        if (!shahiAmount && !dollarAmount) return ctx.reply('⚠️ لطفاً حداقل یک مقدار معتبر (سکه یا دلار) ارسال کنید.');

        try {
          const res = await actions.grantMoneyAndCoinsWithRank(
            savedMainTelegram || bot.telegram,
            target.countryId,
            rankText,
            dollarAmount,
            shahiAmount,
            ctx.from.id,
            'admin_bot'
          );
          await ctx.reply(`✅ <b>سکه شاهی و پاداش با موفقیت به ${target.flag} ${target.countryName} اعطا گردید!</b>\n👑 سکه شاهی افزوده شده: +${res.addedShahi}\n💵 مبلغ نقدی افزوده شده: +${fmtNum(res.addedDollars)}$\n🏅 عنوان: ${res.rankText}`, { parse_mode: 'HTML' });
          return renderAdminDashboard(ctx, false);
        } catch (e) {
          return ctx.reply(`⚠️ خطا در اعطای سکه شاهی: ${e.message}`);
        }
      }

      // ۴. جریمه بازیکن
      if (adminPenaltyFlows.has(adminId)) {
        const target = adminPenaltyFlows.get(adminId);
        adminPenaltyFlows.delete(adminId);
        if (ctx.message.text.trim() === '/cancel') return ctx.reply('❌ لغو شد.');
        const parts = ctx.message.text.trim().split(/\s+/);
        const fineDollar = Number(parts[0]?.replace(/[^0-9]/g, '') || 0);
        let fineShahi = 0;
        let reason = '';
        if (parts.length >= 2 && /^\d+$/.test(parts[1])) {
          fineShahi = Number(parts[1]);
          reason = parts.slice(2).join(' ');
        } else {
          reason = parts.slice(1).join(' ');
        }

        try {
          const res = await actions.finePlayer(savedMainTelegram || bot.telegram, target.countryId, fineDollar, fineShahi, reason, ctx.from.id);
          await ctx.reply(`✅ <b>جریمه کشور ${target.flag} ${target.countryName} اعمال شد:</b>\n💵 کسر دلاری: ${fmtNum(res.fineD)}$\n👑 کسر سکه شاهی: ${res.fineS}\n📝 علت: ${reason || 'تخلف اداری'}`, { parse_mode: 'HTML' });
          return renderAdminDashboard(ctx, false);
        } catch (e) {
          return ctx.reply(`⚠️ خطا: ${e.message}`);
        }
      }

      // ۵. بن از سیزن
      if (adminSeasonBanFlows.has(adminId)) {
        const target = adminSeasonBanFlows.get(adminId);
        adminSeasonBanFlows.delete(adminId);
        if (ctx.message.text.trim() === '/cancel') return ctx.reply('❌ لغو شد.');
        const reason = ctx.message.text.trim();
        try {
          await actions.banPlayerFromSeason(savedMainTelegram || bot.telegram, target.countryId, reason, ctx.from.id);
          await ctx.reply(`✅ <b>رهبر کشور ${target.flag} ${target.countryName} با موفقیت از سیزن جاری بن شد و کشور آزاد گردید.</b>`, { parse_mode: 'HTML' });
          return renderAdminDashboard(ctx, false);
        } catch (e) {
          return ctx.reply(`⚠️ خطا: ${e.message}`);
        }
      }
    });


    // راه‌اندازی بدون مسدودسازی
    try {
      await bot.telegram.deleteWebhook({ drop_pending_updates: false });
      bot.launch({ dropPendingUpdates: false }).catch((e) => logger.warn('خطای پولینگ ربات ادمین:', e.message));
      logger.info('داشبورد ربات اختصاصی ادمین با موفقیت آماده و فعال شد.');
    } catch (e) {
      logger.warn('راه‌اندازی پولینگ ربات ادمین ناموفق:', e.message);
    }

    adminBotInstance = bot;
    return adminBotInstance;
  } catch (err) {
    logger.warn('عدم موفقیت در ساخت ربات ادمین:', err.message);
    return null;
  }
}

// ارسال پیام فقط به ربات ادمین (دیگر پیام‌ها برای ادمین در ربات اصلی فرستاده نمی‌شود)
async function sendToAdminBot(mainTelegram, text, extra = {}, photoUrl = null) {
  if (mainTelegram) savedMainTelegram = mainTelegram;
  const botToken = await getAdminBotToken();
  const chatId = await getAdminChatId();

  if (botToken && chatId) {
    try {
      const adminBot = adminBotInstance || await initAdminBot(mainTelegram);
      if (adminBot) {
        if (photoUrl) {
          return await adminBot.telegram.sendPhoto(chatId, photoUrl, { caption: text, parse_mode: 'HTML', ...extra });
        }
        return await adminBot.telegram.sendMessage(chatId, text, { parse_mode: 'HTML', ...extra });
      }
    } catch (err) {
      logger.warn('خطا در ارسال پیام از طریق ربات ادمین اختصاصی:', err.message);
    }
  }

  // اگر توکن اختصاصی ربات ادمین تنظیم نشده بود، اعلان‌ها به عنوان fallback به ادمین‌ها در ربات اصلی ارسال می‌شوند
  if (mainTelegram && config.adminIds && config.adminIds.length) {
    const results = [];
    for (const aId of config.adminIds) {
      try {
        if (photoUrl) {
          results.push(await mainTelegram.sendPhoto(aId, photoUrl, { caption: text, parse_mode: 'HTML', ...extra }));
        } else {
          results.push(await mainTelegram.sendMessage(aId, text, { parse_mode: 'HTML', ...extra }));
        }
      } catch (_) {}
    }
    return results[0] || null;
  }
  return null;
}

module.exports = {
  getAdminBotToken,
  getAdminChatId,
  initAdminBot,
  sendToAdminBot,
  renderAdminDashboard,
};
