'use strict';
const { col, docs } = require('../db/firestore');
const logger = require('../utils/logger');

async function audit(adminTelegramId, action, target = null, details = null, via = 'telegram') {
  try {
    await col('auditLogs').add({ adminTelegramId, action, target: target ? String(target) : null, details, via, createdAt: new Date() });
  } catch (err) {
    logger.error('ثبت گزارش حسابرسی ناموفق بود:', err.message);
  }
}

async function recent(limit = 50) {
  return docs(await col('auditLogs').orderBy('createdAt', 'desc').limit(limit).get());
}
module.exports = { audit, recent };
