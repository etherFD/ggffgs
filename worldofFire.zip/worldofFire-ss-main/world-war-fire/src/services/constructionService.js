'use strict';

/**
 * سرویس ساخت‌وساز، بازار بورس سهام، شرکت‌های اختصاصی، مگاپروژه‌ها و مصالح بازار جهانی
 */

const { col, snap, docs } = require('../db/firestore');
const settingsService = require('./settingsService');
const { GameError } = require('../utils/errors');
const { acquireLock, releaseLock } = require('../db/locks');
const countryService = require('./countryService');
const { fmtNum } = require('../utils/text');

// سهام شرکت‌های معتبر بورس با نوسان دوره‌ای ۳ ساعته
const DEFAULT_BLUE_CHIP_STOCKS = {
  petro_pars: { name: 'پتروشیمی بین‌المللی پارس', key: 'petro_pars', price: 5400, growth: 12.5, dividendRate: 0.08, sector: 'انرژی و نفت', emoji: '🛢' },
  steel_mobarakeh: { name: 'صنایع فولاد متالورژی', key: 'steel_mobarakeh', price: 8200, growth: 8.2, dividendRate: 0.07, sector: 'صنایع سنگین', emoji: '🏗' },
  iran_khodro: { name: 'هولدینگ خودروسازی ملی', key: 'iran_khodro', price: 3100, growth: -3.4, dividendRate: 0.05, sector: 'ترابری', emoji: '🚗' },
  telecom_holding: { name: 'ارتباطات ماهواره‌ای کوانتوم', key: 'telecom_holding', price: 12500, growth: 16.8, dividendRate: 0.10, sector: 'فناوری', emoji: '📡' },
  pharma_sina: { name: 'داروسازی بیوتکنولوژی سینا', key: 'pharma_sina', price: 6900, growth: 5.1, dividendRate: 0.06, sector: 'پزشکی', emoji: '💊' },
};

// دسته‌بندی شرکت‌های اختصاصی قابل تاسیس با نام کوتاه در انتخاب و نام کامل در گزارش‌ها
const ENTERPRISE_CATEGORIES = {
  fashion: {
    shortName: 'مد و پوشاک',
    name: 'صنایع بین‌المللی مد، پوشاک و منسوجات',
    emoji: '👗',
    desc: 'تولید و صادرات پوشاک، منسوجات فاخر و البسه با ارزش افزوده بالا',
    description: 'تولید و صادرات پوشاک، منسوجات فاخر و البسه با ارزش افزوده بالا',
    baseIncome: 5000000,
    baseCost: 40000000,
    materials: { wood: 20 },
    requiredMaterials: { wood: 20 },
    scienceBoost: 5,
  },
  gamedev: {
    shortName: 'بازی‌سازی',
    name: 'استودیو بازی‌سازی و سرگرمی‌های دیجیتال',
    emoji: '🎮',
    desc: 'توسعه بازی‌های رایانه‌ای، موتورهای شبیه‌ساز و نرم‌افزارهای هوش مصنوعی',
    description: 'توسعه بازی‌های رایانه‌ای، موتورهای شبیه‌ساز و نرم‌افزارهای هوش مصنوعی',
    baseIncome: 8000000,
    baseCost: 60000000,
    materials: { copper: 10 },
    requiredMaterials: { copper: 10 },
    scienceBoost: 10,
  },
  film: {
    shortName: 'استودیو سینما',
    name: 'کمپانی فیلم‌سازی و استودیوهای سینمایی',
    emoji: '🎬',
    desc: 'تولید آثار سینمایی بین‌المللی، مستندهای راهبردی و قدرت نرم رسانه‌ای',
    description: 'تولید آثار سینمایی بین‌المللی، مستندهای راهبردی و قدرت نرم رسانه‌ای',
    baseIncome: 10000000,
    baseCost: 75000000,
    materials: { wood: 30, copper: 15 },
    requiredMaterials: { wood: 30, copper: 15 },
    scienceBoost: 8,
  },
  automotive: {
    shortName: 'خودروسازی',
    name: 'مجموعه صنایع خودروسازی پیشرفته و الکتریک',
    emoji: '🚘',
    desc: 'خطوط تولید خودروهای سبک و سنگین، پیشرانه‌های مدرن و قطعات صنعتی',
    description: 'خطوط تولید خودروهای سبک و سنگین، پیشرانه‌های مدرن و قطعات صنعتی',
    baseIncome: 18000000,
    baseCost: 140000000,
    materials: { steel: 50, iron: 40, oil: 200 },
    requiredMaterials: { steel: 50, iron: 40, oil: 200 },
    scienceBoost: 15,
  },
  pharma: {
    shortName: 'زیست‌دارویی',
    name: 'شرکت داروسازی، بیوتکنولوژی و واکسن‌سازی',
    emoji: '🧪',
    desc: 'پژوهش بیوتکنولوژی، داروسازی فوق‌پیشرفته و زنجیره تامین سلامت ملی',
    description: 'پژوهش بیوتکنولوژی، داروسازی فوق‌پیشرفته و زنجیره تامین سلامت ملی',
    baseIncome: 25000000,
    baseCost: 200000000,
    materials: { copper: 25, oil: 300 },
    requiredMaterials: { copper: 25, oil: 300 },
     scienceBoost: 20,
   },
   tech: {
     shortName: 'الکترونیک',
     name: 'صنایع الکترونیک و فناوری پیشرفته',
     emoji: '⚡',
     desc: 'تولید تجهیزات الکترونیک، نیمه‌هادی‌ها و نرم‌افزارهای صنعتی',
     description: 'تولید تجهیزات الکترونیک، نیمه‌هادی‌ها و نرم‌افزارهای صنعتی',
     baseIncome: 12000000,
     baseCost: 80000000,
     materials: { copper: 100, steel: 100 },
     requiredMaterials: { copper: 100, steel: 100 },
     scienceBoost: 12,
   },
};

// مگاپروژه‌های بزرگ ملی با مصالح واقعی بازار جهانی و نفت خام به عنوان مصالح رسمی
const DEFAULT_MEGAPROJECTS = {
  artificial_island: {
    key: 'artificial_island',
    name: 'جزیره مصنوعی خلیج',
    cost: 800000000,
    science: 15,
    emoji: '🏝',
    desc: 'توسعه مرز آبی، پایگاه لوکس دریایی و قطب ترانزیت جهانی',
    materials: { cement: 300, iron: 150, oil: 500 },
    requiredMaterials: { cement: 300, iron: 150, oil: 500 },
  },
  national_tower: {
    key: 'national_tower',
    name: 'برج ملی و نماد حاکمیت',
    cost: 1200000000,
    science: 25,
    emoji: '🗼',
    desc: 'بلندترین سازه مخابراتی، دیدبانی و نماد غرور ملی',
    materials: { steel: 400, cement: 250, copper: 80 },
    requiredMaterials: { steel: 400, cement: 250, copper: 80 },
  },
  megacity: {
    key: 'megacity',
    name: 'کلان‌شهر هوشمند آینده',
    cost: 2500000000,
    science: 40,
    emoji: '🏙',
    desc: 'شهر سبز بدون آلودگی با زیرساخت هوش مصنوعی و اتوماسیون',
    materials: { steel: 800, cement: 900, copper: 200, oil: 1200 },
    requiredMaterials: { steel: 800, cement: 900, copper: 200, oil: 1200 },
  },
  moon_mission: {
    key: 'moon_mission',
    name: 'پروژه فضایی فرود بر ماه',
    cost: 5000000000,
    science: 70,
    emoji: '🌕',
    desc: 'اکتشاف فضایی و استقرار نخستین پایگاه بر سطح ماه',
    materials: { steel: 1500, copper: 600, oil: 3000 },
    requiredMaterials: { steel: 1500, copper: 600, oil: 3000 },
  },
  space_station: {
    key: 'space_station',
    name: 'ساخت پایگاه فضایی مداری',
    cost: 10000000000,
    science: 100,
    emoji: '🛰',
    desc: 'تسلط کامل ماهواره‌ای، ایستگاه پژوهشی و پدافند استراتژیک مداری',
    materials: { steel: 3000, copper: 1200, oil: 6000 },
    requiredMaterials: { steel: 3000, copper: 1200, oil: 6000 },
  },
  mega_refinery: {
    key: 'mega_refinery',
    name: 'پالایشگاه فوق‌پیشرفته و زنجیره پتروشیمی ملی',
    cost: 500000000,
    science: 20,
    emoji: '🏭',
    desc: 'پالایشگاه فوق‌پیشرفته و زنجیره پتروشیمی ملی',
    materials: { oil: 500, steel: 120, cement: 140 },
    requiredMaterials: { oil: 500, steel: 120, cement: 140 },
  },
};

const MEGAPROJECTS = DEFAULT_MEGAPROJECTS;

const MATERIAL_NAMES = {
  wood: { name: 'چوب', unit: 'تن', emoji: '🪵' },
  cement: { name: 'سیمان', unit: 'تن', emoji: '🧱' },
  steel: { name: 'فولاد', unit: 'تن', emoji: '🏗' },
  iron: { name: 'آهن', unit: 'تن', emoji: '⛓' },
  copper: { name: 'مس', unit: 'تن', emoji: '🥉' },
  oil: { name: 'نفت خام (مصالح رسمی)', unit: 'بشکه', emoji: '🛢' },
};

// دریافت مگاپروژه‌ها با امکان سفارشی‌سازی کامل مصالح و مقادیر توسط ادمین
async function getProjectMaterialsConfig() {
  const custom = await settingsService.get('project_materials_config', null);
  return custom || {};
}

async function setProjectMaterialsConfig(config) {
  await settingsService.set('project_materials_config', config);
  return config;
}

async function getMegaprojectsList() {
  const dynamicConfig = (await getProjectMaterialsConfig()) || {};
  const list = JSON.parse(JSON.stringify(DEFAULT_MEGAPROJECTS));
  for (const [key, conf] of Object.entries(dynamicConfig || {})) {
    if (list[key] && conf && typeof conf === 'object') {
      if (conf.materials) {
        list[key].materials = conf.materials;
        list[key].requiredMaterials = conf.materials;
      }
      if (conf.cost !== undefined) list[key].cost = Number(conf.cost);
      if (conf.science !== undefined) list[key].science = Number(conf.science);
    }
  }
  return list;
}

// ثبت لاگ زنده عملیات پژوهش و پیشرفت‌های ملی
async function logResearchOperation(entry) {
  try {
    const docRef = col('research_logs').doc();
    await docRef.set({
      id: docRef.id,
      timestamp: new Date().toISOString(),
      countryId: entry.countryId || '',
      countryName: entry.countryName || '',
      countryFlag: entry.countryFlag || '',
      type: entry.type || 'research',
      title: entry.title || '',
      details: entry.details || '',
      scienceGain: Number(entry.scienceGain || 0),
    });
  } catch (err) {
    logger.warn(`[ResearchLogs] خطا در ثبت لاگ پژوهش: ${err.message}`);
  }
}

async function getResearchLogs(limit = 60) {
  try {
    const snap = await col('research_logs').orderBy('timestamp', 'desc').limit(limit).get();
    return docs(snap);
  } catch {
    return [];
  }
}

// محاسبه پویا و بدون سقف (بینهایت) نسل‌های اینترنت ملی
function getInternetTier(tierKey) {
  const baseTiers = {
    '2G': { name: 'اینترنت نسل ۲ (2G EDGE)', next: '3G', upgradeCost: 20000000, scienceBonus: 3, satisfactionBonus: 3 },
    '3G': { name: 'اینترنت نسل ۳ (3G)', next: '4G', upgradeCost: 50000000, scienceBonus: 5, satisfactionBonus: 5 },
    '4G': { name: 'اینترنت نسل ۴ (4G LTE)', next: '5G', upgradeCost: 150000000, scienceBonus: 12, satisfactionBonus: 10 },
    '5G': { name: 'اینترنت نسل ۵ (5G گیگابیتی)', next: '6G', upgradeCost: 400000000, scienceBonus: 25, satisfactionBonus: 15 },
    '6G': { name: 'شبکه کوانتومی نسل ۶ (6G ترابیت)', next: '7G', upgradeCost: 1000000000, scienceBonus: 50, satisfactionBonus: 20 },
  };

  if (baseTiers[tierKey]) return baseTiers[tierKey];

  // فراتر از 6G: محاسبه دینامیک ریاضی تا بینهایت
  const match = String(tierKey || '').match(/^(\d+)G$/i);
  const n = match ? parseInt(match[1], 10) : 7;
  const nextN = n + 1;
  const multiplier = Math.pow(1.85, Math.max(1, n - 6));
  const cost = Math.round(1000000000 * multiplier);
  const science = Math.round(50 + (n - 6) * 35);
  const satisfaction = Math.min(100, 20 + (n - 6) * 5);

  return {
    name: `شبکه فراکوانتومی نسل ${n} (${n}G هیپرسیگنال)`,
    next: `${nextN}G`,
    upgradeCost: cost,
    scienceBonus: science,
    satisfactionBonus: satisfaction,
  };
}

const INTERNET_TIERS = {
  get: getInternetTier,
};


/**
 * دریافت سهام معتبر بورس با بروزرسانی دوره ۳ ساعته
 */
async function getStockMarket(seasonId) {
  const custom = await settingsService.get(`stock_market_${seasonId}`, null);
  if (custom && custom.stocks && typeof custom.stocks === 'object' && custom.lastUpdate && (Date.now() - custom.lastUpdate < 3 * 3600 * 1000)) {
    return custom.stocks;
  }

  const stocks = JSON.parse(JSON.stringify(DEFAULT_BLUE_CHIP_STOCKS));
  for (const k of Object.keys(stocks || {})) {
    const delta = (Math.random() * 20 - 8).toFixed(1);
    const mult = 1 + Number(delta) / 100;
    stocks[k].growth = Number(delta);
    stocks[k].price = Math.max(500, Math.round(stocks[k].price * mult));
  }

  await settingsService.set(`stock_market_${seasonId}`, {
    stocks,
    lastUpdate: Date.now(),
  }).catch(() => {});

  return stocks;
}

/**
 * خرید سهام با تعداد دلخواه
 */
async function buyStockShares(countryId, seasonId, stockKey, quantity, gameService) {
  const qty = Math.max(1, Math.floor(Number(quantity) || 1));
  const market = await getStockMarket(seasonId);
  const stock = market[stockKey];
  if (!stock) throw new GameError('سهام شرکت مورد نظر در تابلوی بورس یافت نشد.');

  const totalCost = qty * stock.price;
  const state = await gameService.getCountryState(countryId, seasonId);
  const treasury = Number(state.treasury || 0);

  if (treasury < totalCost) {
    throw new GameError(`بودجه خزانه کافی نیست. خرید ${fmtNum(qty)} سهم به ${fmtNum(totalCost)}$ نیاز دارد (موجودی: ${fmtNum(treasury)}$).`);
  }

  const shares = state.stockShares || {};
  shares[stockKey] = Number(shares[stockKey] || 0) + qty;
  const currentScience = Number(state.scienceScore || 10);
  const scienceGain = Math.max(1, Math.floor(qty * 0.05));

  await gameService.updateCountryState(countryId, seasonId, {
    treasury: treasury - totalCost,
    stockShares: shares,
    scienceScore: currentScience + scienceGain,
  });

  return {
    stock,
    qty,
    totalCost,
    remainingTreasury: treasury - totalCost,
    totalShares: shares[stockKey],
    scienceGain,
  };
}

/**
 * بررسی و اعتبارسنجی مصالح موردنیاز برای ساخت
 */
function validateMaterialsAvailability(state, materialsRequired = {}) {
  const inventory = state.inventory || {};
  const currentOil = Number(state.oil || 0);
  const shortages = [];

  for (const [matKey, requiredQty] of Object.entries(materialsRequired || {})) {
    const req = Number(requiredQty) || 0;
    if (req <= 0) continue;

    const info = MATERIAL_NAMES[matKey] || { name: matKey, unit: 'واحد' };
    const available = matKey === 'oil' ? currentOil : Number(inventory[matKey] || 0);

    if (available < req) {
      shortages.push(`• ${info.name}: نیاز ${fmtNum(req)} ${info.unit} (موجودی فعلی: ${fmtNum(available)} ${info.unit})`);
    }
  }

  if (shortages.length > 0) {
    throw new GameError(
      `❌ کمبود مصالح ساختمانی در انبار کشور!\n` +
      `برای آغاز این پروژه، به مقادیر زیر نیاز دارید:\n` +
      shortages.join('\n') +
      `\n\n💡 می‌توانید مصالح لازم را از منوی «🌐 بازار جهانی» و نفت را از بخش «استخراج نفت» تأمین فرمایید.`
    );
  }
}

/**
 * تاسیس شرکت اختصاصی با اعتبارسنجی اتمیک و ممانعت قطعی از کلیک تکراری
 */
async function createCustomEnterprise(countryId, seasonId, { category, name, logo }, gameService) {
  const cat = ENTERPRISE_CATEGORIES[category];
  if (!cat) throw new GameError('دسته‌بندی شرکت نامعتبر است.');

  const cleanName = String(name || '').trim();
  if (!cleanName || cleanName.length < 2 || cleanName.length > 50) {
    throw new GameError('نام شرکت باید بین ۲ تا ۵۰ کاراکتر باشد.');
  }

  const lockKey = `create_enterprise:${countryId}`;
  const locked = await acquireLock(lockKey, 10000);
  if (!locked) {
    throw new GameError('درخواست ثبت شرکت شما هم‌اکنون در حال پردازش است. لطفاً از کلیک مکرر خودداری کنید.');
  }

  try {
    const gs = gameService || require('./gameService');
    const state = await gs.getCountryState(countryId, seasonId);
    const treasury = Number(state.treasury || 0);

    if (treasury < cat.baseCost) {
      throw new GameError(`برای تاسیس شرکت «${cat.name}» به ${fmtNum(cat.baseCost)}$ بودجه در خزانه نیاز است (موجودی شما: ${fmtNum(treasury)}$).`);
    }

    // بررسی مصالح در صورت وجود
    if (cat.materials) {
      validateMaterialsAvailability(state, cat.materials);
    }

    // کسر مصالح از انبار
    const inventory = { ...(state.inventory || {}) };
    let newOil = Number(state.oil || 0);
    if (cat.materials) {
      for (const [matKey, qty] of Object.entries(cat.materials)) {
        if (matKey === 'oil') newOil = Math.max(0, newOil - qty);
        else inventory[matKey] = Math.max(0, Number(inventory[matKey] || 0) - qty);
      }
    }

    const enterpriseId = `ent_${Date.now()}`;
    const newEnterprise = {
      id: enterpriseId,
      category,
      categoryShortName: cat.shortName,
      categoryName: cat.name,
      name: cleanName,
      logo: String(logo || cat.emoji).trim().slice(0, 10),
      tier: 1,
      cycleIncome: cat.baseIncome,
      scienceScore: cat.scienceBoost,
      createdAt: new Date(),
    };

    const enterprises = [...(state.customEnterprises || []), newEnterprise];
    const curScience = Number(state.scienceScore || 10);

    await gs.updateCountryState(countryId, seasonId, {
      treasury: treasury - cat.baseCost,
      oil: newOil,
      inventory,
      customEnterprises: enterprises,
      scienceScore: curScience + cat.scienceBoost,
    });

    return {
      enterprise: newEnterprise,
      cost: cat.baseCost,
      remainingTreasury: treasury - cat.baseCost,
    };
  } finally {
    await releaseLock(lockKey);
  }
}

/**
 * ارتقای شرکت اختصاصی
 */
async function upgradeEnterprise(countryId, seasonId, enterpriseId, gameService) {
  const lockKey = `upgrade_enterprise:${countryId}:${enterpriseId}`;
  const locked = await acquireLock(lockKey, 8000);
  if (!locked) throw new GameError('عملیات ارتقای شرکت در حال انجام است.');

  try {
    const state = await gameService.getCountryState(countryId, seasonId);
    const enterprises = [...(state.customEnterprises || [])];
    const ent = enterprises.find((e) => e.id === enterpriseId);
    if (!ent) throw new GameError('شرکت مورد نظر یافت نشد.');

    if (ent.tier >= 5) throw new GameError('این شرکت به بالاترین سطح فناوری و درآمدزایی (سطح ۵) رسیده است.');

    const nextTier = ent.tier + 1;
    const upgradeCost = ent.cycleIncome * 4;
    const treasury = Number(state.treasury || 0);

    if (treasury < upgradeCost) {
      throw new GameError(`برای ارتقای شرکت ${ent.name} به سطح ${nextTier} به ${fmtNum(upgradeCost)}$ نیاز دارید.`);
    }

    ent.tier = nextTier;
    ent.cycleIncome = Math.round(ent.cycleIncome * 1.8);
    ent.scienceScore += 10;

    const curScience = Number(state.scienceScore || 10);

    await gameService.updateCountryState(countryId, seasonId, {
      treasury: treasury - upgradeCost,
      customEnterprises: enterprises,
      scienceScore: curScience + 10,
    });

    return {
      enterprise: ent,
      upgradeCost,
      remainingTreasury: treasury - upgradeCost,
    };
  } finally {
    await releaseLock(lockKey);
  }
}

/**
 * احداث مگاپروژه ملی با کسر واقعی مصالح بازار جهانی و نفت خام به صورت اتمیک
 */
async function buildMegaproject(countryId, seasonId, projectKey, gameService) {
  const lockKey = `build_megaproject:${countryId}:${projectKey}`;
  const locked = await acquireLock(lockKey, 10000);
  if (!locked) throw new GameError('عملیات ساخت پروژه در حال ثبت است.');

  try {
    const projectsMap = await getMegaprojectsList();
    const proj = projectsMap[projectKey];
    if (!proj) throw new GameError('مگاپروژه مورد نظر در سامانه تعریف نشده است.');

    const state = await gameService.getCountryState(countryId, seasonId);
    const built = [...(state.megaprojects || [])];
    if (built.includes(projectKey)) {
      throw new GameError(`مگاپروژه «${proj.name}» پیش‌تر در کشور احداث شده است.`);
    }

    const treasury = Number(state.treasury || 0);
    if (treasury < proj.cost) {
      throw new GameError(`برای احداث «${proj.name}» به ${fmtNum(proj.cost)}$ بودجه نیاز دارید (موجودی: ${fmtNum(treasury)}$).`);
    }

    // اعتبارسنجی مصالح بازار جهانی و نفت
    if (proj.materials) {
      validateMaterialsAvailability(state, proj.materials);
    }

    // کسر اتمیک مصالح
    const inventory = { ...(state.inventory || {}) };
    let newOil = Number(state.oil || 0);

    if (proj.materials) {
      for (const [matKey, qty] of Object.entries(proj.materials)) {
        if (matKey === 'oil') newOil = Math.max(0, newOil - qty);
        else inventory[matKey] = Math.max(0, Number(inventory[matKey] || 0) - qty);
      }
    }

    built.push(projectKey);
    const curScience = Number(state.scienceScore || 10);

    await gameService.updateCountryState(countryId, seasonId, {
      treasury: treasury - proj.cost,
      oil: newOil,
      inventory,
      megaprojects: built,
      scienceScore: curScience + proj.science,
    });

    // ثبت لاگ احداث پروژه در دیتابیس
    await col('project_logs').add({
      countryId: String(countryId),
      seasonId: String(seasonId),
      projectKey,
      projectName: proj.name,
      cost: proj.cost,
      materials: proj.materials || {},
      completedAt: new Date(),
    });

    const country = await countryService.get(countryId).catch(() => null);
    await logResearchOperation({
      countryId,
      seasonId,
      countryName: country?.name || 'کشور نامشخص',
      countryFlag: country?.flag || '🏛️',
      type: 'megaproject',
      title: `احداث مگاپروژه ملی: ${proj.name} ${proj.emoji}`,
      details: `پروژه «${proj.name}» با سرمایه‌گذاری ${fmtNum(proj.cost)}$ و مصالح جهانی با موفقیت تکمیل گردید (+${proj.science} امتیاز علمی)`,
      scienceGain: proj.science,
    });


    return {
      project: proj,
      remainingTreasury: treasury - proj.cost,
      newScience: curScience + proj.science,
      materialsUsed: proj.materials || {},
    };
  } finally {
    await releaseLock(lockKey);
  }
}

/**
 * ارتقای زیرساخت اینترنت ملی (بدون سقف و تا بینهایت)
 */
async function upgradeInternet(countryId, seasonId, gameService) {
  const state = await gameService.getCountryState(countryId, seasonId);
  const curTierKey = state.internet || '3G';
  const tierInfo = getInternetTier(curTierKey);

  const nextTierKey = tierInfo.next;
  const nextInfo = getInternetTier(nextTierKey);
  const treasury = Number(state.treasury || 0);

  if (treasury < tierInfo.upgradeCost) {
    throw new GameError(`برای ارتقا به ${nextInfo.name} به ${fmtNum(tierInfo.upgradeCost)}$ نیاز دارید (موجودی شما: ${fmtNum(treasury)}$).`);
  }

  const curScience = Number(state.scienceScore || 10);
  const curSat = Number(state.satisfaction || 60);

  await gameService.updateCountryState(countryId, seasonId, {
    treasury: treasury - tierInfo.upgradeCost,
    internet: nextTierKey,
    scienceScore: curScience + tierInfo.scienceBonus,
    satisfaction: Math.min(100, curSat + tierInfo.satisfactionBonus),
  });

  // ثبت لاگ پژوهش
  const country = await countryService.get(countryId).catch(() => null);
  await logResearchOperation({
    countryId,
    seasonId,
    countryName: country?.name || 'کشور نامشخص',
    countryFlag: country?.flag || '🌐',
    type: 'internet_upgrade',
    title: `ارتقای اینترنت ملی به ${nextInfo.name}`,
    details: `شبکه اینترنت ملی از ${curTierKey} به ${nextTierKey} ارتقا یافت (+${tierInfo.scienceBonus} امتیاز علمی و +${tierInfo.satisfactionBonus}٪ رضایت مردمی)`,
    scienceGain: tierInfo.scienceBonus,
  });

  return {
    oldTier: curTierKey,
    newTier: nextTierKey,
    nextInfo,
    cost: tierInfo.upgradeCost,
    remainingTreasury: treasury - tierInfo.upgradeCost,
    country,
  };
}

module.exports = {
  DEFAULT_BLUE_CHIP_STOCKS,
  ENTERPRISE_CATEGORIES,
  DEFAULT_MEGAPROJECTS,
  MEGAPROJECTS: DEFAULT_MEGAPROJECTS,
  MATERIAL_NAMES,
  INTERNET_TIERS,
  getInternetTier,
  getMegaprojectsList,
  getProjectMaterialsConfig,
  setProjectMaterialsConfig,
  logResearchOperation,
  getResearchLogs,
  getStockMarket,
  buyStockShares,
  validateMaterialsAvailability,
  createCustomEnterprise,
  upgradeEnterprise,
  buildMegaproject,
  upgradeInternet,
};

