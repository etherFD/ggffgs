'use strict';
const { db, col } = require('../db/firestore');

async function nextSeq(name) {
  const ref = col('counters').doc(name);
  return db().runTransaction(async (tx) => {
    const s = await tx.get(ref);
    const seq = (s.exists ? s.data().seq : 0) + 1;
    tx.set(ref, { seq });
    return seq;
  });
}
module.exports = { nextSeq };
