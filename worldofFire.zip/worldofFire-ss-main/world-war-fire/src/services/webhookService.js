'use strict';
const { config } = require('../config');
const { GameError } = require('../utils/errors');

function webhookUrl(baseUrl) {
  const base = String(baseUrl || '').trim().replace(/\/+$/, '');
  if (!/^https:\/\/[^\s/]+/.test(base)) throw new GameError('آدرس پایه باید با https:// شروع شود (مثلاً https://xxxx.run.app).');
  if (base.includes('ais-dev-') || base.includes('localhost') || base.includes('127.0.0.1')) {
    throw new GameError('دامنه پیش‌نمایش توسعه داخلی (ais-dev) نیازمند ورود به حساب گوگل است و تلگرام نمی‌تواند با آن ارتباط بگیرد (خطای ۳۰۲). ربات در این محیط به صورت کاملاً پایدار در حالت دریافت مستقیم و زنده (Polling) فعال است و نیازی به ست کردن وب‌هوک ندارد.');
  }
  return `${base}/telegram/${config.webhookPath}`;
}

async function setWebhook(telegram, baseUrl) {
  const url = webhookUrl(baseUrl);
  await telegram.setWebhook(url, { secret_token: config.webhookSecret, allowed_updates: ['message', 'callback_query'] });
  return url;
}

async function webhookInfo(telegram) {
  if (!telegram) {
    return {
      isSet: false,
      host: null,
      pendingUpdates: 0,
      lastError: null,
      lastErrorDate: null,
      unauthorized: true,
    };
  }
  try {
    const i = await telegram.getWebhookInfo();
    const isSet = Boolean(i && i.url);
    return {
      isSet,
      host: isSet ? new URL(i.url).host : null,
      pendingUpdates: (i && i.pending_update_count) || 0,
      lastError: isSet ? ((i && i.last_error_message) || null) : null,
      lastErrorDate: (isSet && i && i.last_error_date) ? new Date(i.last_error_date * 1000).toISOString() : null,
      unauthorized: false,
    };
  } catch (err) {
    const is401 = String(err.message || '').includes('401');
    return {
      isSet: false,
      host: null,
      pendingUpdates: 0,
      lastError: is401 ? 'توکن ربات تلگرام نامعتبر است (401: Unauthorized)' : null,
      lastErrorDate: is401 ? new Date().toISOString() : null,
      unauthorized: is401,
      error: err.message,
    };
  }
}

async function fixWebhook(telegram) {
  if (!telegram) return { ok: false, error: 'ربات در دسترس نیست' };
  try {
    await telegram.deleteWebhook({ drop_pending_updates: true });
    return { ok: true, message: 'وب‌هوک با موفقیت پاکسازی شد و ربات در حالت دریافت مستقیم و بلادرنگ (Polling) فعال گردید.' };
  } catch (err) {
    const is401 = String(err.message || '').includes('401');
    return {
      ok: false,
      error: is401 ? 'توکن ربات تلگرام نامعتبر است (401: Unauthorized)' : err.message,
      message: is401 ? 'توکن ربات تلگرام نامعتبر است. لطفاً توکن صحیح را از BotFather دریافت و تنظیم کنید.' : err.message,
    };
  }
}

module.exports = { setWebhook, webhookInfo, webhookUrl, fixWebhook };
