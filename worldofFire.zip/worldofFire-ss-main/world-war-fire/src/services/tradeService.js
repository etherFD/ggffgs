'use strict';
const { col, snap, docs } = require('../db/firestore');
const { GameError } = require('../utils/errors');
const gameService = require('./gameService');
const countryService = require('./countryService');

const TRADE_ITEMS = {
  money: { name: 'پول و نقدینگی', unit: '$', emoji: '💰' },
  oil: { name: 'نفت خام', unit: 'بشکه', emoji: '🛢' },
  weapons: { name: 'تسلیحات و تانک', unit: 'دستگاه', emoji: '🪖' },
  research: { name: 'پژوهش و تکنولوژی', unit: 'امتیاز علمی', emoji: '🔬' },
};

async function getTradeOffer(id) {
  if (!id) return null;
  return snap(await col('trade_offers').doc(String(id)).get());
}

async function listIncomingOffers(countryId, seasonId) {
  const q = await col('trade_offers')
    .where('toCountryId', '==', String(countryId))
    .where('seasonId', '==', String(seasonId))
    .where('status', '==', 'pending')
    .get();
  return docs(q);
}

async function listOutgoingOffers(countryId, seasonId) {
  const q = await col('trade_offers')
    .where('fromCountryId', '==', String(countryId))
    .where('seasonId', '==', String(seasonId))
    .where('status', '==', 'pending')
    .get();
  return docs(q);
}

function checkHasResource(state, item, qty) {
  if (item === 'money') {
    if ((state.treasury || 0) < qty) {
      throw new GameError(`موجودی پول کافی نیست! موجودی فعلی: ${(state.treasury || 0).toLocaleString()}$ و مقدار مورد نیاز: ${qty.toLocaleString()}$`);
    }
  } else if (item === 'oil') {
    if ((state.oil || 0) < qty) {
      throw new GameError(`موجودی نفت کافی نیست! موجودی فعلی: ${(state.oil || 0).toLocaleString()} بشکه و مقدار مورد نیاز: ${qty.toLocaleString()}`);
    }
  } else if (item === 'weapons') {
    const tanks = state.groundUnits?.tank || 0;
    if (tanks < qty) {
      throw new GameError(`تعداد تانک و سلاح کافی نیست! موجودی فعلی: ${tanks} دستگاه و مقدار درخواستی: ${qty}`);
    }
  } else if (item === 'research') {
    const score = state.scoreToNext || 100;
    if (score < qty) {
      throw new GameError(`امتیاز علمی و پژوهشی کافی نیست! امتیاز فعلی: ${score} و مقدار درخواستی: ${qty}`);
    }
  }
}

async function createTradeOffer({ fromCountryId, fromUserId, toCountryId, seasonId, offerItem, offerQty, requestItem, requestQty, note = '' }) {
  if (fromCountryId === toCountryId) throw new GameError('نمی‌توانید با کشور خودتان دادوستد کنید!');
  if (!TRADE_ITEMS[offerItem] || !TRADE_ITEMS[requestItem]) throw new GameError('اقلام تجاری انتخاب‌شده نامعتبر است.');

  const offQty = Math.max(1, Number(offerQty) || 0);
  const reqQty = Math.max(1, Number(requestQty) || 0);

  // بررسی موجودی پیشنهاددهنده
  const state = await gameService.getCountryState(fromCountryId, seasonId);
  checkHasResource(state, offerItem, offQty);

  const fromCountry = await countryService.get(fromCountryId);
  const toCountry = await countryService.get(toCountryId);
  if (!fromCountry || !toCountry) throw new GameError('کشورها معتبر نیستند.');

  const ref = col('trade_offers').doc();
  const offer = {
    id: ref.id,
    seasonId: String(seasonId),
    fromCountryId: String(fromCountryId),
    fromCountryName: fromCountry.name,
    fromCountryFlag: fromCountry.flag,
    fromUserId: Number(fromUserId),
    toCountryId: String(toCountryId),
    toCountryName: toCountry.name,
    toCountryFlag: toCountry.flag,
    offerItem,
    offerQty: offQty,
    requestItem,
    requestQty: reqQty,
    note: String(note || '').trim().slice(0, 300),
    status: 'pending',
    createdAt: new Date(),
  };

  await ref.set(offer);
  return offer;
}

async function acceptTradeOffer({ offerId, targetCountryId }) {
  const offer = await getTradeOffer(offerId);
  if (!offer || offer.status !== 'pending') throw new GameError('پیشنهاد معامله نامعتبر است یا قبلاً تعیین تکلیف شده است.');
  if (offer.toCountryId !== String(targetCountryId)) throw new GameError('این پیشنهاد برای کشور شما نیست.');

  const { fromCountryId, toCountryId, seasonId, offerItem, offerQty, requestItem, requestQty } = offer;

  // بررسی موجودی هر دو کشور در لحظه پذیرش
  const fromState = await gameService.getCountryState(fromCountryId, seasonId);
  const toState = await gameService.getCountryState(toCountryId, seasonId);

  checkHasResource(fromState, offerItem, offerQty);
  checkHasResource(toState, requestItem, requestQty);

  // اجرای تراکنش انتقال منابع
  const patchFrom = {};
  const patchTo = {};

  // ۱. انتقال قلم پیشنهادی از فرستنده به گیرنده
  if (offerItem === 'money') {
    patchFrom.treasury = (fromState.treasury || 0) - offerQty;
    patchTo.treasury = (toState.treasury || 0) + offerQty;
  } else if (offerItem === 'oil') {
    patchFrom.oil = (fromState.oil || 0) - offerQty;
    patchTo.oil = (toState.oil || 0) + offerQty;
  } else if (offerItem === 'weapons') {
    patchFrom['groundUnits.tank'] = Math.max(0, (fromState.groundUnits?.tank || 0) - offerQty);
    patchTo['groundUnits.tank'] = (toState.groundUnits?.tank || 0) + offerQty;
  } else if (offerItem === 'research') {
    patchFrom.scoreToNext = Math.max(0, (fromState.scoreToNext || 0) - offerQty);
    patchTo.scoreToNext = (toState.scoreToNext || 0) + offerQty;
  }

  // ۲. انتقال قلم درخواستی از گیرنده به فرستنده
  if (requestItem === 'money') {
    patchTo.treasury = ((patchTo.treasury !== undefined ? patchTo.treasury : toState.treasury) || 0) - requestQty;
    patchFrom.treasury = ((patchFrom.treasury !== undefined ? patchFrom.treasury : fromState.treasury) || 0) + requestQty;
  } else if (requestItem === 'oil') {
    patchTo.oil = ((patchTo.oil !== undefined ? patchTo.oil : toState.oil) || 0) - requestQty;
    patchFrom.oil = ((patchFrom.oil !== undefined ? patchFrom.oil : fromState.oil) || 0) + requestQty;
  } else if (requestItem === 'weapons') {
    patchTo['groundUnits.tank'] = Math.max(0, ((patchTo['groundUnits.tank'] !== undefined ? patchTo['groundUnits.tank'] : toState.groundUnits?.tank) || 0) - requestQty);
    patchFrom['groundUnits.tank'] = ((patchFrom['groundUnits.tank'] !== undefined ? patchFrom['groundUnits.tank'] : fromState.groundUnits?.tank) || 0) + requestQty;
  } else if (requestItem === 'research') {
    patchTo.scoreToNext = Math.max(0, ((patchTo.scoreToNext !== undefined ? patchTo.scoreToNext : toState.scoreToNext) || 0) - requestQty);
    patchFrom.scoreToNext = ((patchFrom.scoreToNext !== undefined ? patchFrom.scoreToNext : fromState.scoreToNext) || 0) + requestQty;
  }

  await gameService.updateCountryState(fromCountryId, seasonId, patchFrom);
  await gameService.updateCountryState(toCountryId, seasonId, patchTo);

  await col('trade_offers').doc(offer.id).update({
    status: 'accepted',
    completedAt: new Date(),
  });

  return { offer, patchFrom, patchTo };
}

async function rejectTradeOffer({ offerId, targetCountryId }) {
  const offer = await getTradeOffer(offerId);
  if (!offer || offer.status !== 'pending') throw new GameError('پیشنهاد نامعتبر است.');
  if (offer.toCountryId !== String(targetCountryId)) throw new GameError('مجوز رد این پیشنهاد را ندارید.');

  await col('trade_offers').doc(offer.id).update({
    status: 'rejected',
    closedAt: new Date(),
  });
  return offer;
}

async function cancelTradeOffer({ offerId, fromCountryId }) {
  const offer = await getTradeOffer(offerId);
  if (!offer || offer.status !== 'pending') throw new GameError('پیشنهاد نامعتبر است.');
  if (offer.fromCountryId !== String(fromCountryId)) throw new GameError('شما ایجادکننده این پیشنهاد نیستید.');

  await col('trade_offers').doc(offer.id).update({
    status: 'cancelled',
    closedAt: new Date(),
  });
  return offer;
}

// ارسال مستقیم پیمان به یک کشور بدون نیاز به مذاکره
async function sendDirectPact({ fromCountryId, toCountryId, seasonId, pactType = 'non_aggression', note = '' }) {
  if (fromCountryId === toCountryId) throw new GameError('نمی‌توانید به کشور خودتان پیمان بفرستید.');
  const [fromCountry, toCountry] = await Promise.all([
    countryService.get(fromCountryId),
    countryService.get(toCountryId),
  ]);
  if (!fromCountry || !toCountry) throw new GameError('کشور مبدأ یا مقصد یافت نشد.');

  const ref = col('diplomatic_pacts').doc();
  const pact = {
    id: ref.id,
    seasonId: String(seasonId),
    fromCountryId: String(fromCountryId),
    fromCountryName: fromCountry.name,
    fromCountryFlag: fromCountry.flag,
    toCountryId: String(toCountryId),
    toCountryName: toCountry.name,
    toCountryFlag: toCountry.flag,
    pactType, // 'non_aggression' | 'friendship'
    note: String(note || '').trim().slice(0, 300),
    status: 'active', // مستقیم و بدون مذاکره
    createdAt: new Date(),
  };
  await ref.set(pact);
  return pact;
}

// قطع روابط تجاری با یک کشور (باعث افت ۵ درصدی درآمد هر دو کشور می‌شود)
async function cutTradeRelations({ sourceCountryId, targetCountryId, seasonId }) {
  if (sourceCountryId === targetCountryId) throw new GameError('نمی‌توانید روابط تجاری با خودتان را قطع کنید.');
  const [sourceCountry, targetCountry] = await Promise.all([
    countryService.get(sourceCountryId),
    countryService.get(targetCountryId),
  ]);
  if (!sourceCountry || !targetCountry) throw new GameError('کشور مبدأ یا مقصد یافت نشد.');

  const [sourceState, targetState] = await Promise.all([
    gameService.getCountryState(sourceCountryId, seasonId),
    gameService.getCountryState(targetCountryId, seasonId),
  ]);

  const sourceSevered = sourceState.severedTrades || [];
  if (sourceSevered.includes(String(targetCountryId))) {
    throw new GameError('روابط تجاری شما با این کشور قبلاً قطع شده است.');
  }

  // افت ۵ درصدی از درآمد روزانه هر دو کشور
  const sourceOldIncome = sourceState.incomeDaily || 300000000;
  const targetOldIncome = targetState.incomeDaily || 300000000;

  const sourceDrop = Math.max(1000000, Math.floor(sourceOldIncome * 0.05));
  const targetDrop = Math.max(1000000, Math.floor(targetOldIncome * 0.05));

  const sourceNewIncome = Math.max(10000000, sourceOldIncome - sourceDrop);
  const targetNewIncome = Math.max(10000000, targetOldIncome - targetDrop);

  const updatedSourceSevered = [...sourceSevered, String(targetCountryId)];
  const targetSevered = targetState.severedTrades || [];
  const updatedTargetSevered = targetSevered.includes(String(sourceCountryId)) ? targetSevered : [...targetSevered, String(sourceCountryId)];

  await gameService.updateCountryState(sourceCountryId, seasonId, {
    incomeDaily: sourceNewIncome,
    severedTrades: updatedSourceSevered,
  });

  await gameService.updateCountryState(targetCountryId, seasonId, {
    incomeDaily: targetNewIncome,
    severedTrades: updatedTargetSevered,
  });

  const ref = col('trade_embargoes').doc();
  const embargo = {
    id: ref.id,
    seasonId: String(seasonId),
    sourceCountryId: String(sourceCountryId),
    sourceCountryName: sourceCountry.name,
    targetCountryId: String(targetCountryId),
    targetCountryName: targetCountry.name,
    sourceDrop,
    targetDrop,
    createdAt: new Date(),
  };
  await ref.set(embargo);

  return {
    sourceCountry,
    targetCountry,
    sourceDrop,
    targetDrop,
    sourceNewIncome,
    targetNewIncome,
  };
}

module.exports = {
  TRADE_ITEMS,
  getTradeOffer,
  listIncomingOffers,
  listOutgoingOffers,
  createTradeOffer,
  acceptTradeOffer,
  rejectTradeOffer,
  cancelTradeOffer,
  sendDirectPact,
  cutTradeRelations,
};

