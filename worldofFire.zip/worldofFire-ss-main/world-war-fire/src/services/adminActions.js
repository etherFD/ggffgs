'use strict';
// اقدامات مدیریتی مشترک بین داشبورد وب و پنل تلگرام: اعتبارسنجی + اجرا + حسابرسی + اطلاع به بازیکن
const { mainMenu } = require('../bot/keyboards/main');
const selection = require('./selectionService');
const ownership = require('./ownershipService');
const countryService = require('./countryService');
const gameService = require('./gameService');
const userService = require('./userService');
const seasonService = require('./seasonService');
const settings = require('./settingsService');
const notifications = require('./notificationService');
const { audit } = require('./auditService');
const { GameError } = require('../utils/errors');
const { esc, parseNonNegInt, toLatinDigits } = require('../utils/text');
const logger = require('../utils/logger');

// ---------- درخواست‌ها ----------
async function approvePayment(telegram, requestId, adminId, via) {
  const req = await selection.approvePayment({ requestId, adminTelegramId: adminId });
  await audit(adminId, 'payment.approve', req.id, null, via);
  await notifications.safeSend(telegram, req.userId, '✅ پرداخت شما تأیید شد. مدیر به‌زودی کشور را به شما اختصاص می‌دهد.');
  return req;
}

async function rejectPayment(telegram, requestId, adminId, note, via) {
  const n = note && note !== '-' ? String(note).slice(0, 500) : null;
  const req = await selection.rejectPayment({ requestId, adminTelegramId: adminId, note: n });
  await audit(adminId, 'payment.reject', req.id, { note: n }, via);
  await notifications.safeSend(telegram, req.userId, `❌ پرداخت شما رد شد.${n ? `\nدلیل: ${esc(n)}` : ''}\nمی‌توانید دوباره کشور انتخاب کنید.`);
  return req;
}

async function assignRequest(telegram, requestId, adminId, via) {
  const req = await selection.approveAndAssign({ requestId, adminTelegramId: adminId });
  await audit(adminId, 'country.assign', req.id, { country: req.countryId, user: req.userId }, via);
  const c = await countryService.get(req.countryId);
  const u = await userService.getById(req.userId);
  const season = await seasonService.getActiveSeason();
  const state = season ? await gameService.getCountryState(req.countryId, season.id) : null;
  const flag = countryService.getDynamicFlag(c, state || {});
  await notifications.safeSend(telegram, req.userId, `🎉 تبریک! کشور ${esc(flag)} <b>${esc(c.name)}</b> به شما اختصاص یافت.\nاز منوی زیر مدیریت کشور خود را شروع کنید.`, mainMenu());

  const announceText = [
    '🏳️ <b>کشور جدیدی وارد بازی شد</b>',
    '– – – – – – – – – –',
    `کشور ${esc(flag)} <b>${esc(c.name)}</b> رهبر جدیدی پیدا کرد و رسماً وارد ${season ? esc(season.name) : 'سیزن جدید'} شد`,
    '',
    `👑 رهبر ~ <b>${esc(u?.displayName || req.displayName || 'ناشناس')}</b>`,
    '',
    '🌍 خوش آمدی، نقشه‌ی جهان دوباره عوض شد',
  ].join('\n');
  await notifications.publishToChannel(telegram, 'leader_change', announceText).catch(() => {});
  return req;
}

async function rejectRequest(telegram, requestId, adminId, note, via) {
  const n = note && note !== '-' ? String(note).slice(0, 500) : null;
  const req = await selection.rejectRequest({ requestId, adminTelegramId: adminId, note: n });
  await audit(adminId, 'request.reject', req.id, { note: n }, via);
  await notifications.safeSend(telegram, req.userId, `❌ درخواست انتخاب کشور شما رد شد.${n ? `\nدلیل: ${esc(n)}` : ''}\nمی‌توانید دوباره کشور انتخاب کنید.`);
  return req;
}

// ---------- کشورها ----------
async function createCountry(adminId, data, via) {
  const c = await countryService.create(data);
  await audit(adminId, 'country.create', c.id, { name: c.name }, via);
  return c;
}
async function updateCountry(adminId, id, patch, via) {
  if (patch.isActive === false) {
    const season = await seasonService.getActiveSeason();
    if (season && (await ownership.getOwnerOfCountry(id, season.id))) throw new GameError('ابتدا کشور را از مالک فعلی آزاد کنید.');
  }
  const previousCountry = await countryService.get(id);
  const c = await countryService.update(id, patch);
  // اگر ادمین سقف پایه مخزن را تغییر دهد، کشور فعال هم همان لحظه به‌روزرسانی می‌شود؛ ظرفیت اکتشاف‌شده حفظ می‌شود.
  if (patch.oilReserve !== undefined) {
    const season = await seasonService.getActiveSeason();
    if (season) {
      const state = await gameService.getCountryState(id, season.id);
      const previousBase = Math.max(0, Number(previousCountry?.oilReserve ?? 5000));
      const existingTotal = Number(state.oilReserve ?? previousBase);
      const bonus = state.oilReserveBonus !== undefined
        ? Math.max(0, Number(state.oilReserveBonus) || 0)
        : Math.max(0, existingTotal - previousBase);
      const newBase = Math.max(0, Number(c.oilReserve ?? 5000));
      await gameService.updateCountryState(id, season.id, { oilReserve: newBase + bonus, oilReserveBonus: bonus });
    }
  }
  await audit(adminId, 'country.update', id, patch, via);
  return c;
}
async function seedCountries(adminId, via) {
  const r = await countryService.seedDefaults();
  await audit(adminId, 'country.seed', null, r, via);
  return r;
}
async function manualAssign(telegram, countryId, playerQuery, adminId, via) {
  const n = parseNonNegInt(playerQuery);
  if (n === null) throw new GameError('یک شناسه عددی (شناسه بازی یا Telegram ID) وارد کنید.');
  const u = await userService.findByAnyId(n);
  if (!u) throw new GameError('بازیکنی با این شناسه پیدا نشد (بازیکن باید حداقل یک بار /start زده باشد).');
  const season = await seasonService.getActiveSeason();
  if (!season) throw new GameError('سیزن فعالی وجود ندارد.');
  await ownership.assignCountry({ userTelegramId: u.telegramId, countryId, seasonId: season.id, adminTelegramId: adminId });
  await audit(adminId, 'country.assign.manual', countryId, { user: u.telegramId }, via);
  const c = await countryService.get(countryId);
  await notifications.safeSend(telegram, u.telegramId, `🎉 کشور ${esc(c.flag)} <b>${esc(c.name)}</b> توسط مدیریت به شما اختصاص یافت.`, mainMenu());

  const announceText = [
    '🏳️ <b>کشور جدیدی وارد بازی شد</b>',
    '– – – – – – – – – –',
    `کشور ${esc(c.flag)} <b>${esc(c.name)}</b> رهبر جدیدی پیدا کرد و رسماً وارد ${season ? esc(season.name) : 'سیزن جدید'} شد`,
    '',
    `👑 رهبر ~ <b>${esc(u?.displayName || 'ناشناس')}</b>`,
    '',
    '🌍 خوش آمدی، نقشه‌ی جهان دوباره عوض شد',
  ].join('\n');
  await notifications.publishToChannel(telegram, 'leader_change', announceText).catch(() => {});
  return { user: u, country: c };
}
async function releaseCountry(telegram, countryId, adminId, via) {
  const season = await seasonService.getActiveSeason();
  if (!season) throw new GameError('سیزن فعالی وجود ندارد.');
  const own = await ownership.releaseOwnership({ countryId, seasonId: season.id, reason: `released_by_admin:${adminId}` });
  await audit(adminId, 'country.release', countryId, { user: own.userId }, via);
  const c = await countryService.get(countryId);
  await notifications.safeSend(telegram, own.userId, `ℹ️ کشور ${esc(c.flag)} ${esc(c.name)} توسط مدیریت از شما آزاد شد. می‌توانید کشور جدیدی انتخاب کنید.`);
  return own;
}

// ---------- بازیکنان / سیزن ----------
async function banPlayer(telegram, telegramId, reason, adminId, via) {
  const r = reason && reason !== '-' ? String(reason).slice(0, 300) : null;
  const u = await userService.ban(telegramId, r);
  await audit(adminId, 'player.ban', telegramId, { reason: r }, via);
  await notifications.safeSend(telegram, u.telegramId, `⛔ حساب شما مسدود شد.${r ? `\nدلیل: ${esc(r)}` : ''}`);
  return u;
}
async function unbanPlayer(telegram, telegramId, adminId, via) {
  const u = await userService.unban(telegramId);
  await audit(adminId, 'player.unban', telegramId, null, via);
  await notifications.safeSend(telegram, u.telegramId, '✅ مسدودی حساب شما برداشته شد.');
  return u;
}

// ---------- سیزن ----------
async function createSeason(arg1, arg2, arg3, arg4) {
  let telegram = null, adminId = 0, name = '', via = 'web';
  if (arg1 && typeof arg1 === 'object' && (arg1.sendMessage || arg1.telegram)) {
    telegram = arg1.telegram || arg1; adminId = arg2; name = arg3; via = arg4;
  } else {
    adminId = arg1; name = arg2; via = arg3;
  }
  const s = await seasonService.createSeason({ name: String(name || '').trim() });
  await audit(adminId, 'season.create', s.id, { name: s.name }, via);
  if (telegram) {
    await notifications.announceSeasonChange(telegram, { type: 'create', seasonName: s.name });
  }
  return s;
}

async function resetCurrentSeason(arg1, arg2, arg3) {
  let telegram = null, adminId = 0, via = 'web';
  if (arg1 && typeof arg1 === 'object' && (arg1.sendMessage || arg1.telegram)) {
    telegram = arg1.telegram || arg1; adminId = arg2; via = arg3;
  } else {
    adminId = arg1; via = arg2;
  }
  const season = await seasonService.getActiveSeason();
  const seasonName = season ? season.name : 'جاری';
  const res = await seasonService.resetSeason();
  await audit(adminId, 'season.reset', res.seasonId, res, via);
  if (telegram) {
    await notifications.announceSeasonChange(telegram, { type: 'reset', seasonName });
  }
  return res;
}

async function deleteCurrentSeason(arg1, arg2, arg3) {
  let telegram = null, adminId = 0, via = 'web';
  if (arg1 && typeof arg1 === 'object' && (arg1.sendMessage || arg1.telegram)) {
    telegram = arg1.telegram || arg1; adminId = arg2; via = arg3;
  } else {
    adminId = arg1; via = arg2;
  }
  const season = await seasonService.getActiveSeason();
  const seasonName = season ? season.name : 'جاری';
  const res = await seasonService.deleteSeason();
  await audit(adminId, 'season.delete', res.deletedId, res, via);
  if (telegram) {
    await notifications.announceSeasonChange(telegram, { type: 'delete', seasonName });
  }
  return res;
}

async function advanceSeason(arg1, arg2, arg3, arg4) {
  let telegram = null, adminId = 0, winnerNote = '', via = 'web';
  if (arg1 && typeof arg1 === 'object' && (arg1.sendMessage || arg1.telegram)) {
    telegram = arg1.telegram || arg1; adminId = arg2; winnerNote = arg3; via = arg4;
  } else {
    adminId = arg1; winnerNote = arg2; via = arg3;
  }
  const res = await seasonService.advanceSeason({ winnerNote });
  await audit(adminId, 'season.advance', res.newSeason.id, res, via);
  if (telegram) {
    await notifications.announceSeasonChange(telegram, { type: 'create', seasonName: res.newSeason.name, details: winnerNote });
  }
  return res;
}

// ---------- تنظیمات ----------
const SETTING_DEFS = {
  channelId: { label: 'شناسه کانال رسمی (@channel یا -100...) (عضویت اجباری)', clearable: true },
  channelLink: { label: 'لینک جوین کانال رسمی (https://t.me/...)', clearable: true },
  groupId: { label: 'شناسه ابرگروه رسمی (@group یا -100...) (عضویت اجباری)', clearable: true },
  groupLink: { label: 'لینک جوین گروه رسمی (https://t.me/...)', clearable: true },
  channelName: { label: 'نام کانال', clearable: true },
  gameName: { label: 'نام بازی', clearable: true },
  adminBotToken: { label: 'توکن ربات اختصاصی ادمین (پیام‌ها و تاییدها)', secret: true, clearable: true },
  adminChatId: { label: 'شناسه تلگرام ادمین جهت دریافت اعلان‌ها (Chat ID)', clearable: true },
  paymentCardNumber: { label: 'شماره کارت پرداخت', secret: true },
  paymentCardHolder: { label: 'نام صاحب کارت' },
  paymentNote: { label: 'توضیح پرداخت', clearable: true },
  countryCooldownHours: { label: 'انتظار انتخاب مجدد کشور (ساعت)' },
  capitalChangeCost: { label: 'هزینه تغییر استان پایتخت ملی ($)' },
  oilExplorationCost: { label: 'هزینه اعزام تیم اکتشاف نفت ($)' },
  plant_wind_cost: { label: 'هزینه احداث نیروگاه بادی ($)' },
  plant_solar_cost: { label: 'هزینه احداث برق خورشیدی ($)' },
  plant_hydro_cost: { label: 'هزینه احداث سد برق‌آبی ($)' },
  plant_fuel_cost: { label: 'هزینه احداث نیروگاه سوختی فسیلی ($)' },
  plant_nuclear_cost: { label: 'هزینه احداث نیروگاه اتمی ($)' },
  water_wastewater_cost: { label: 'هزینه تصفیه آب فاضلاب ($)' },
  water_groundwater_cost: { label: 'هزینه حفر چاه و آب زیرزمینی ($)' },
  water_desalination_cost: { label: 'هزینه تصفیه آب دریا ($)' },
  gas_storage_cost: { label: 'هزینه ساخت مخازن گاز ($)' },
  gas_flare_cost: { label: 'هزینه جمع‌آوری گاز مشعل ($)' },
  quell_police_cost: { label: 'هزینه یگان ویژه و پلیس ضدشورش ($)' },
  quell_military_cost: { label: 'هزینه سرکوب قهرآمیز ارتش ($)' },
  quell_reform_cost: { label: 'هزینه شورای اصلاحات و عفو عمومی ($)' },
};

async function getSettingsView() {
  const out = {};
  for (const [k, d] of Object.entries(SETTING_DEFS)) {
    try {
      let v = await settings.get(k, null);
      if (k === 'channelId') v = await settings.getChannelId().catch(() => '');
      if (k === 'channelName' || k === 'gameName') {
        const brand = await settings.getBrand().catch(() => ({}));
        v = (brand || {})[k] || '';
      }
      if (k === 'countryCooldownHours' && v === null) v = 24;
      if (k === 'capitalChangeCost' && v === null) v = 250000000;
      if (k === 'oilExplorationCost' && v === null) v = 450000000;
      out[k] = { label: d.label, value: v };
    } catch (_) {
      out[k] = { label: d.label, value: null };
    }
  }
  return out;
}

async function setSetting(telegram, key, rawValue, adminId, via) {
  const def = SETTING_DEFS[key];
  if (!def) throw new GameError('تنظیم نامعتبر است.');
  const text = String(rawValue ?? '').trim();
  if (!text) throw new GameError('مقدار خالی است.');
  if (text === '-' && def.clearable) {
    await settings.unset(key);
    await audit(adminId, `setting.unset.${key}`, null, null, via);
    return { message: 'حذف شد (مقدار پیش‌فرض اعمال می‌شود).' };
  }
  let value = text;
  let message = 'ذخیره شد.';
  if (key === 'channelId') {
    if (!/^(@[A-Za-z][A-Za-z0-9_]{3,})$|^-100\d{6,}$/.test(text)) throw new GameError('قالب شناسه معتبر نیست. نمونه: @my_channel یا -1001234567890');
    const r = await notifications.verifyChannel(telegram, text);
    if (!r.ok) throw new GameError(`${r.reason} ربات را ادمین کانال کنید و دوباره تلاش کنید.`);
    message = `کانال «${r.title}» تنظیم شد و ربات مجوز ارسال دارد.`;
  } else if (key === 'countryCooldownHours') {
    const n = parseNonNegInt(text);
    if (n === null || n > 24 * 60) throw new GameError('یک عدد معتبر (ساعت) وارد کنید.');
    value = n;
  } else if (key === 'capitalChangeCost' || key === 'oilExplorationCost') {
    const n = parseNonNegInt(text);
    if (n === null || n > Number.MAX_SAFE_INTEGER) throw new GameError('هزینه باید یک عدد صحیح نامنفی و معتبر باشد.');
    value = n;
  } else if (key === 'paymentCardNumber') {
    const digits = toLatinDigits(text).replace(/[\s-]/g, '');
    if (!/^\d{12,19}$/.test(digits)) throw new GameError('شماره کارت معتبر نیست.');
    value = digits;
  } else if (key === 'adminBotToken') {
    if (text.length < 20 || !text.includes(':')) throw new GameError('توکن ربات نامعتبر است.');
    value = text;
    // راه‌اندازی یا به‌روزرسانی ربات دوم
    try {
      const adminBotService = require('./adminBotService');
      await adminBotService.initAdminBot(telegram);
    } catch (_) {}
  } else if (text.length > 200) {
    throw new GameError('حداکثر ۲۰۰ کاراکتر.');
  }
  await settings.set(key, value, adminId);
  await audit(adminId, `setting.set.${key}`, null, def.secret ? { masked: true } : { value }, via);
  return { message };
}

// ---------- اطلاعیه هدفمند (کاربران / کانال / هر دو) ----------
async function broadcast(telegram, payload, adminId, via) {
  let text = '';
  let target = 'both'; // 'both' | 'channel' | 'users'
  let photoUrl = null;

  if (typeof payload === 'string') {
    text = payload;
  } else if (payload && typeof payload === 'object') {
    text = payload.text || '';
    target = payload.target || 'both';
    photoUrl = payload.photoUrl ? String(payload.photoUrl).trim() : null;
  }

  const t = String(text || '').trim();
  if (!t || t.length > 3000) throw new GameError('متن اطلاعیه باید بین ۱ تا ۳۰۰۰ کاراکتر باشد.');
  const body = `📢 <b>اطلاعیه رسمی</b>\n\n${esc(t)}`;

  await audit(adminId, 'broadcast.send', null, { length: t.length, target, hasPhoto: !!photoUrl }, via);

  let photoSource = null;
  if (photoUrl) {
    try {
      photoSource = await notifications.resolvePhotoSource(photoUrl);
    } catch (e) {
      logger.warn('خطا در تبدیل تصویر اطلاعیه:', e.message);
    }
  }

  let channel = 'skipped';
  // ۱. ارسال به کانال (در صورت انتخاب channel یا both)
  if (target === 'channel' || target === 'both') {
    try {
      let r = null;
      if (photoSource) {
        r = await notifications.publishPhotoToChannel(telegram, 'announcement', photoSource, body);
      } else {
        r = await notifications.publishToChannel(telegram, 'announcement', body);
      }
      channel = r ? 'ok' : 'skipped';
    } catch (err) {
      logger.warn('انتشار اطلاعیه در کانال ناموفق بود:', err.description || err.message);
      channel = 'failed';
    }
  }

  // ۲. ارسال به کاربران (در صورت انتخاب users یا both)
  let ok = 0;
  let fail = 0;
  if (target === 'users' || target === 'both') {
    const users = (await userService.listAll()).filter((u) => u.status === 'active');
    const returnMarkup = {
      inline_keyboard: [[{ text: '🔙 بازگشت به منوی اصلی', callback_data: 'menu:home' }]],
    };
    for (const u of users) {
      try {
        let r = null;
        if (photoSource) {
          const safeCaption = body.length > 980 ? body.slice(0, 970) + '...' : body;
          r = await telegram.sendPhoto(u.telegramId, photoSource, {
            caption: safeCaption,
            parse_mode: 'HTML',
            reply_markup: returnMarkup,
          });
        } else {
          r = await notifications.safeSend(telegram, u.telegramId, body, { reply_markup: returnMarkup });
        }
        if (r) ok++; else fail++;
      } catch (_) {
        fail++;
      }
      await new Promise((res) => setTimeout(res, 40)); // رعایت محدودیت نرخ تلگرام
    }
  }

  return { ok, fail, channel, target };
}

// ---------- عملیات انضباطی ربات ادمین (جریمه، خلع ید، بن از سیزن) ----------
async function finePlayer(telegram, countryId, dollarAmount, shahiAmount = 0, reason = '', adminId = 0, via = 'admin_bot') {
  const season = await seasonService.getActiveSeason();
  if (!season) throw new GameError('سیزنی فعال نیست.');
  const owner = await ownership.getOwnerOfCountry(countryId, season.id);
  const country = await countryService.get(countryId);
  const state = await gameService.getCountryState(countryId, season.id);

  const fineD = Math.max(0, Math.floor(Number(dollarAmount) || 0));
  const fineS = Math.max(0, Math.floor(Number(shahiAmount) || 0));

  const newTreasury = Math.max(0, (state.treasury || 0) - fineD);
  const newShahi = Math.max(0, (state.shahiCoins || 0) - fineS);

  await gameService.updateCountryState(countryId, season.id, {
    treasury: newTreasury,
    shahiCoins: newShahi,
    legitimacy: Math.max(0, (state.legitimacy || 100) - 15),
  });

  if (owner) {
    const notifyText = [
      '⚖️ <b>حکم انضباطی مدیریت بازی</b>',
      '– – – – – – – – – –',
      `🌍 کشور شما (${country ? country.flag + ' ' + country.name : countryId}) مشمول جریمه اداری گردید:`,
      fineD > 0 ? `🔻 کسر نقدی از خزانه: <b>-${fineD.toLocaleString()}$</b>` : null,
      fineS > 0 ? `🔻 کسر سکه شاهی: <b>-${fineS} سکه</b>` : null,
      reason ? `📝 علت: <i>${esc(reason)}</i>` : null,
    ].filter(Boolean).join('\n');
    await notifications.safeSend(telegram, owner.userId, notifyText);
  }

  await audit(adminId, 'player.fine', countryId, { fineD, fineS, reason }, via);
  return { country, owner, fineD, fineS, newTreasury, newShahi };
}

async function removeCountryOwnership(telegram, countryId, reason = '', adminId = 0, via = 'admin_bot') {
  const season = await seasonService.getActiveSeason();
  if (!season) throw new GameError('سیزنی فعال نیست.');
  const owner = await ownership.getOwnerOfCountry(countryId, season.id);
  const country = await countryService.get(countryId);

  const released = await ownership.releaseOwnership({
    countryId,
    seasonId: season.id,
    reason: `revoked_by_admin:${adminId}:${reason || 'disapproval'}`,
  });

  if (owner) {
    await notifications.safeSend(
      telegram,
      owner.userId,
      `🚫 <b>سلب مالکیت و خلع ید از رهبری کشور</b>\nمالکیت شما بر کشور ${country ? country.flag + ' ' + country.name : countryId} توسط مدیریت بازی لغو گردید.${reason ? `\nعلت: ${esc(reason)}` : ''}`
    );
  }

  await audit(adminId, 'player.revoke_country', countryId, { user: owner?.userId, reason }, via);
  return { country, owner, released };
}

async function banPlayerFromSeason(telegram, countryIdOrUserId, reason = '', adminId = 0, via = 'admin_bot') {
  const season = await seasonService.getActiveSeason();
  if (!season) throw new GameError('سیزنی فعال نیست.');

  let targetUserId = null;
  let country = null;

  const owner = await ownership.getOwnerOfCountry(countryIdOrUserId, season.id);
  if (owner) {
    targetUserId = owner.userId;
    country = await countryService.get(countryIdOrUserId);
    await ownership.releaseOwnership({
      countryId: countryIdOrUserId,
      seasonId: season.id,
      reason: `banned_from_season:${adminId}:${reason || 'disciplinary'}`,
    });
  } else {
    targetUserId = Number(countryIdOrUserId);
  }

  // ثبت در لیست بن سیزن
  const { col } = require('../db/firestore');
  await col('season_bans').doc(`${season.id}_${targetUserId}`).set({
    seasonId: season.id,
    userId: targetUserId,
    reason: reason || 'تخلف از قوانین بازی و رفتار نامتعارف',
    bannedBy: adminId,
    createdAt: new Date(),
  });

  if (targetUserId) {
    await notifications.safeSend(
      telegram,
      targetUserId,
      `🔨 <b>حکم محرومیت (بن) از سیزن فعال!</b>\nشما تا پایان سیزن جاری (${esc(season.name)}) از تصدی رهبری کشورها و شرکت در جنگ محروم شدید.\nدلیل: ${esc(reason || 'تخلف انضباطی')}`
    );
  }

  await audit(adminId, 'player.season_ban', targetUserId, { seasonId: season.id, reason }, via);
  return { season, targetUserId, country };
}

async function grantMoneyAndCoinsWithRank(telegram, countryId, rankText, dollarAmount, shahiAmount, adminId = 0, via = 'admin_bot') {
  const season = await seasonService.getActiveSeason();
  if (!season) throw new GameError('سیزنی فعال نیست.');
  const country = await countryService.get(countryId);
  const owner = await ownership.getOwnerOfCountry(countryId, season.id);
  const state = await gameService.getCountryState(countryId, season.id);

  const addedDollars = Math.max(0, Math.floor(Number(dollarAmount) || 0));
  const addedShahi = Math.max(0, Math.floor(Number(shahiAmount) || 0));

  const newTreasury = (state.treasury || 0) + addedDollars;
  const newShahi = (state.shahiCoins || 0) + addedShahi;

  await gameService.updateCountryState(countryId, season.id, {
    treasury: newTreasury,
    shahiCoins: newShahi,
  });

  if (owner) {
    const notifyText = [
      '👑 <b>اعطای ویژه جایزه و رتبه توسط مدیریت بازی!</b>',
      '– – – – – – – – – –',
      `🌍 به رهبر کشور: <b>${country ? country.flag + ' ' + country.name : countryId}</b>`,
      rankText ? `🏅 <b>رتبه / عنوان ثبت‌شده:</b> ${esc(rankText)}` : null,
      addedDollars > 0 ? `💵 <b>مبلغ نقدی افزوده شده:</b> +${addedDollars.toLocaleString()}$` : null,
      addedShahi > 0 ? `👑 <b>سکه شاهی افزوده شده:</b> +${addedShahi} سکه` : null,
      '',
      `🏦 موجودی کل جدید خزانه: <b>${newTreasury.toLocaleString()}$</b>`,
      `👑 موجودی جدید سکه شاهی: <b>${newShahi} سکه</b>`,
    ].filter(Boolean).join('\n');

    await notifications.safeSend(telegram, owner.userId, notifyText);
  }

  await audit(adminId, 'grant.money_coins_rank', countryId, { rankText, addedDollars, addedShahi }, via);
  return { country, owner, rankText, addedDollars, addedShahi, newTreasury, newShahi };
}

async function togglePayoutFreeze(adminId, freezeStatus = null, via = 'admin_bot') {
  const currentFrozen = await settings.isPayoutsFrozen();
  const nextStatus = freezeStatus !== null ? Boolean(freezeStatus) : !currentFrozen;
  await settings.setPayoutsFrozen(nextStatus, adminId);
  await audit(adminId, 'payouts.toggle_freeze', null, { frozen: nextStatus }, via);
  return { frozen: nextStatus };
}

async function setPayoutIntervalMinutes(adminId, minutes, via = 'admin_bot') {
  const mins = Math.max(1, Number(minutes) || 10);
  await settings.setPayoutInterval(mins, adminId);
  await audit(adminId, 'payouts.set_interval', null, { intervalMinutes: mins }, via);
  return { intervalMinutes: mins };
}

async function resetPlayerAssets(telegram, countryId, reason = '', adminId = 0, via = 'admin_bot') {
  const season = await seasonService.getActiveSeason();
  if (!season) throw new GameError('سیزنی فعال نیست.');

  const country = await countryService.get(countryId);
  if (!country) throw new GameError('کشور مورد نظر یافت نشد.');

  const defaultState = gameService.defaultCountryState(country);
  await gameService.updateCountryState(countryId, season.id, {
    treasury: defaultState.treasury,
    shahiCoins: 0,
    oil: defaultState.oil || 1500,
    stockShares: {},
    customEnterprises: [],
    megaprojects: [],
    inventory: {},
    telecomOperator: null,
    'military.attack': defaultState.military?.attack || 2124,
    'military.defense': defaultState.military?.defense || 2459,
    groundUnits: defaultState.groundUnits,
    airUnits: defaultState.airUnits,
    missiles: defaultState.missiles,
    airDefense: defaultState.airDefense,
    navalUnits: {},
    sanctionUntil: null,
  });

  const owner = await ownership.getOwnerOfCountry(countryId, season.id);
  if (owner) {
    const notifyText = [
      '⚠️ <b>اخطار انضباطی: ریست کامل دارایی‌های کشور</b>',
      '– – – – – – – – – –',
      `کلیه موجودی خزانه، سکه‌ها، سهام، پروژه‌ها و تسلیحات کشور <b>${country.flag} ${esc(country.name)}</b> توسط مدیریت بازی ریست شد.`,
      reason ? `📝 دلیل: <i>${esc(reason)}</i>` : null,
      '',
      'موجودی کشور به مقادیر پایه اولیه بازگردانده شد.',
    ].filter(Boolean).join('\n');
    await notifications.safeSend(telegram, owner.userId, notifyText);
  }

  await audit(adminId, 'player.reset_assets', countryId, { reason }, via);
  return { country, owner, defaultState };
}

module.exports = {
  approvePayment, rejectPayment, assignRequest, rejectRequest,
  createCountry, updateCountry, seedCountries, manualAssign, releaseCountry,
  banPlayer, unbanPlayer, createSeason, resetCurrentSeason, deleteCurrentSeason, advanceSeason,
  getSettingsView, setSetting, broadcast, SETTING_DEFS,
  finePlayer, removeCountryOwnership, banPlayerFromSeason, grantMoneyAndCoinsWithRank,
  togglePayoutFreeze, setPayoutIntervalMinutes, resetPlayerAssets,
};


