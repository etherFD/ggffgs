'use strict';
const { db, col, snap, docs } = require('../db/firestore');
const locks = require('../db/locks');
const countryService = require('./countryService');
const { GameError } = require('../utils/errors');

const lockRef = (id) => col('locks').doc(id);

const ownershipCache = new Map();
const OWN_CACHE_TTL = 30000; // ۳۰ ثانیه

function invalidateOwnershipCache(userTelegramId) {
  if (userTelegramId) {
    const sId = String(userTelegramId);
    const suffix = `_${sId}`;
    for (const k of ownershipCache.keys()) {
      if (k === sId || k.endsWith(suffix)) {
        ownershipCache.delete(k);
      }
    }
  } else {
    ownershipCache.clear();
  }
}

// مالکیت فعال بازیکن در سیزن (با country پر می‌شود) یا null
async function getActiveOwnership(userTelegramId, seasonId) {
  if (!seasonId || !userTelegramId) return null;
  const key = `${seasonId}_${userTelegramId}`;
  const cached = ownershipCache.get(key);
  if (cached && Date.now() - cached._cachedAt < OWN_CACHE_TTL) {
    return cached.data;
  }

  const l = await lockRef(locks.ownUser(seasonId, userTelegramId)).get();
  if (!l.exists) {
    ownershipCache.set(key, { data: null, _cachedAt: Date.now() });
    return null;
  }
  const own = snap(await col('ownerships').doc(l.data().ownershipId).get());
  if (!own) {
    ownershipCache.set(key, { data: null, _cachedAt: Date.now() });
    return null;
  }
  own.country = await countryService.get(own.countryId);
  ownershipCache.set(key, { data: own, _cachedAt: Date.now() });
  return own;
}

async function getOwnerOfCountry(countryId, seasonId) {
  const l = await lockRef(locks.ownCountry(seasonId, countryId)).get();
  if (!l.exists) return null;
  return snap(await col('ownerships').doc(l.data().ownershipId).get());
}

async function ownedCountryIds(seasonId) {
  const q = await col('ownerships').where('seasonId', '==', seasonId).where('status', '==', 'active').get();
  return docs(q).map((o) => o.countryId);
}

async function listActive(seasonId) {
  const q = await col('ownerships').where('seasonId', '==', seasonId).where('status', '==', 'active').get();
  return docs(q);
}

// تخصیص دستی/مدیریتی؛ همه‌چیز (قفل‌ها، مالکیت، بستن درخواست باز) در یک تراکنش
async function assignCountry({ userTelegramId, countryId, seasonId, adminTelegramId = null }) {
  const ownRef = col('ownerships').doc();
  const cLock = lockRef(locks.ownCountry(seasonId, countryId));
  const uLock = lockRef(locks.ownUser(seasonId, userTelegramId));
  const rLock = lockRef(locks.reqLock(seasonId, userTelegramId));
  const userRef = col('users').doc(String(userTelegramId));
  const countryRef = col('countries').doc(String(countryId));
  const stateRef = col('country_states').doc(`${seasonId}_${countryId}`);
  return db().runTransaction(async (tx) => {
    const [userS, countryS, cS, uS, rS, stateS] = [await tx.get(userRef), await tx.get(countryRef), await tx.get(cLock), await tx.get(uLock), await tx.get(rLock), await tx.get(stateRef)];
    if (!userS.exists) throw new GameError('بازیکن یافت نشد.');
    if (userS.data().status === 'banned') throw new GameError('این بازیکن مسدود است.');
    if (!countryS.exists || !countryS.data().isActive) throw new GameError('این کشور وجود ندارد یا غیرفعال است.');
    if (stateS.exists && stateS.data().fallen) throw new GameError('این کشور در این سیزن سقوط کرده و تا سیزن بعد قابل انتخاب نیست.');
    if (cS.exists) throw new GameError('این کشور در این سیزن قبلاً به بازیکن دیگری اختصاص داده شده است.');
    if (uS.exists) throw new GameError('این بازیکن در این سیزن از قبل یک کشور فعال دارد.');
    let reqS = null;
    if (rS.exists) reqS = await tx.get(col('requests').doc(rS.data().requestId));
    const data = { seasonId, countryId, userId: userTelegramId, status: 'active', startedAt: new Date(), endedAt: null, endReason: null, requestId: null, assignedByTelegramId: adminTelegramId, createdAt: new Date() };
    tx.create(ownRef, data);
    tx.set(cLock, { ownershipId: ownRef.id });
    tx.set(uLock, { ownershipId: ownRef.id });
    if (reqS && reqS.exists) {
      tx.update(reqS.ref, { status: 'cancelled', isOpen: false, adminNote: 'تخصیص دستی توسط مدیر' });
      tx.delete(rLock);
    }
    invalidateOwnershipCache(userTelegramId);
    return { id: ownRef.id, ...data };
  });
}

async function releaseOwnership({ countryId, seasonId, reason = 'released', status = 'released' }) {
  const cLock = lockRef(locks.ownCountry(seasonId, countryId));
  const res = await db().runTransaction(async (tx) => {
    const cS = await tx.get(cLock);
    if (!cS.exists) throw new GameError('این کشور در حال حاضر مالک فعالی ندارد.');
    const ownRef = col('ownerships').doc(cS.data().ownershipId);
    const ownS = await tx.get(ownRef);
    const own = snap(ownS);
    tx.update(ownRef, { status, endedAt: new Date(), endReason: reason });
    tx.delete(cLock);
    tx.delete(lockRef(locks.ownUser(seasonId, own.userId)));
    invalidateOwnershipCache(own.userId);
    return own;
  });

  // ریست کامل دارایی‌های کشور به مقادیر پایه (خزانه ۴۰۰M، نفت ۱۵۰۰ و نیروهای پایه)
  try {
    const gameService = require('./gameService');
    await gameService.resetCountryAssets(countryId, seasonId);
  } catch (_) {}

  return res;
}

module.exports = { getActiveOwnership, getOwnerOfCountry, ownedCountryIds, listActive, assignCountry, releaseOwnership, invalidateOwnershipCache };
