'use strict';
const { db, col, snap, docs } = require('../db/firestore');
const locks = require('../db/locks');
const { GameError } = require('../utils/errors');

async function getActiveSeason() {
  const q = await col('seasons').where('status', '==', 'active').limit(1).get();
  if (q.empty) {
    return null;
  }
  return snap(q.docs[0]);
}

async function listSeasons(limit = 15) {
  const all = docs(await col('seasons').get());
  return all.sort((a, b) => (b.number || 0) - (a.number || 0)).slice(0, limit);
}

// ایجاد سیزن: حداکثر یک سیزن فعال (با قفل تراکنشی)
async function createSeason({ name }) {
  const lockRef = col('locks').doc(locks.activeSeason);
  const cRef = col('counters').doc('season');
  const ref = col('seasons').doc();
  return db().runTransaction(async (tx) => {
    const lock = await tx.get(lockRef);
    if (lock.exists) throw new GameError('هم‌اکنون یک سیزن فعال وجود دارد. ابتدا سیزن فعلی را به اتمام برسانید یا ریست کنید.');
    const c = await tx.get(cRef);
    const number = (c.exists ? c.data().seq : 0) + 1;
    const data = {
      number,
      name: (name || `سیزن ${number}`).slice(0, 60),
      status: 'active',
      startsAt: new Date(),
      endsAt: null,
      closedAt: null,
      createdAt: new Date(),
    };
    tx.set(cRef, { seq: number });
    tx.create(ref, data);
    tx.set(lockRef, { seasonId: ref.id });
    return { id: ref.id, ...data };
  });
}

// ریست سیزن فعلی (پاکسازی وضعیت بازی و بازگرداندن به حالت اولیه سیزن)
async function resetSeason(seasonId) {
  const season = await getActiveSeason();
  const targetId = seasonId || (season && season.id);
  if (!targetId) throw new GameError('سیزن فعالی جهت ریست یافت نشد.');

  // حذف تمام وضعیت‌های کشوری این سیزن
  const statesQ = await col('country_states').get();
  const batch = db().batch();
  let count = 0;
  for (const doc of statesQ.docs) {
    if (doc.id.startsWith(`${targetId}_`)) {
      batch.delete(doc.ref);
      count++;
    }
  }

  // حذف اعلان‌های جنگ این سیزن
  const warsQ = await col('war_declarations').where('seasonId', '==', targetId).get();
  for (const doc of warsQ.docs) {
    batch.delete(doc.ref);
  }

  await batch.commit();
  return { seasonId: targetId, resetCount: count };
}

// حذف کامل سیزن جاری
async function deleteSeason(seasonId) {
  const season = await getActiveSeason();
  const targetId = seasonId || (season && season.id);
  if (!targetId) throw new GameError('سیزنی جهت حذف یافت نشد.');

  const lockRef = col('locks').doc(locks.activeSeason);
  const seasonRef = col('seasons').doc(targetId);

  const batch = db().batch();
  batch.delete(seasonRef);
  batch.delete(lockRef);

  // پاکسازی وضعیت‌ها و اعلان‌های جنگ
  const statesQ = await col('country_states').get();
  for (const doc of statesQ.docs) {
    if (doc.id.startsWith(`${targetId}_`)) {
      batch.delete(doc.ref);
    }
  }

  await batch.commit();
  return { deletedId: targetId };
}

// اتمام سیزن جاری و آغاز سیزن بعدی
async function advanceSeason({ name, winnerNote = '' } = {}) {
  const current = await getActiveSeason();
  if (!current) throw new GameError('هیچ سیزن فعالی برای اتمام وجود ندارد.');

  const lockRef = col('locks').doc(locks.activeSeason);
  const cRef = col('counters').doc('season');
  const currentRef = col('seasons').doc(current.id);
  const nextRef = col('seasons').doc();

  return db().runTransaction(async (tx) => {
    // ۱. بستن سیزن فعلی
    tx.update(currentRef, {
      status: 'finished',
      closedAt: new Date(),
      winnerNote: winnerNote || 'سیزن با موفقیت پایان یافت.',
    });

    // ۲. محاسبه شماره سیزن جدید
    const c = await tx.get(cRef);
    const nextNumber = (c.exists ? c.data().seq : current.number || 1) + 1;
    const nextSeasonData = {
      number: nextNumber,
      name: name || `سیزن ${nextNumber}`,
      status: 'active',
      startsAt: new Date(),
      endsAt: null,
      closedAt: null,
      createdAt: new Date(),
    };

    tx.set(cRef, { seq: nextNumber });
    tx.create(nextRef, nextSeasonData);
    tx.set(lockRef, { seasonId: nextRef.id });

    return {
      previousSeason: { id: current.id, number: current.number },
      newSeason: { id: nextRef.id, ...nextSeasonData },
    };
  });
}

async function ensureDefaultSeason() {
  const active = await getActiveSeason();
  if (active) return active;
  const any = await col('seasons').limit(1).get();
  if (!any.empty) return null; // سیزن‌ها بسته شده‌اند؛ مدیر باید سیزن جدید بسازد
  return createSeason({ name: 'سیزن ۱۲' });
}

module.exports = {
  getActiveSeason,
  listSeasons,
  createSeason,
  resetSeason,
  deleteSeason,
  advanceSeason,
  ensureDefaultSeason,
};
