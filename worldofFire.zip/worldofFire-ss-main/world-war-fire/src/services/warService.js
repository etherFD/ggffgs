'use strict';
const { col, docs, snap } = require('../db/firestore');
const { GameError } = require('../utils/errors');
const countryService = require('./countryService');
const { getActiveSeason } = require('./seasonService');

async function listWars(seasonId, status = null) {
  let q = col('war_declarations');
  if (seasonId) q = q.where('seasonId', '==', seasonId);
  if (status) q = q.where('status', '==', status);
  const items = docs(await q.get());
  return items.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
}

async function getWar(id) {
  const s = await col('war_declarations').doc(id).get();
  return snap(s);
}

// ثبت رأی هر کشور برای یک جنگ؛ رأی دوباره همان کشور جایگزین رأی قبلی می‌شود.
async function castWarSideVote({ warId, countryId, side, userId }) {
  if (!['neutral', 'attacker', 'defender'].includes(side)) throw new GameError('انتخاب جبهه نامعتبر است.');
  if (!countryId || !userId) throw new GameError('شناسه کشور یا کاربر نامعتبر است.');
  const ref = col('war_declarations').doc(String(warId));
  const s = await ref.get();
  if (!s.exists) throw new GameError('جنگ موردنظر پیدا نشد.');
  const war = snap(s);
  if (!['active', 'approved'].includes(war.status)) throw new GameError('رأی‌گیری فقط برای جنگ تأییدشده و فعال ممکن است.');
  const joinDeadline = war.sideJoinDeadlineAt ? new Date(war.sideJoinDeadlineAt).getTime() : new Date(war.createdAt).getTime() + 120000;
  if (Date.now() >= joinDeadline) throw new GameError('مهلت پیوستن به جبهه تمام شده است؛ این مهلت فقط ۲ دقیقه است.');
  if (String(countryId) === String(war.attackerCountryId) || String(countryId) === String(war.defenderCountryId)) {
    throw new GameError('کشورهای درگیر نمی‌توانند به‌عنوان کشور ثالث رأی بدهند.');
  }
  const votes = { ...(war.sideVotes || {}) };
  votes[String(countryId)] = { side, userId: String(userId), updatedAt: new Date() };
  await ref.update({ sideVotes: votes, sideVotesUpdatedAt: new Date() });
  const totals = { neutral: 0, attacker: 0, defender: 0 };
  for (const vote of Object.values(votes || {})) {
    if (vote && vote.side && totals[vote.side] !== undefined) totals[vote.side]++;
  }
  return { warId: String(warId), side, totals, sideVotes: votes };
}

// ثبت اعلان جنگ (با مجوز یا بدون مجوز)
async function declareWar({
  attackerCountryId,
  defenderCountryId,
  seasonId,
  type = 'authorized', // 'authorized' | 'unauthorized'
  reason = '',
  userId,
  userDisplayName,
}) {
  if (attackerCountryId === defenderCountryId) {
    throw new GameError('نمی‌توانید به کشور خودتان اعلان جنگ بدهید!');
  }

  const [attackerCountry, defenderCountry] = await Promise.all([
    countryService.get(attackerCountryId),
    countryService.get(defenderCountryId),
  ]);

  if (!attackerCountry || !defenderCountry) {
    throw new GameError('کشور مبدأ یا مقصد یافت نشد.');
  }

  const cleanReason = String(reason || '').trim();
  if (type === 'authorized' && (!cleanReason || cleanReason.length < 5)) {
    throw new GameError('برای اعلان جنگ با مجوز، درج دلیل و توجیه منطقی (حداقل ۵ کاراکتر) الزامی است.');
  }

  // بررسی تحریم و آتش‌بس سازمان ملل برای مهاجم و مدافع
  const unService = require('./unService');
  const [attSanction, defSanction] = await Promise.all([
    unService.checkCountrySanction(attackerCountryId, seasonId),
    unService.checkCountrySanction(defenderCountryId, seasonId),
  ]);

  if (attSanction.isSanctioned) {
    throw new GameError(`کشور شما به دلیل قطعنامه سازمان ملل تا ${attSanction.remainingMinutes} دقیقه دیگر در آتش‌بس و تحریم نظامی است و امکان اعلان جنگ ندارد.`);
  }
  if (defSanction.isSanctioned) {
    throw new GameError(`کشور مقصد تا ${defSanction.remainingMinutes} دقیقه دیگر تحت مصونیت و آتش‌بس سازمان ملل است و امکان اعلان جنگ به آن وجود ندارد.`);
  }

  const docRef = col('war_declarations').doc();
  let unSession = null;
  if (type === 'unauthorized') {
    unSession = await unService.createVoteSession({
      seasonId,
      initiatorCountryId: attackerCountryId,
      targetCountryId: defenderCountryId,
      type: 'war_investigation',
      title: `رسیدگی به اعلان جنگ غیرمجاز ${attackerCountry.name} علیه ${defenderCountry.name}`,
      description: `کشور ${attackerCountry.flag} ${attackerCountry.name} بدون مجوز اقدام به اعلان جنگ علیه ${defenderCountry.flag} ${defenderCountry.name} نموده است. اعضای مجمع عمومی سازمان ملل طی ۳۰ دقیقه آینده رأی خود را در خصوص محکومیت و اعمال تحریم یا تبرئه ثبت نمایند.`,
      metadata: { warId: docRef.id, reason: cleanReason },
    });
  }

  const warData = {
    id: docRef.id,
    seasonId,
    attackerCountryId,
    defenderCountryId,
    attackerName: attackerCountry.name,
    attackerFlag: attackerCountry.flag,
    defenderName: defenderCountry.name,
    defenderFlag: defenderCountry.flag,
    userId,
    userDisplayName: userDisplayName || 'رهبر کشور',
    type, // 'authorized' | 'unauthorized'
    reason: cleanReason,
    status: type === 'authorized' ? 'pending' : 'un_investigation',
    unVoteSessionId: unSession ? unSession.id : null,
    createdAt: new Date(),
    sideJoinDeadlineAt: new Date(Date.now() + 120000),
    reviewedAt: type === 'unauthorized' ? new Date() : null,
    reviewedBy: null,
  };

  await docRef.set(warData);
  return warData;
}

// تایید درخواست جنگ با مجوز توسط ادمین
async function approveWar(warId, adminId) {
  const ref = col('war_declarations').doc(warId);
  const s = await ref.get();
  if (!s.exists) throw new GameError('اعلان جنگ یافت نشد.');
  const war = snap(s);
  if (war.status !== 'pending') throw new GameError('این اعلان جنگ قبلاً تعیین وضعیت شده است.');

  const patch = {
    status: 'approved',
    reviewedAt: new Date(),
    reviewedBy: adminId || 'admin',
    // پنجره پیوستن دقیقاً از زمان انتشار جنگ تأییدشده شروع می‌شود.
    sideJoinDeadlineAt: new Date(Date.now() + 120000),
  };
  await ref.update(patch);
  return { ...war, ...patch };
}

// رد درخواست جنگ با مجوز توسط ادمین
async function rejectWar(warId, adminId, note = '') {
  const ref = col('war_declarations').doc(warId);
  const s = await ref.get();
  if (!s.exists) throw new GameError('اعلان جنگ یافت نشد.');
  const war = snap(s);
  if (war.status !== 'pending') throw new GameError('این اعلان جنگ قبلاً تعیین وضعیت شده است.');

  const patch = {
    status: 'rejected',
    rejectReason: note || 'عدم احراز دلیل منطقی و کافی',
    reviewedAt: new Date(),
    reviewedBy: adminId || 'admin',
  };
  await ref.update(patch);
  return { ...war, ...patch };
}

// ساخت متن دقیق جبهه‌های نبرد بر اساس قالب درخواست کاربر:
// مهاجم
// [پرچم و نام]
// طرف
// [پرچم و نام]
// مدافع
// [پرچم و نام]
// بی طرف
// [پرچم و نام]
function formatWarFrontsText(war, allCountries = []) {
  const countryById = new Map((allCountries || []).map((c) => [String(c.id), c]));
  const sideVotes = war.sideVotes || {};

  const getVoters = (side) => {
    return Object.entries(sideVotes || {})
      .filter(([, v]) => v && v.side === side)
      .map(([cId]) => countryById.get(String(cId)))
      .filter(Boolean)
      .map((c) => `${c.flag || '🏳️'} ${c.name}`);
  };

  const attackers = [`${war.attackerFlag || '🏳️'} ${war.attackerName}`];
  const attackerAllies = getVoters('attacker').filter((item) => !item.includes(war.attackerName));
  const defenders = [`${war.defenderFlag || '🏳️'} ${war.defenderName}`, ...getVoters('defender').filter((item) => !item.includes(war.defenderName))];
  const neutrals = getVoters('neutral');

  const lines = [
    'مهاجم',
    attackers.length ? attackers.join('\n') : '—',
    '',
    'طرف',
    attackerAllies.length ? attackerAllies.join('\n') : '—',
    '',
    'مدافع',
    defenders.length ? defenders.join('\n') : '—',
    '',
    'بی طرف',
    neutrals.length ? neutrals.join('\n') : '—',
  ];

  return lines.join('\n');
}

// -------------------------------------------------------------
// سیستم نبرد ۱۰ دقیقه‌ای زمان‌واقعی و جلوگیری قطعی از فتح آبکی
// -------------------------------------------------------------

async function createActiveBattle({
  seasonId,
  attackerCountryId,
  attackerUserId,
  defenderCountryId,
  defenderUserId,
  attackType,
  selectedUnits,
  travelSeconds = 600,
  targetProvinceId = null,
  speedBonusPercent = 0,
}) {
  const unService = require('./unService');
  const [attSanction, defSanction] = await Promise.all([
    unService.checkCountrySanction(attackerCountryId, seasonId),
    unService.checkCountrySanction(defenderCountryId, seasonId),
  ]);

  if (attSanction.isSanctioned) {
    throw new GameError(`کشور شما تا پایان مدت آتش‌بس و تحریم سازمان ملل (${attSanction.remainingMinutes} دقیقه باقی‌مانده) اجازه اعزام قوا ندارد.`);
  }
  if (defSanction.isSanctioned) {
    throw new GameError(`کشور مقصد تا پایان مدت مصونیت و آتش‌بس سازمان ملل (${defSanction.remainingMinutes} دقیقه باقی‌مانده) مصون است و تهاجم به آن مجاز نیست.`);
  }

  // اعتبارسنجی مجدد و کسر قطعی تجهیزات و نفت در لحظه صدور نهایی فرمان حمله
  const gameService = require('./gameService');
  await gameService.validateAndDeductAttackUnits(attackerCountryId, seasonId, selectedUnits);

  const [attackerCountry, defenderCountry] = await Promise.all([
    countryService.get(attackerCountryId),
    countryService.get(defenderCountryId),
  ]);

  // بررسی وجود پایگاه نظامی فعال در کشور هم‌مرز با هدف جهت حمله برق‌آسا و سریع‌تر
  let forwardBaseInfo = null;
  try {
    const militaryBaseService = require('./militaryBaseService');
    forwardBaseInfo = await militaryBaseService.getForwardBaseSpeedBonus(attackerCountryId, defenderCountryId, seasonId);
    if (forwardBaseInfo && forwardBaseInfo.hasForwardBase) {
      speedBonusPercent = Math.max(speedBonusPercent, forwardBaseInfo.speedBonusPercent || 50);
      travelSeconds = Math.max(120, Math.round(travelSeconds * 0.5)); // ۵۰٪ کاهش زمان رسیدن قوا
    }
  } catch (_) {}

  const docRef = col('active_battles').doc();
  const startedAt = new Date();
  const resolvesAt = new Date(startedAt.getTime() + travelSeconds * 1000);

  const battleData = {
    id: docRef.id,
    seasonId: String(seasonId),
    attackerCountryId: String(attackerCountryId),
    attackerUserId: attackerUserId ? Number(attackerUserId) : null,
    attackerName: attackerCountry?.name || 'مهاجم',
    attackerFlag: attackerCountry?.flag || '🏳️',
    defenderCountryId: String(defenderCountryId),
    defenderUserId: defenderUserId ? Number(defenderUserId) : null,
    defenderName: defenderCountry?.name || 'مدافع',
    defenderFlag: defenderCountry?.flag || '🏳️',
    attackType,
    selectedUnits: selectedUnits || [],
    travelSeconds,
    speedBonusPercent,
    targetProvinceId,
    status: 'in_transit',
    startedAt,
    resolvesAt,
    result: null,
  };

  await docRef.set(battleData);
  return battleData;
}

async function listActiveBattles(seasonId = null) {
  let q = col('active_battles').where('status', '==', 'in_transit');
  if (seasonId) q = q.where('seasonId', '==', String(seasonId));
  return docs(await q.get());
}

async function getActiveBattlesForCountry(countryId, seasonId = null) {
  const all = await listActiveBattles(seasonId);
  const cid = String(countryId);
  return all.filter((b) => b.attackerCountryId === cid || b.defenderCountryId === cid);
}

// پردازش نبردهای فعال سررسیدشده در چرخه ۱۰ ثانیه‌ای
async function processPendingBattles(telegram) {
  const now = new Date();
  const q = await col('active_battles').where('status', '==', 'in_transit').get();
  const battles = docs(q);
  if (!battles.length) return [];

  const gameService = require('./gameService');
  const notifications = require('./notificationService');
  const { fmtNum } = require('../utils/text');

  const resolved = [];

  for (const battle of battles) {
    const resolveTime = battle.resolvesAt?.toDate ? battle.resolvesAt.toDate() : new Date(battle.resolvesAt);
    if (resolveTime <= now) {
      // قفل اولیه جهت جلوگیری از پردازش همزمان
      await col('active_battles').doc(battle.id).update({ status: 'resolving' });

      try {
        const attackRes = await gameService.executeAttack({
          attackerCountryId: battle.attackerCountryId,
          defenderCountryId: battle.defenderCountryId,
          seasonId: battle.seasonId,
          attackType: battle.attackType,
          selectedUnits: battle.selectedUnits,
          targetProvinceId: battle.targetProvinceId,
          fromScheduledBattle: true,
        });

        await col('active_battles').doc(battle.id).update({
          status: 'resolved',
          resolvedAt: new Date(),
          result: {
            isVictory: attackRes.isVictory,
            conquered: Boolean(attackRes.conquered),
            capturedProvinceName: attackRes.capturedProvinceName || null,
            lootCash: attackRes.lootCash || 0,
            lootOil: attackRes.lootOil || 0,
            borderDamage: attackRes.borderDamage || 0,
          },
        });

        resolved.push({ battle, attackRes });

         // ثبت لاگ جنگ
         await logWarEvent({ warId: battle.warId || null, seasonId: battle.seasonId, type: attackRes.isVictory ? 'victory' : 'defeat', text: `${battle.attackerName} vs ${battle.defenderName}: ${attackRes.isVictory ? 'پیروزی مهاجم' : 'پیروزی مدافع'} (${battle.attackType})` }).catch(() => {});

        // اطلاع‌رسانی رسمی به مهاجم و مدافع در تلگرام
        const typeFa = {
          ground: 'زمینی',
          naval: 'دریایی',
          air: 'هوایی',
          missile: 'موشکی',
          combined: 'ترکیبی تمام‌عیار',
        }[battle.attackType] || battle.attackType;

        if (attackRes.isVictory) {
          const victoryText = [
            `🔥 <b>پایان زمان محاصره و پیروزی در عملیات ${typeFa}!</b>`,
            '– – – – – – – – – –',
            `مهاجم: ${battle.attackerFlag} <b>${battle.attackerName}</b>`,
            `مدافع: ${battle.defenderFlag} <b>${battle.defenderName}</b>`,
            `🗺️ وضعیت قلمرو: <b>${attackRes.capturedProvinceName || 'پیشروی کامل در مرزها'}</b>`,
            `💥 خسارت به استحکامات حریف: <b>${fmtNum(attackRes.borderDamage)}</b>`,
            `💵 غنیمت نقدی حاصله: <b>+${fmtNum(attackRes.lootCash)}$</b>`,
            `🛢 غنیمت نفتی مصادره‌شده: <b>+${fmtNum(attackRes.lootOil)} بشکه</b>`,
            attackRes.conquered ? `\n🏆 <b>کشور ${battle.defenderName} رسماً فتح شد و قلمرو آن ضمیمه کشور شما گردید!</b>` : '',
          ].filter(Boolean).join('\n');

          if (telegram && battle.attackerUserId) {
            await notifications.safeSend(telegram, battle.attackerUserId, victoryText).catch(() => {});
          }

          const defLossText = [
            `💔 <b>شکست در دفاع از کشور در عملیات ${typeFa}!</b>`,
            '– – – – – – – – – –',
            `نیروهای متخاصم <b>${battle.attackerFlag} ${battle.attackerName}</b> پس از محاصره کامل، خطوط دفاعی شما را درهم شکستند.`,
            `💵 غنیمت نقدی غارت‌شده: <b>-${fmtNum(attackRes.lootCash)}$</b>`,
            `🛢 نفت مصادره‌شده: <b>-${fmtNum(attackRes.lootOil)} بشکه</b>`,
            attackRes.conquered ? `\n🏳️ <b>کشور شما به طور کامل سقوط کرد و تحت سلطه ${battle.attackerName} درآمد.</b>` : '',
          ].filter(Boolean).join('\n');

          if (telegram && battle.defenderUserId) {
            await notifications.safeSend(telegram, battle.defenderUserId, defLossText).catch(() => {});
          }

          // اعلام در کانال
          const chanNews = [
            attackRes.conquered ? '🚩 <b>سقوط و فتح کامل کشور در نبرد سنگین!</b>' : '⚔️ <b>پایان نبرد سرنوشت‌ساز و پیروزی مهاجم!</b>',
            '– – – – – – – – – –',
            `فاتح: <b>${battle.attackerFlag} ${battle.attackerName}</b>`,
            `مدافع: <b>${battle.defenderFlag} ${battle.defenderName}</b>`,
            `شیوه تهاجم: <b>نیروی ${typeFa}</b>`,
            attackRes.conquered ? `🌍 کشور ${battle.defenderName} رسماً به عنوان استان تصرف‌شده اداره خواهد شد.` : `💥 خطوط مرزی مدافع دچار شکاف سنگین شد.`,
          ].join('\n');
          await notifications.publishToChannel(telegram, 'war_news', chanNews).catch(() => {});
        } else {
          // شکست حمله / پیروزی دفاع
          const attFailText = [
            `🛡 <b>شکست عملیات نظامی ${typeFa}!</b>`,
            '– – – – – – – – – –',
            `نیروهای شما پس از پایان پیشروی، با پدافند مستحکم و دفاع آماده <b>${battle.defenderFlag} ${battle.defenderName}</b> مواجه شده و عملیات متوقف گردید.`,
          ].join('\n');
          if (telegram && battle.attackerUserId) {
            await notifications.safeSend(telegram, battle.attackerUserId, attFailText).catch(() => {});
          }

          const defWinText = [
            `🎉 <b>پیروزی دفاعی در دفع تهاجم متخاصم!</b>`,
            '– – – – – – – – – –',
            `نیروهای مدافع کشور شما با موفقیت تهاجم ${typeFa} نیروهای <b>${battle.attackerFlag} ${battle.attackerName}</b> را درهم کوبیدند و مرزها امن باقی ماند!`,
          ].join('\n');
          if (telegram && battle.defenderUserId) {
            await notifications.safeSend(telegram, battle.defenderUserId, defWinText).catch(() => {});
          }
        }
      } catch (err) {
        await col('active_battles').doc(battle.id).update({ status: 'failed', error: err.message });
      }
    }
  }

  return resolved;
}

// -------------------------------------------------------------
// سامانه درخواست مجوز عبور نظامی ترانزیت همسایه (کشورهای محصور در خشکی)
// -------------------------------------------------------------

async function requestTransit({ fromCountryId, transitCountryId, targetCountryId, seasonId, userId }) {
  const docRef = col('transit_requests').doc();
  const req = {
    id: docRef.id,
    fromCountryId: String(fromCountryId),
    transitCountryId: String(transitCountryId),
    targetCountryId: String(targetCountryId),
    seasonId: String(seasonId),
    requestedByUserId: Number(userId),
    status: 'pending',
    createdAt: new Date(),
    expiresAt: new Date(Date.now() + 24 * 3600 * 1000),
  };
  await docRef.set(req);
  return req;
}

async function decideTransit({ requestId, approved, adminOrLeaderId }) {
  const s = await col('transit_requests').doc(String(requestId)).get();
  if (!s.exists) throw new Error('درخواست ترانزیت پیدا نشد.');
  const data = s.data();
  const status = approved ? 'approved' : 'rejected';
  await col('transit_requests').doc(String(requestId)).update({
    status,
    decidedBy: adminOrLeaderId,
    decidedAt: new Date(),
  });
  return { ...data, status };
}

async function checkTransitPermission({ fromCountryId, transitCountryId, targetCountryId, seasonId }) {
  const q = await col('transit_requests')
    .where('fromCountryId', '==', String(fromCountryId))
    .where('status', '==', 'approved')
    .get();
  const docsList = docs(q);
  return docsList.some((r) => (!targetCountryId || r.targetCountryId === String(targetCountryId)) &&
    (!transitCountryId || r.transitCountryId === String(transitCountryId)));
}

async function logWarEvent({ warId, seasonId, type, text, countryId = null }) {
  try {
    const settingsService = require('./settingsService');
    const enabled = await settingsService.get('war_logs_enabled', true);
    if (!enabled) return;
    await col('war_logs').add({
      warId: warId ? String(warId) : null,
      seasonId: seasonId ? String(seasonId) : null,
      countryId: countryId ? String(countryId) : null,
      type: type || 'info',
      text: String(text || ''),
      createdAt: new Date(),
    });
  } catch (_) {}
}

async function listWarLogs(seasonId = null, limit = 50) {
  let q = col('war_logs').orderBy('createdAt', 'desc').limit(limit);
  if (seasonId) q = col('war_logs').where('seasonId', '==', String(seasonId)).orderBy('createdAt', 'desc').limit(limit);
  const snap = await q.get().catch(() => ({ docs: [] }));
  return docs(snap) || [];
}
module.exports = {
  listWars,
  getWar,
  castWarSideVote,
  declareWar,
  approveWar,
  rejectWar,
  formatWarFrontsText,
  createActiveBattle,
  listActiveBattles,
  getActiveBattlesForCountry,
  processPendingBattles,
  requestTransit,
  decideTransit,
  checkTransitPermission,
  logWarEvent,
  listWarLogs,
};

