'use strict';
const { col, snap, docs } = require('../db/firestore');
const { GameError } = require('../utils/errors');
const gameService = require('./gameService');
const countryService = require('./countryService');

const ALLIANCE_COST = 1000000000; // ۱ میلیارد دلار هزینه تاسیس اتحاد

async function getAlliance(id) {
  if (!id) return null;
  return snap(await col('alliances').doc(String(id)).get());
}

async function getCountryAlliance(countryId, seasonId) {
  if (!countryId || !seasonId) return null;
  const q = await col('alliances')
    .where('seasonId', '==', String(seasonId))
    .where('memberCountryIds', 'array-contains', String(countryId))
    .get();
  const list = docs(q);
  return list[0] || null;
}

async function listAlliances(seasonId) {
  if (!seasonId) return [];
  const q = await col('alliances').where('seasonId', '==', String(seasonId)).get();
  return docs(q);
}

async function createAlliance({ leaderCountryId, leaderUserId, seasonId, name, logo }) {
  if (!leaderCountryId || !seasonId) throw new GameError('اطلاعات کشور نامعتبر است.');
  const cleanName = String(name || '').trim();
  if (!cleanName || cleanName.length < 3 || cleanName.length > 50) {
    throw new GameError('نام اتحاد باید بین ۳ تا ۵۰ کاراکتر باشد.');
  }

  // بررسی عدم عضویت قبلی در اتحاد
  const existing = await getCountryAlliance(leaderCountryId, seasonId);
  if (existing) {
    throw new GameError(`کشور شما در حال حاضر عضو اتحاد «${existing.name}» است و نمی‌تواند اتحاد جدیدی تاسیس کند.`);
  }

  // بررسی بودجه خزانه
  const state = await gameService.getCountryState(leaderCountryId, seasonId);
  if ((state.treasury || 0) < ALLIANCE_COST) {
    throw new GameError(`بودجه کشور کافی نیست! هزینه ساخت یک اتحاد ۱,۰۰۰,۰۰۰,۰۰۰$ (۱ میلیارد دلار) است؛ موجودی فعلی: ${(state.treasury || 0).toLocaleString()}$`);
  }

  // کسر ۱ میلیارد دلار
  const newTreasury = (state.treasury || 0) - ALLIANCE_COST;
  await gameService.updateCountryState(leaderCountryId, seasonId, { treasury: newTreasury });

  const ref = col('alliances').doc();
  const alliance = {
    id: ref.id,
    name: cleanName,
    logo: logo ? String(logo).trim() : '🛡️',
    leaderCountryId: String(leaderCountryId),
    leaderUserId: Number(leaderUserId),
    seasonId: String(seasonId),
    memberCountryIds: [String(leaderCountryId)],
    createdAt: new Date(),
  };

  await ref.set(alliance);
  return { alliance, remainingTreasury: newTreasury };
}

async function inviteCountry({ allianceId, fromCountryId, fromUserId, targetCountryId, seasonId }) {
  const alliance = await getAlliance(allianceId);
  if (!alliance) throw new GameError('اتحاد یافت نشد.');
  if (alliance.leaderCountryId !== String(fromCountryId)) {
    throw new GameError('تنها مالک و رهبر اتحاد مجاز به ارسال دعوت‌نامه عضویت است.');
  }
  if (alliance.memberCountryIds.includes(String(targetCountryId))) {
    throw new GameError('این کشور در حال حاضر عضو اتحاد است.');
  }

  const targetAlliance = await getCountryAlliance(targetCountryId, seasonId);
  if (targetAlliance) {
    throw new GameError(`این کشور در حال حاضر عضو اتحاد «${targetAlliance.name}» می‌باشد.`);
  }

  const ref = col('alliance_invitations').doc();
  const inv = {
    id: ref.id,
    allianceId: alliance.id,
    allianceName: alliance.name,
    allianceLogo: alliance.logo,
    fromCountryId: String(fromCountryId),
    fromUserId: Number(fromUserId),
    targetCountryId: String(targetCountryId),
    seasonId: String(seasonId),
    status: 'pending',
    createdAt: new Date(),
  };
  await ref.set(inv);
  return inv;
}

async function getInvitation(invitationId) {
  return snap(await col('alliance_invitations').doc(String(invitationId)).get());
}

async function acceptInvitation({ invitationId, targetCountryId }) {
  const inv = await getInvitation(invitationId);
  if (!inv || inv.status !== 'pending') throw new GameError('دعوت‌نامه معتبر نیست یا منقضی شده است.');
  if (inv.targetCountryId !== String(targetCountryId)) throw new GameError('دعوت‌نامه متعلق به کشور شما نیست.');

  const alliance = await getAlliance(inv.allianceId);
  if (!alliance) throw new GameError('اتحاد دیگر وجود ندارد.');

  const members = [...new Set([...alliance.memberCountryIds, String(targetCountryId)])];
  await col('alliances').doc(alliance.id).update({ memberCountryIds: members });
  await col('alliance_invitations').doc(inv.id).update({ status: 'accepted', answeredAt: new Date() });

  return { alliance: { ...alliance, memberCountryIds: members }, invitation: inv };
}

async function rejectInvitation({ invitationId, targetCountryId }) {
  const inv = await getInvitation(invitationId);
  if (!inv || inv.status !== 'pending') throw new GameError('دعوت‌نامه نامعتبر است.');
  await col('alliance_invitations').doc(inv.id).update({ status: 'rejected', answeredAt: new Date() });
  return inv;
}

// ایجاد پیش‌نویس بیانیه گروهی
async function createGroupStatement({ allianceId, countryId, seasonId, text, photoFileId = null }) {
  const alliance = await getAlliance(allianceId);
  if (!alliance) throw new GameError('اتحاد یافت نشد.');
  if (alliance.leaderCountryId !== String(countryId)) {
    throw new GameError('تنها رهبر اتحاد امکان ثبت بیانیه گروهی را دارد.');
  }
  const cleanText = String(text || '').trim().slice(0, 1000);
  if (!cleanText) throw new GameError('متن بیانیه نمی‌تواند خالی باشد.');

  const memberCount = alliance.memberCountryIds.length;
  // قانون: نیاز به تایید ۷۵٪ اعضا
  const requiredVotes = Math.ceil(memberCount * 0.75);

  const ref = col('alliance_statements').doc();
  const stmt = {
    id: ref.id,
    allianceId: alliance.id,
    allianceName: alliance.name,
    allianceLogo: alliance.logo,
    leaderCountryId: String(countryId),
    seasonId: String(seasonId),
    text: cleanText,
    photoFileId: photoFileId || null,
    memberCount,
    requiredVotes,
    approvals: [String(countryId)], // رای موافق اولیه رهبر
    rejections: [],
    status: memberCount === 1 ? 'approved' : 'voting',
    createdAt: new Date(),
  };

  await ref.set(stmt);
  return stmt;
}

async function voteGroupStatement({ statementId, countryId, approve = true }) {
  const ref = col('alliance_statements').doc(String(statementId));
  const snapDoc = await ref.get();
  if (!snapDoc.exists) throw new GameError('بیانیه یافت نشد.');
  const stmt = snap(snapDoc);

  if (stmt.status !== 'voting') throw new GameError('رای‌گیری برای این بیانیه به پایان رسیده است.');

  const alliance = await getAlliance(stmt.allianceId);
  if (!alliance || !alliance.memberCountryIds.includes(String(countryId))) {
    throw new GameError('شما عضو این اتحاد نیستید.');
  }

  const strCountryId = String(countryId);
  let approvals = stmt.approvals || [];
  let rejections = stmt.rejections || [];

  approvals = approvals.filter((id) => id !== strCountryId);
  rejections = rejections.filter((id) => id !== strCountryId);

  if (approve) approvals.push(strCountryId);
  else rejections.push(strCountryId);

  const memberCount = alliance.memberCountryIds.length;
  const approvalPercent = (approvals.length / memberCount) * 100;
  const isApproved = approvalPercent >= 75;

  let newStatus = 'voting';
  if (isApproved) {
    newStatus = 'approved';
  } else if ((rejections.length / memberCount) > 0.25) {
    // اگر بیش از ۲۵٪ مخالفت کنند، امکان رسیدن به ۷۵٪ منتفی است
    newStatus = 'rejected';
  }

  const patch = {
    approvals,
    rejections,
    status: newStatus,
    updatedAt: new Date(),
  };

  await ref.update(patch);
  return { ...stmt, ...patch, approvalPercent, isApproved };
}

async function leaveAlliance({ allianceId, countryId, seasonId }) {
  const alliance = await getAlliance(allianceId);
  if (!alliance) throw new GameError('اتحاد یافت نشد.');

  const strCountryId = String(countryId);
  if (!alliance.memberCountryIds.includes(strCountryId)) {
    throw new GameError('کشور شما عضو این اتحاد نیست.');
  }

  // اگر مالک خارج شود و اعضای دیگری باشند:
  if (alliance.leaderCountryId === strCountryId) {
    const otherMembers = alliance.memberCountryIds.filter((id) => id !== strCountryId);
    if (otherMembers.length === 0) {
      // انحلال اتحاد
      await col('alliances').doc(alliance.id).delete();
      return { dissolved: true };
    } else {
      // انتقال رهبری به عضو بعدی
      const nextLeader = otherMembers[0];
      await col('alliances').doc(alliance.id).update({
        leaderCountryId: nextLeader,
        memberCountryIds: otherMembers,
      });
      return { transferredTo: nextLeader };
    }
  } else {
    const remaining = alliance.memberCountryIds.filter((id) => id !== strCountryId);
    await col('alliances').doc(alliance.id).update({ memberCountryIds: remaining });
    return { left: true };
  }
}

module.exports = {
  ALLIANCE_COST,
  getAlliance,
  getCountryAlliance,
  listAlliances,
  createAlliance,
  inviteCountry,
  getInvitation,
  acceptInvitation,
  rejectInvitation,
  createGroupStatement,
  voteGroupStatement,
  leaveAlliance,
};
