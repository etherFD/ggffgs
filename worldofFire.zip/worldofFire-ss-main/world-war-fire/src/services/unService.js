'use strict';

/**
 * سرویس مجمع عمومی و شورای امنیت سازمان ملل (United Nations)
 * مدیریت رأی‌گیری‌های عمومی ۳۰ دقیقه‌ای، پرونده‌های هسته‌ای و تهاجم‌های نظامی
 */

const { col, snap, docs } = require('../db/firestore');
const { GameError } = require('../utils/errors');
const { acquireLock, releaseLock } = require('../db/locks');
const countryService = require('./countryService');
const settingsService = require('./settingsService');
const notifications = require('./notificationService');
const { fmtNum } = require('../utils/text');

const VOTE_DURATION_MS = 30 * 60 * 1000; // ۳۰ دقیقه زمان رأی‌گیری
const DEFAULT_WAR_PENALTY = 250000000; // ۲۵۰ میلیون دلار جریمه پیش‌فرض تهاجم محکوم‌شده
const SANCTION_DURATION_MS = 60 * 60 * 1000; // ۱ ساعت آتش‌بس و مصونیت متقابل

/**
 * ایجاد یک پرونده رأی‌گیری جدید در سازمان ملل
 */
async function createVoteSession({
  seasonId,
  initiatorCountryId,
  type, // 'nuclear_license' | 'war_investigation' | 'strait_blockade'
  title,
  description,
  targetCountryId = null,
  metadata = {},
  telegramBot = null,
}) {
  const lockKey = `un_create:${initiatorCountryId}:${type}`;
  const locked = await acquireLock(lockKey, 10000);
  if (!locked) throw new GameError('درخواست شما برای سازمان ملل در حال پردازش است. لطفاً شکیبا باشید.');

  try {
    const country = await countryService.get(initiatorCountryId);
    if (!country) throw new GameError('کشور ثبت‌کننده معتبر نیست.');

    let targetCountry = null;
    if (targetCountryId) {
      targetCountry = await countryService.get(targetCountryId);
    }

    const now = Date.now();
    const expiresAt = new Date(now + VOTE_DURATION_MS);

    const ref = col('un_votes').doc();
    const session = {
      id: ref.id,
      seasonId: String(seasonId),
      initiatorCountryId: String(initiatorCountryId),
      initiatorCountryName: country.name,
      initiatorFlag: country.flag,
      targetCountryId: targetCountryId ? String(targetCountryId) : null,
      targetCountryName: targetCountry?.name || null,
      targetCountryFlag: targetCountry?.flag || null,
      type,
      title,
      description,
      metadata: metadata || {},
      status: 'active', // 'active' | 'approved' | 'rejected' | 'expired'
      votes: {
        yes: [], // آرای موافق: { countryId, countryName, flag, userId }
        no: [],  // آرای مخالف
        abstain: [], // آرای ممتنع
      },
      counts: {
        yes: 0,
        no: 0,
        abstain: 0,
      },
      channelMessageId: null,
      createdAt: new Date(now),
      expiresAt,
      resolvedAt: null,
      resolutionResult: null,
    };

    await ref.set(session);

    // اگر ربات تلگرام در دسترس است، انتشار در کانال
    if (telegramBot) {
      await publishUNVoteToChannel(telegramBot, session).catch(() => {});
    }

    return session;
  } finally {
    await releaseLock(lockKey);
  }
}

/**
 * دریافت اطلاعات یک جلسه رأی‌گیری
 */
async function getVoteSession(voteId) {
  if (!voteId) return null;
  return snap(await col('un_votes').doc(String(voteId)).get());
}

/**
 * فهرست جلسات رأی‌گیری فعال سازمان ملل
 */
async function listActiveVotes(seasonId) {
  const now = new Date();
  const q = await col('un_votes')
    .where('seasonId', '==', String(seasonId))
    .where('status', '==', 'active')
    .get();

  const list = docs(q);
  // بررسی منقضی شدن خودکار
  const activeList = [];
  for (const session of list) {
    if (new Date(session.expiresAt).getTime() <= now.getTime()) {
      await resolveVoteSession(session.id).catch(() => {});
    } else {
      activeList.push(session);
    }
  }
  return activeList;
}

/**
 * ثبت رأی یک کشور در رأی‌گیری سازمان ملل
 */
async function castVote({ voteId, countryId, userId, choice }) {
  if (!['yes', 'no', 'abstain'].includes(choice)) {
    throw new GameError('گزینه رأی نامعتبر است (فقط موافق، مخالف یا ممتنع).');
  }

  const lockKey = `un_cast:${voteId}`;
  const locked = await acquireLock(lockKey, 10000);
  if (!locked) throw new GameError('سیستم رأی‌گیری مشغول است. لطفاً ۲ ثانیه بعد مجدداً امتحان کنید.');

  try {
    const ref = col('un_votes').doc(String(voteId));
    const sDoc = await ref.get();
    if (!sDoc.exists) throw new GameError('جلسه رأی‌گیری مورد نظر یافت نشد.');
    const session = sDoc.data();

    if (session.status !== 'active' || Date.now() >= new Date(session.expiresAt).getTime()) {
      throw new GameError('زمان قانونی این رأی‌گیری ۳۰ دقیقه‌ای به پایان رسیده و پرونده مختومه است.');
    }

    const country = await countryService.get(countryId);
    if (!country) throw new GameError('صلاحیت کشور رأی‌دهنده احراز نشد.');

    // بررسی اینکه آیا کشور قبلاً رأی داده است یا خیر
    const allVoted = [
      ...(session.votes.yes || []),
      ...(session.votes.no || []),
      ...(session.votes.abstain || []),
    ];

    const prevVote = allVoted.find((v) => String(v.countryId) === String(countryId) || Number(v.userId) === Number(userId));
    if (prevVote) {
      throw new GameError(`کشور ${country.name} قبلاً رأی خود را در این قطعنامه ثبت کرده است و امکان تغییر یا رأی مجدد وجود ندارد.`);
    }

    const voterInfo = {
      countryId: String(countryId),
      countryName: country.name,
      flag: country.flag,
      userId: Number(userId),
      votedAt: new Date(),
    };

    const votes = session.votes || { yes: [], no: [], abstain: [] };
    votes[choice] = votes[choice] || [];
    votes[choice].push(voterInfo);

    const counts = {
      yes: (votes.yes || []).length,
      no: (votes.no || []).length,
      abstain: (votes.abstain || []).length,
    };

    await ref.update({
      votes,
      counts,
    });

    return { session: { ...session, votes, counts }, voterInfo, choice };
  } finally {
    await releaseLock(lockKey);
  }
}

/**
 * بستن و اجرای نتیجه قطعی رأی‌گیری سازمان ملل (فقط یک بار اجرا می‌شود)
 */
async function resolveVoteSession(voteId, telegramBot = null) {
  const lockKey = `un_resolve:${voteId}`;
  const locked = await acquireLock(lockKey, 15000);
  if (!locked) return null;

  try {
    const ref = col('un_votes').doc(String(voteId));
    const sDoc = await ref.get();
    if (!sDoc.exists) return null;
    const session = sDoc.data();

    if (session.status !== 'active') {
      return session; // قبلاً تعیین تکلیف شده است
    }

    const yesCount = session.counts?.yes || 0;
    const noCount = session.counts?.no || 0;

    // قانون تصویب قطعنامه: اگر آرا موافق بیشتر از مخالف باشد -> تایید؛ در غیر این صورت -> رد
    const isApproved = yesCount > noCount;
    const newStatus = isApproved ? 'approved' : 'rejected';

    const resolutionResult = {
      approved: isApproved,
      yesCount,
      noCount,
      abstainCount: session.counts?.abstain || 0,
      totalVotes: yesCount + noCount + (session.counts?.abstain || 0),
      summaryFa: isApproved ? 'قطعنامه با اکثریت آرای اعضا به تصویب رسید.' : 'قطعنامه با مخالفت اعضا رد گردید.',
    };

    await ref.update({
      status: newStatus,
      resolvedAt: new Date(),
      resolutionResult,
    });

    // اعمال اثرات عینی قطعنامه بر اساس نوع آن
    const gameService = require('./gameService');
    const warService = require('./warService');

    if (session.type === 'nuclear_license') {
      // صدور یا رد مجوز غنی‌سازی هسته‌ای
      const tier = Number(session.metadata?.targetTier || 20);
      if (isApproved) {
        await approveNuclearLicense(session.initiatorCountryId, session.seasonId, tier);
      }
    } else if (session.type === 'war_investigation') {
      // قطعنامه تهاجم بدون مجوز:
      // اگر yesCount > noCount -> به معنی محکومیت متجاوز و وتوی جنگ است (کشور مجرم شناخته شد)
      if (isApproved) {
        // اعمال جریمه اقتصادی + تحریم ۱ ساعته جنگ و مصونیت
        const penaltyAmount = await settingsService.get('un_war_penalty', DEFAULT_WAR_PENALTY);
        await applyWarSanctions({
          condemnedCountryId: session.initiatorCountryId,
          seasonId: session.seasonId,
          penaltyAmount,
          reason: `محکومیت قطعی در سازمان ملل بابت قصد تهاجم غیرقانونی به ${session.targetCountryName || 'کشور همسایه'}`,
        });
      } else {
        // کشور تبرئه شد یا اتهام رد شد -> جنگ مجاز است در صورت داشتن شرایط
        // آزاد شدن قفل جنگ
      }
    }

    // ارسال اعلان به کانال رسمی در صورت تنظیم بودن
    if (telegramBot) {
      await announceResolutionInChannel(telegramBot, session, resolutionResult).catch(() => {});
    }

    return { ...session, status: newStatus, resolutionResult };
  } finally {
    await releaseLock(lockKey);
  }
}

/**
 * تایید و صدور مجوز غنی‌سازی هسته‌ای برای کشور
 */
async function approveNuclearLicense(countryId, seasonId, tier) {
  const gameService = require('./gameService');
  const state = await gameService.getCountryState(countryId, seasonId);
  const licenses = state.nuclearLicenses || [];
  if (!licenses.includes(tier)) {
    licenses.push(tier);
    licenses.sort((a, b) => a - b);
  }

  await gameService.updateCountryState(countryId, seasonId, {
    nuclearLicenses: licenses,
    nuclearMaxTier: Math.max(tier, Number(state.nuclearMaxTier || 0)),
  });

  // ثبت در جدول مجوزهای رسمی
  await col('nuclear_licenses').add({
    countryId: String(countryId),
    seasonId: String(seasonId),
    tier,
    approvedAt: new Date(),
    status: 'granted',
  });
}

/**
 * اعمال تحریم ۱ ساعته آتش‌بس و جریمه سنگین اقتصادی
 */
async function applyWarSanctions({ condemnedCountryId, seasonId, penaltyAmount, reason }) {
  const gameService = require('./gameService');
  const state = await gameService.getCountryState(condemnedCountryId, seasonId);
  const currentTreasury = Number(state.treasury || 0);
  const deduction = Math.min(currentTreasury, Number(penaltyAmount) || DEFAULT_WAR_PENALTY);

  const sanctionEnd = new Date(Date.now() + SANCTION_DURATION_MS);

  await gameService.updateCountryState(condemnedCountryId, seasonId, {
    treasury: Math.max(0, currentTreasury - deduction),
    sanctionUntil: sanctionEnd, // ۱ ساعت عدم امکان حمله و مصونیت از حمله
    legitimacy: Math.max(0, (state.legitimacy || 100) - 25),
  });

  // ثبت لاگ رویداد رسمی
  await col('sanction_logs').add({
    countryId: String(condemnedCountryId),
    seasonId: String(seasonId),
    penaltyAmount: deduction,
    sanctionUntil: sanctionEnd,
    reason,
    createdAt: new Date(),
  });
}

/**
 * بررسی آیا کشوری در حال حاضر تحت تحریم یا آتش‌بس ۱ ساعته است
 */
async function checkCountrySanction(countryId, seasonId) {
  const gameService = require('./gameService');
  const state = await gameService.getCountryState(countryId, seasonId);
  if (!state.sanctionUntil) return { isSanctioned: false, remainingMs: 0 };

  const untilTime = new Date(state.sanctionUntil).getTime();
  const now = Date.now();
  if (now < untilTime) {
    return {
      isSanctioned: true,
      remainingMs: untilTime - now,
      remainingMinutes: Math.ceil((untilTime - now)/60000),
      until: new Date(untilTime),
    };
  }

  return { isSanctioned: false, remainingMs: 0 };
}

function formatVotersList(list) {
  if (!list || !list.length) return '• <i>هنوز هیچ کشوری در این بخش رأی نداده است</i>';
  return list.map((v) => `• ${v.flag || '🏳️'} <b>${v.countryName || 'کشور'}</b> (شناسه: <code>${v.userId || v.numericId || '—'}</code>)`).join('\n');
}

function renderUNVoteContent(session) {
  const now = Date.now();
  const expMs = session.expiresAt?.toDate ? session.expiresAt.toDate().getTime() : new Date(session.expiresAt).getTime();
  const remSec = Math.max(0, Math.ceil((expMs - now) / 1000));
  const remMin = Math.floor(remSec / 60);

  const yesList = session.votes?.yes || [];
  const noList = session.votes?.no || [];
  const absList = session.votes?.abstain || [];

  const text = [
    '🏛 <b>قطعنامه اضطراری مجمع عمومی سازمان ملل متحد (United Nations)</b>',
    '– – – – – – – – – –',
    `📜 موضوع: <b>${session.title}</b>`,
    `🌍 کشور بانی / متقاضی: <b>${session.initiatorFlag || '🏳️'} ${session.initiatorCountryName}</b>`,
    session.targetCountryName ? `🎯 طرف دعوا / ذی‌نفع: <b>${session.targetCountryFlag || '🏳️'} ${session.targetCountryName}</b>` : '',
    '',
    `📄 <b>شرح لایحه:</b>`,
    `« <i>${session.description}</i> »`,
    '',
    `⏳ مهلت قانونی: <b>${session.status === 'active' ? `${remMin} دقیقه زمان باقی‌مانده` : 'پایان‌یافته و مختومه'}</b>`,
    '– – – – – – – – – –',
    `📊 <b>فهرست و آرای تفکیکی اعضای رسمی سازمان ملل:</b>`,
    '',
    `✅ <b>تاییدها (موافق) - ${yesList.length} کشور:</b>`,
    formatVotersList(yesList),
    '',
    `❌ <b>ردها (مخالف) - ${noList.length} کشور:</b>`,
    formatVotersList(noList),
    '',
    `⚪ <b>ممتنع - ${absList.length} کشور:</b>`,
    formatVotersList(absList),
    '– – – – – – – – – –',
    '🗳 <i>فقط بازیکنان دارای کشور رسمی در بازی مجاز به ثبت یک رأی معتبر هستند.</i>',
  ].filter(Boolean).join('\n');

  const { Markup } = require('telegraf');
  const kb = Markup.inlineKeyboard([
    [
      Markup.button.callback(`✅ تایید (${yesList.length})`, `un:vote:${session.id}:yes`),
      Markup.button.callback(`❌ رد (${noList.length})`, `un:vote:${session.id}:no`),
      Markup.button.callback(`⚪ ممتنع (${absList.length})`, `un:vote:${session.id}:abstain`),
    ],
  ]);

  return { text, kb };
}

/**
 * انتشار پیام رأی‌گیری در کانال رسمی
 */
async function publishUNVoteToChannel(telegramBot, session) {
  const { text, kb } = renderUNVoteContent(session);
  const sent = await notifications.publishToChannel(telegramBot, 'announcement', text, kb).catch(() => null);
  if (sent && sent.message_id) {
    const channelId = await settingsService.getChannelId();
    await col('un_votes').doc(session.id).update({
      channelMessageId: sent.message_id,
      channelChatId: channelId,
    }).catch(() => {});
    session.channelMessageId = sent.message_id;
    session.channelChatId = channelId;
  }
}

/**
 * اعلام نتیجه قطعی قطعنامه در کانال
 */
async function announceResolutionInChannel(telegramBot, session, res) {
  const verdictIcon = res.approved ? '✅' : '❌';
  const text = [
    `🏛 <b>نتیجه قطعی رأی‌گیری سازمان ملل اعلام شد ${verdictIcon}</b>`,
    '– – – – – – – – – –',
    `📜 موضوع: <b>${session.title}</b>`,
    `🌍 کشور بانی: <b>${session.initiatorFlag} ${session.initiatorCountryName}</b>`,
    '',
    `📊 <b>آرای مأخوذه:</b>`,
    `• موافق: <b>${res.yesCount} رأی</b>`,
    `• مخالف: <b>${res.noCount} رأی</b>`,
    `• ممتنع: <b>${res.abstainCount} رأی</b>`,
    '– – – – – – – – – –',
    `⚖️ <b>حکم نهایی: ${res.summaryFa}</b>`,
  ].join('\n');

  await notifications.publishToChannel(telegramBot, 'announcement', text).catch(() => {});
}

module.exports = {
  VOTE_DURATION_MS,
  SANCTION_DURATION_MS,
  DEFAULT_WAR_PENALTY,
  createVoteSession,
  getVoteSession,
  listActiveVotes,
  castVote,
  resolveVoteSession,
  resolveSession: resolveVoteSession,
  approveNuclearLicense,
  applyWarSanctions,
  checkCountrySanction,
  renderUNVoteContent,
  publishUNVoteToChannel,
};
