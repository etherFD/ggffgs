'use strict';
const logger = require('../utils/logger');
const { getActiveSeason } = require('./seasonService');
const { listActive } = require('./ownershipService');
const countryService = require('./countryService');
const gameService = require('./gameService');
const straitService = require('./straitService');
const cryptoService = require('./cryptoService');
const warService = require('./warService');
const { safeSend } = require('./notificationService');
const { fmtNum } = require('../utils/text');

let loopIntervalId = null;
let lastTenMinuteTick = Date.now();
let lastThirtyMinuteTick = Date.now();

// اجرای یک چرخه ۱۰ دقیقه‌ای واریز درآمد و نفت
async function executeTenMinutePayout(telegram) {
  try {
    const season = await getActiveSeason();
    if (!season) return;

    const activeOwnerships = await listActive(season.id);
    if (!activeOwnerships || activeOwnerships.length === 0) return;

    // بارگذاری تنگه‌ها و تعیین عوارض
    const straits = await straitService.getStraits(season.id);
    const ownedStraits = straits.filter((s) => s.ownerCountryId);

    // محاسبه درآمدهای ناخالص هر کشور
    // درآمد ناخالص بر مبنای تقسیم incomeDaily به ۱۴۴ واحد (هر ۱۰ دقیقه یک بار در ۲۴ ساعت)
    // با حداقل کف معقول مثلاً ۳ تا ۱۰ میلیون دلار بر مبنای جمعیت و سطح کشور
    const countryDataMap = new Map();
    for (const own of activeOwnerships) {
      const state = await gameService.getCountryState(own.countryId, season.id);
      const country = await countryService.get(own.countryId);
      const isLarge = (country?.population || 10000000) > 40000000;
      const baseDaily = state.incomeDaily || (isLarge ? 420000000 : 300000000);
      const grossIncome = Math.max(2500000, Math.floor(baseDaily / 144));
      
      // استخراج نفت از دکل‌ها؛ برداشت خودکار هم نمی‌تواند از سقف مخزن عبور کند.
      const rigs = state.oilRigs || 5;
      const requestedOil = Math.floor(rigs * 25 + Math.random() * 20);
      const reserveCapacity = gameService.calculateOilReserveCapacity(state, country || {});
      const oilReserve = reserveCapacity.total;
      const remainingOilCapacity = Math.max(0, oilReserve - Number(state.oil || 0));
      const extractedOil = Math.min(requestedOil, remainingOilCapacity);

      countryDataMap.set(String(own.countryId), {
        ownership: own,
        country,
        state,
        oilReserve,
        oilReserveBonus: reserveCapacity.bonus,
        grossIncome,
        extractedOil,
        tollPaid: 0,
        tollReceived: 0,
        blockadeTollPaid: 0,
        blockadeTollReceived: 0,
        netIncome: grossIncome,
      });
    }

    // محاسبه عوارض ترانزیت تنگه‌ها (۵٪ برای هر تنگه غیر خودی)
    for (const [countryId, data] of countryDataMap.entries()) {
      let totalTollDeduction = 0;

      for (const strait of ownedStraits) {
        // کشور برای تنگه متعلق به خودش عوارض نمی‌پردازد
        if (String(strait.ownerCountryId) === countryId) continue;

        const ownerData = countryDataMap.get(String(strait.ownerCountryId));
        if (!ownerData) continue;

        // بررسی آیا این تنگه مسدودیت تایید شده سازمان ملل دارد؟
        let tollRate = 0.05; // ۵ درصد استاندارد
        let isBlockade = false;

        if (strait.blockade && strait.blockade.status === 'approved') {
          if (strait.blockade.targetType === 'worldwide' || String(strait.blockade.targetCountryId) === countryId) {
            tollRate = 0.40; // ۴۰ درصد در صورت بستن تنگه با مجوز سازمان ملل
            isBlockade = true;
          }
        }

        const tollAmount = Math.floor(data.grossIncome * tollRate);
        totalTollDeduction += tollAmount;
        if (isBlockade) {
          data.blockadeTollPaid += tollAmount;
          ownerData.blockadeTollReceived += tollAmount;
        } else {
          data.tollPaid += tollAmount;
          ownerData.tollReceived += tollAmount;
        }
      }

      // اطمینان از اینکه کل کسر عوارض از ۹۰٪ درآمد ناخالص تجاوز نکند
      const maxDeductible = Math.floor(data.grossIncome * 0.90);
      const actualDeduction = Math.min(totalTollDeduction, maxDeductible);
      data.actualTollDeduction = actualDeduction;
      data.netIncome = Math.max(100000, data.grossIncome - actualDeduction);
    }

    // اعمال تغییرات در دیتابیس و ارسال اعلان به رهبران
    for (const [countryId, data] of countryDataMap.entries()) {
      const finalRevenue = data.netIncome + data.tollReceived + data.blockadeTollReceived;
      
      // تسویه خودکار وام بین کشورها: کسر ۸۰ درصد از درآمد و انتقال به وام‌دهنده تا صاف شدن بدهی
      const loanRepay = await gameService.repayLoanFromIncome(countryId, season.id, finalRevenue);
      const actualReceivedIncome = loanRepay.netIncome;

      const currentTreasury = data.state.treasury || 0;
      const currentOil = data.state.oil || 0;
      const newTreasury = currentTreasury + actualReceivedIncome;
      const newOil = currentOil + data.extractedOil;

      await gameService.updateCountryState(countryId, season.id, {
        treasury: newTreasury,
        oil: newOil,
        oilReserve: data.oilReserve,
        oilReserveBonus: data.oilReserveBonus,
      });

      // پیام اختصاصی به کاربر با کلیدهای بازگشت
      if (telegram && data.ownership.userId) {
        const lines = [
          '🏛 <b>واریز دوره‌ای ۱۰ دقیقه‌ای درآمد ملی و نفت</b>',
          '– – – – – – – – – –',
          `💵 درآمد ناخالص ملی: <b>+${fmtNum(data.grossIncome)}$</b>`,
        ];

        if (loanRepay.totalRepaid > 0) {
          lines.push(`🤝 کسر خودکار ۸۰٪ درآمد جهت بازپرداخت بدهی وام: <b>-${fmtNum(loanRepay.totalRepaid)}$</b>`);
        }
        if (data.actualTollDeduction > 0) {
          lines.push(`🚢 عوارض ترانزیت کسرشده تنگه‌ها: <b>-${fmtNum(data.actualTollDeduction)}$</b>`);
        }
        if (data.tollReceived > 0) {
          lines.push(`🌊 درآمد ترانزیت تنگه‌های شما: <b>+${fmtNum(data.tollReceived)}$</b>`);
        }
        if (data.blockadeTollReceived > 0) {
          lines.push(`🚫 خراج انسداد مصوب تنگه‌ها: <b>+${fmtNum(data.blockadeTollReceived)}$</b>`);
        }

        lines.push(`💰 خالص واریزی به خزانه: <b>+${fmtNum(finalRevenue)}$</b>`);
        lines.push(`🛢 نفت استخراج‌شده از دکل‌ها: <b>+${fmtNum(data.extractedOil)} بشکه</b>`);
        lines.push('– – – – – – – – – –');
        lines.push(`🏦 موجودی کل خزانه: <b>${fmtNum(newTreasury)}$</b>`);
        lines.push(`🛢 موجودی کل انبار نفت: <b>${fmtNum(newOil)} بشکه</b>`);

        const incomeKb = {
          reply_markup: {
            inline_keyboard: [
              [{ text: '👑 ورود به امپراطوری', callback_data: 'menu:empire' }],
              [{ text: '🔙 بازگشت به منوی اصلی', callback_data: 'menu:home' }],
            ],
          },
        };

        await safeSend(telegram, data.ownership.userId, lines.join('\n'), incomeKb).catch(() => {});
      }
    }

    logger.info(`واریز ۱۰ دقیقه‌ای برای ${countryDataMap.size} کشور فعال با موفقیت انجام شد.`);
  } catch (err) {
    logger.error('خطا در محاسبه واریز دوره‌ای ۱۰ دقیقه‌ای:', err);
  }
}

// راه‌اندازی تایمرهای بازی
function startGameLoop(telegram) {
  if (loopIntervalId) clearInterval(loopIntervalId);

  const settings = require('./settingsService');
  logger.info('چرخه مرکزی بازی (نفت‌کش‌ها، واریز ۱۰ دقیقه‌ای و بازار ۳۰ دقیقه‌ای) فعال شد.');

  // تیک هر ۱۰ ثانیه برای بررسی نفت‌کش‌ها و سررسید چرخه‌ها
  loopIntervalId = setInterval(async () => {
    try {
      // در صورت خاموش بودن ربات توسط ادمین، فرآیندهای پس‌زمینه متوقف می‌شوند
      const isDisabled = await settings.isBotDisabled();
      if (isDisabled) return;

      // ۱. تحویل نفت‌کش‌ها (بعد از ۱ دقیقه)
      await gameService.processPendingOilShipments(telegram).catch(() => {});

      // ۲. پردازش نبردهای فعال زمان‌واقعی (۱۰ دقیقه‌ای و ترابری سریع‌تر)
      await warService.processPendingBattles(telegram).catch((e) => logger.warn('خطا در پردازش نبردهای فعال:', e.message));

      const now = Date.now();

      // ۳. بررسی وضعیت واریز دوره‌ای درآمد (با رعایت لغو/انجماد و فاصله زمانی مصوب ادمین)
      const isFrozen = await settings.isPayoutsFrozen();
      const payoutIntervalMinutes = await settings.getPayoutInterval();
      const payoutIntervalMs = payoutIntervalMinutes * 60 * 1000;

      if (!isFrozen && (now - lastTenMinuteTick >= payoutIntervalMs)) {
        lastTenMinuteTick = now;
        await executeTenMinutePayout(telegram).catch((e) => logger.warn('خطا در تسویه دوره‌ای:', e.message));
      }

      // ۴. انتشار بولتن ۳۰ دقیقه‌ای رمزارز و سرمایه (۱,۸۰۰,۰۰۰ میلی‌ثانیه)
      if (now - lastThirtyMinuteTick >= 30 * 60 * 1000) {
        lastThirtyMinuteTick = now;
        await cryptoService.publishCryptoBulletin(telegram).catch((e) => logger.warn('خطا در انتشار بولتن ۳۰ دقیقه‌ای:', e.message));
      }
    } catch (err) {
      logger.error('خطای تیک حلقه بازی:', err.message);
    }
  }, 10000);
}

function stopGameLoop() {
  if (loopIntervalId) {
    clearInterval(loopIntervalId);
    loopIntervalId = null;
  }
}

module.exports = {
  startGameLoop,
  stopGameLoop,
  executeTenMinutePayout,
};
