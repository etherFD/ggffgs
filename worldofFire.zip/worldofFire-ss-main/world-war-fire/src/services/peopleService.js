'use strict';

/**
 * سرویس مدیریت خدمات عمومی مردم، مصرف برق، آب، گاز، قطعی‌ها و سرکوب شورش
 */

const { col, snap } = require('../db/firestore');
const settingsService = require('./settingsService');
const countryService = require('./countryService');
const { GameError } = require('../utils/errors');
const { fmtNum } = require('../utils/text');

// مشخصات نیروگاه‌ها و تجهیزات با قیمت‌های پایه قابل ویرایش توسط ادمین
const DEFAULT_UTILITY_PLANTS = {
  power: {
    wind: { name: 'نیروگاه بادی', defaultCost: 25000000, coverage: 10, unit: 'مگاوات', emoji: '💨' },
    solar: { name: 'برق خورشیدی', defaultCost: 40000000, coverage: 15, unit: 'مگاوات', emoji: '☀️' },
    hydro_dam: { name: 'سد برق‌آبی', defaultCost: 120000000, coverage: 30, unit: 'مگاوات', emoji: '🌊' },
    fuel_plant: { name: 'نیروگاه سوختی فسیلی', defaultCost: 70000000, coverage: 25, unit: 'مگاوات', emoji: '🏭', dailyOil: 2000 },
    nuclear: { name: 'نیروگاه اتمی', defaultCost: 350000000, coverage: 50, unit: 'مگاوات', emoji: '☢️' },
  },
  water: {
    wastewater: { name: 'تصفیه آب فاضلاب', defaultCost: 30000000, coverage: 15, unit: 'متر مکعب', emoji: '♻️' },
    groundwater: { name: 'حفر چاه و آب زیرزمینی', defaultCost: 50000000, coverage: 25, unit: 'متر مکعب', emoji: '🚰' },
    desalination: { name: 'تصفیه و نمک‌زدایی آب دریا', defaultCost: 150000000, coverage: 40, unit: 'متر مکعب', emoji: '🌊' },
  },
  gas: {
    gas_storage: { name: 'مخازن ذخیره‌سازی گاز', defaultCost: 45000000, coverage: 20, unit: 'متر مکعب', emoji: '⛽' },
    flare_gas_capture: { name: 'جمع‌آوری گاز مشعل نفت', defaultCost: 85000000, coverage: 35, unit: 'متر مکعب', emoji: '🔥', minRigsRequired: 5 },
  },
};

// هزینه‌های پایه سرکوب شورش
const DEFAULT_QUELL_COSTS = {
  police: 35000000,
  military: 60000000,
  apology: 5000000,
  reform_amnesty: 50000000,
};

async function getPlantCost(category, plantKey) {
  const customKey = `plant_cost_${category}_${plantKey}`;
  const custom = await settingsService.get(customKey, null);
  if (custom && Number(custom) > 0) return Math.floor(Number(custom));
  const def = DEFAULT_UTILITY_PLANTS[category]?.[plantKey];
  return def ? def.defaultCost : 50000000;
}

async function getQuellCost(method) {
  const customKey = `quell_cost_${method}`;
  const custom = await settingsService.get(customKey, null);
  if (custom && Number(custom) > 0) return Math.floor(Number(custom));
  return DEFAULT_QUELL_COSTS[method] || 30000000;
}

/**
 * بازیابی یا مقداردهی اولیه داده‌های خدمات عمومی و شورش کشور
 */
async function getCountryUtilities(countryId, seasonId, gameService) {
  const state = await gameService.getCountryState(countryId, seasonId);
  const country = await countryService.get(countryId);

  const population = Number(state.population || country?.population || 70000000);
  const powerPlants = (state && typeof state.powerPlants === 'object' && state.powerPlants) ? state.powerPlants : { wind: 1, solar: 1 };
  const waterPlants = (state && typeof state.waterPlants === 'object' && state.waterPlants) ? state.waterPlants : { groundwater: 1 };
  const gasPlants = (state && typeof state.gasPlants === 'object' && state.gasPlants) ? state.gasPlants : { gas_storage: 1 };

  // محاسبه درصد پوشش برق
  let powerCoverage = 0;
  for (const [pk, count] of Object.entries(powerPlants || {})) {
    const info = DEFAULT_UTILITY_PLANTS.power && DEFAULT_UTILITY_PLANTS.power[pk];
    if (info && count > 0) {
      if (pk === 'fuel_plant') {
        // اگر نفت کمتر از ۲۰۰۰ بشکه باشد، نیروگاه سوختی خاموش می‌شود
        const oilReserve = Number(state.oil || 0);
        if (oilReserve >= 2000) {
          powerCoverage += info.coverage * count;
        }
      } else {
        powerCoverage += info.coverage * count;
      }
    }
  }

  // محاسبه درصد پوشش آب
  let waterCoverage = 0;
  for (const [pk, count] of Object.entries(waterPlants || {})) {
    const info = DEFAULT_UTILITY_PLANTS.water && DEFAULT_UTILITY_PLANTS.water[pk];
    if (info && count > 0) waterCoverage += info.coverage * count;
  }

  // محاسبه درصد پوشش گاز
  let gasCoverage = 0;
  for (const [pk, count] of Object.entries(gasPlants || {})) {
    const info = DEFAULT_UTILITY_PLANTS.gas && DEFAULT_UTILITY_PLANTS.gas[pk];
    if (info && count > 0) gasCoverage += info.coverage * count;
  }

  // محاسبه نارضایتی ناشی از کمبودها یا قطعی‌ها
  let dissatisfaction = Math.max(0, 100 - Number(state.satisfaction || 60));

  // زیر ۶۰ درصد نارضایتی را افزایش می‌دهد
  if (powerCoverage < 60) dissatisfaction = Math.min(100, dissatisfaction + (60 - powerCoverage) * 0.4);
  if (waterCoverage < 60) dissatisfaction = Math.min(100, dissatisfaction + (60 - waterCoverage) * 0.5);
  if (gasCoverage < 60) dissatisfaction = Math.min(100, dissatisfaction + (60 - gasCoverage) * 0.4);

  // قطعی‌های ثبت‌شده
  const powerOutage = Number(state.powerOutageHours || 0);
  const waterOutage = Number(state.waterOutageHours || 0);
  const gasOutage = Number(state.gasOutageHours || 0);

  if (powerOutage > 6) dissatisfaction = Math.min(100, dissatisfaction + (powerOutage - 6) * 5);
  if (waterOutage > 3) dissatisfaction = Math.min(100, dissatisfaction + (waterOutage - 3) * 7);
  if (gasOutage > 4) dissatisfaction = Math.min(100, dissatisfaction + (gasOutage - 4) * 6);

  dissatisfaction = Math.round(dissatisfaction);
  const satisfaction = Math.max(0, 100 - dissatisfaction);

  // وضعیت شورش
  let rebellionActive = Boolean(state.rebellionActive);
  let rebelRatio = Number(state.rebelRatio || 0);
  const rebellionStartedAt = state.rebellionStartedAt ? new Date(state.rebellionStartedAt) : null;

  if (dissatisfaction >= 70 && !rebellionActive) {
    rebellionActive = true;
    rebelRatio = 15;
  }

  // بررسی رشد شورش هر ۱۰ دقیقه
  if (rebellionActive && rebellionStartedAt) {
    const diffMins = Math.floor((Date.now() - rebellionStartedAt.getTime()) / (10 * 60 * 1000));
    if (diffMins > 0) {
      rebelRatio = Math.min(100, 15 + diffMins * 10);
    }
  }

  return {
    population,
    powerCoverage: Math.min(100, powerCoverage),
    waterCoverage: Math.min(100, waterCoverage),
    gasCoverage: Math.min(100, gasCoverage),
    powerPlants,
    waterPlants,
    gasPlants,
    powerOutage,
    waterOutage,
    gasOutage,
    dissatisfaction,
    satisfaction,
    rebellionActive,
    rebelRatio,
    state,
  };
}

/**
 * خرید و احداث نیروگاه جدید
 */
async function buyUtilityPlant(countryId, seasonId, category, plantKey, gameService) {
  const catPlants = DEFAULT_UTILITY_PLANTS[category];
  if (!catPlants || !catPlants[plantKey]) {
    throw new GameError('تاسیسات یا نیروگاه موردنظر یافت نشد.');
  }

  const plantInfo = catPlants[plantKey];
  const state = await gameService.getCountryState(countryId, seasonId);

  // شرط پیش‌نیاز جمع‌آوری گاز مشعل: داشتن حداقل ۵ دکل نفت فعال
  if (plantKey === 'flare_gas_capture') {
    const rigs = Number(state.oilRigs || 0);
    if (rigs < 5) {
      throw new GameError(`برای احداث تاسیسات جمع‌آوری گاز مشعل نفت، کشور شما باید حداقل ۵ دکل نفتی فعال داشته باشد (تعداد دکل فعلی شما: ${rigs} عدد است).`);
    }
  }

  // شرط پیش‌نیاز نیروگاه هسته‌ای: داشتن حداقل ۱۰۰ کیلوگرم اورانیوم غنی‌شده ۴۰٪ (سوخت راکتور)
  if (plantKey === 'nuclear') {
    const enrichedStock = Number(state.enrichedUranium?.tier40 || 0);
    if (enrichedStock < 100) {
      throw new GameError(`⚠️ احداث نیروگاه اتمی نیازمند حداقل ۱۰۰ کیلوگرم اورانیوم غنی‌شده ۴۰٪ (سوخت راکتور) است!\nموجودی فعلی کشور شما: ${enrichedStock.toLocaleString()} کیلوگرم اورانیوم ۴۰٪ می‌باشد.\n\nابتدا از بازار جهانی اورانیوم خام خریده و در برنامه هسته‌ای آن را غنی‌سازی فرمایید.`);
    }
  }

  const cost = await getPlantCost(category, plantKey);
  const treasury = Number(state.treasury || 0);
  if (treasury < cost) {
    throw new GameError(`موجودی خزانه کافی نیست. هزینه ساخت ${plantInfo.name} برابر با ${fmtNum(cost)}$ است.`);
  }

  const plantsField = category === 'power' ? 'powerPlants' : category === 'water' ? 'waterPlants' : 'gasPlants';
  const currentPlants = state[plantsField] || {};
  currentPlants[plantKey] = Number(currentPlants[plantKey] || 0) + 1;

  // اگر نیروگاه سوختی خریداری شد، ۲۰۰۰ بشکه نفت کسر می‌شود
  let newOil = Number(state.oil || 0);
  if (plantKey === 'fuel_plant') {
    if (newOil >= 2000) {
      newOil -= 2000;
    }
  }

  const patch = {
    treasury: treasury - cost,
    oil: newOil,
    [plantsField]: currentPlants,
  };

  if (plantKey === 'nuclear') {
    const enrichedUranium = { ...(state.enrichedUranium || {}) };
    enrichedUranium.tier40 = Math.max(0, Number(enrichedUranium.tier40 || 0) - 100);
    patch.enrichedUranium = enrichedUranium;
  }

  await gameService.updateCountryState(countryId, seasonId, patch);

  return {
    plant: plantInfo,
    cost,
    remainingTreasury: treasury - cost,
    count: currentPlants[plantKey],
  };
}

/**
 * اعمال قطعی دلخواه برق، آب یا گاز
 */
async function setUtilityOutage(countryId, seasonId, category, hours, gameService) {
  const h = Math.max(0, Math.floor(Number(hours) || 0));
  const field = category === 'power' ? 'powerOutageHours' : category === 'water' ? 'waterOutageHours' : 'gasOutageHours';

  let penalty = 0;
  let threshold = category === 'power' ? 6 : category === 'water' ? 3 : 4;
  if (h > threshold) {
    const diff = h - threshold;
    penalty = category === 'power' ? diff * 5 : category === 'water' ? diff * 7 : diff * 6;
  }

  const state = await gameService.getCountryState(countryId, seasonId);
  const curSat = Number(state.satisfaction || 60);
  const newSat = Math.max(5, curSat - penalty);

  const patch = {
    [field]: h,
    satisfaction: newSat,
  };

  // اگر نارضایتی به بالای ۷۰ رسید، شورش فعال می‌شود
  if (100 - newSat >= 70 && !state.rebellionActive) {
    patch.rebellionActive = true;
    patch.rebelRatio = 20;
    patch.rebellionStartedAt = new Date();
  }

  await gameService.updateCountryState(countryId, seasonId, patch);

  return {
    category,
    hours: h,
    threshold,
    penalty,
    newSatisfaction: newSat,
    dissatisfaction: 100 - newSat,
    rebellionTriggered: 100 - newSat >= 70,
  };
}

/**
 * سرکوب و مهار شورش مردم
 */
async function quellRebellion(countryId, seasonId, method, gameService) {
  const state = await gameService.getCountryState(countryId, seasonId);
  if (!state.rebellionActive && (100 - Number(state.satisfaction || 60)) < 70) {
    throw new GameError('شورش فعالی در کشور وجود ندارد و اوضاع عمومی تحت کنترل است.');
  }

  const cost = await getQuellCost(method);
  const treasury = Number(state.treasury || 0);
  if (treasury < cost) {
    throw new GameError(`هزینه اجرای این راهکار امنیتی (${fmtNum(cost)}$) بیشتر از موجودی خزانه است.`);
  }

  let patch = {
    treasury: treasury - cost,
  };

  let title = '';
  let resultMsg = '';

  if (method === 'police') {
    title = 'استقرار پلیس و یگان ویژه ضدشورش';
    patch.rebelRatio = Math.max(0, (state.rebelRatio || 20) - 45);
    patch.satisfaction = Math.min(65, (state.satisfaction || 25) + 20);
    if (patch.rebelRatio <= 0) {
      patch.rebellionActive = false;
    }
    resultMsg = 'نیروهای یگان ویژه خیابان‌های اصلی را بازپس گرفتند. درصد شورشی‌ها کاهش یافت.';
  } else if (method === 'military') {
    title = 'کشتن شورشی‌ها و سرکوب قهرآمیز ارتش';
    patch.rebelRatio = 0;
    patch.rebellionActive = false;
    patch.legitimacy = Math.max(0, (state.legitimacy || 100) - 30);
    patch.satisfaction = Math.min(50, (state.satisfaction || 20) + 10);
    resultMsg = 'شورشیان با آتش سنگین سرکوب شدند، اما مشروعیت بین‌المللی ۳۰٪ سقوط کرد.';
  } else if (method === 'apology') {
    title = 'پیام عذرخواهی رسمی دولت و وعده حل مشکلات';
    patch.satisfaction = Math.min(60, (state.satisfaction || 25) + 25);
    patch.rebelRatio = Math.max(0, (state.rebelRatio || 20) - 30);
    if (patch.rebelRatio <= 0) {
      patch.rebellionActive = false;
    }
    resultMsg = 'پیام تواضع و وعده رفع فوری قطعی‌ها باعث کاهش التهاب و ترک خیابان‌ها شد.';
  } else if (method === 'reform_amnesty') {
    title = 'تشکیل شورای اصلاحات ملی و عفو عمومی سیاسی';
    patch.rebellionActive = false;
    patch.rebelRatio = 0;
    patch.satisfaction = Math.max(75, (state.satisfaction || 25) + 45);
    patch.powerOutageHours = 0;
    patch.waterOutageHours = 0;
    patch.gasOutageHours = 0;
    resultMsg = 'شورای ملی مطالبات را تصویب و عفو عمومی صادر کرد. کشور به ثبات کامل و پایدار رسید.';
  } else {
    throw new GameError('روش سرکوب انتخاب‌شده نامعتبر است.');
  }

  await gameService.updateCountryState(countryId, seasonId, patch);

  return {
    method,
    title,
    cost,
    remainingTreasury: patch.treasury,
    rebellionActive: patch.rebellionActive,
    newSatisfaction: patch.satisfaction,
    resultMsg,
  };
}

module.exports = {
  DEFAULT_UTILITY_PLANTS,
  DEFAULT_QUELL_COSTS,
  getPlantCost,
  getQuellCost,
  getCountryUtilities,
  buyUtilityPlant,
  setUtilityOutage,
  quellRebellion,
};
