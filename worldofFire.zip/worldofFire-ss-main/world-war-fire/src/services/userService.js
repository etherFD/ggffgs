'use strict';
const { db, col, snap, docs } = require('../db/firestore');
const { displayNameOf } = require('../utils/text');
const { config } = require('../config');
const { GameError } = require('../utils/errors');

const GAME_ID_BASE = 1000;

const userMemoryCache = new Map();
const CACHE_TTL_MS = 90000; // ۹۰ ثانیه نگهداری در حافظه رم برای پاسخ‌دهی میلی‌ثانیه‌ای

async function getById(telegramId) {
  const cached = userMemoryCache.get(String(telegramId));
  if (cached && Date.now() - cached._cachedAt < CACHE_TTL_MS) {
    return cached;
  }
  const u = snap(await col('users').doc(String(telegramId)).get());
  if (u) {
    u._cachedAt = Date.now();
    userMemoryCache.set(String(telegramId), u);
  }
  return u;
}

// ساخت/به‌روزرسانی کاربر با کش سریع در رم جهت پاسخ‌دهی بلادرنگ و بدون کندی
async function touchUser(from) {
  const id = String(from.id);
  const name = displayNameOf(from);
  const username = from.username || null;
  const now = Date.now();

  const cached = userMemoryCache.get(id);
  if (cached && now - cached._cachedAt < CACHE_TTL_MS) {
    // تغییر فوری نام یا یوزرنیم
    if (cached.username !== username || cached.displayName !== name) {
      cached.username = username;
      cached.displayName = name;
      col('users').doc(id).update({ username, displayName: name }).catch(() => {});
    }
    return cached;
  }

  const ref = col('users').doc(id);
  const existing = snap(await ref.get());
  if (existing) {
    const patch = {};
    if (existing.username !== username) patch.username = username;
    if (existing.displayName !== name) patch.displayName = name;
    if (!existing.lastSeenAt || now - new Date(existing.lastSeenAt).getTime() > 120000) {
      patch.lastSeenAt = new Date();
    }
    if (Object.keys(patch).length) {
      ref.update(patch).catch(() => {});
      Object.assign(existing, patch);
    }
    existing._cachedAt = now;
    userMemoryCache.set(id, existing);
    return existing;
  }

  return db().runTransaction(async (tx) => {
    const cur = await tx.get(ref);
    if (cur.exists) {
      const u = snap(cur);
      u._cachedAt = Date.now();
      userMemoryCache.set(id, u);
      return u;
    }
    const cRef = col('counters').doc('userGameId');
    const c = await tx.get(cRef);
    const seq = (c.exists ? c.data().seq : 0) + 1;
    const nowDate = new Date();
    const data = {
      telegramId: from.id, gameId: GAME_ID_BASE + seq, username, displayName: name,
      status: 'active', banReason: null, joinedAt: nowDate, lastSeenAt: nowDate,
      flowName: null, flowData: null, countryCooldownUntil: null,
    };
    tx.set(cRef, { seq });
    tx.create(ref, data);
    const created = { id, ...data, _cachedAt: Date.now() };
    userMemoryCache.set(id, created);
    return created;
  });
}

async function setFlow(userTelegramId, name, data = {}) {
  const id = String(userTelegramId);
  const cached = userMemoryCache.get(id);
  if (cached) {
    cached.flowName = name;
    cached.flowData = data;
  }
  try {
    await col('users').doc(id).set({ flowName: name, flowData: data }, { merge: true });
  } catch (_) {
    // در صورت قطعی موقت دیتابیس، کش حافظه ادامه جریان را تضمین می‌کند
  }
}

async function clearFlow(userTelegramId) {
  const id = String(userTelegramId);
  const cached = userMemoryCache.get(id);
  if (cached) {
    cached.flowName = null;
    cached.flowData = null;
  }
  try {
    await col('users').doc(id).set({ flowName: null, flowData: null }, { merge: true });
  } catch (_) {
    // نادیده‌گرفتن خطای ذخیره‌سازی
  }
}

// جست‌وجو با شناسه بازی یا Telegram ID
async function findByAnyId(n) {
  const q = await col('users').where('gameId', '==', n).limit(1).get();
  if (!q.empty) return snap(q.docs[0]);
  return getById(n);
}

async function listAll() {
  return docs(await col('users').get());
}

async function search(text) {
  const t = String(text || '').trim();
  if (!t) {
    const all = await listAll();
    return all.sort((a, b) => b.joinedAt - a.joinedAt).slice(0, 30);
  }
  if (/^\d+$/.test(t)) {
    const u = await findByAnyId(Number(t));
    return u ? [u] : [];
  }
  const low = t.toLowerCase().replace(/^@/, '');
  const all = await listAll();
  return all.filter((u) => (u.displayName || '').toLowerCase().includes(low) || (u.username || '').toLowerCase().includes(low)).slice(0, 30);
}

async function ban(telegramId, reason = null) {
  if (config.adminIds.includes(Number(telegramId))) throw new GameError('مدیران را نمی‌توان مسدود کرد.');
  const u = await getById(telegramId);
  if (!u) throw new GameError('بازیکن یافت نشد.');
  u.status = 'banned';
  u.banReason = reason || null;
  await col('users').doc(String(telegramId)).update({ status: 'banned', banReason: reason || null });
  userMemoryCache.set(String(telegramId), u);
  return u;
}
async function unban(telegramId) {
  const u = await getById(telegramId);
  if (!u) throw new GameError('بازیکن یافت نشد.');
  u.status = 'active';
  u.banReason = null;
  await col('users').doc(String(telegramId)).update({ status: 'active', banReason: null });
  userMemoryCache.set(String(telegramId), u);
  return u;
}

function _clearCache() {
  userMemoryCache.clear();
}

module.exports = { getById, touchUser, setFlow, clearFlow, findByAnyId, listAll, search, ban, unban, _clearCache };
