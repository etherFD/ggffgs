'use strict';
const { db, col, snap, docs } = require('../db/firestore');
const locks = require('../db/locks');
const countryService = require('./countryService');
const ownership = require('./ownershipService');
const { getActiveSeason } = require('./seasonService');
const { GameError } = require('../utils/errors');

const lockRef = (id) => col('locks').doc(id);

function requiresPayment(c) {
  return c.selectionType === 'premium' || (c.selectionType === 'exclusive' && c.price > 0);
}
function canSeeCountry(c, telegramId) {
  if (!c.isActive) return false;
  if (c.selectionType === 'exclusive') return (c.allowedUserIds || []).includes(telegramId);
  return true;
}

async function createRequest({ user, countryId }) {
  const season = await getActiveSeason();
  if (!season) throw new GameError('در حال حاضر هیچ سیزن فعالی وجود ندارد.');
  if (user.status === 'banned') throw new GameError('حساب شما مسدود است.');
  if (user.countryCooldownUntil && user.countryCooldownUntil > new Date()) throw new GameError('هنوز مدت انتظار انتخاب کشور جدید شما تمام نشده است.');
  if (await ownership.getActiveOwnership(user.telegramId, season.id)) throw new GameError('شما در این سیزن از قبل یک کشور دارید.');
  const country = await countryService.get(countryId);
  if (!country || !canSeeCountry(country, user.telegramId)) throw new GameError('این کشور در دسترس نیست.');
  const currentCountryState = await col('country_states').doc(`${season.id}_${country.id}`).get();
  if (currentCountryState.exists && currentCountryState.data().fallen) throw new GameError('این کشور در این سیزن سقوط کرده و تا سیزن بعد قابل انتخاب نیست.');
  const paid = requiresPayment(country);
  const ref = col('requests').doc();
  const rLock = lockRef(locks.reqLock(season.id, user.telegramId));
  const cLock = lockRef(locks.ownCountry(season.id, country.id));
  const data = {
    userId: user.telegramId, username: user.username, displayName: user.displayName,
    countryId: country.id, seasonId: season.id, selectionType: country.selectionType,
    status: 'pending', paymentStatus: paid ? 'awaiting' : 'not_required', price: paid ? country.price : 0,
    isOpen: true, adminNote: null, reviewedByTelegramId: null, reviewedAt: null, createdAt: new Date(),
  };
  await db().runTransaction(async (tx) => {
    const l = await tx.get(rLock);
    const c = await tx.get(cLock);
    if (l.exists) throw new GameError('شما یک درخواست باز دارید. ابتدا آن را لغو کنید یا منتظر نتیجه بمانید.');
    if (c.exists) throw new GameError('این کشور قبلاً توسط بازیکن دیگری انتخاب شده است.');
    tx.create(ref, data);
    tx.set(rLock, { requestId: ref.id });
  });
  return { request: { id: ref.id, ...data }, country, paid };
}

async function getRequest(id) { return snap(await col('requests').doc(String(id)).get()); }

async function getOpenRequest(userTelegramId) {
  const season = await getActiveSeason();
  if (!season) return null;
  const l = await lockRef(locks.reqLock(season.id, userTelegramId)).get();
  if (!l.exists) return null;
  const req = await getRequest(l.data().requestId);
  if (!req) return null;
  req.country = await countryService.get(req.countryId);
  return req;
}

async function listOpenRequests() {
  const reqs = docs(await col('requests').where('isOpen', '==', true).get()).sort((a, b) => a.createdAt - b.createdAt);
  const cmap = await countryService.getMany(reqs.map((r) => r.countryId));
  for (const r of reqs) r.country = cmap[r.countryId];
  return reqs;
}

async function getPayment(requestId) { return snap(await col('payments').doc(String(requestId)).get()); }

async function submitReceipt({ requestId, userTelegramId, receipt }) {
  const reqRef = col('requests').doc(String(requestId));
  const payRef = col('payments').doc(String(requestId));
  return db().runTransaction(async (tx) => {
    const rS = await tx.get(reqRef);
    const pS = await tx.get(payRef);
    const req = snap(rS);
    if (!req || req.userId !== userTelegramId || !req.isOpen || req.paymentStatus !== 'awaiting') throw new GameError('این درخواست دیگر منتظر رسید نیست.');
    if (pS.exists) throw new GameError('رسید این درخواست قبلاً ثبت شده است.');
    tx.create(payRef, { requestId: req.id, userId: userTelegramId, amount: req.price, receipt, status: 'submitted', reviewedByTelegramId: null, reviewedAt: null, adminNote: null, createdAt: new Date() });
    tx.update(reqRef, { paymentStatus: 'submitted', paymentId: req.id });
    return { ...req, paymentStatus: 'submitted' };
  });
}

async function approvePayment({ requestId, adminTelegramId }) {
  const reqRef = col('requests').doc(String(requestId));
  const payRef = col('payments').doc(String(requestId));
  return db().runTransaction(async (tx) => {
    const req = snap(await tx.get(reqRef));
    const pS = await tx.get(payRef);
    if (!req || !req.isOpen || req.paymentStatus !== 'submitted' || !pS.exists) throw new GameError('این پرداخت در وضعیت «در انتظار بررسی» نیست.');
    tx.update(reqRef, { paymentStatus: 'approved' });
    tx.update(payRef, { status: 'approved', reviewedByTelegramId: adminTelegramId, reviewedAt: new Date() });
    return { ...req, paymentStatus: 'approved' };
  });
}

async function rejectPayment({ requestId, adminTelegramId, note }) {
  const reqRef = col('requests').doc(String(requestId));
  const payRef = col('payments').doc(String(requestId));
  return db().runTransaction(async (tx) => {
    const req = snap(await tx.get(reqRef));
    const pS = await tx.get(payRef);
    if (!req || !req.isOpen || req.paymentStatus !== 'submitted' || !pS.exists) throw new GameError('این پرداخت در وضعیت «در انتظار بررسی» نیست.');
    const upd = { paymentStatus: 'rejected', status: 'rejected', isOpen: false, adminNote: note || null, reviewedByTelegramId: adminTelegramId, reviewedAt: new Date() };
    tx.update(reqRef, upd);
    tx.update(payRef, { status: 'rejected', adminNote: note || null, reviewedByTelegramId: adminTelegramId, reviewedAt: new Date() });
    tx.delete(lockRef(locks.reqLock(req.seasonId, req.userId)));
    return { ...req, ...upd };
  });
}

// تأیید و تخصیص کشور: همه‌چیز در یک تراکنش اتمیک (دوبار اجرا یا تخصیص هم‌زمان ممکن نیست)
async function approveAndAssign({ requestId, adminTelegramId, note }) {
  const reqRef = col('requests').doc(String(requestId));
  const ownRef = col('ownerships').doc();
  const res = await db().runTransaction(async (tx) => {
    const req = snap(await tx.get(reqRef));
    if (!req || !req.isOpen || req.status !== 'pending' || !['not_required', 'approved'].includes(req.paymentStatus)) {
      throw new GameError('این درخواست قابل تخصیص نیست (پرداخت تأیید نشده، قبلاً بررسی شده یا بسته شده است).');
    }
    const cLock = lockRef(locks.ownCountry(req.seasonId, req.countryId));
    const uLock = lockRef(locks.ownUser(req.seasonId, req.userId));
    const countryS = await tx.get(col('countries').doc(req.countryId));
    const userS = await tx.get(col('users').doc(String(req.userId)));
    const cS = await tx.get(cLock);
    const uS = await tx.get(uLock);
    const countryStateS = await tx.get(col('country_states').doc(`${req.seasonId}_${req.countryId}`));
    if (!countryS.exists || !countryS.data().isActive) throw new GameError('این کشور وجود ندارد یا غیرفعال است.');
    if (countryStateS.exists && countryStateS.data().fallen) throw new GameError('این کشور در این سیزن سقوط کرده و تا سیزن بعد قابل انتخاب نیست.');
    if (!userS.exists || userS.data().status === 'banned') throw new GameError('بازیکن یافت نشد یا مسدود است.');
    if (cS.exists) throw new GameError('این کشور در این سیزن قبلاً به بازیکن دیگری اختصاص داده شده است.');
    if (uS.exists) throw new GameError('این بازیکن در این سیزن از قبل یک کشور فعال دارد.');
    tx.create(ownRef, { seasonId: req.seasonId, countryId: req.countryId, userId: req.userId, status: 'active', startedAt: new Date(), endedAt: null, endReason: null, requestId: req.id, assignedByTelegramId: adminTelegramId, createdAt: new Date() });
    tx.set(cLock, { ownershipId: ownRef.id });
    tx.set(uLock, { ownershipId: ownRef.id });
    const upd = { status: 'approved', isOpen: false, adminNote: note || null, reviewedByTelegramId: adminTelegramId, reviewedAt: new Date() };
    tx.update(reqRef, upd);
    tx.delete(lockRef(locks.reqLock(req.seasonId, req.userId)));
    return { ...req, ...upd };
  });
  ownership.invalidateOwnershipCache(res.userId);
  return res;
}

async function rejectRequest({ requestId, adminTelegramId, note }) {
  const reqRef = col('requests').doc(String(requestId));
  return db().runTransaction(async (tx) => {
    const req = snap(await tx.get(reqRef));
    if (!req || !req.isOpen || req.status !== 'pending') throw new GameError('این درخواست دیگر قابل رد کردن نیست.');
    const upd = { status: 'rejected', isOpen: false, adminNote: note || null, reviewedByTelegramId: adminTelegramId, reviewedAt: new Date() };
    tx.update(reqRef, upd);
    tx.delete(lockRef(locks.reqLock(req.seasonId, req.userId)));
    return { ...req, ...upd };
  });
}

async function cancelByUser({ requestId, userTelegramId }) {
  const reqRef = col('requests').doc(String(requestId));
  return db().runTransaction(async (tx) => {
    const req = snap(await tx.get(reqRef));
    if (!req || req.userId !== userTelegramId || !req.isOpen || req.status !== 'pending' || !['not_required', 'awaiting'].includes(req.paymentStatus)) {
      throw new GameError('این درخواست دیگر قابل لغو نیست.');
    }
    tx.update(reqRef, { status: 'cancelled', isOpen: false });
    tx.delete(lockRef(locks.reqLock(req.seasonId, req.userId)));
    return { ...req, status: 'cancelled', isOpen: false };
  });
}

module.exports = {
  requiresPayment, canSeeCountry, createRequest, getRequest, getOpenRequest, listOpenRequests, getPayment,
  submitReceipt, approvePayment, rejectPayment, approveAndAssign, rejectRequest, cancelByUser,
};
