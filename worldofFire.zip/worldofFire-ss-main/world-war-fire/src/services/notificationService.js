'use strict';
const settings = require('./settingsService');
const { config } = require('../config');
const logger = require('../utils/logger');

// فقط پیام‌های مربوط به بازی با این دسته‌ها در کانال منتشر می‌شوند
const CHANNEL_CATEGORIES = Object.freeze([
  'statement', 'economic_report', 'war_news', 'ceasefire_news', 'trade_news',
  'alliance_news', 'leader_change', 'religion_change', 'government_change',
  'project_news', 'season_results', 'announcement',
]);

let cachedBotUsername = null;
async function getBotLink(telegram) {
  if (cachedBotUsername) return `https://t.me/${cachedBotUsername}`;
  if (process.env.BOT_USERNAME) {
    cachedBotUsername = process.env.BOT_USERNAME.replace(/^@/, '');
    return `https://t.me/${cachedBotUsername}`;
  }
  if (telegram && typeof telegram.getMe === 'function') {
    try {
      const me = await telegram.getMe();
      if (me && me.username) {
        cachedBotUsername = me.username;
        return `https://t.me/${cachedBotUsername}`;
      }
    } catch (_) {}
  }
  return 'https://t.me/FIRE_OF_War_Bot';
}

let colorCounter = 0;
// استایل‌های رنگی متنوع جهت چرخش رنگ پیام به پیام (سبز: success، آبی: primary، قرمز: danger)
const BUTTON_STYLES = [
  { style: 'success', text: '🟢 ورود به ربات و مرکز فرماندهی' },
  { style: 'primary', text: '🔵 ورود به نبرد جهانی و عملیات' },
  { style: 'danger', text: '🔴 ورود فوری به بازی جنگ جهانی' },
  { style: 'primary', text: '👑 ورود به مدیریت امپراطوری' },
  { style: 'success', text: '⚡ ورود به پایگاه اقتصادی و نفت' },
  { style: 'danger', text: '💥 پیوستن به جبهه‌های نبرد' },
];

function getNextButtonStyle() {
  const item = BUTTON_STYLES[colorCounter % BUTTON_STYLES.length];
  colorCounter++;
  return item;
}

function attachBotButton(extra, botUrl) {
  const chosen = (extra && extra.buttonStyle) || getNextButtonStyle();
  const botBtn = {
    text: String((extra && extra.buttonText) || chosen.text),
    url: String(botUrl),
    style: chosen.style,
  };
  const out = { ...(extra || {}) };
  delete out.buttonStyle;
  delete out.buttonText;

  let ik = [];
  const STYLES_CYCLE = ['primary', 'success', 'danger'];
  let sIdx = colorCounter;

  if (out.reply_markup && out.reply_markup.inline_keyboard) {
    ik = out.reply_markup.inline_keyboard.map((row) => {
      if (!Array.isArray(row)) return [];
      return row.map((btn) => {
        const assignedStyle = btn.style || STYLES_CYCLE[(sIdx++) % STYLES_CYCLE.length];
        if (btn.url) return { text: String(btn.text), url: String(btn.url), style: assignedStyle };
        if (btn.callback_data) return { text: String(btn.text), callback_data: String(btn.callback_data), style: assignedStyle };
        return { text: String(btn.text), url: String(botUrl), style: assignedStyle };
      });
    });
  }

  const hasBotBtn = ik.some((row) => Array.isArray(row) && row.some((b) => b.url && b.url.includes('t.me')));
  if (!hasBotBtn) ik.push([botBtn]);

  out.reply_markup = { inline_keyboard: ik };
  return out;
}

async function publishToChannel(telegram, category, text, extra = {}) {
  if (!CHANNEL_CATEGORIES.includes(category)) throw new Error(`دسته انتشار نامعتبر: ${category}`);
  if (!(await settings.get(`channelCategory.${category}`, true))) return null;
  const channelId = await settings.getChannelId();
  if (!channelId) {
    logger.warn('شناسه کانال تنظیم نشده؛ پیام منتشر نشد:', category);
    return null;
  }
  const botUrl = await getBotLink(telegram);
  const finalExtra = attachBotButton(extra, botUrl);
  return telegram.sendMessage(channelId, text, { parse_mode: 'HTML', disable_web_page_preview: true, ...finalExtra });
}

async function resolvePhotoSource(photo) {
  if (!photo) return null;
  if (typeof photo === 'object' && (photo.source || Buffer.isBuffer(photo))) return photo;

  const fs = require('fs');
  const path = require('path');

  if (typeof photo === 'string') {
    const trimmed = photo.trim();
    if (!trimmed) return null;

    // 1. Base64 Data URL (data:image/...)
    if (trimmed.startsWith('data:image/')) {
      const match = trimmed.match(/^data:image\/[a-zA-Z0-9+]+;base64,(.+)$/);
      if (match) {
        return { source: Buffer.from(match[1], 'base64') };
      }
    }

    // 2. جستجوی فایل محلی در تمام دایرکتوری‌های پروژه و public
    const cleanRel = trimmed.replace(/^\/+/, '');
    const candidatePaths = [
      trimmed,
      path.resolve(process.cwd(), cleanRel),
      path.resolve(process.cwd(), 'world-war-fire', 'public', cleanRel),
      path.resolve(process.cwd(), 'world-war-fire', 'public', cleanRel.replace(/^public\//, '')),
      path.resolve(process.cwd(), 'public', cleanRel),
      path.resolve(process.cwd(), 'public', cleanRel.replace(/^public\//, '')),
      path.resolve(__dirname, '..', '..', 'public', cleanRel),
      path.resolve(__dirname, '..', '..', 'public', cleanRel.replace(/^public\//, '')),
      path.resolve(__dirname, '..', '..', '..', 'public', cleanRel),
      path.resolve(__dirname, '..', '..', '..', 'public', cleanRel.replace(/^public\//, '')),
    ];

    for (const cand of candidatePaths) {
      try {
        if (fs.existsSync(cand) && fs.statSync(cand).isFile()) {
          return { source: cand };
        }
      } catch (_) {}
    }

    // 3. آدرس وب اینترنتی (HTTP / HTTPS)
    if (trimmed.startsWith('http://') || trimmed.startsWith('https://')) {
      try {
        const parsed = new URL(trimmed);
        const pathPart = parsed.pathname.replace(/^\/+/, '');
        const urlCand = [
          path.resolve(process.cwd(), 'world-war-fire', 'public', pathPart),
          path.resolve(process.cwd(), 'public', pathPart),
          path.resolve(__dirname, '..', '..', 'public', pathPart),
        ];
        for (const c of urlCand) {
          if (fs.existsSync(c) && fs.statSync(c).isFile()) {
            return { source: c };
          }
        }

        const r = await fetch(trimmed, { redirect: 'follow' });
        if (r.ok) {
          const buf = Buffer.from(await r.arrayBuffer());
          return { source: buf };
        }
      } catch (_) {}
      return trimmed;
    }

    // 4. شناسه فایل تلگرام یا نام فایل
    return trimmed;
  }

  return photo;
}

async function publishPhotoToChannel(telegram, category, photo, caption, extra = {}) {
  if (!CHANNEL_CATEGORIES.includes(category)) throw new Error(`دسته انتشار نامعتبر: ${category}`);
  if (!(await settings.get(`channelCategory.${category}`, true))) return null;
  const channelId = await settings.getChannelId();
  if (!channelId) return null;

  const photoSource = await resolvePhotoSource(photo);
  if (!photoSource) {
    return publishToChannel(telegram, category, caption, extra);
  }

  const botUrl = await getBotLink(telegram);
  const finalExtra = attachBotButton(extra, botUrl);

  // تلگرام حداکثر ۱۰۲۴ کاراکتر برای کپشن عکس قبول می‌کند
  let safeCaption = caption || '';
  if (safeCaption.length > 980) {
    safeCaption = safeCaption.slice(0, 970) + '...';
  }

  // تلاش ۱: ارسال مستقیم عکس با Telegraf
  try {
    return await telegram.sendPhoto(channelId, photoSource, { caption: safeCaption, parse_mode: 'HTML', ...finalExtra });
  } catch (err1) {
    logger.warn('خطای مرحله ۱ در ارسال عکس به کانال:', err1.description || err1.message);

    // تلاش ۲: اگر عکس رشته بود (شناسه فایل تلگرام یا آدرس فایل)، دانلود و ارسال مستقیم Buffer
    if (typeof photoSource === 'string' && telegram && typeof telegram.getFileLink === 'function') {
      try {
        const fileLink = await telegram.getFileLink(photoSource);
        if (fileLink) {
          const res = await fetch(fileLink.href || String(fileLink));
          if (res.ok) {
            const buf = Buffer.from(await res.arrayBuffer());
            return await telegram.sendPhoto(channelId, { source: buf }, { caption: safeCaption, parse_mode: 'HTML', ...finalExtra });
          }
        }
      } catch (err2) {
        logger.warn('تلاش مرحله ۲ (دریافت باینری تصویر با getFileLink) ناموفق بود:', err2.message);
      }
    }

    // تلاش ۳: اگر خطا مربوط به parse_mode و تگ‌های HTML بود، حذف تگ‌ها و ارسال مجدد
    if (err1.message && (err1.message.includes('can\'t parse entities') || err1.message.includes('entity'))) {
      try {
        const plainCaption = safeCaption.replace(/<[^>]+>/g, '');
        return await telegram.sendPhoto(channelId, photoSource, { caption: plainCaption, ...finalExtra });
      } catch (_) {}
    }

    // در نهایت اگر هیچ راهی برای ارسال عکس پاسخ نداد، ارسال پیام متنی تا خبر از بین نرود
    return telegram.sendMessage(channelId, caption, { parse_mode: 'HTML', disable_web_page_preview: false, ...finalExtra });
  }
}

// اعلام رسمی تغییرات سیزن (ایجاد، حذف یا ریست) در کانال و پیوی تمام کاربران
async function announceSeasonChange(telegram, { type, seasonName, details = '' }) {
  const { esc } = require('../utils/text');
  const userService = require('./userService');

  let channelText = '';
  let pvText = '';

  if (type === 'create') {
    channelText = [
      '🏆 <b>آغاز رسمی سیزن جدید در WORLD WAR FIRE!</b>',
      '– – – – – – – – – –',
      `🌍 <b>${esc(seasonName)}</b> رسماً آغاز شد!`,
      '👑 تمامی رهبران، پادشاهان و فرماندهان جهان می‌توانند هم‌اکنون وارد ربات شده و کشور خود را برگزینند.',
      '⚔️ مرزها گشوده شد، استخراج نفت و تحرکات استراتژیک نظامی آغاز گردید!',
      details ? `\n📝 توضیحات: <i>${esc(details)}</i>` : '',
    ].filter(Boolean).join('\n');

    pvText = [
      '🏆 <b>سیزن جدید آغاز شد!</b>',
      '– – – – – – – – – –',
      `🌍 <b>${esc(seasonName)}</b> رسماً کلید خورد!`,
      '👑 هم‌اکنون وارد ربات شوید، کشور خود را انتخاب کنید و نبرد جهانی را فرماندهی نمایید.',
      details ? `\n📝 توضیحات: ${esc(details)}` : '',
    ].filter(Boolean).join('\n');
  } else if (type === 'delete') {
    channelText = [
      '⚠️ <b>اطلاعیه مهم: پایان و انحلال سیزن جاری</b>',
      '– – – – – – – – – –',
      `سیزن <b>${esc(seasonName)}</b> توسط مدیریت بازی بسته و حذف گردید.`,
      '🕊️ تمامی عملیات‌ها موقتاً متوقف شد. منتظر اطلاعیه بعدی و آغاز سیزن باشکوه جدید باشید.',
      details ? `\n📝 علت: <i>${esc(details)}</i>` : '',
    ].filter(Boolean).join('\n');

    pvText = [
      '⚠️ <b>پایان و انحلال سیزن بازی</b>',
      '– – – – – – – – – –',
      `سیزن <b>${esc(seasonName)}</b> توسط مدیریت بازی بسته و حذف شد.`,
      'به‌زودی با آغاز سیزن جدید، اطلاع‌رسانی رسمی در پیوی شما انجام خواهد شد.',
      details ? `\n📝 علت: ${esc(details)}` : '',
    ].filter(Boolean).join('\n');
  } else if (type === 'reset') {
    channelText = [
      '🔄 <b>ریست و شروع مجدد سیزن بازی!</b>',
      '– – – – – – – – – –',
      `سیزن <b>${esc(seasonName)}</b> ریست شد و کلیه وضعیت‌های نظامی، اقتصادی و قلمروها به حالت اولیه بازگشت.`,
      '🌍 فرصت دوباره برای تمام کشورها جهت فتح جهان!',
    ].join('\n');

    pvText = [
      '🔄 <b>ریست و شروع مجدد سیزن بازی!</b>',
      '– – – – – – – – – –',
      `سیزن <b>${esc(seasonName)}</b> ریست شد و به نقطه شروع بازگشت.`,
      'وارد ربات شوید و استراتژی جدید خود را پیاده کنید.',
    ].join('\n');
  }

  // ۱. انتشار در کانال با دکمه رنگی ورود به ربات
  if (telegram) {
    try {
      await publishToChannel(telegram, 'announcement', channelText);
    } catch (err) {
      logger.warn('خطا در انتشار اعلان سیزن در کانال:', err.message);
    }
  }

  // ۲. ارسال مستقیم به پیوی تمام بازیکنان ثبت‌شده در ربات
  if (telegram) {
    try {
      const users = await userService.listAll();
      const botUrl = await getBotLink(telegram);
      const pvExtra = {
        reply_markup: {
          inline_keyboard: [
            [{ text: '🟢 ورود به ربات 🤖', url: botUrl, style: 'success' }],
          ],
        },
      };

      let sentCount = 0;
      for (const u of users) {
        if (u.status !== 'banned' && u.telegramId) {
          await safeSend(telegram, u.telegramId, pvText, pvExtra);
          sentCount++;
        }
      }
      logger.info(`اعلان تغییرات سیزن (${type}) به پیوی ${sentCount} بازیکن مخابره شد.`);
    } catch (err) {
      logger.warn('خطا در ارسال اعلان سیزن به پیوی کاربران:', err.message);
    }
  }
}

async function verifyChannel(telegram, channelId) {
  try {
    const chat = await telegram.getChat(channelId);
    const me = await telegram.getMe();
    const member = await telegram.getChatMember(chat.id, me.id);
    const ok = member.status === 'creator' || (member.status === 'administrator' && (chat.type !== 'channel' || member.can_post_messages !== false));
    if (!ok) return { ok: false, title: chat.title, reason: 'ربات در این کانال ادمین با مجوز «ارسال پیام» نیست.' };
    return { ok: true, title: chat.title, id: chat.id };
  } catch (err) {
    return { ok: false, reason: `دسترسی به کانال ممکن نیست: ${err.description || err.message}` };
  }
}

async function notifyAdmins(telegram, text, extra = {}, photoFileId = null) {
  // طبق درخواست کاربر، پیام‌های مدیریتی منحصراً به ربات اختصاصی ادمین فرستاده می‌شود و ربات اصلی درگیر نمی‌شود
  const adminBotService = require('./adminBotService');
  return adminBotService.sendToAdminBot(telegram, text, extra, photoFileId);
}

async function safeSend(telegram, chatId, text, extra = {}) {
  try {
    const finalExtra = { parse_mode: 'HTML', ...(extra || {}) };
    const defaultReturnBtn = [{ text: '🔙 بازگشت به منوی اصلی', callback_data: 'menu:home' }];

    if (!finalExtra.reply_markup) {
      finalExtra.reply_markup = { inline_keyboard: [defaultReturnBtn] };
    } else if (finalExtra.reply_markup.inline_keyboard) {
      const ik = finalExtra.reply_markup.inline_keyboard;
      const hasBack = ik.some((r) =>
        Array.isArray(r) &&
        r.some((b) =>
          (b.callback_data && (b.callback_data.includes('home') || b.callback_data.includes('back') || b.callback_data.includes('ad:home'))) ||
          (b.text && (b.text.includes('بازگشت') || b.text.includes('منو')))
        )
      );
      if (!hasBack) {
        ik.push(defaultReturnBtn);
      }
    }
    return await telegram.sendMessage(chatId, text, finalExtra);
  } catch (err) {
    logger.warn(`ارسال پیام به ${chatId} ناموفق بود: ${err.description || err.message}`);
    return null;
  }
}

module.exports = {
  CHANNEL_CATEGORIES,
  resolvePhotoSource,
  publishToChannel,
  publishPhotoToChannel,
  verifyChannel,
  notifyAdmins,
  safeSend,
  announceSeasonChange,
};
