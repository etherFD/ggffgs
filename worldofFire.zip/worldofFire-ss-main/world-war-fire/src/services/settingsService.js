'use strict';
const { col, snap } = require('../db/firestore');
const { config } = require('../config');

const NOT_FOUND = Symbol('nf');
const cache = new Map();

async function get(key, def = null) {
  if (cache.has(key)) {
    const v = cache.get(key);
    return v === NOT_FOUND ? def : v;
  }
  const d = snap(await col('settings').doc(key).get());
  cache.set(key, d ? d.value : NOT_FOUND);
  return d ? d.value : def;
}

async function set(key, value, adminTelegramId = null) {
  await col('settings').doc(key).set({ value, updatedBy: adminTelegramId, updatedAt: new Date() });
  cache.set(key, value);
}

async function unset(key) {
  await col('settings').doc(key).delete();
  cache.set(key, NOT_FOUND);
}

// شناسه کانال: اولویت با داشبورد، سپس متغیر محیطی
async function getChannelId() {
  const v = await get('channelId', null);
  return (v && String(v).trim()) || config.channelId || process.env.CHANNEL_ID || null;
}

// شناسه ابرگروه رسمی بازی
async function getGroupId() {
  const v = await get('groupId', null);
  return (v && String(v).trim()) || process.env.GROUP_ID || null;
}

// لینک‌های عضویت اجباری کانال و گروه
async function getRequiredLinks() {
  const chLink = await get('channelLink', null);
  const gpLink = await get('groupLink', null);
  const chId = await getChannelId();
  const gpId = await getGroupId();
  return {
    channelLink: chLink || (chId && chId.startsWith('@') ? `https://t.me/${chId.slice(1)}` : 'https://t.me/worldwarfire_ch'),
    groupLink: gpLink || (gpId && gpId.startsWith('@') ? `https://t.me/${gpId.slice(1)}` : 'https://t.me/worldwarfire_gp'),
    channelId: chId,
    groupId: gpId,
  };
}

// وضعیت انجماد/لغو واریز درآمدهای دوره‌ای
async function isPayoutsFrozen() {
  const v = await get('payouts_frozen', false);
  return v === true || v === 'true';
}

async function setPayoutsFrozen(frozen, adminTelegramId = null) {
  await set('payouts_frozen', Boolean(frozen), adminTelegramId);
}

// فاصله زمانی واریز درآمد (به دقیقه، پیش‌فرض ۱۰ دقیقه)
async function getPayoutInterval() {
  const v = await get('payout_interval_minutes', 10);
  const num = Number(v);
  return Number.isFinite(num) && num >= 1 ? num : 10;
}

async function setPayoutInterval(minutes, adminTelegramId = null) {
  const val = Math.max(1, Number(minutes) || 10);
  await set('payout_interval_minutes', val, adminTelegramId);
}

// برند: WORLD WAR FIRE پیش‌فرض است و مدیر می‌تواند تغییر دهد
async function getBrand() {
  return {
    gameName: (await get('gameName', null)) || config.brandDefaults.gameName,
    channelName: (await get('channelName', null)) || config.brandDefaults.channelName,
  };
}

// بررسی وضعیت فعال/خاموش بودن ربات توسط ادمین
async function isBotDisabled() {
  const v = await get('botDisabled', false);
  return v === true || v === 'true';
}

async function setBotDisabled(disabled, adminTelegramId = null) {
  await set('botDisabled', Boolean(disabled), adminTelegramId);
}

const _clearCache = () => cache.clear();
module.exports = {
  get,
  set,
  unset,
  getChannelId,
  getGroupId,
  getRequiredLinks,
  isPayoutsFrozen,
  setPayoutsFrozen,
  getPayoutInterval,
  setPayoutInterval,
  getBrand,
  isBotDisabled,
  setBotDisabled,
  _clearCache,
};
