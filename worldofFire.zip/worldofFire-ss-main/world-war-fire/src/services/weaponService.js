'use strict';
const { col, docs, snap } = require('../db/firestore');
const { GameError } = require('../utils/errors');

const WEAPON_CATEGORIES = [
  {
    id: 'army',
    name: 'ارتش',
    emoji: '🪖',
    capability: 'پیاده‌نظام و نیروهای زمینی، تصرف خطوط و پادگان‌های مرزی',
    attackModes: ['ground', 'combined'],
    requiresTransportForIslands: true,
  },
  {
    id: 'tank',
    name: 'تانک',
    emoji: '🛡️',
    capability: 'زره سنگین زمینی، درهم‌شکستن استحکامات و پیشروی میدانی',
    attackModes: ['ground', 'combined'],
    requiresTransportForIslands: true,
  },
  {
    id: 'fighter',
    name: 'جنگنده',
    emoji: '✈️',
    capability: 'برتری هوایی، رهگیری هوایی و عملیات هجومی برق‌آسا',
    attackModes: ['air', 'combined'],
  },
  {
    id: 'missile',
    name: 'موشک',
    emoji: '🚀',
    capability: 'شلیک دوربرد بالستیک نقطه‌زن بدون ریسک تلفات انسانی',
    attackModes: ['missile', 'combined'],
  },
  {
    id: 'defense',
    name: 'پدافند',
    emoji: '🛡️',
    capability: 'رهگیری و انهدام موشک‌ها، پهپادها و جنگنده‌های متخاصم',
    attackModes: ['defense', 'combined'],
  },
  {
    id: 'spy_drone',
    name: 'پهپاد جاسوسی',
    emoji: '📡',
    capability: 'شناسایی آرایش نظامی دشمن پیش از حمله و افزایش دقت عملیات',
    attackModes: ['air', 'ground', 'naval', 'combined'],
  },
  {
    id: 'kamikaze_drone',
    name: 'پهپاد انتحاری',
    emoji: '🛸',
    capability: 'ضربه انتحاری ارزان و دقیق به سامانه‌های راداری و پدافندی دشمن',
    attackModes: ['air', 'ground', 'combined'],
  },
  {
    id: 'armored_carrier',
    name: 'زره بر',
    emoji: '🚚',
    capability: 'ترابری سریع زرهی و کاهش ۳۵٪ زمان رسیدن تجهیزات به خط نبرد',
    attackModes: ['ground', 'combined'],
    speedMultiplier: 1.5,
  },
  {
    id: 'army_ai',
    name: 'هوش مصنوعی ارتش',
    emoji: '🤖',
    capability: 'فرماندهی تاکتیکی خودکار جبهه (قابلیت ارتقا و سطح‌بندی؛ هر لول +۱۰٪ قدرت ارتش)',
    attackModes: ['ground', 'air', 'naval', 'missile', 'combined'],
    isUpgradeable: true,
  },
  {
    id: 'aircraft_carrier',
    name: 'ناو هواپیما بر',
    emoji: '🚢',
    capability: 'پایگاه هوایی متحرک در اقیانوس، پشتیبانی از حملات هوایی و دریایی دوردست',
    attackModes: ['naval', 'air', 'combined'],
    canTransportGroundToIslands: true,
  },
  {
    id: 'warship',
    name: 'ناو جنگی',
    emoji: '🛳️',
    capability: 'آتشباری سنگین سطحی، انهدام مواضع ساحلی و پشتیبانی از عملیات آبخاکی',
    attackModes: ['naval', 'combined'],
    canTransportGroundToIslands: true,
  },
  {
    id: 'boat',
    name: 'قایق',
    emoji: '🚤',
    capability: 'قایق‌های تندرو موشک‌انداز، گشت ساحلی سریع و غافلگیری در آبراه‌ها',
    attackModes: ['naval', 'combined'],
  },
  {
    id: 'submarine',
    name: 'زیر دریایی',
    emoji: '🌊',
    capability: 'کمین خاموش زیر سطحی، شکار ناوها و قطع خطوط مواصلاتی دریایی',
    attackModes: ['naval', 'combined'],
  },
  {
    id: 'cargo_plane',
    name: 'هواپیما انتقال تجهییزات',
    emoji: '🛫',
    capability: 'پل هوایی استراتژیک و کاهش تا ۶۰٪ زمان اعزام و رسیدن تجهیزات به جبهه',
    attackModes: ['air', 'ground', 'combined'],
    speedMultiplier: 2.5,
  },
  {
    id: 'nuclear_sub',
    name: 'زیر دریایی هسته ای',
    emoji: '☢️',
    capability: 'بازدارندگی راهبردی اتمی، ماندگاری نامحدود در اعماق و موشک‌های سهمگین',
    attackModes: ['naval', 'missile', 'combined'],
  },
  {
    id: 'bomber',
    name: 'بمب افکن',
    emoji: '💣',
    capability: 'بمباران سنگین هوایی زیرساخت‌ها، پالایشگاه‌ها و استحکامات دشمن',
    attackModes: ['air', 'combined'],
  },
  {
    id: 'cargo_ship',
    name: 'ناو تجهییزات بر',
    emoji: '⛴️',
    capability: 'ترابری سنگین دریایی و انتقال ادوات و تانک‌ها به جزایر و سواحل دور',
    attackModes: ['naval', 'ground', 'combined'],
    canTransportGroundToIslands: true,
  },
];

const DEFAULT_WEAPONS = [
  // ۱. ارتش
  { id: 'wpn_infantry', name: 'پیاده‌نظام تکاور (گروهان ۵۰ نفره)', emoji: '🪖', price: 250000, category: 'army', power: 45, bundle: 50 },
  { id: 'wpn_special_forces', name: 'کماندوهای نیروی مخصوص', emoji: '🪖', price: 1200000, category: 'army', power: 120, bundle: 10 },

  // ۲. تانک
  { id: 'wpn_tank_karrar', name: 'تانک سنگین کرار / T-90', emoji: '🛡️', price: 3500000, category: 'tank', power: 180 },
  { id: 'wpn_tank_zulfiqar', name: 'تانک ذوالفقار ۳', emoji: '🛡️', price: 2000000, category: 'tank', power: 95 },

  // ۳. جنگنده
  { id: 'wpn_f16', name: 'جنگنده چندمنظوره F-16', emoji: '✈️', price: 35000000, category: 'fighter', power: 650 },
  { id: 'wpn_kowsar', name: 'جنگنده بمب‌افکن کوثر', emoji: '✈️', price: 18000000, category: 'fighter', power: 340 },

  // ۴. موشک
  { id: 'wpn_fateh110', name: 'موشک بالستیک نقطه‌زن فاتح ۱۱۰', emoji: '🚀', price: 15000000, category: 'missile', power: 380 },
  { id: 'wpn_khorramshahr', name: 'موشک سنگین خرمشهر ۴', emoji: '🚀', price: 45000000, category: 'missile', power: 900 },

  // ۵. پدافند
  { id: 'wpn_khordad15', name: 'سامانه پدافند هوایی خرداد ۱۵', emoji: '🛡️', price: 28000000, category: 'defense', power: 500 },
  { id: 'wpn_s300', name: 'سامانه پدافند موشکی S-300', emoji: '🛡️', price: 55000000, category: 'defense', power: 850 },

  // ۶. پهپاد جاسوسی
  { id: 'wpn_spy_mohajer', name: 'پهپاد شناسایی مهاجر ۶', emoji: '📡', price: 4000000, category: 'spy_drone', power: 90 },

  // ۷. پهپاد انتحاری
  { id: 'wpn_shahed136', name: 'پهپاد انتحاری شاهد ۱۳۶', emoji: '🛸', price: 2500000, category: 'kamikaze_drone', power: 160 },

  // ۸. زره بر
  { id: 'wpn_apc_carrier', name: 'ترابری زرهی شنی‌دار و نفربر زره‌بر', emoji: '🚚', price: 6000000, category: 'armored_carrier', power: 80 },

  // ۹. هوش مصنوعی ارتش
  { id: 'wpn_ai_commander_1', name: 'هوش مصنوعی ارتش - سطح ۱', emoji: '🤖', price: 50000000, category: 'army_ai', power: 400, level: 1, capability: 'تحلیل پایه میدان نبرد و +۱۰٪ قدرت ارتش' },
  { id: 'wpn_ai_commander_2', name: 'هوش مصنوعی ارتش - سطح ۲', emoji: '🤖', price: 95000000, category: 'army_ai', power: 650, level: 2, capability: 'جایگزین سطح ۱؛ تحلیل بهتر و +۲۰٪ قدرت ارتش' },
  { id: 'wpn_ai_commander_3', name: 'هوش مصنوعی ارتش - سطح ۳', emoji: '🤖', price: 175000000, category: 'army_ai', power: 950, level: 3, capability: 'جایگزین سطح ۲؛ پیش‌بینی نبرد و +۳۰٪ قدرت ارتش' },
  { id: 'wpn_ai_commander_4', name: 'هوش مصنوعی ارتش - سطح ۴', emoji: '🤖', price: 300000000, category: 'army_ai', power: 1400, level: 4, capability: 'جایگزین سطح ۳؛ فرماندهی پیشرفته و +۴۰٪ قدرت ارتش' },

  // ۱۰. ناو هواپیما بر
  { id: 'wpn_aircraft_carrier', name: 'ناو هواپیمابر کلاس سنگین', emoji: '🚢', price: 180000000, category: 'aircraft_carrier', power: 2500 },

  // ۱۱. ناو جنگی
  { id: 'wpn_destroyer', name: 'ناوشکن رزمی جماران / ناوجنگی', emoji: '🛳️', price: 45000000, category: 'warship', power: 750 },

  // ۱۲. قایق
  { id: 'wpn_speed_boat', name: 'قایق تندرو موشک‌انداز عاشورا', emoji: '🚤', price: 3000000, category: 'boat', power: 90 },

  // ۱۳. زیر دریایی
  { id: 'wpn_sub_fateh', name: 'زیردریایی تهاجمی فاتح', emoji: '🌊', price: 60000000, category: 'submarine', power: 950 },

  // ۱۴. هواپیما انتقال تجهییزات
  { id: 'wpn_cargo_il76', name: 'هواپیمای ترابری استراتژیک ایلوشین ۷۶', emoji: '🛫', price: 40000000, category: 'cargo_plane', power: 200 },

  // ۱۵. زیر دریایی هسته ای
  { id: 'wpn_nuc_sub', name: 'زیردریایی اتمی کلاس تایفون', emoji: '☢️', price: 250000000, category: 'nuclear_sub', power: 3500 },

  // ۱۶. بمب افکن
  { id: 'wpn_bomber_tu22', name: 'بمب‌افکن استراتژیک فراصوت', emoji: '💣', price: 75000000, category: 'bomber', power: 1200 },

  // ۱۷. ناو تجهییزات بر
  { id: 'wpn_cargo_ship', name: 'ناو ترابری و تجهیزات‌بر اقیانوس‌پیما', emoji: '⛴️', price: 30000000, category: 'cargo_ship', power: 250 },
  // ۱۸. پدافند پیشرفته
  { id: 'wpn_patriot', name: 'سامانه پدافند پیشرفته پاتریوت PAC-3', emoji: '🛡️', price: 90000000, category: 'defense', power: 1200 },
  { id: 'wpn_s400', name: 'سامانه پدافند S-400 تریومف', emoji: '🛡️', price: 120000000, category: 'defense', power: 1600 },
  // ۱۹. جنگنده نسل پنجم
  { id: 'wpn_f35', name: 'جنگنده نسل پنجم F-35 لایتنینگ ۲', emoji: '✈️', price: 85000000, category: 'fighter', power: 1100 },
  { id: 'wpn_su57', name: 'جنگنده نسل پنجم Su-57 فلیسون', emoji: '✈️', price: 78000000, category: 'fighter', power: 1050 },
  // ۲۰. پهپاد تهاجمی
  { id: 'wpn_mq9', name: 'پهپاد تهاجمی MQ-9 ریپر', emoji: '🛸', price: 15000000, category: 'kamikaze_drone', power: 320 },
  { id: 'wpn_bayraktar', name: 'پهپاد تهاجمی بیرقدار TB2', emoji: '🛸', price: 5000000, category: 'kamikaze_drone', power: 210 },
  // ۲۱. موشک کروز
  { id: 'wpn_tomahawk', name: 'موشک کروز تاماهاک', emoji: '🚀', price: 60000000, category: 'missile', power: 750 },
  // ۲۲. توپخانه
  { id: 'wpn_artillery', name: 'توپخانه خودکششی ۱۵۵mm', emoji: '💣', price: 8000000, category: 'tank', power: 220 },
];

function getCategoryInfo(categoryId) {
  const norm = String(categoryId || '').trim().toLowerCase();
  return WEAPON_CATEGORIES.find((c) => c.id === norm || c.name === categoryId) || {
    id: norm || 'other',
    name: categoryId || 'سایر',
    emoji: '🛡️',
    capability: 'ادوات نظامی پشتیبانی',
    attackModes: ['ground', 'combined'],
  };
}

const settings = require('./settingsService');

async function ensureInitialized() {
  const isInit = await settings.get('weapons_seeded', false);
  if (!isInit) {
    const q = await col('weapons').get();
    if (q.empty) {
      await seedDefaults();
    }
    await settings.set('weapons_seeded', true);
  }
}

async function list() {
  await ensureInitialized();
  const q = await col('weapons').get();
  const dbWeapons = docs(q);
  return dbWeapons.sort((a, b) => (a.price || 0) - (b.price || 0));
}

async function get(id) {
  await ensureInitialized();
  const s = await col('weapons').doc(id).get();
  if (s.exists) return snap(s);
  return null;
}

async function create(data) {
  await ensureInitialized();
  const name = String(data.name || '').trim();
  if (!name) throw new GameError('نام تجهیزات الزامی است.');
  const id = (data.id || name.toLowerCase().replace(/[^a-z0-9]+/g, '_') || `wpn_${Date.now()}`).slice(0, 45);
  const emoji = (data.emoji || '🛡️').slice(0, 10);
  const price = Math.max(1000, Number(data.price) || 1000000);
  const category = (data.category || 'tank').toLowerCase();
  const catInfo = getCategoryInfo(category);
  const power = Math.max(1, Number(data.power) || 50);

  const docData = {
    id,
    name,
    emoji: emoji || catInfo.emoji,
    price,
    category: catInfo.id,
    categoryName: catInfo.name,
    power,
    oilUse: Math.max(0, Number(data.oilUse ?? ({ army: 2, tank: 18, fighter: 45, missile: 8, defense: 12, spy_drone: 3, kamikaze_drone: 2, armored_carrier: 10, army_ai: 5, aircraft_carrier: 180, warship: 90, boat: 12, submarine: 70, cargo_plane: 65, nuclear_sub: 120, bomber: 110, cargo_ship: 55 }[category] || 5))),
    oilUseUnit: 'بشکه به‌ازای هر ساعت فعالیت؛ هنگام هر عملیات یک ساعت مصرف پایه محاسبه می‌شود',
    capability: data.capability || catInfo.capability,
    attackModes: catInfo.attackModes || ['ground', 'combined'],
    bundle: Number(data.bundle) || 1,
    level: Number(data.level) || 1,
    createdAt: new Date(),
    updatedAt: new Date(),
  };

  await col('weapons').doc(id).set(docData);
  return docData;
}

// ایجاد دسته‌جمعی با پشتیبانی از فرمت { اسم / قیمت / قدرت } یا { اسم | قیمت | قدرت }
async function bulkCreate(text, explicitCategory = null) {
  await ensureInitialized();
  if (!text || typeof text !== 'string') throw new GameError('متن وارد شده خالی است.');
  const lines = text.split('\n').map((l) => l.trim()).filter(Boolean);
  const created = [];

  for (const line of lines) {
    // پشتیبانی از جداکننده‌های: / یا | یا ، یا ,
    let parts = line.split(/[/|،,]/).map((p) => p.trim());
    if (parts.length >= 2) {
      const name = parts[0];
      const price = Number(parts[1].replace(/[^0-9]/g, '')) || 1000000;
      const power = parts[2] ? Number(parts[2].replace(/[^0-9]/g, '')) || Math.max(10, Math.floor(price / 100000)) : Math.max(10, Math.floor(price / 100000));
      
      let category = explicitCategory || 'tank';
      if (!explicitCategory && parts[3]) {
        category = parts[3];
      }

      const res = await create({
        name,
        price,
        power,
        category,
      });
      created.push(res);
    }
  }

  return { count: created.length, items: created };
}

async function seedDefaults() {
  let count = 0;
  for (const w of DEFAULT_WEAPONS) {
    const catInfo = getCategoryInfo(w.category);
    await col('weapons').doc(w.id).set({
      ...w,
      oilUse: w.oilUse ?? ({ army: 2, tank: 18, fighter: 45, missile: 8, defense: 12, spy_drone: 3, kamikaze_drone: 2, armored_carrier: 10, army_ai: 5, aircraft_carrier: 180, warship: 90, boat: 12, submarine: 70, cargo_plane: 65, nuclear_sub: 120, bomber: 110, cargo_ship: 55 }[w.category] || 5),
      oilUseUnit: 'بشکه به‌ازای هر ساعت فعالیت؛ هنگام هر عملیات یک ساعت مصرف پایه محاسبه می‌شود',
      categoryName: catInfo.name,
      capability: w.capability || catInfo.capability,
      attackModes: catInfo.attackModes,
      createdAt: new Date(),
      updatedAt: new Date(),
    });
    count++;
  }
  await settings.set('weapons_seeded', true);
  return { count };
}

async function remove(id) {
  await ensureInitialized();
  await col('weapons').doc(id).delete();
  return { id, deleted: true };
}

// حذف کامل و پاکسازی تمامی تجهیزات
async function clearAll() {
  await ensureInitialized();
  const q = await col('weapons').get();
  const all = docs(q);
  for (const item of all) {
    await col('weapons').doc(item.id).delete();
  }
  await settings.set('weapons_seeded', true);
  return { deleted: all.length };
}

module.exports = {
  WEAPON_CATEGORIES,
  DEFAULT_WEAPONS,
  getCategoryInfo,
  ensureInitialized,
  list,
  get,
  create,
  bulkCreate,
  seedDefaults,
  remove,
  clearAll,
};
