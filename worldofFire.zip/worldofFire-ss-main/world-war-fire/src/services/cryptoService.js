'use strict';
const { fmtNum } = require('../utils/text');
const notifications = require('./notificationService');

const ASSETS = [
  { symbol: 'BTC', nameFa: 'بیت‌کوین', icon: '₿', basePrice: 94200, volatility: 0.05 },
  { symbol: 'ETH', nameFa: 'اتریوم', icon: 'Ξ', basePrice: 3450, volatility: 0.06 },
  { symbol: 'SOL', nameFa: 'سولانا', icon: '☀️', basePrice: 195, volatility: 0.08 },
  { symbol: 'TON', nameFa: 'تون‌کوین', icon: '💎', basePrice: 6.85, volatility: 0.07 },
  { symbol: 'XRP', nameFa: 'ریپل', icon: '✕', basePrice: 1.48, volatility: 0.09 },
];

// محاسبه قیمت‌های دینامیک و درصد سود و زیان دوره‌ای
function getCryptoMarket() {
  const timeBlock = Math.floor(Date.now() / (15 * 60 * 1000)); // نوسان هر ۱۵ دقیقه
  return ASSETS.map((asset, index) => {
    const seed = timeBlock * 7919 + index * 104729;
    const wave1 = Math.sin(seed * 0.13);
    const wave2 = Math.cos(seed * 0.07);
    const combinedChange = (wave1 * 0.6 + wave2 * 0.4) * asset.volatility;
    
    // درصد تغییر ۲۴ ساعته بین -12% تا +15%
    const changePercent = Number((combinedChange * 100).toFixed(2));
    const currentPrice = Math.max(0.1, Number((asset.basePrice * (1 + combinedChange)).toFixed(asset.basePrice < 10 ? 3 : 2)));
    const isUp = changePercent >= 0;

    return {
      symbol: asset.symbol,
      nameFa: asset.nameFa,
      icon: asset.icon,
      price: currentPrice,
      changePercent,
      isUp,
      trendIcon: isUp ? '🟢 +' : '🔴 ',
    };
  });
}

function getAssetPrice(symbol) {
  const market = getCryptoMarket();
  const found = market.find((c) => c.symbol.toUpperCase() === symbol.toUpperCase());
  return found ? found.price : 100;
}

// دریافت سبد دارایی رمزارز یک کشور
async function getPortfolio(countryId, seasonId) {
  const gameService = require('./gameService');
  const state = await gameService.getCountryState(countryId, seasonId);
  const cryptoHoldings = state.crypto || {};
  const market = getCryptoMarket();

  let totalValueUsd = 0;
  let totalCostUsd = 0;

  const holdings = market.map((coin) => {
    const h = cryptoHoldings[coin.symbol] || { amount: 0, totalInvested: 0 };
    const currentValue = h.amount * coin.price;
    const pnlUsd = currentValue - (h.totalInvested || 0);
    const pnlPercent = h.totalInvested > 0 ? Number(((pnlUsd / h.totalInvested) * 100).toFixed(2)) : 0;

    totalValueUsd += currentValue;
    totalCostUsd += (h.totalInvested || 0);

    return {
      ...coin,
      amount: Number((h.amount || 0).toFixed(4)),
      investedUsd: Math.round(h.totalInvested || 0),
      currentValueUsd: Math.round(currentValue),
      pnlUsd: Math.round(pnlUsd),
      pnlPercent,
      hasHolding: (h.amount || 0) > 0,
    };
  });

  const totalPnlUsd = Math.round(totalValueUsd - totalCostUsd);
  const totalPnlPercent = totalCostUsd > 0 ? Number(((totalPnlUsd / totalCostUsd) * 100).toFixed(2)) : 0;

  return {
    holdings,
    totalValueUsd: Math.round(totalValueUsd),
    totalCostUsd: Math.round(totalCostUsd),
    totalPnlUsd,
    totalPnlPercent,
    treasury: state.treasury || 0,
  };
}

// خرید رمزارز با سرمایه خزانه
async function buyCrypto({ countryId, seasonId, symbol, amountUsd }) {
  const gameService = require('./gameService');
  const state = await gameService.getCountryState(countryId, seasonId);
  const numericUsd = Math.max(1000000, Number(amountUsd) || 0);

  if ((state.treasury || 0) < numericUsd) {
    throw new Error(`سرمایه خزانه کافی نیست. نیاز به ${fmtNum(numericUsd)}$ دارید.`);
  }

  const coin = getCryptoMarket().find((c) => c.symbol.toUpperCase() === symbol.toUpperCase());
  if (!coin) throw new Error('نماد رمزارز نامعتبر است.');

  const coinsBought = numericUsd / coin.price;
  const currentCrypto = { ...(state.crypto || {}) };
  const prevHolding = currentCrypto[coin.symbol] || { amount: 0, totalInvested: 0 };

  currentCrypto[coin.symbol] = {
    amount: (prevHolding.amount || 0) + coinsBought,
    totalInvested: (prevHolding.totalInvested || 0) + numericUsd,
    lastBoughtAt: new Date(),
  };

  const newTreasury = (state.treasury || 0) - numericUsd;
  await gameService.updateCountryState(countryId, seasonId, {
    treasury: newTreasury,
    crypto: currentCrypto,
  });

  return {
    coin,
    usdSpent: numericUsd,
    coinsBought: Number(coinsBought.toFixed(4)),
    price: coin.price,
    newTreasury,
    totalOwned: Number(currentCrypto[coin.symbol].amount.toFixed(4)),
  };
}

// فروش درصدی رمزارز به دلار خزانه
async function sellCrypto({ countryId, seasonId, symbol, percent = 100 }) {
  const gameService = require('./gameService');
  const state = await gameService.getCountryState(countryId, seasonId);
  const coin = getCryptoMarket().find((c) => c.symbol.toUpperCase() === symbol.toUpperCase());
  if (!coin) throw new Error('نماد رمزارز نامعتبر است.');

  const currentCrypto = { ...(state.crypto || {}) };
  const holding = currentCrypto[coin.symbol];
  if (!holding || holding.amount <= 0) {
    throw new Error(`شما هیچ مقداری از رمزارز ${coin.nameFa} (${coin.symbol}) در سبد دارایی ندارید.`);
  }

  const fraction = percent === 100 ? 1 : percent === 50 ? 0.5 : 0.25;
  const coinsToSell = holding.amount * fraction;
  const revenueUsd = Math.round(coinsToSell * coin.price);
  const costBasis = (holding.totalInvested || 0) * fraction;
  const profitUsd = Math.round(revenueUsd - costBasis);

  holding.amount = Math.max(0, holding.amount - coinsToSell);
  holding.totalInvested = Math.max(0, (holding.totalInvested || 0) - costBasis);
  currentCrypto[coin.symbol] = holding;

  const newTreasury = (state.treasury || 0) + revenueUsd;
  await gameService.updateCountryState(countryId, seasonId, {
    treasury: newTreasury,
    crypto: currentCrypto,
  });

  return {
    coin,
    coinsSold: Number(coinsToSell.toFixed(4)),
    revenueUsd,
    profitUsd,
    price: coin.price,
    percentSold: percent,
    newTreasury,
    remainingCoins: Number(holding.amount.toFixed(4)),
  };
}

// ساخت متن بولتن هر ۳۰ دقیقه
function buildCryptoBulletinText() {
  const market = getCryptoMarket();
  const lines = [
    '📊 <b>بولتن بازار سرمایه و رمزارزها — نوسانات ۳۰ دقیقه‌ای</b>',
    '– – – – – – – – – –',
    'آخرین نرخ برابری ارزهای دیجیتال و درصد سود و زیان جهانی:',
    '',
  ];

  for (const c of market) {
    const sign = c.changePercent >= 0 ? '+' : '';
    const badge = c.changePercent >= 0 ? '🟢 صعودی' : '🔴 نزولی';
    lines.push(
      `${c.icon} <b>${c.nameFa} (${c.symbol}):</b> <code>${fmtNum(c.price)}$</code> | ${c.trendIcon}${sign}${c.changePercent}% (${badge})`
    );
  }

  lines.push('');
  lines.push('💡 <i>رهبران کشورها می‌توانند با مراجعه به بخش «بازار و سرمایه» در ربات، با بودجه ملی اقدام به خرید یا فروش رمزارز نمایند.</i>');

  return lines.join('\n');
}

// انتشار بولتن هر ۳۰ دقیقه به کانال
async function publishCryptoBulletin(telegram) {
  const text = buildCryptoBulletinText();
  return notifications.publishToChannel(telegram, 'economic_report', text).catch((err) => {
    // اگر کانال تنظیم نشده باشد یا تلگرام خطا دهد
    return null;
  });
}

module.exports = {
  ASSETS,
  getCryptoMarket,
  getAssetPrice,
  getPortfolio,
  buyCrypto,
  sellCrypto,
  buildCryptoBulletinText,
  publishCryptoBulletin,
};
