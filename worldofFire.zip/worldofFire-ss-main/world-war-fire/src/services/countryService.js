'use strict';
const { col, snap, docs } = require('../db/firestore');
const { nextSeq } = require('./counterService');
const { GameError } = require('../utils/errors');

const TYPES = ['free', 'premium', 'exclusive'];

const KNOWN_FLAGS = {
  'ایران': '🇮🇷', 'عراق': '🇮🇶', 'آمریکا': '🇺🇸', 'امریکا': '🇺🇸',
  'سوریه': '🇸🇾', 'لبنان': '🇱🇧', 'آلمان': '🇩🇪', 'المان': '🇩🇪',
  'فرانسه': '🇫🇷', 'بریتانیا': '🇬🇧', 'انگلیس': '🇬🇧', 'روسیه': '🇷🇺',
  'چین': '🇨🇳', 'ژاپن': '🇯🇵', 'هند': '🇮🇳', 'برزیل': '🇧🇷',
  'عربستان': '🇸🇦', 'عربستان سعودی': '🇸🇦', 'امارات': '🇦🇪', 'ترکیه': '🇹🇷',
  'مصر': '🇪🇬', 'کانادا': '🇨🇦', 'کره جنوبی': '🇰🇷', 'کره شمالی': '🇰🇵',
  'ایتالیا': '🇮🇹', 'اسپانیا': '🇪🇸', 'سوئد': '🇸🇪', 'لهستان': '🇵🇱',
  'اوکراین': '🇺🇦', 'پاکستان': '🇵🇰', 'افغانستان': '🇦🇫', 'قطر': '🇶🇦',
  'کویت': '🇰🇼', 'عمان': '🇴🇲', 'بحرین': '🇧🇭', 'یمن': '🇾🇪',
  'اردن': '🇯🇴', 'فلسطین': '🇵🇸', 'یونان': '🇬🇷', 'هلند': '🇳🇱',
  'بلژیک': '🇧🇪', 'سوئیس': '🇨🇭', 'نروژ': '🇳🇴', 'فنلاند': '🇫🇮',
  'دانمارک': '🇩🇰', 'آرژانتین': '🇦🇷', 'مکزیک': '🇲🇽', 'استرالیا': '🇦🇺',
  'آفریقای جنوبی': '🇿🇦', 'لیبی': '🇱🇾', 'قبرس': '🇨🇾', 'کامبوج': '🇰🇭',
};

const DEFAULTS = [
  { code: 'IRN', name: 'ایران', flag: '🇮🇷' },
  { code: 'USA', name: 'آمریکا', flag: '🇺🇸', selectionType: 'premium', price: 150000 },
  { code: 'RUS', name: 'روسیه', flag: '🇷🇺', selectionType: 'premium', price: 150000 },
  { code: 'CHN', name: 'چین', flag: '🇨🇳', selectionType: 'premium', price: 150000 },
  { code: 'TUR', name: 'ترکیه', flag: '🇹🇷' },
  { code: 'DEU', name: 'آلمان', flag: '🇩🇪' },
  { code: 'FRA', name: 'فرانسه', flag: '🇫🇷' },
  { code: 'GBR', name: 'بریتانیا', flag: '🇬🇧' },
  { code: 'JPN', name: 'ژاپن', flag: '🇯🇵' },
  { code: 'IND', name: 'هند', flag: '🇮🇳' },
  { code: 'SAU', name: 'عربستان سعودی', flag: '🇸🇦' },
  { code: 'BRA', name: 'برزیل', flag: '🇧🇷' },
];

const KNOWN_GEOGRAPHY = {
  'ژاپن': 'island', 'بریتانیا': 'island', 'انگلیس': 'island', 'استرالیا': 'island',
  'قبرس': 'island', 'اندونزی': 'island', 'ایرلند': 'island', 'نیوزیلند': 'island',
  'تایوان': 'island', 'ایسلند': 'island', 'ماداگاسکار': 'island', 'کوبا': 'island', 'فیلیپین': 'island',
  'افغانستان': 'landlocked', 'سوئیس': 'landlocked', 'ارمنستان': 'landlocked',
  'اتریش': 'landlocked', 'بلاروس': 'landlocked', 'ازبکستان': 'landlocked',
  'آذربایجان': 'landlocked', 'قزاقستان': 'landlocked', 'ترکمنستان': 'landlocked',
  'تاجیکستان': 'landlocked', 'بولیوی': 'landlocked', 'پاراگوئه': 'landlocked',
};

function getCountryGeography(name, explicitGeo = null) {
  if (explicitGeo && ['coastal', 'island', 'landlocked'].includes(explicitGeo)) return explicitGeo;
  return KNOWN_GEOGRAPHY[name] || 'coastal';
}

function base(c) {
  const geo = getCountryGeography(c.name, c.geography);
  return {
    name: c.name,
    flag: c.flag || KNOWN_FLAGS[c.name] || '🏳️',
    leaderName: c.leaderName || 'تعیین نشده',
    selectionType: c.selectionType || 'free',
    price: c.price || 0,
    allowedUserIds: c.allowedUserIds || [],
    isActive: true,
    governmentType: 'republic',
    religion: 'none',
    population: 10000000,
    oilRichness: Number.isFinite(c.oilRichness) ? Math.max(0, Math.min(100, c.oilRichness)) : 50,
    oilReserve: Number.isFinite(c.oilReserve) ? Math.max(0, c.oilReserve) : 5000,
    geography: geo, // 'coastal' | 'island' | 'landlocked'
    activeFlagSource: 'default', // 'default', 'religion', 'ideology'
    photoUrl: c.photoUrl || null,
    bannerUrl: c.bannerUrl || null,
    statementPhotoUrl: c.statementPhotoUrl || null,
    religionFlags: c.religionFlags || {},
    ideologyFlags: c.ideologyFlags || {},
    governmentFlags: c.governmentFlags || [],
    religionUrls: c.religionUrls || {},
    governmentUrls: c.governmentUrls || {},
    mapRegion: c.mapRegion || null, // شناسهٔ ناحیهٔ نقشهٔ مربوط به کشور (برای نمایش/تسخیر)
  };
}

function validate(p) {
  const out = {};
  if (p.geography !== undefined) {
    if (!['coastal', 'island', 'landlocked'].includes(p.geography)) throw new GameError('موقعیت جغرافیایی نامعتبر است (coastal/island/landlocked).');
    out.geography = p.geography;
  }
  if (p.name !== undefined) {
    const s = String(p.name).trim();
    if (!s || s.length > 60) throw new GameError('نام کشور باید بین ۱ تا ۶۰ کاراکتر باشد.');
    out.name = s;
  }
  if (p.flag !== undefined) {
    const s = String(p.flag).trim();
    if (!s || s.length > 24) throw new GameError('پرچم باید یک نماد یا ایموجی معتبر باشد.');
    out.flag = s;
  }
  if (p.leaderName !== undefined) {
    const s = String(p.leaderName).trim();
    if (!s || s.length > 60) throw new GameError('نام رهبر باید بین ۱ تا ۶۰ کاراکتر باشد.');
    out.leaderName = s;
  }
  if (p.selectionType !== undefined) {
    if (!TYPES.includes(p.selectionType)) throw new GameError('نوع انتخاب نامعتبر است.');
    out.selectionType = p.selectionType;
  }
  if (p.oilRichness !== undefined) {
    const n = Number(p.oilRichness);
    if (!Number.isFinite(n) || n < 0 || n > 100) throw new GameError('درصد نفت‌خیزی باید بین ۰ تا ۱۰۰ باشد.');
    out.oilRichness = n;
  }
  if (p.oilReserve !== undefined) {
    const n = Number(p.oilReserve);
    if (!Number.isSafeInteger(n) || n < 0) throw new GameError('ظرفیت مخزن نفت باید عدد صحیح نامنفی باشد.');
    out.oilReserve = n;
  }
  if (p.price !== undefined) {
    const n = Number(p.price);
    if (!Number.isSafeInteger(n) || n < 0) throw new GameError('قیمت باید عدد صحیح نامنفی باشد.');
    out.price = n;
  }
  if (p.allowedUserIds !== undefined) {
    const arr = Array.isArray(p.allowedUserIds) ? p.allowedUserIds : String(p.allowedUserIds).split(/[\s,;]+/);
    out.allowedUserIds = [...new Set(arr.map(Number).filter((n) => Number.isSafeInteger(n) && n > 0))];
  }
  if (p.isActive !== undefined) out.isActive = Boolean(p.isActive);
  if (p.activeFlagSource !== undefined) out.activeFlagSource = p.activeFlagSource;
  if (p.mapRegion !== undefined) out.mapRegion = p.mapRegion ? String(p.mapRegion).trim() : null;
  if (p.photoUrl !== undefined) out.photoUrl = p.photoUrl ? String(p.photoUrl).trim() : null;
  if (p.bannerUrl !== undefined) out.bannerUrl = p.bannerUrl ? String(p.bannerUrl).trim() : null;
  if (p.statementPhotoUrl !== undefined) out.statementPhotoUrl = p.statementPhotoUrl ? String(p.statementPhotoUrl).trim() : null;
  if (p.religionFlags !== undefined) out.religionFlags = p.religionFlags;
  if (p.ideologyFlags !== undefined) out.ideologyFlags = p.ideologyFlags;
  if (p.governmentFlags !== undefined) out.governmentFlags = Array.isArray(p.governmentFlags) ? p.governmentFlags : [];
  if (p.religionUrls !== undefined) out.religionUrls = typeof p.religionUrls === 'object' && p.religionUrls !== null ? p.religionUrls : {};
  if (p.governmentUrls !== undefined) out.governmentUrls = typeof p.governmentUrls === 'object' && p.governmentUrls !== null ? p.governmentUrls : {};
  return out;
}

async function get(id) { return snap(await col('countries').doc(String(id)).get()); }

async function list() {
  const all = docs(await col('countries').get());
  return all.sort((a, b) => a.name.localeCompare(b.name, 'fa'));
}

async function getMany(ids) {
  const map = {};
  await Promise.all([...new Set(ids)].map(async (id) => { map[id] = await get(id); }));
  return map;
}

async function create(p) {
  const v = validate({
    name: p.name,
    flag: p.flag || KNOWN_FLAGS[p.name] || '🏳️',
    leaderName: p.leaderName || 'تعیین نشده',
    selectionType: p.selectionType || 'free',
    price: p.price || 0,
    allowedUserIds: p.allowedUserIds || [],
    oilRichness: p.oilRichness === undefined ? 50 : Number(p.oilRichness),
    oilReserve: p.oilReserve === undefined ? 5000 : Number(p.oilReserve),
    photoUrl: p.photoUrl || null,
  });
  const code = `C${String(await nextSeq('countryCode')).padStart(3, '0')}`;
  const ref = col('countries').doc();
  const data = { ...base(v), ...v, code, createdAt: new Date() };
  await ref.create(data);
  return { id: ref.id, ...data };
}

async function update(id, patch) {
  const c = await get(id);
  if (!c) throw new GameError('کشور یافت نشد.');
  const v = validate(patch);
  if (Object.keys(v).length) await col('countries').doc(String(id)).update(v);
  return { ...c, ...v };
}

// افزودن کشورهای اولیه؛ قابل اجرای مجدد
async function seedDefaults() {
  let created = 0;
  for (const d of DEFAULTS) {
    const ref = col('countries').doc(d.code);
    if ((await ref.get()).exists) continue;
    await ref.create({ ...base(d), code: d.code, createdAt: new Date() });
    created++;
  }
  return { created, total: DEFAULTS.length };
}

// پاکسازی تمام کشورها
async function clearAll() {
  const all = docs(await col('countries').get());
  for (const c of all) {
    await col('countries').doc(c.id).delete();
  }
  return { deleted: all.length };
}

// افزودن دسته‌جمعی کشورها (مثلاً: ایران، عراق، آمریکا، آلمان...)
async function bulkCreate(rawInput) {
  if (!rawInput || typeof rawInput !== 'string') throw new GameError('ورودی معتبر نیست.');
  // جدا کردن با کاما، خط جدید، ویرگول فارسی و اسلش
  const names = rawInput
    .split(/[\n,،;|]+/)
    .map((s) => s.trim().replace(/^[-*•\d.]+\s*/, ''))
    .filter((s) => s.length > 0);

  const uniqueNames = [...new Set(names)];
  const created = [];
  for (const name of uniqueNames) {
    const flag = KNOWN_FLAGS[name] || '🏳️';
    const c = await create({ name, flag, selectionType: 'free', price: 0 });
    created.push(c);
  }
  return { count: created.length, countries: created };
}

const DEFAULT_GOVERNMENT_FLAGS = {
  'ایران': [
    { id: 'ir_monarchy', name: 'پادشاهی پهلوی', flag: '👑🦁', emoji: '👑', desc: 'دوران مشروطه و نشان شیر و خورشید' },
    { id: 'ir_islamic', name: 'جمهوری اسلامی', flag: '☪️🇮🇷', emoji: '☪️', desc: 'نظام جمهوری اسلامی' },
    { id: 'ir_kaviani', name: 'درفش کاویانی', flag: '🦅🔥', emoji: '🔥', desc: 'امپراطوری باستانی پارس' },
    { id: 'ir_communist', name: 'ایران سوسیالیست', flag: '🚩⭐', emoji: '🚩', desc: 'جمهوری سوسیالیستی ایران' },
    { id: 'ir_secular', name: 'جمهوری سکولار', flag: '🏛️☀️', emoji: '☀️', desc: 'نظام دموکراتیک سکولار' },
    { id: 'ir_military', name: 'حکومت نظامی', flag: '⚔️🛡️', emoji: '⚔️', desc: 'فرماندهی ارتش و حکومت دفاعی' },
    { id: 'ir_theocracy', name: 'تئوکراسی مذهبی', flag: '🕌🗡️', emoji: '🕌', desc: 'حکومت دینی تام' },
    { id: 'ir_default', name: 'پرچم استاندارد', flag: '🇮🇷', emoji: '🇮🇷', desc: 'پرچم رسمی فعلی' },
  ],
  'آمریکا': [
    { id: 'us_republic', name: 'جمهوری فدرال', flag: '🇺🇸', emoji: '🏛️', desc: 'سیستم دموکراسی فدرال' },
    { id: 'us_empire', name: 'امپراطوری آمریکا', flag: '👑🦅', emoji: '👑', desc: 'امپراطوری سلطنتی' },
    { id: 'us_communist', name: 'سوسیالیسم آمریکا', flag: '🚩🗽', emoji: '🚩', desc: 'سوسیالیسم آمریکایی' },
    { id: 'us_military', name: 'پنتاگون نظامی', flag: '🎖️🦅', emoji: '🎖️', desc: 'اقتدارگرایی نظامی' },
    { id: 'us_theocracy', name: 'تئوکراسی مسیحی', flag: '✝️🇺🇸', emoji: '✝️', desc: 'تئوکراسی مذهبی' },
  ],
  'روسیه': [
    { id: 'ru_federation', name: 'فدراسیون روسیه', flag: '🇷🇺', emoji: '🇷🇺', desc: 'فدراسیون نوین روسیه' },
    { id: 'ru_soviet', name: 'شوروی کمونیست', flag: '☭🚩', emoji: '🚩', desc: 'شوروی کمونیستی' },
    { id: 'ru_tsar', name: 'امپراطوری تزار', flag: '👑🦅', emoji: '👑', desc: 'امپراطوری ارتدوکس تزاری' },
    { id: 'ru_military', name: 'حکومت جنگی کرملین', flag: '⚔️🇷🇺', emoji: '⚔️', desc: 'دیکتاتوری جنگی' },
  ],
  'آلمان': [
    { id: 'de_federal', name: 'جمهوری فدرال', flag: '🇩🇪', emoji: '🇩🇪', desc: 'جمهوری مدرن' },
    { id: 'de_empire', name: 'رایش دوم', flag: '👑🦅', emoji: '👑', desc: 'امپراطوری پروس' },
    { id: 'de_communist', name: 'آلمان شرقی (DDR)', flag: '🚩⚙️', emoji: '🚩', desc: 'آلمان سوسیالیست کارگری' },
    { id: 'de_fascist', name: 'رایش سوم', flag: '🦅⚡', emoji: '🦅', desc: 'نظام فاشیستی و میلیتاریستی' },
  ],
  'ایتالیا': [
    { id: 'it_republic', name: 'جمهوری ایتالیا', flag: '🇮🇹', emoji: '🏛️', desc: 'جمهوری دموکراتیک' },
    { id: 'it_fascist', name: 'ایتالیای فاشیست', flag: '🦅🇮🇹', emoji: '🦅', desc: 'فاشیسم اقتدارگرا' },
    { id: 'it_kingdom', name: 'پادشاهی ساوی', flag: '👑🇮🇹', emoji: '👑', desc: 'پادشاهی خاندان ساوی' },
  ],
  'فرانسه': [
    { id: 'fr_republic', name: 'جمهوری فرانسه', flag: '🇫🇷', emoji: '🇫🇷', desc: 'جمهوری سکولار' },
    { id: 'fr_empire', name: 'امپراطوری ناپلئون', flag: '👑⚜️', emoji: '👑', desc: 'امپراطوری ناپلئونی' },
    { id: 'fr_commune', name: 'کمون پاریس', flag: '🚩🥖', emoji: '🚩', desc: 'سوسیالیسم رادیکال' },
  ],
  'عراق': [
    { id: 'iq_republic', name: 'جمهوری عراق', flag: '🇮🇶', emoji: '🇮🇶', desc: 'جمهوری مدرن' },
    { id: 'iq_monarchy', name: 'پادشاهی عراق', flag: '👑🇮🇶', emoji: '👑', desc: 'پادشاهی سلطنتی' },
    { id: 'iq_military', name: 'حکومت نظامی', flag: '⚔️🇮🇶', emoji: '⚔️', desc: 'اقتدار نظامی' },
  ],
  'عربستان': [
    { id: 'sa_monarchy', name: 'پادشاهی سعودی', flag: '🇸🇦', emoji: '🇸🇦', desc: 'پادشاهی اسلامی' },
    { id: 'sa_caliphate', name: 'خلافت اسلامی', flag: '🏴🗡️', emoji: '🏴', desc: 'خلافت مذهبی' },
    { id: 'sa_republic', name: 'جمهوری عربی', flag: '🏛️🌴', emoji: '🏛️', desc: 'جمهوری سکولار' },
  ],
  'چین': [
    { id: 'cn_prc', name: 'جمهوری خلق چین', flag: '🇨🇳', emoji: '🇨🇳', desc: 'حکومت پکن' },
    { id: 'cn_empire', name: 'امپراطوری باستان', flag: '🐉👑', emoji: '🐉', desc: 'امپراطوری مینگ و کینگ' },
    { id: 'cn_nationalist', name: 'چین ملی‌گرا', flag: '🇹🇼☀️', emoji: '☀️', desc: 'چین ملی' },
  ],
  'بریتانیا': [
    { id: 'gb_kingdom', name: 'پادشاهی متحده', flag: '🇬🇧', emoji: '🇬🇧', desc: 'بریتانیای کبیر' },
    { id: 'gb_empire', name: 'امپراطوری بریتانیا', flag: '👑🦁', emoji: '👑', desc: 'امپراطوری جهانی' },
    { id: 'gb_republic', name: 'جمهوری بریتانیا', flag: '🏛️🇬🇧', emoji: '🏛️', desc: 'جمهوری بدون پادشاهی' },
  ],
  'ترکیه': [
    { id: 'tr_republic', name: 'جمهوری ترکیه', flag: '🇹🇷', emoji: '🇹🇷', desc: 'جمهوری مدرن' },
    { id: 'tr_ottoman', name: 'امپراطوری عثمانی', flag: '👑🌙', emoji: '👑', desc: 'سلطنت و خلافت عثمانی' },
  ],
};

function getAvailableGovernmentFlags(country) {
  const custom = country.governmentFlags || [];
  const preset = DEFAULT_GOVERNMENT_FLAGS[country.name] || [
    { id: 'gen_monarchy', name: 'پادشاهی', flag: `👑 ${country.flag || '🏳️'}`, emoji: '👑', desc: 'نظام سلطنتی' },
    { id: 'gen_republic', name: 'جمهوری', flag: country.flag || '🏳️', emoji: '🏛️', desc: 'جمهوری دموکراتیک' },
    { id: 'gen_communist', name: 'سوسیالیسم', flag: `🚩 ${country.flag || '🏳️'}`, emoji: '🚩', desc: 'حکومت سوسیالیست' },
    { id: 'gen_military', name: 'حکومت نظامی', flag: `⚔️ ${country.flag || '🏳️'}`, emoji: '⚔️', desc: 'حکومت ارتش' },
    { id: 'gen_fascism', name: 'فاشیسم', flag: `🦅 ${country.flag || '🏳️'}`, emoji: '🦅', desc: 'نظام فاشیستی' },
    { id: 'gen_theocracy', name: 'تئوکراسی', flag: `🕌 ${country.flag || '🏳️'}`, emoji: '🕌', desc: 'حکومت دینی' },
    { id: 'gen_ancient', name: 'تمدن کهن', flag: `🔥 ${country.flag || '🏳️'}`, emoji: '🔥', desc: 'هویت تاریخی' },
  ];
  return [...preset, ...custom];
}

// محاسبه پرچم پویای کشور بر اساس انتخاب مستقیم حکومت، دین یا ایدئولوژی
function getDynamicFlag(country, state = {}) {
  // اگر کاربر مستقیماً یکی از پرچم‌های حکومت را سوییچ کرده باشد:
  if (state.customFlag) return state.customFlag;

  const religion = state.religion || country.religion || 'none';
  const government = state.government || country.governmentType || 'republic';
  const source = state.flagChoice || country.activeFlagSource || 'default';

  if (source === 'religion') {
    if (country.religionFlags && country.religionFlags[religion]) return country.religionFlags[religion];
    if (country.name === 'ایران') {
      if (religion === 'zoroastrian') return '🦁🔥';
      if (religion === 'islam') return '☪️🇮🇷';
      if (religion === 'christianity') return '✝️🇮🇷';
      if (religion === 'judaism') return '✡️🇮🇷';
      if (religion === 'buddhism') return '☸️🇮🇷';
      if (religion === 'none') return '☀️🇮🇷';
    }
    const relEmoji = {
      zoroastrian: '🔥', islam: '☪️', christianity: '✝️', judaism: '✡️', buddhism: '☸️', none: '🌐',
    }[religion] || '🕊';
    return `${relEmoji} ${country.flag || '🏳️'}`;
  }

  if (source === 'ideology') {
    if (country.ideologyFlags && country.ideologyFlags[government]) return country.ideologyFlags[government];
    if (country.name === 'ایران') {
      if (government === 'monarchy') return '👑🦁';
      if (government === 'dictatorship') return '🎖️⚡';
      if (government === 'communist') return '🚩⭐';
      if (government === 'theocracy') return '🕌📜';
      if (government === 'republic') return '🏛️🇮🇷';
      if (government === 'fascism') return '🦅⚡';
    }
    const govEmoji = {
      dictatorship: '🎖', monarchy: '👑', republic: '🏛️', communist: '🚩', theocracy: '🕌', fascism: '🦅',
    }[government] || '🏛️';
    return `${govEmoji} ${country.flag || '🏳️'}`;
  }

  return country.flag || KNOWN_FLAGS[country.name] || '🏳️';
}

const DEFAULT_RELIGION_URLS = {
  islam: 'https://images.unsplash.com/photo-1542816417-0983c9c9ad53?w=800&q=80',
  zoroastrian: 'https://images.unsplash.com/photo-1509114397022-ed747cca3f65?w=800&q=80',
  christianity: 'https://images.unsplash.com/photo-1548625361-120000216694?w=800&q=80',
  judaism: 'https://images.unsplash.com/photo-1544427920-c49ccfb85579?w=800&q=80',
  buddhism: 'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?w=800&q=80',
  none: 'https://images.unsplash.com/photo-1451187580459-43490279c0fa?w=800&q=80',
};

const DEFAULT_GOVERNMENT_URLS = {
  monarchy: 'https://images.unsplash.com/photo-1579783900882-c0d3dad7b119?w=800&q=80',
  republic: 'https://images.unsplash.com/photo-1541872703-74c5e44368f9?w=800&q=80',
  dictatorship: 'https://images.unsplash.com/photo-1579783902614-a3fb3927b675?w=800&q=80',
  communist: 'https://images.unsplash.com/photo-1526778548025-fa2f459cd5c1?w=800&q=80',
  theocracy: 'https://images.unsplash.com/photo-1564507592333-c60657eea523?w=800&q=80',
  fascism: 'https://images.unsplash.com/photo-1579783900882-c0d3dad7b119?w=800&q=80',
};

function getReligionImageUrl(country, religionKey) {
  if (country && country.religionUrls && country.religionUrls[religionKey]) {
    return country.religionUrls[religionKey];
  }
  return DEFAULT_RELIGION_URLS[religionKey] || (country && country.photoUrl) || null;
}

function getGovernmentImageUrl(country, governmentKey) {
  if (country && country.governmentUrls && country.governmentUrls[governmentKey]) {
    return country.governmentUrls[governmentKey];
  }
  return DEFAULT_GOVERNMENT_URLS[governmentKey] || (country && country.photoUrl) || null;
}

module.exports = {
  get,
  list,
  getMany,
  create,
  update,
  seedDefaults,
  clearAll,
  bulkCreate,
  getDynamicFlag,
  getAvailableGovernmentFlags,
  getReligionImageUrl,
  getGovernmentImageUrl,
  DEFAULT_RELIGION_URLS,
  DEFAULT_GOVERNMENT_URLS,
  DEFAULT_GOVERNMENT_FLAGS,
  TYPES,
  DEFAULTS,
  KNOWN_FLAGS,
  KNOWN_GEOGRAPHY,
  getCountryGeography,
};
