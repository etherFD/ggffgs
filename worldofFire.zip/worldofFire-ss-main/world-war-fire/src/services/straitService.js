'use strict';
const { col, snap, docs } = require('../db/firestore');
const { GameError } = require('../utils/errors');
const { acquireLock, releaseLock } = require('../db/locks');
const countryService = require('./countryService');
const { fmtNum } = require('../utils/text');

const STRAITS_CATALOG = [
  { id: 'hormuz', name: 'تنگه هرمز', icon: '🌊', region: 'خلیج فارس', desc: 'مهم‌ترین شریان ترانزیت نفت و انرژی خلیج فارس و جهان', minNavalNeutral: 300 },
  { id: 'malacca', name: 'تنگه مالاکا', icon: '🚢', region: 'آسیای شرقی', desc: 'پرترددترین گذرگاه تجاری کانتینری میان شرق و غرب آسیا', minNavalNeutral: 250 },
  { id: 'bab_el_mandeb', name: 'تنگه باب‌المندب', icon: '⚓', region: 'دریای سرخ', desc: 'دروازه اتصال خلیج عدن و اقیانوس هند به کانال سوئز', minNavalNeutral: 200 },
  { id: 'suez', name: 'کانال سوئز', icon: '⛴️', region: 'مصر و مدیترانه', desc: 'شاهراه پیونددهنده ترانزیت دریایی اروپا و آسیا', minNavalNeutral: 350 },
  { id: 'gibraltar', name: 'تنگه جبل‌الطارق', icon: '🏰', region: 'مدیترانه و اطلس', desc: 'دروازه استراتژیک ورود به دریای مدیترانه و اقیانوس اطلس', minNavalNeutral: 250 },
  { id: 'bosporus', name: 'تنگه بسفر', icon: '🌉', region: 'دریای سیاه', desc: 'گذرگاه حیاتی پیونددهنده اروپا، ترکیه و دریای سیاه', minNavalNeutral: 200 },
  { id: 'dardanelles', name: 'تنگه داردانل', icon: '🛡️', region: 'دریای مرمره و اژه', desc: 'معبر تاریخی و راهبردی کشتیرانی تجاری و نظامی', minNavalNeutral: 180 },
  { id: 'panama', name: 'کانال پاناما', icon: '🌐', region: 'آمریکای مرکزی', desc: 'پل پیونددهنده دو اقیانوس اطلس و آرام', minNavalNeutral: 300 },
];

const CLAIM_COST = 200000000; // ۲۰۰ میلیون دلار هزینه تدارکات لجستیک دریایی

function getCatalog() {
  return STRAITS_CATALOG;
}

/**
 * محاسبه قدرت خالص نیروی دریایی کشور بر اساس ادوات معتبر در دیتابیس
 */
async function calculateCountryNavalPower(countryId, seasonId) {
  const gameService = require('./gameService');
  const weaponService = require('./weaponService');

  const state = await gameService.getCountryState(countryId, seasonId);
  const weapons = await weaponService.list();
  const weaponMap = new Map(weapons.map((w) => [String(w.id || w.key), w]));
  const DEFAULT_UNIT_POWER = { warship: 90, boat: 12, submarine: 70, aircraft_carrier: 180, cargo_ship: 55, naval: 50 };

  const navalUnits = state.navalUnits || {};
  let totalPower = 0;
  for (const [key, countRaw] of Object.entries(navalUnits)) {
    const count = Number(countRaw) || 0;
    if (count <= 0) continue;
    const w = weaponMap.get(String(key));
    const power = Number(w?.power) || DEFAULT_UNIT_POWER[key] || 50;
    totalPower += count * power;
  }

  // اگر واحد دریایی اختصاصی ثبت نشده، سهمی از قدرت کلی پدافندی محاسبه شود
  if (totalPower === 0) {
    const baseNavalEstimate = Math.floor(Number(state.military?.defense || 1000) * 0.15);
    totalPower = Math.max(50, baseNavalEstimate);
  }

  return totalPower;
}

async function getStraits(seasonId) {
  const q = await col('straits').where('seasonId', '==', String(seasonId)).get();
  const existingMap = new Map();
  docs(q).forEach((d) => existingMap.set(d.straitId, d));

  const result = [];
  for (const item of STRAITS_CATALOG) {
    const d = existingMap.get(item.id);
    if (d) {
      result.push({
        ...item,
        ownerCountryId: d.ownerCountryId || null,
        ownerCountryName: d.ownerCountryName || null,
        ownerFlag: d.ownerFlag || null,
        claimedAt: d.claimedAt || null,
        blockade: d.blockade || null,
        totalTollCollected: d.totalTollCollected || 0,
        defenderNavalPower: d.defenderNavalPower || 0,
      });
    } else {
      result.push({
        ...item,
        ownerCountryId: null,
        ownerCountryName: null,
        ownerFlag: null,
        claimedAt: null,
        blockade: null,
        totalTollCollected: 0,
        defenderNavalPower: 0,
      });
    }
  }
  return result;
}

async function getStrait(seasonId, straitId) {
  const list = await getStraits(seasonId);
  return list.find((s) => s.id === straitId) || null;
}

/**
 * عملیات تصاحب تنگه با بررسی شرط قطعی ۲ برابر قدرت دریایی مدافع
 * Attacker Naval Power >= 2 * Defender Naval Power
 */
async function claimStrait({ countryId, seasonId, straitId }) {
  const item = STRAITS_CATALOG.find((s) => s.id === straitId);
  if (!item) throw new GameError('تنگه انتخاب‌شده نامعتبر است.');

  const lockKey = `strait_claim:${seasonId}:${straitId}`;
  const locked = await acquireLock(lockKey, 10000);
  if (!locked) throw new GameError('عملیات دریایی دیگری روی این تنگه در جریان است. لطفاً چند لحظه بعد تلاش کنید.');

  try {
    const ref = col('straits').doc(`${seasonId}_${straitId}`);
    const sDoc = await ref.get();
    const curData = sDoc.exists ? sDoc.data() : null;

    if (curData && String(curData.ownerCountryId) === String(countryId)) {
      throw new GameError('این تنگه در حال حاضر تحت کنترل و حاکمیت نیروی دریایی کشور شماست!');
    }

    const gameService = require('./gameService');
    const attackerState = await gameService.getCountryState(countryId, seasonId);
    const attackerCountry = await countryService.get(countryId);

    // محاسبه قدرت دریایی کشور مهاجم
    const attackerNavalPower = await calculateCountryNavalPower(countryId, seasonId);

    // ۱. اگر تنگه متعلق به کشور دیگری است:
    if (curData && curData.ownerCountryId) {
      const defenderCountryId = curData.ownerCountryId;
      const defenderCountry = await countryService.get(defenderCountryId);
      const defenderNavalPower = await calculateCountryNavalPower(defenderCountryId, seasonId);

      // فرمول الزامی: قدرت دریایی مهاجم باید حداقل ۲ برابر قدرت دریایی مدافع باشد
      const requiredNavalPower = 2 * defenderNavalPower;
      if (attackerNavalPower < requiredNavalPower) {
        throw new GameError(
          `❌ قدرت دریایی ناکافی برای تصاحب تنگه!\n` +
          `• قدرت نیروی دریایی شما: ${fmtNum(attackerNavalPower)}\n` +
          `• قدرت نیروی دریایی مدافع (${defenderCountry ? defenderCountry.name : 'مدافع'}): ${fmtNum(defenderNavalPower)}\n` +
          `• حداقل ۲ برابر قدرت مدافع لازم است: ${fmtNum(requiredNavalPower)}\n` +
          `جهت آغاز موفق عملیات باید ناوگان و ادوات دریایی خود را تقویت کنید.`
        );
      }
    } else {
      // ۲. اگر تنگه بی‌طرف است: نیاز به حداقل قدرت دریایی مشخص‌شده در کاتالوگ
      const minRequired = item.minNavalNeutral || 200;
      if (attackerNavalPower < minRequired) {
        throw new GameError(
          `برای استقرار ناوگان و تسلط اولیه بر آبراهه ${item.name}، نیاز به حداقل ${fmtNum(minRequired)} قدرت دریایی دارید (توان فعلی شما: ${fmtNum(attackerNavalPower)}).`
        );
      }
    }

    // بررسی بودجه خزانه جهت پشتیبانی لجستیک و اعزام کاروان
    if ((attackerState.treasury || 0) < CLAIM_COST) {
      throw new GameError(`خزانه کشور کافی نیست. هزینه تدارکات و استقرار ناوگان در تنگه ${fmtNum(CLAIM_COST)}$ است (موجودی: ${fmtNum(attackerState.treasury)}$).`);
    }

    // کسر هزینه لجستیک
    await gameService.updateCountryState(countryId, seasonId, {
      treasury: (attackerState.treasury || 0) - CLAIM_COST,
    });

    const straitData = {
      id: ref.id,
      seasonId: String(seasonId),
      straitId,
      name: item.name,
      ownerCountryId: String(countryId),
      ownerCountryName: attackerCountry ? attackerCountry.name : String(countryId),
      ownerFlag: attackerCountry ? attackerCountry.flag : '🏳️',
      defenderNavalPower: attackerNavalPower,
      claimedAt: new Date(),
      blockade: null,
      totalTollCollected: Number(curData?.totalTollCollected || 0),
    };

    await ref.set(straitData);

    return {
      strait: { ...item, ...straitData },
      cost: CLAIM_COST,
      attackerNavalPower,
      conquered: true,
      isConquestFromDefender: Boolean(curData && curData.ownerCountryId),
    };
  } finally {
    await releaseLock(lockKey);
  }
}

// درخواست بستن تنگه با مجوز سازمان ملل
async function requestBlockade({ countryId, seasonId, straitId, targetType = 'worldwide', targetCountryId = null, reason = '' }) {
  const ref = col('straits').doc(`${seasonId}_${straitId}`);
  const s = await ref.get();
  if (!s.exists || String(s.data().ownerCountryId) !== String(countryId)) {
    throw new GameError('شما مالک این تنگه نیستید و اختیاری برای مسدودسازی آن ندارید.');
  }

  const cur = s.data();
  if (cur.blockade && cur.blockade.status === 'approved') {
    throw new GameError('این تنگه در حال حاضر با مجوز سازمان ملل مسدود است.');
  }
  if (cur.blockade && cur.blockade.status === 'pending_un') {
    throw new GameError('درخواست مسدودسازی این تنگه هم‌اکنون در دبیرخانه سازمان ملل در دست بررسی است.');
  }

  let targetName = 'کل جهان (کشتیرانی بین‌المللی)';
  if (targetType === 'country' && targetCountryId) {
    const tc = await countryService.get(targetCountryId);
    if (tc) targetName = `${tc.flag} ${tc.name}`;
  }

  const blockade = {
    targetType,
    targetCountryId: targetType === 'country' ? String(targetCountryId) : null,
    targetName,
    status: 'pending_un',
    reason: reason || 'حفظ امنیت ملی و بازدارندگی ژئوپلیتیک',
    requestedAt: new Date(),
    decidedAt: null,
    approvedBy: null,
  };

  await ref.update({ blockade });
  return { strait: { ...cur, blockade }, blockade };
}

// تصمیم‌گیری پیرامون انسداد توسط شورای امنیت سازمان ملل
async function decideBlockade({ seasonId, straitId, approved, adminId = 'UN_SECURITY_COUNCIL', note = '' }) {
  const ref = col('straits').doc(`${seasonId}_${straitId}`);
  const s = await ref.get();
  if (!s.exists || !s.data().blockade) throw new GameError('درخواست مسدودسازی یافت نشد.');

  const cur = s.data();
  const blockade = {
    ...cur.blockade,
    status: approved ? 'approved' : 'rejected',
    decidedAt: new Date(),
    approvedBy: adminId,
    unNote: note || (approved ? 'تصویب شده با قطعنامه شورای امنیت' : 'رد شده به‌دلیل نقض حقوق تجارت بین‌الملل'),
  };

  await ref.update({ blockade });
  return { strait: { ...cur, blockade }, approved };
}

// لغو انسداد تنگه توسط مالک
async function liftBlockade({ countryId, seasonId, straitId }) {
  const ref = col('straits').doc(`${seasonId}_${straitId}`);
  const s = await ref.get();
  if (!s.exists || String(s.data().ownerCountryId) !== String(countryId)) {
    throw new GameError('شما مالک این تنگه نیستید.');
  }

  await ref.update({ blockade: null });
  return true;
}

// واگذاری مالکیت تنگه
async function transferStrait({ seasonId, straitId, newCountryId, newCountryName, newFlag }) {
  const ref = col('straits').doc(`${seasonId}_${straitId}`);
  await ref.update({
    ownerCountryId: String(newCountryId),
    ownerCountryName: newCountryName,
    ownerFlag: newFlag,
    blockade: null,
  });
}

module.exports = {
  STRAITS_CATALOG,
  CLAIM_COST,
  getCatalog,
  calculateCountryNavalPower,
  getStraits,
  getStrait,
  claimStrait,
  requestBlockade,
  decideBlockade,
  liftBlockade,
  transferStrait,
};
