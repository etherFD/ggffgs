'use strict';
const { col, snap, docs } = require('../db/firestore');
const { GameError } = require('../utils/errors');
const countryService = require('./countryService');
const notifications = require('./notificationService');
const { esc, fmtDate } = require('../utils/text');

const ROLES = {
  war: {
    key: 'war',
    title: 'وزیر جنگ و نیروهای مسلح ⚔️',
    shortTitle: 'وزیر جنگ',
    emoji: '⚔️',
    description: 'فرماندهی عملیات نظامی، اعلان جنگ رسمی و حملات سایبری (اجرا مشروط به تایید رهبر کشور است).',
  },
  economy: {
    key: 'economy',
    title: 'وزیر اقتصاد و توسعه 💰',
    shortTitle: 'وزیر اقتصاد',
    emoji: '💰',
    description: 'احداث دکل‌های نفتی، ساخت‌وساز و مگاپروژه‌ها، استخدام نیروی کار و مدیریت درآمدهای ملی.',
  },
  prime: {
    key: 'prime',
    title: 'وزیر کل و معاونت عالی 🎖️',
    shortTitle: 'وزیر کل',
    emoji: '🎖️',
    description: 'نخست‌وزیر و معاون عالی کشور؛ اختیارات کامل اجرایی در هماهنگی و تایید رهبر.',
  },
};

/**
 * دریافت هیئت وزیران یک کشور
 */
async function getMinistersForCountry(countryId, seasonId) {
  const gameService = require('./gameService');
  const state = await gameService.getCountryState(countryId, seasonId);
  const m = state.ministers || {};
  return {
    war: m.war || null,
    economy: m.economy || null,
    prime: m.prime || (state.minister ? {
      userId: String(state.minister.telegramId || state.minister.userId),
      telegramId: Number(state.minister.telegramId || state.minister.userId),
      name: state.minister.name || state.ministerName || 'وزیر',
      role: 'prime',
      appointedAt: state.minister.appointedAt || state.ministerAppointedAt,
    } : null),
  };
}

/**
 * جستجوی سمت وزارتی یک کاربر در سیزن جاری
 */
async function findMinisterRole(userId, seasonId) {
  const uid = Number(userId);
  if (!uid || !seasonId) return null;

  // بررسی در کشورها
  const snapDocs = await col('country_state').where('seasonId', '==', String(seasonId)).get();
  const allStates = docs(snapDocs);

  for (const s of allStates) {
    const ministers = s.ministers || {};
    for (const [roleKey, minister] of Object.entries(ministers)) {
      if (minister && Number(minister.telegramId || minister.userId) === uid) {
        return {
          countryId: s.countryId || s.id.split('_')[0],
          role: roleKey,
          roleTitle: ROLES[roleKey]?.title || 'وزیر',
          roleConfig: ROLES[roleKey],
          appointedAt: minister.appointedAt,
          name: minister.name,
        };
      }
    }
    // پشتیبانی عقب‌رو برای ساختار قبلی state.minister
    if (s.minister && Number(s.minister.telegramId || s.minister.userId) === uid) {
      return {
        countryId: s.countryId || s.id.split('_')[0],
        role: 'prime',
        roleTitle: ROLES.prime.title,
        roleConfig: ROLES.prime,
        appointedAt: s.minister.appointedAt,
        name: s.minister.name,
      };
    }
  }

  return null;
}

/**
 * ارسال دعوت‌نامه رسمی انتصاب وزیر
 */
async function sendMinisterInvitation({ countryId, seasonId, leaderId, leaderName, candidateId, candidateName, role, telegram }) {
  const roleConfig = ROLES[role];
  if (!roleConfig) throw new GameError('سمت وزارتی مشخص‌شده نامعتبر است.');

  const cid = Number(candidateId);
  const ownershipService = require('./ownershipService');
  const activeOwnerships = await ownershipService.listActive(seasonId).catch(() => []);
  if (activeOwnerships.some((o) => Number(o.userId) === cid)) {
    throw new GameError('این کاربر در حال حاضر رهبر یک کشور مستقل است و نمی‌تواند وزیر شود.');
  }

  const existingRole = await findMinisterRole(cid, seasonId);
  if (existingRole) {
    throw new GameError(`این کاربر در حال حاضر ${existingRole.roleTitle} در کشور دیگری است.`);
  }

  const country = await countryService.get(countryId);
  const invRef = col('minister_invitations').doc();
  const invitation = {
    id: invRef.id,
    countryId: String(countryId),
    countryName: country.name,
    countryFlag: country.flag || '🏳️',
    seasonId: String(seasonId),
    leaderId: Number(leaderId),
    leaderName: String(leaderName || 'رهبر کشور'),
    candidateId: cid,
    candidateName: String(candidateName),
    role,
    roleTitle: roleConfig.title,
    roleDesc: roleConfig.description,
    status: 'pending',
    createdAt: new Date().toISOString(),
  };

  await invRef.set(invitation);

  if (telegram) {
    const { Markup } = require('telegraf');
    const text = [
      '🎖️ <b>پیشنهاد رسمی انتصاب در هیئت دولت!</b>',
      '– – – – – – – – – –',
      `رهبر کشور <b>${country.flag || ''} ${esc(country.name)}</b> (${esc(leaderName)}) به شما پیشنهاد تصدی مقام عالی <b>«${roleConfig.title}»</b> را داده است.`,
      '',
      `📋 <b>شرح اختیارات و وظایف:</b>\n${roleConfig.description}`,
      '',
      'آیا این مسئولیت رسمی را می‌پذیرید؟',
    ].join('\n');

    await notifications.safeSend(telegram, cid, text, Markup.inlineKeyboard([
      [
        Markup.button.callback('✅ قبول مسئولیت و ورود به دولت', `min:acc:${invRef.id}`),
        Markup.button.callback('❌ رد پیشنهاد انتصاب', `min:rej:${invRef.id}`),
      ],
    ])).catch(() => {});
  }

  return invitation;
}

/**
 * قبول پیشنهاد انتصاب توسط کاربر
 */
async function acceptMinisterInvitation({ invitationId, candidateUserId, telegram }) {
  const ref = col('minister_invitations').doc(invitationId);
  const snapDoc = await ref.get();
  if (!snapDoc.exists) throw new GameError('دعوت‌نامه یافت نشد.');
  const inv = snapDoc.data();
  if (inv.status !== 'pending') throw new GameError('این دعوت‌نامه قبلاً تعیین تکلیف شده است.');
  if (Number(inv.candidateId) !== Number(candidateUserId)) {
    throw new GameError('این پیشنهاد برای شناسه شما صادر نشده است.');
  }

  const gameService = require('./gameService');
  const state = await gameService.getCountryState(inv.countryId, inv.seasonId);
  const ministers = state.ministers || {};

  const ministerData = {
    userId: String(inv.candidateId),
    telegramId: Number(inv.candidateId),
    name: inv.candidateName,
    role: inv.role,
    appointedAt: new Date().toISOString(),
  };

  ministers[inv.role] = ministerData;

  const updatePayload = {
    ministers,
  };
  // اگر وزیر کل بود، فیلدهای سنتی وزیر را هم ست می‌کنیم
  if (inv.role === 'prime') {
    updatePayload.minister = ministerData;
    updatePayload.ministerName = inv.candidateName;
    updatePayload.ministerTelegramId = Number(inv.candidateId);
    updatePayload.ministerAppointedAt = ministerData.appointedAt;
  }

  await gameService.updateCountryState(inv.countryId, inv.seasonId, updatePayload);
  await ref.update({ status: 'accepted', acceptedAt: new Date().toISOString() });

  // اطلاع به رهبر کشور
  if (telegram && inv.leaderId) {
    await notifications.safeSend(
      telegram,
      inv.leaderId,
      `✅ <b>پذیرش حکم وزارت!</b>\nجناب <b>${esc(inv.candidateName)}</b> پیشنهاد شما را پذیرفت و رسماً به عنوان <b>${inv.roleTitle}</b> در کابینه کشور شما منصوب گردید.`
    ).catch(() => {});
  }

  // ثبت در کانال رسمی
  if (telegram) {
    await notifications.publishToChannel(
      telegram,
      'leader_change',
      `🎖️ <b>انتصاب جدید در هیئت دولت!</b>\nرهبر کشور <b>${inv.countryFlag} ${esc(inv.countryName)}</b>، جناب <b>${esc(inv.candidateName)}</b> را به عنوان <b>${inv.roleTitle}</b> منصوب نمود.`
    ).catch(() => {});
  }

  return { ok: true, invitation: inv };
}

/**
 * رد پیشنهاد انتصاب
 */
async function rejectMinisterInvitation({ invitationId, candidateUserId, telegram }) {
  const ref = col('minister_invitations').doc(invitationId);
  const snapDoc = await ref.get();
  if (!snapDoc.exists) throw new GameError('دعوت‌نامه یافت نشد.');
  const inv = snapDoc.data();
  if (inv.status !== 'pending') throw new GameError('این دعوت‌نامه قبلاً تعیین تکلیف شده است.');
  if (Number(inv.candidateId) !== Number(candidateUserId)) {
    throw new GameError('این پیشنهاد برای شناسه شما صادر نشده است.');
  }

  await ref.update({ status: 'rejected', rejectedAt: new Date().toISOString() });

  if (telegram && inv.leaderId) {
    await notifications.safeSend(
      telegram,
      inv.leaderId,
      `❌ <b>عدم پذیرش سمت:</b>\nجناب <b>${esc(inv.candidateName)}</b> پیشنهاد تصدی سمت <b>${inv.roleTitle}</b> را نپذیرفت.`
    ).catch(() => {});
  }

  return { ok: true };
}

/**
 * عزل وزیر توسط رهبر
 */
async function dismissMinister({ countryId, seasonId, role, leaderUserId, telegram }) {
  const gameService = require('./gameService');
  const state = await gameService.getCountryState(countryId, seasonId);
  const ministers = state.ministers || {};
  const current = ministers[role];

  if (!current) throw new GameError('وزیری در این سمت منصوب نیست.');

  ministers[role] = null;
  const updatePayload = { ministers };
  if (role === 'prime') {
    updatePayload.minister = null;
    updatePayload.ministerName = null;
    updatePayload.ministerTelegramId = null;
    updatePayload.ministerAppointedAt = null;
  }

  await gameService.updateCountryState(countryId, seasonId, updatePayload);

  if (telegram && current.telegramId) {
    const country = await countryService.get(countryId);
    await notifications.safeSend(
      telegram,
      current.telegramId,
      `⚠️ <b>اطلاعیه هیئت دولت:</b> حکم تصدی شما به عنوان ${ROLES[role]?.title || 'وزیر'} در کشور ${country?.flag || ''} ${country?.name || ''} لغو گردید.`
    ).catch(() => {});
  }

  return { ok: true };
}

/**
 * ثبت پیشنهاد عملیات نظامی توسط وزیر جنگ (نیازمند تایید رهبر)
 */
async function createMinisterWarProposal({ type, countryId, seasonId, ministerId, ministerName, targetCountryId, targetCountryName, payload, telegram }) {
  const ownershipService = require('./ownershipService');
  const leaderOwner = await ownershipService.getOwnerOfCountry(countryId, seasonId);
  if (!leaderOwner) throw new GameError('رهبر فعال کشور جهت تایید عملیات یافت نشد.');

  const country = await countryService.get(countryId);
  const target = await countryService.get(targetCountryId);

  const propRef = col('minister_proposals').doc();
  const proposal = {
    id: propRef.id,
    type, // 'attack' | 'war_declare' | 'cyber'
    countryId: String(countryId),
    countryName: country.name,
    countryFlag: country.flag || '🏳️',
    seasonId: String(seasonId),
    ministerId: Number(ministerId),
    ministerName: String(ministerName),
    targetCountryId: String(targetCountryId),
    targetCountryName: target ? target.name : targetCountryName,
    targetCountryFlag: target ? target.flag : '🏳️',
    payload: payload || {},
    status: 'pending',
    createdAt: new Date().toISOString(),
  };

  await propRef.set(proposal);

  const typeLabels = {
    attack: '⚔️ حمله و عملیات فتح خاکریزها',
    war_declare: '🚨 اعلام جنگ رسمی تمام‌عیار',
    cyber: '💻 حمله سنگین سایبری و فلج زیرساخت',
  };

  // ارسال به رهبر کشور با دکمه تایید/رد
  if (telegram && leaderOwner.userId) {
    const { Markup } = require('telegraf');
    const msg = [
      '🚨 <b>پیشنهاد عملیات نظامی از سوی وزیر جنگ!</b>',
      '– – – – – – – – – –',
      `جناب <b>${esc(ministerName)}</b> (وزیر جنگ کشور شما) پیشنهاد اجرای عملیات زیر را به ستاد فرماندهی کل ارسال کرده است:`,
      '',
      `🎯 <b>نوع عملیات:</b> ${typeLabels[type] || type}`,
      `🌍 <b>کشور هدف:</b> ${proposal.targetCountryFlag} <b>${esc(proposal.targetCountryName)}</b>`,
      '',
      '⚠️ <i>طبق قوانین کشورداری، اجرای این عملیات منوط به فرمان مستقیم و تایید شما به عنوان رهبر کشور است.</i>',
      '',
      'آیا این عملیات را تایید و ابلاغ می‌فرمایید؟',
    ].join('\n');

    await notifications.safeSend(telegram, leaderOwner.userId, msg, Markup.inlineKeyboard([
      [
        Markup.button.callback('✅ تایید و صدور فرمان حمله', `prop:appr:${propRef.id}`),
        Markup.button.callback('❌ رد عملیات نظامی', `prop:rejc:${propRef.id}`),
      ],
    ])).catch(() => {});
  }

  return proposal;
}

module.exports = {
  ROLES,
  getMinistersForCountry,
  findMinisterRole,
  sendMinisterInvitation,
  acceptMinisterInvitation,
  rejectMinisterInvitation,
  dismissMinister,
  createMinisterWarProposal,
};
