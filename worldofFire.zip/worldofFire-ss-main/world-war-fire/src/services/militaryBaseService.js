'use strict';
const { col, snap, docs } = require('../db/firestore');
const { GameError } = require('../utils/errors');
const countryService = require('./countryService');
const notifications = require('./notificationService');
const { esc, fmtNum } = require('../utils/text');

// نقشه همسایگی رسمی مرزهای زمینی و دریایی کشورها
const KNOWN_NEIGHBORS = {
  'ایران': ['عراق', 'ترکیه', 'افغانستان', 'پاکستان', 'ترکمنستان', 'آذربایجان', 'ارمنستان', 'عمان', 'امارات', 'قطر', 'کویت', 'سوریه'],
  'عراق': ['ایران', 'سوریه', 'ترکیه', 'عربستان', 'عربستان سعودی', 'اردن', 'کویت'],
  'سوریه': ['عراق', 'ترکیه', 'لبنان', 'اردن', 'فلسطین', 'ایران'],
  'ترکیه': ['ایران', 'عراق', 'سوریه', 'یونان', 'بلغارستان', 'گرجستان', 'ارمنستان', 'آذربایجان'],
  'عربستان': ['عراق', 'اردن', 'کویت', 'امارات', 'قطر', 'عمان', 'یمن'],
  'عربستان سعودی': ['عراق', 'اردن', 'کویت', 'امارات', 'قطر', 'عمان', 'یمن'],
  'روسیه': ['چین', 'اوکراین', 'بلاروس', 'فنلاند', 'نروژ', 'لهستان', 'قزاقستان', 'مغولستان', 'کره شمالی', 'گرجستان', 'آذربایجان'],
  'چین': ['روسیه', 'هند', 'پاکستان', 'افغانستان', 'کره شمالی', 'ویتنام', 'ژاپن', 'قزاقستان', 'مغولستان'],
  'آمریکا': ['کانادا', 'مکزیک', 'بریتانیا', 'ژاپن'],
  'امریکا': ['کانادا', 'مکزیک', 'بریتانیا', 'ژاپن'],
  'آلمان': ['فرانسه', 'لهستان', 'هلند', 'بلژیک', 'سوئیس', 'اتریش', 'دانمارک'],
  'المان': ['فرانسه', 'لهستان', 'هلند', 'بلژیک', 'سوئیس', 'اتریش', 'دانمارک'],
  'فرانسه': ['آلمان', 'اسپانیا', 'ایتالیا', 'بلژیک', 'سوئیس', 'بریتانیا'],
  'بریتانیا': ['فرانسه', 'آمریکا', 'ایرلند', 'آلمان'],
  'ایتالیا': ['فرانسه', 'سوئیس', 'اتریش', 'یونان'],
  'هند': ['چین', 'پاکستان', 'بنگلادش', 'افغانستان'],
  'پاکستان': ['ایران', 'افغانستان', 'هند', 'چین'],
  'افغانستان': ['ایران', 'پاکستان', 'چین', 'تاجیکستان'],
  'برزیل': ['آرژانتین', 'کلمبیا', 'پرو', 'پاراگوئه'],
  'ژاپن': ['کره جنوبی', 'روسیه', 'چین', 'آمریکا'],
  'کره جنوبی': ['کره شمالی', 'ژاپن', 'آمریکا'],
  'کره شمالی': ['کره جنوبی', 'چین', 'روسیه'],
  'اوکراین': ['روسیه', 'بلاروس', 'لهستان', 'رومانی'],
  'لهستان': ['آلمان', 'روسیه', 'اوکراین', 'بلاروس'],
  'امارات': ['عربستان', 'عربستان سعودی', 'عمان', 'قطر', 'ایران'],
  'قطر': ['عربستان', 'عربستان سعودی', 'امارات', 'ایران'],
  'کویت': ['عراق', 'عربستان', 'عربستان سعودی', 'ایران'],
};

function normalizeName(n) {
  return String(n || '').trim().replace(/[\u200B-\u200D\uFEFF]/g, '');
}

function areNeighbors(countryNameA, countryNameB) {
  const a = normalizeName(countryNameA);
  const b = normalizeName(countryNameB);
  if (a === b) return false;
  const listA = KNOWN_NEIGHBORS[a] || [];
  const listB = KNOWN_NEIGHBORS[b] || [];
  return listA.some((item) => normalizeName(item) === b) || listB.some((item) => normalizeName(item) === a);
}

const BASE_BUILD_COST = 200000000; // هزینه احداث پایگاه ۲۰۰ میلیون دلار
const HOST_GRANT = 50000000; // پاداش میزبانی ۵۰ میلیون دلار برای کشور میزبان

/**
 * ثبت درخواست احداث پایگاه نظامی در کشور دیگر
 */
async function requestMilitaryBase({ ownerCountryId, hostCountryId, seasonId, ownerUserId, telegram }) {
  if (String(ownerCountryId) === String(hostCountryId)) {
    throw new GameError('امکان احداث پایگاه نظامی در خاک کشور خودتان نیست؛ برای ساخت تاسیسات داخلی از بخش پادگان استفاده کنید.');
  }

  const gameService = require('./gameService');
  const ownershipService = require('./ownershipService');

  const [ownerCountry, hostCountry, ownerState] = await Promise.all([
    countryService.get(ownerCountryId),
    countryService.get(hostCountryId),
    gameService.getCountryState(ownerCountryId, seasonId),
  ]);

  if (!hostCountry) throw new GameError('کشور میزبان یافت نشد.');
  if (Number(ownerState.treasury || 0) < BASE_BUILD_COST) {
    throw new GameError(`موجودی خزانه ناکافی است. برای احداث پایگاه نظامی به ${fmtNum(BASE_BUILD_COST)}$ بودجه نیاز دارید.`);
  }

  // بررسی تکراری نبودن پایگاه فعال یا در حال انتظار
  const baseId = `${ownerCountryId}_base_in_${hostCountryId}_${seasonId}`;
  const existingSnap = await col('military_bases').doc(baseId).get();
  if (existingSnap.exists) {
    const d = existingSnap.data();
    if (d.status === 'active') {
      throw new GameError(`شما قبلاً در کشور ${hostCountry.flag || ''} ${hostCountry.name} دارای یک پایگاه نظامی فعال هستید.`);
    }
    if (d.status === 'pending') {
      throw new GameError(`درخواست احداث پایگاه شما در کشور ${hostCountry.flag || ''} ${hostCountry.name} قبلاً ثبت شده و در انتظار پاسخ رهبر آن کشور است.`);
    }
  }

  // رهبر کشور میزبان
  const hostOwner = await ownershipService.getOwnerOfCountry(hostCountryId, seasonId);
  if (!hostOwner) {
    throw new GameError(`کشور ${hostCountry.name} در حال حاضر رهبر فعال ندارد و امکان اخذ موافقت احداث پایگاه وجود ندارد.`);
  }

  // کسر بودجه ساخت پایگاه
  await gameService.updateCountryState(ownerCountryId, seasonId, {
    treasury: Number(ownerState.treasury || 0) - BASE_BUILD_COST,
  });

  const baseRecord = {
    id: baseId,
    seasonId: String(seasonId),
    ownerCountryId: String(ownerCountryId),
    ownerCountryName: ownerCountry.name,
    ownerCountryFlag: ownerCountry.flag || '🏳️',
    ownerUserId: Number(ownerUserId),
    hostCountryId: String(hostCountryId),
    hostCountryName: hostCountry.name,
    hostCountryFlag: hostCountry.flag || '🏳️',
    hostUserId: Number(hostOwner.userId),
    buildCost: BASE_BUILD_COST,
    status: 'pending',
    requestedAt: new Date().toISOString(),
    deployedUnits: {
      tanks: 0,
      fighters: 0,
      airDefense: 0,
      soldiers: 0,
    },
  };

  await col('military_bases').doc(baseId).set(baseRecord);

  // ارسال اعلان رسمی با دکمه تایید/رد برای رهبر کشور میزبان
  if (telegram && hostOwner.userId) {
    const { Markup } = require('telegraf');
    const msg = [
      '🪖 <b>درخواست رسمی احداث پایگاه نظامی فرامرزی!</b>',
      '– – – – – – – – – –',
      `کشور <b>${ownerCountry.flag || ''} ${esc(ownerCountry.name)}</b> رسماً تقاضای تاسیس یک «پایگاه نظامی و لجستیکی مشترک» در خاک کشور شما را دارد.`,
      '',
      '💎 <b>مزایای موافقت با میزبانی:</b>',
      `• دریافت بلاعوض <b>${fmtNum(HOST_GRANT)}$</b> حق استقرار به خزانه کشور شما`,
      '• تقویت پدافند هوایی مرزی مشترک',
      '',
      'آیا با احداث این پایگاه نظامی در خاک خود موافقت می‌نمایید؟',
    ].join('\n');

    await notifications.safeSend(telegram, hostOwner.userId, msg, Markup.inlineKeyboard([
      [
        Markup.button.callback('✅ موافقت با احداث پایگاه', `base:appr:${baseId}`),
        Markup.button.callback('❌ رد درخواست احداث', `base:rejc:${baseId}`),
      ],
    ])).catch(() => {});
  }

  return baseRecord;
}

/**
 * تایید احداث پایگاه توسط کشور میزبان
 */
async function approveMilitaryBase({ baseId, hostUserId, telegram }) {
  const ref = col('military_bases').doc(baseId);
  const snapDoc = await ref.get();
  if (!snapDoc.exists) throw new GameError('درخواست پایگاه یافت نشد.');
  const base = snapDoc.data();
  if (base.status !== 'pending') throw new GameError('این درخواست قبلاً تعیین تکلیف شده است.');
  if (Number(base.hostUserId) !== Number(hostUserId)) {
    throw new GameError('تنها رهبر کشور میزبان مجاز به موافقت با احداث پایگاه است.');
  }

  const gameService = require('./gameService');
  const hostState = await gameService.getCountryState(base.hostCountryId, base.seasonId);

  // افزایش خزانه میزبان به عنوان حق استقرار
  await gameService.updateCountryState(base.hostCountryId, base.seasonId, {
    treasury: Number(hostState.treasury || 0) + HOST_GRANT,
  });

  await ref.update({
    status: 'active',
    approvedAt: new Date().toISOString(),
  });

  // اعلان به کشور صاحب پایگاه
  if (telegram && base.ownerUserId) {
    await notifications.safeSend(
      telegram,
      base.ownerUserId,
      `🎉 <b>پایگاه نظامی شما تاسیس شد!</b>\nکشور <b>${base.hostCountryFlag} ${esc(base.hostCountryName)}</b> با احداث پایگاه نظامی شما موافقت نمود.\nاکنون می‌توانید از منوی پایگاه، تسلیحات و یگان‌های خود را به این پایگاه اعزام کنید.`
    ).catch(() => {});
  }

  return { ok: true, base };
}

/**
 * رد درخواست احداث پایگاه
 */
async function rejectMilitaryBase({ baseId, hostUserId, telegram }) {
  const ref = col('military_bases').doc(baseId);
  const snapDoc = await ref.get();
  if (!snapDoc.exists) throw new GameError('درخواست پایگاه یافت نشد.');
  const base = snapDoc.data();
  if (base.status !== 'pending') throw new GameError('این درخواست قبلاً تعیین تکلیف شده است.');
  if (Number(base.hostUserId) !== Number(hostUserId)) {
    throw new GameError('تنها رهبر کشور میزبان مجاز به پاسخگویی است.');
  }

  const gameService = require('./gameService');
  const ownerState = await gameService.getCountryState(base.ownerCountryId, base.seasonId);

  // عودت کامل بودجه به کشور صاحب پایگاه
  await gameService.updateCountryState(base.ownerCountryId, base.seasonId, {
    treasury: Number(ownerState.treasury || 0) + BASE_BUILD_COST,
  });

  await ref.update({
    status: 'rejected',
    rejectedAt: new Date().toISOString(),
  });

  if (telegram && base.ownerUserId) {
    await notifications.safeSend(
      telegram,
      base.ownerUserId,
      `❌ <b>درخواست پایگاه رد شد:</b>\nرهبر کشور <b>${base.hostCountryFlag} ${esc(base.hostCountryName)}</b> با احداث پایگاه نظامی مخالفت کرد و مبلغ ${fmtNum(BASE_BUILD_COST)}$ به خزانه شما بازگشت.`
    ).catch(() => {});
  }

  return { ok: true };
}

/**
 * انتقال تسلیحات به پایگاه نظامی
 */
async function deployWeaponsToBase({ baseId, ownerCountryId, seasonId, units }) {
  const ref = col('military_bases').doc(baseId);
  const snapDoc = await ref.get();
  if (!snapDoc.exists) throw new GameError('پایگاه یافت نشد.');
  const base = snapDoc.data();
  if (base.status !== 'active') throw new GameError('پایگاه در وضعیت فعال نیست.');
  if (String(base.ownerCountryId) !== String(ownerCountryId)) {
    throw new GameError('شما مالک این پایگاه نظامی نیستید.');
  }

  const gameService = require('./gameService');
  const state = await gameService.getCountryState(ownerCountryId, seasonId);
  const military = state.military || {};
  const currentUnits = base.deployedUnits || { tanks: 0, fighters: 0, airDefense: 0, soldiers: 0 };

  const tanksToDeploy = Math.max(0, Number(units.tanks || 0));
  const fightersToDeploy = Math.max(0, Number(units.fighters || 0));
  const airDefenseToDeploy = Math.max(0, Number(units.airDefense || 0));
  const soldiersToDeploy = Math.max(0, Number(units.soldiers || 0));

  if (tanksToDeploy > Number(military.tanks || 0)) throw new GameError('تعداد تانک‌های موجود در کشور کافی نیست.');
  if (fightersToDeploy > Number(military.fighters || 0)) throw new GameError('تعداد جنگنده‌های موجود در کشور کافی نیست.');
  if (airDefenseToDeploy > Number(military.airDefense || 0)) throw new GameError('تعداد پدافند هوایی کافی نیست.');
  if (soldiersToDeploy > Number(military.soldiers || 0)) throw new GameError('تعداد نیروی پیاده کافی نیست.');

  // کسر از مبدا و افزودن به پایگاه
  await gameService.updateCountryState(ownerCountryId, seasonId, {
    military: {
      ...military,
      tanks: Number(military.tanks || 0) - tanksToDeploy,
      fighters: Number(military.fighters || 0) - fightersToDeploy,
      airDefense: Number(military.airDefense || 0) - airDefenseToDeploy,
      soldiers: Number(military.soldiers || 0) - soldiersToDeploy,
    },
  });

  const updatedDeployed = {
    tanks: (currentUnits.tanks || 0) + tanksToDeploy,
    fighters: (currentUnits.fighters || 0) + fightersToDeploy,
    airDefense: (currentUnits.airDefense || 0) + airDefenseToDeploy,
    soldiers: (currentUnits.soldiers || 0) + soldiersToDeploy,
  };

  await ref.update({ deployedUnits: updatedDeployed, lastDeployedAt: new Date().toISOString() });
  return updatedDeployed;
}

/**
 * بررسی امکان حمله سریع‌تر از طریق پایگاه هم‌مرز با هدف
 */
async function getForwardBaseSpeedBonus(attackerCountryId, targetCountryId, seasonId) {
  if (!attackerCountryId || !targetCountryId || !seasonId) return null;

  const targetCountry = await countryService.get(targetCountryId);
  if (!targetCountry) return null;

  // تمام پایگاه‌های فعال متعلق به مهاجم در این سیزن
  const snapDocs = await col('military_bases')
    .where('seasonId', '==', String(seasonId))
    .where('ownerCountryId', '==', String(attackerCountryId))
    .where('status', '==', 'active')
    .get();

  const bases = docs(snapDocs);
  for (const b of bases) {
    // آیا کشور میزبان این پایگاه با کشور هدف هم‌مرز است؟
    if (areNeighbors(b.hostCountryName, targetCountry.name)) {
      const u = b.deployedUnits || {};
      const totalPower = (u.tanks || 0) + (u.fighters || 0) + (u.soldiers || 0);
      if (totalPower > 0) {
        return {
          hasForwardBase: true,
          baseId: b.id,
          hostCountryName: b.hostCountryName,
          hostCountryFlag: b.hostCountryFlag,
          speedBonusPercent: 50, // ۵۰٪ افزایش سرعت
          travelReductionSeconds: 300, // کاهش از ۶۰۰ به ۳۰۰ ثانیه
        };
      }
    }
  }

  return null;
}

/**
 * فهرست پایگاه‌های نظامی یک کشور (پایگاه‌های خود و پایگاه‌های مستقر در خاک خود)
 */
async function listCountryBases(countryId, seasonId) {
  const [ownedSnap, hostedSnap] = await Promise.all([
    col('military_bases').where('seasonId', '==', String(seasonId)).where('ownerCountryId', '==', String(countryId)).get(),
    col('military_bases').where('seasonId', '==', String(seasonId)).where('hostCountryId', '==', String(countryId)).get(),
  ]);

  const owned = docs(ownedSnap);
  const hosted = docs(hostedSnap);

  return {
    ownedActive: owned.filter((b) => b.status === 'active'),
    ownedPending: owned.filter((b) => b.status === 'pending'),
    hostedActive: hosted.filter((b) => b.status === 'active'),
    hostedPending: hosted.filter((b) => b.status === 'pending'),
  };
}

module.exports = {
  KNOWN_NEIGHBORS,
  areNeighbors,
  BASE_BUILD_COST,
  HOST_GRANT,
  requestMilitaryBase,
  approveMilitaryBase,
  rejectMilitaryBase,
  deployWeaponsToBase,
  getForwardBaseSpeedBonus,
  listCountryBases,
};
