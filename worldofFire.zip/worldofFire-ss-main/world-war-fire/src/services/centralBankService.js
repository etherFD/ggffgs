'use strict';
const settingsService = require('./settingsService');
const { col, snap, docs } = require('../db/firestore');
const { GameError } = require('../utils/errors');
const logger = require('../utils/logger');

const DEFAULT_CENTRAL_BANK_BUDGET = 500000000; // ۵۰۰ میلیون دلار پیش‌فرض اولیه بانک مرکزی

async function getCentralBankBudget() {
  const custom = await settingsService.get('central_bank_treasury', null);
  if (custom !== null && custom !== undefined) {
    const n = Number(custom);
    return Number.isFinite(n) && n >= 0 ? Math.floor(n) : 0;
  }
  return DEFAULT_CENTRAL_BANK_BUDGET;
}

async function addCentralBankTax(amount, reason = 'کارمزد و مالیات تراکنش بین کشوری') {
  const numeric = Math.max(0, Math.floor(Number(amount) || 0));
  if (numeric <= 0) return await getCentralBankBudget();
  const current = await getCentralBankBudget();
  const next = current + numeric;
  await settingsService.set('central_bank_treasury', next);
  logger.info(`[Central Bank] مالیات/کارمزد ${numeric.toLocaleString()}$ به بانک مرکزی اضافه شد (${reason}). موجودی کل: ${next.toLocaleString()}$`);
  return next;
}

async function deductCentralBankBudget(amount, reason = 'اعطای کمک بشردوستانه توسط مدیریت') {
  const numeric = Math.max(1, Math.floor(Number(amount) || 0));
  const current = await getCentralBankBudget();
  if (current < numeric) {
    throw new GameError(`موجودی بانک مرکزی کافی نیست! موجودی در دسترس: ${current.toLocaleString()}$ | مبلغ درخواستی: ${numeric.toLocaleString()}$ (ادمین تنها می‌تواند از بودجه تجمیع‌شده در بانک مرکزی کمک اعطا کند).`);
  }
  const next = current - numeric;
  await settingsService.set('central_bank_treasury', next);
  logger.info(`[Central Bank] کسر ${numeric.toLocaleString()}$ از بانک مرکزی جهت ${reason}. موجودی باقیمانده: ${next.toLocaleString()}$`);
  return next;
}

module.exports = {
  getCentralBankBudget,
  addCentralBankTax,
  deductCentralBankBudget,
};
