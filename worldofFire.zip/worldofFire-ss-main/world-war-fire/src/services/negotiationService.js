'use strict';
const { col, snap, docs } = require('../db/firestore');
const { GameError } = require('../utils/errors');
const gameService = require('./gameService');
const countryService = require('./countryService');
const warService = require('./warService');

async function getNegotiation(id) {
  if (!id) return null;
  return snap(await col('negotiations').doc(String(id)).get());
}

async function getActiveNegotiationForUser(userId) {
  if (!userId) return null;
  const numId = Number(userId);
  const q1 = await col('negotiations')
    .where('userA', '==', numId)
    .where('status', '==', 'active')
    .get();
  const l1 = docs(q1);
  if (l1.length) return l1[0];

  const q2 = await col('negotiations')
    .where('userB', '==', numId)
    .where('status', '==', 'active')
    .get();
  const l2 = docs(q2);
  return l2[0] || null;
}

async function requestNegotiation({ fromCountryId, fromUserId, targetCountryId, targetUserId, seasonId }) {
  if (fromCountryId === targetCountryId) throw new GameError('نمی‌توانید با کشور خود مذاکره کنید!');

  // بررسی عدم وجود جلسه فعال
  const activeExisting = await getActiveNegotiationForUser(fromUserId);
  if (activeExisting) {
    throw new GameError('شما در حال حاضر یک جلسه مذاکره دیپلماتیک فعال دارید.');
  }

  const fromCountry = await countryService.get(fromCountryId);
  const targetCountry = await countryService.get(targetCountryId);

  const ref = col('negotiations').doc();
  const nego = {
    id: ref.id,
    seasonId: String(seasonId),
    countryA: String(fromCountryId),
    countryAName: fromCountry ? fromCountry.name : 'مهاجم',
    countryAFlag: fromCountry ? fromCountry.flag : '🏳️',
    userA: Number(fromUserId),
    countryB: String(targetCountryId),
    countryBName: targetCountry ? targetCountry.name : 'مدافع',
    countryBFlag: targetCountry ? targetCountry.flag : '🏳️',
    userB: Number(targetUserId),
    status: 'pending',
    createdAt: new Date(),
  };

  await ref.set(nego);
  return nego;
}

async function acceptNegotiation(negoId, userId) {
  const nego = await getNegotiation(negoId);
  if (!nego || nego.status !== 'pending') throw new GameError('درخواست مذاکره نامعتبر است.');
  if (nego.userB !== Number(userId)) throw new GameError('شما مخاطب این درخواست مذاکره نیستید.');

  await col('negotiations').doc(nego.id).update({
    status: 'active',
    startedAt: new Date(),
  });

  return { ...nego, status: 'active' };
}

async function rejectNegotiation(negoId, userId) {
  const nego = await getNegotiation(negoId);
  if (!nego || nego.status !== 'pending') throw new GameError('درخواست مذاکره نامعتبر است.');
  if (nego.userB !== Number(userId)) throw new GameError('اجازه رد این درخواست را ندارید.');

  await col('negotiations').doc(nego.id).update({
    status: 'failed',
    endedAt: new Date(),
    reason: 'رد توسط مخاطب',
  });

  return nego;
}

// پایان یک‌طرفه با "به نتیجه نرسیدیم"
async function terminateNegotiation(negoId, userId) {
  const nego = await getNegotiation(negoId);
  if (!nego || nego.status !== 'active') throw new GameError('جلسه مذاکره فعالی یافت نشد.');
  const numId = Number(userId);
  if (nego.userA !== numId && nego.userB !== numId) {
    throw new GameError('شما عضو این مذاکره نیستید.');
  }

  await col('negotiations').doc(nego.id).update({
    status: 'ended',
    endedAt: new Date(),
    terminatedBy: numId,
    reason: 'به نتیجه نرسیدیم',
  });

  const otherUserId = nego.userA === numId ? nego.userB : nego.userA;
  return { nego, otherUserId };
}

// ثبت پیشنهاد توافق (نظامی / عدم تعارض / صلح / فروش زمین)
async function proposeAgreement({ negoId, userId, agreementType, details }) {
  const nego = await getNegotiation(negoId);
  if (!nego || nego.status !== 'active') throw new GameError('جلسه مذاکره فعالی یافت نشد.');
  const numId = Number(userId);
  if (nego.userA !== numId && nego.userB !== numId) {
    throw new GameError('شما عضو این مذاکره نیستید.');
  }

  const proposerCountryId = nego.userA === numId ? nego.countryA : nego.countryB;
  const targetCountryId = nego.userA === numId ? nego.countryB : nego.countryA;
  const targetUserId = nego.userA === numId ? nego.userB : nego.userA;

  const proposal = {
    type: agreementType, // 'military_pact', 'non_aggression', 'peace_treaty', 'land_deal'
    proposerCountryId,
    targetCountryId,
    details: details || {},
    createdAt: new Date(),
  };

  await col('negotiations').doc(nego.id).update({
    proposedAgreement: proposal,
  });

  return { nego, proposal, targetUserId };
}

// تایید و امضای توافق
async function confirmAgreement({ negoId, userId }) {
  const nego = await getNegotiation(negoId);
  if (!nego || !nego.proposedAgreement) throw new GameError('پیشنهاد توافقی ثبت نشده است.');
  const numId = Number(userId);
  const p = nego.proposedAgreement;

  const countryAId = nego.countryA;
  const countryBId = nego.countryB;
  const seasonId = nego.seasonId;

  let announceText = '';

  if (p.type === 'military_pact') {
    // قرارداد نظامی و حمایت در جنگ
    const pactRef = col('diplomatic_pacts').doc();
    await pactRef.set({
      id: pactRef.id,
      seasonId,
      countries: [countryAId, countryBId],
      type: 'military_pact',
      createdAt: new Date(),
    });
    announceText = `🛡️ <b>امضای پیمان نظامی و اتحاد مشترک!</b>\n– – – – – – – – – –\nدو کشور <b>${nego.countryAFlag} ${nego.countryAName}</b> و <b>${nego.countryBFlag} ${nego.countryBName}</b> پیمان دفاعی نظامی امضا کردند و در صورت حمله به هریک، دیگری متعهد به دفاع است.`;
  } else if (p.type === 'non_aggression') {
    // عدم تعارض
    const pactRef = col('diplomatic_pacts').doc();
    await pactRef.set({
      id: pactRef.id,
      seasonId,
      countries: [countryAId, countryBId],
      type: 'non_aggression',
      createdAt: new Date(),
    });
    announceText = `🕊️ <b>امضای پیمان عدم تعارض!</b>\n– – – – – – – – – –\nدو کشور <b>${nego.countryAFlag} ${nego.countryAName}</b> و <b>${nego.countryBFlag} ${nego.countryBName}</b> رسماً پیمان عدم تعارض امضا کرده و هرگونه تحرک نظامی بین طرفین ممنوع شد.`;
  } else if (p.type === 'peace_treaty') {
    // پیمان صلح و آتش‌بس (در صورت وجود جنگ فعال)
    const activeWars = await warService.listWars(seasonId);
    const warBetween = activeWars.find(
      (w) =>
        (w.attackerCountryId === countryAId && w.defenderCountryId === countryBId) ||
        (w.attackerCountryId === countryBId && w.defenderCountryId === countryAId)
    );
    if (warBetween) {
      await warService.endWar(warBetween.id, 'peace_treaty');
    }
    announceText = `🏳️ <b>امضای معاهده صلح پایدار و پایان جنگ!</b>\n– – – – – – – – – –\nجنگ و تخاصم میان <b>${nego.countryAFlag} ${nego.countryAName}</b> و <b>${nego.countryBFlag} ${nego.countryBName}</b> با امضای معاهده صلح پایان یافت.`;
  } else if (p.type === 'land_deal') {
    // معامله زمین (فروش یا خرید استان در ازای پول/نفت/سلاح/پژوهش)
    const { action, provinceId, compensationType, compensationAmount } = p.details;
    const sellerId = action === 'sell' ? p.proposerCountryId : p.targetCountryId;
    const buyerId = action === 'sell' ? p.targetCountryId : p.proposerCountryId;

    const sellerState = await gameService.getCountryState(sellerId, seasonId);
    const buyerState = await gameService.getCountryState(buyerId, seasonId);

    const sellerCountry = await countryService.get(sellerId);
    const buyerCountry = await countryService.get(buyerId);

    const sellerProvs = gameService.normalizeProvinces(sellerState.provinces, sellerCountry ? sellerCountry.name : 'فروشنده');
    const buyerProvs = gameService.normalizeProvinces(buyerState.provinces, buyerCountry ? buyerCountry.name : 'خریدار');

    const provIndex = sellerProvs.findIndex((x) => x.id === provinceId || x.direction === provinceId);
    const soldProv = provIndex >= 0 ? sellerProvs[provIndex] : sellerProvs[0];

    // انتقال استان به خریدار
    const updatedSellerProvs = sellerProvs.filter((_, i) => i !== provIndex);
    const updatedBuyerProvs = [...buyerProvs, { ...soldProv, name: `${soldProv.name} (خریداری‌شده از ${sellerCountry.name})` }];

    const patchSeller = { provinces: updatedSellerProvs };
    const patchBuyer = { provinces: updatedBuyerProvs };

    const compAmt = Math.max(1, Number(compensationAmount) || 0);

    // انتقال مابه‌ازا (پول / نفت / سلاح و سرباز / پژوهش)
    if (compensationType === 'money') {
      patchBuyer.treasury = Math.max(0, (buyerState.treasury || 0) - compAmt);
      patchSeller.treasury = (sellerState.treasury || 0) + compAmt;
    } else if (compensationType === 'oil') {
      patchBuyer.oil = Math.max(0, (buyerState.oil || 0) - compAmt);
      patchSeller.oil = (sellerState.oil || 0) + compAmt;
    } else if (compensationType === 'weapons') {
      patchBuyer['groundUnits.tank'] = Math.max(0, (buyerState.groundUnits?.tank || 0) - compAmt);
      patchSeller['groundUnits.tank'] = (sellerState.groundUnits?.tank || 0) + compAmt;
    } else if (compensationType === 'research') {
      patchBuyer.scoreToNext = Math.max(0, (buyerState.scoreToNext || 0) - compAmt);
      patchSeller.scoreToNext = (sellerState.scoreToNext || 0) + compAmt;
    }

    await gameService.updateCountryState(sellerId, seasonId, patchSeller);
    await gameService.updateCountryState(buyerId, seasonId, patchBuyer);

    announceText = `🗺️ <b>معاهده تاریخی واگذاری و معامله سرزمین!</b>\n– – – – – – – – – –\nکشور <b>${sellerCountry.flag} ${sellerCountry.name}</b> استان <b>«${soldProv.name}»</b> را در ازای ${compAmt.toLocaleString()} ${compensationType === 'money' ? '$' : compensationType === 'oil' ? 'بشکه نفت' : compensationType === 'weapons' ? 'سلاح و ادوات نظامی' : 'امتیاز پژوهشی'} به کشور <b>${buyerCountry.flag} ${buyerCountry.name}</b> واگذار نمود.`;
  }

  await col('negotiations').doc(nego.id).update({
    status: 'agreed',
    endedAt: new Date(),
  });

  return { nego, announceText };
}

module.exports = {
  getNegotiation,
  getActiveNegotiationForUser,
  requestNegotiation,
  acceptNegotiation,
  rejectNegotiation,
  terminateNegotiation,
  proposeAgreement,
  confirmAgreement,
};
