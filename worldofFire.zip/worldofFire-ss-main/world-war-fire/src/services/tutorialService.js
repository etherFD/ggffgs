'use strict';

/**
 * سرویس آموزش مرحله‌به‌مرحله بازیکنان تازه‌وارد (Tutorial & Starting Grant)
 * اعتبارسنجی پیشرفت واقعی در ۱۰ گام راهبردی و اهدای یک‌بار پاداش شروع
 */

const { col, snap } = require('../db/firestore');
const { GameError } = require('../utils/errors');
const settingsService = require('./settingsService');
const { acquireLock, releaseLock } = require('../db/locks');
const { fmtNum } = require('../utils/text');

const TUTORIAL_STEPS = [
  { id: 1, title: 'مشاهده صفحه امپراتوری', desc: 'ورود به بخش امپراتوری من و شناخت ارکان کشور' },
  { id: 2, title: 'خرید اولین دکل نفتی', desc: 'توسعه زیرساخت استخراج نفت با خرید حداقل ۱ دکل' },
  { id: 3, title: 'استخدام کارگر پالایشگاه', desc: 'استخدام کارگران ماهر برای راه‌اندازی خطوط تولید' },
  { id: 4, title: 'تنظیم نرخ مالیات ملی', desc: 'بررسی و تثبیت نرخ مالیات بر درآمد شهروندان' },
  { id: 5, title: 'آشنایی با تراز مالی خزانه', desc: 'مشاهده گزارش تفکیکی درآمد، هزینه‌ها و بودجه روزانه' },
  { id: 6, title: 'خرید منابع از بازار جهانی', desc: 'خرید اقلام اولیه نظیر چوب، سیمان، آهن یا فولاد' },
  { id: 7, title: 'تاسیس اولین شرکت یا پروژه', desc: 'راه‌اندازی بنگاه اقتصادی اختصاصی یا آغاز پروژه عمرانی' },
  { id: 8, title: 'شناخت ارتش و ادوات نظامی', desc: 'ورود به پادگان و تجهیز قوای زمینی، هوایی یا پدافندی' },
  { id: 9, title: 'دیپلماسی مستقیم و روابط بین‌الملل', desc: 'مشاهده میز دیپلماسی، ارسال پیمان یا تعیین موضع جهانی' },
  { id: 10, title: 'قوانین جنگ و مجمع سازمان ملل', desc: 'آشنایی با مقررات تهاجم، اخذ مجوز و شرکت در رأی‌گیری‌های سازمان ملل' },
];

const DEFAULT_TUTORIAL_REWARD_CASH = 100000000; // ۱۰۰ میلیون دلار پاداش نقدی
const DEFAULT_TUTORIAL_REWARD_SHAHI = 5; // ۵ سکه شاهی

/**
 * دریافت وضعیت آموزش بازیکن
 */
async function getPlayerTutorial(userId) {
  if (!userId) return null;
  const ref = col('user_tutorials').doc(String(userId));
  const s = await ref.get();
  if (!s.exists) {
    const initData = {
      userId: Number(userId),
      completedSteps: [],
      currentStep: 1,
      rewardClaimed: false,
      startedAt: new Date(),
      completedAt: null,
    };
    await ref.set(initData);
    return initData;
  }
  return s.data();
}

/**
 * تکمیل واقعی یک گام از آموزش با بررسی داده‌های بازی
 */
async function completeTutorialStep(userId, countryId, seasonId, stepId) {
  const stepNum = Number(stepId);
  const lockKey = `tutorial:${userId}`;
  const locked = await acquireLock(lockKey, 5000);
  if (!locked) return null;

  try {
    const ref = col('user_tutorials').doc(String(userId));
    let tut = (await ref.get()).data();
    if (!tut) tut = await getPlayerTutorial(userId);

    const completed = tut.completedSteps || [];
    if (completed.includes(stepNum)) {
      return { tut, alreadyCompleted: true };
    }

    // اعتبارسنجی واقعی مرحله بر اساس وضعیت کشور
    const gameService = require('./gameService');
    const state = await gameService.getCountryState(countryId, seasonId);

    let isValid = false;
    switch (stepNum) {
      case 1:
        isValid = true; // گام ۱: مشاهده مرکز فرماندهی
        break;
      case 2:
        isValid = Number(state.oilRigs || 0) >= 1; // دکل نفتی
        break;
      case 3:
        isValid = Number(state.workers || 0) >= 1; // کارگر
        break;
      case 4:
        isValid = state.taxRate !== undefined || state.treasury > 0; // مالیات
        break;
      case 5:
        isValid = Number(state.incomeDaily || 0) > 0; // درآمد روزانه
        break;
      case 6:
        isValid = Object.keys(state.inventory || {}).length > 0 || (state.oil || 0) > 0; // بازار جهانی
        break;
      case 7:
        isValid = (state.customEnterprises && state.customEnterprises.length > 0) || (state.megaprojects && state.megaprojects.length > 0) || Boolean(state.telecomOperator);
        break;
      case 8:
        isValid = (state.military && (state.military.attack > 0 || state.military.defense > 0)) || Object.keys(state.groundUnits || {}).length > 0;
        break;
      case 9:
        isValid = true; // آشنایی با دیپلماسی
        break;
      case 10:
        isValid = true; // آشنایی با سازمان ملل
        break;
      default:
        isValid = true;
    }

    if (!isValid) {
      return { tut, passed: false, reason: 'پیش‌نیاز این گام هنوز در کشور شما عملیاتی نشده است.' };
    }

    completed.push(stepNum);
    completed.sort((a, b) => a - b);

    const isAllDone = TUTORIAL_STEPS.every((s) => completed.includes(s.id));
    let rewardGranted = false;
    let rewardInfo = null;

    if (isAllDone && !tut.rewardClaimed) {
      // واریز پاداش شروع به صورت یک‌باره
      const cashReward = await settingsService.get('tutorial_reward_cash', DEFAULT_TUTORIAL_REWARD_CASH);
      const shahiReward = await settingsService.get('tutorial_reward_shahi', DEFAULT_TUTORIAL_REWARD_SHAHI);

      await gameService.updateCountryState(countryId, seasonId, {
        treasury: (state.treasury || 0) + cashReward,
        shahiCoins: (state.shahiCoins || 0) + shahiReward,
      });

      rewardGranted = true;
      rewardInfo = { cashReward, shahiReward };
      tut.rewardClaimed = true;
      tut.completedAt = new Date();
    }

    const nextStep = TUTORIAL_STEPS.find((s) => !completed.includes(s.id))?.id || 10;
    tut.completedSteps = completed;
    tut.currentStep = nextStep;

    await ref.set(tut, { merge: true });

    return {
      tut,
      passed: true,
      valid: true,
      stepId: stepNum,
      isAllDone,
      rewardGranted,
      rewardInfo,
    };
  } finally {
    await releaseLock(lockKey);
  }
}

/**
 * دریافت پاداش شروع بازی پس از تکمیل تمام گام‌ها
 */
async function claimTutorialReward(userId, countryId, seasonId) {
  const lockKey = `tutorial_reward:${userId}`;
  const locked = await acquireLock(lockKey, 5000);
  if (!locked) throw new GameError('در حال پردازش درخواست پاداش هستید. لطفاً شکیبا باشید.');
  try {
    const ref = col('user_tutorials').doc(String(userId));
    let tut = (await ref.get()).data();
    if (!tut) tut = await getPlayerTutorial(userId);

    if (tut.rewardClaimed) {
      throw new GameError('پاداش شروع بازی قبلاً دریافت شده است.');
    }

    const completed = tut.completedSteps || [];
    const allDone = TUTORIAL_STEPS.every((s) => completed.includes(s.id));
    if (!allDone) {
      throw new GameError('هنوز تمام گام‌های آموزش تکمیل نشده‌اند.');
    }

    const cashReward = await settingsService.get('tutorial_reward_cash', DEFAULT_TUTORIAL_REWARD_CASH);
    const shahiReward = await settingsService.get('tutorial_reward_shahi', DEFAULT_TUTORIAL_REWARD_SHAHI);

    const gameService = require('./gameService');
    const state = await gameService.getCountryState(countryId, seasonId);
    await gameService.updateCountryState(countryId, seasonId, {
      treasury: (state.treasury || 0) + cashReward,
      shahiCoins: (state.shahiCoins || 0) + shahiReward,
    });

    tut.rewardClaimed = true;
    tut.completedAt = new Date();
    await ref.set(tut, { merge: true });

    return { cashReward, shahiReward };
  } finally {
    await releaseLock(lockKey);
  }
}
module.exports = {
  TUTORIAL_STEPS,
  getPlayerTutorial,
  completeTutorialStep,
  claimTutorialReward,
};

