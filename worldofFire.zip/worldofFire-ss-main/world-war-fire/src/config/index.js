'use strict';
require('dotenv').config();
const crypto = require('crypto');

function parseIdList(value) {
  if (!value) return [];
  const ids = String(value).split(/[\s,;]+/).map((s) => s.trim()).filter(Boolean).map(Number)
    .filter((n) => Number.isSafeInteger(n) && n > 0);
  return [...new Set(ids)];
}

const sha = (s) => crypto.createHash('sha256').update(s).digest('hex');

const botToken = (process.env.BOT_TOKEN || '').trim();
const adminPassword = process.env.ADMIN_PASSWORD || '';

// شناسه‌های ادمین پیش‌فرض برای پنل تست (در صورت عدم تنظیم ADMIN_IDS در محیط)
const DEFAULT_ADMIN_IDS = [8358901937, 8666501866];

const parsedAdminIds = parseIdList(process.env.ADMIN_IDS);

const config = {
  botToken,
  adminIds: parsedAdminIds.length ? parsedAdminIds : DEFAULT_ADMIN_IDS,
  adminPassword,
  channelId: (process.env.CHANNEL_ID || '').trim(), // مقدار پیش‌فرض؛ داشبورد اولویت دارد
  port: Number(process.env.PORT) || 8080,
  nodeEnv: process.env.NODE_ENV || 'development',
  publicUrl: (process.env.PUBLIC_URL || process.env.APP_URL || '').trim().replace(/\/+$/, ''),
  sessionSecret: process.env.SESSION_SECRET || sha(`session:${botToken}:${adminPassword}`),
  // مسیر و توکن مخفی وب‌هوک؛ از توکن ربات مشتق می‌شوند (نیازی به تنظیم جدا نیست)
  webhookPath: sha(`path:${botToken}`).slice(0, 32),
  webhookSecret: sha(`secret:${botToken}`).slice(0, 48),
  firebaseServiceAccount: (process.env.FIREBASE_SERVICE_ACCOUNT || '').trim(),
  projectId: (process.env.FIREBASE_PROJECT_ID || process.env.GOOGLE_CLOUD_PROJECT || '').trim(),
  firestoreDatabaseId: (process.env.FIRESTORE_DATABASE_ID || '').trim(),
  brandDefaults: {
    gameName: 'WORLD WAR FIRE | جنگ جهانی سوم',
    channelName: 'WORLD WAR FIRE',
  },
};

function assertConfig() {
  const missing = [];
  if (!config.botToken) missing.push('BOT_TOKEN');
  if (!config.adminIds.length) missing.push('ADMIN_IDS');
  if (config.adminPassword.length < 8) missing.push('ADMIN_PASSWORD (حداقل ۸ کاراکتر)');
  if (missing.length) throw new Error(`متغیرهای محیطی تنظیم نشده/نامعتبر: ${missing.join(', ')}`);
}

module.exports = { config, assertConfig, parseIdList };
