'use strict';
// بررسی سینتکس همه فایل‌های js
const { execFileSync } = require('child_process');
const fs = require('fs');
const path = require('path');
function walk(d, out = []) {
  for (const f of fs.readdirSync(d, { withFileTypes: true })) {
    if (f.name === 'node_modules' || f.name.startsWith('.')) continue;
    const p = path.join(d, f.name);
    if (f.isDirectory()) walk(p, out); else if (p.endsWith('.js')) out.push(p);
  }
  return out;
}
let bad = 0;
for (const f of walk(path.join(__dirname, '..'))) {
  try { execFileSync(process.execPath, ['--check', f], { stdio: 'pipe' }); } catch (e) { bad++; console.error('❌', f, String(e.stderr)); }
}
console.log(bad ? `${bad} فایل خطا دارد` : '✅ سینتکس همه فایل‌ها سالم است');
process.exit(bad ? 1 : 0);
