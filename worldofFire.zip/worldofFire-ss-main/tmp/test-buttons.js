const { FakeFirestore } = require('./world-war-fire/tests/fakeFirestore');
const { setDb } = require('./world-war-fire/src/db/firestore');
const { Telegram } = require('telegraf');
const { createBot } = require('./world-war-fire/src/bot');
const seasonService = require('./world-war-fire/src/services/seasonService');
const settings = require('./world-war-fire/src/services/settingsService');
const userService = require('./world-war-fire/src/services/userService');

async function run() {
  process.env.BOT_TOKEN = '123456:TESTTOKEN';
  process.env.ADMIN_IDS = '900';
  setDb(new FakeFirestore());
  settings._clearCache();
  userService._clearCache();
  await seasonService.ensureDefaultSeason();

  const bot = createBot();
  bot.botInfo = { id: 1, is_bot: true, username: 'wwf_bot', first_name: 'WWF' };

  Telegram.prototype.callApi = async function callApi(method, payload) {
    console.log('[API CALL]', method, JSON.stringify(payload).slice(0, 100));
    if (method === 'sendMessage' || method === 'sendPhoto' || method === 'editMessageText') {
      return { message_id: 123, chat: { id: payload.chat_id || 100 } };
    }
    return true;
  };

  const buttonsToTest = [
    'menu:home',
    'menu:status',
    'menu:empire',
    'menu:commander',
    'menu:mission',
    'menu:account',
    'menu:shield',
    'menu:world',
    'menu:coin',
    'menu:tutorial',
    'menu:leaderboard',
    'cl:0'
  ];

  for (const btn of buttonsToTest) {
    console.log('\n--- Testing button:', btn);
    try {
      await bot.handleUpdate({
        update_id: Math.floor(Math.random() * 100000),
        callback_query: {
          id: String(Math.floor(Math.random() * 100000)),
          from: { id: 100, is_bot: false, first_name: 'TestUser', username: 'testuser' },
          chat_instance: 'x',
          data: btn,
          message: {
            message_id: 555,
            chat: { id: 100, type: 'private' },
            date: 1,
            text: 'Current Menu'
          }
        }
      });
      console.log('✅ Button', btn, 'handled without throw');
    } catch (err) {
      console.error('❌ Button', btn, 'FAILED:', err);
    }
  }

  process.exit(0);
}

run().catch((err) => {
  console.error('Fatal in test script:', err);
  process.exit(1);
});
