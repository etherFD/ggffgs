import path from 'path';
import express from 'express';
// @ts-ignore
import { config, assertConfig } from './world-war-fire/src/config/index.js';
// @ts-ignore
import logger from './world-war-fire/src/utils/logger.js';
// @ts-ignore
import { initDb } from './world-war-fire/src/db/firestore.js';
// @ts-ignore
import { ensureDefaultSeason } from './world-war-fire/src/services/seasonService.js';
// @ts-ignore
import { createBot } from './world-war-fire/src/bot/index.js';
// @ts-ignore
import { createWebApp } from './world-war-fire/src/web/server.js';
// @ts-ignore
import { initAdminBot } from './world-war-fire/src/services/adminBotService.js';
// @ts-ignore
import { startGameLoop, stopGameLoop } from './world-war-fire/src/services/gameLoopService.js';
// @ts-ignore
import weaponService from './world-war-fire/src/services/weaponService.js';

const PORT = Number(process.env.PORT || 3000);

async function startServer() {
  let app: express.Express;
  let bot: any = null;

  try {
    assertConfig();
    initDb();
    bot = createBot();

    const ready = (async () => {
      let isBotAuthed = false;
      try {
        bot.botInfo = await bot.telegram.getMe();
        isBotAuthed = true;
        bot.isAuthorized = true;
        logger.info(`ربات تلگرام @${bot.botInfo.username} با موفقیت تایید شد.`);
      } catch (err: any) {
        logger.warn(`هشدار اتصال به تلگرام (${err.message})؛ داشبورد وب و دیتابیس در حالت پایدار فعال شدند.`);
        bot.botInfo = {
          id: 0,
          is_bot: true,
          first_name: 'World War Fire Bot',
          username: 'offline_bot',
        };
        bot.isAuthorized = false;
        bot.authError = err.message;
      }

      // اتصال دیتابیس، سیزن فعال و تسلیحات پیش‌فرض
      try {
        await ensureDefaultSeason();
        await weaponService.ensureInitialized();
        logger.info('دیتابیس فایراستور، سیزن فعال و تجهیزات نظامی آماده‌سازی شدند.');
      } catch (err: any) {
        logger.error('خطا در آماده‌سازی سیزن یا تسلیحات فایراستور:', err.message);
      }

      if (isBotAuthed) {
        // فعال‌سازی چرخه مرکزی بازی (نفت‌کش‌ها، واریز ۱۰ دقیقه‌ای و بازار ۳۰ دقیقه‌ای)
        try {
          startGameLoop(bot.telegram);
        } catch (err: any) {
          logger.warn('خطا در آغاز چرخه بازی:', err.message);
        }

        // راه‌اندازی ربات دوم مدیریت (در صورت وجود توکن اختصاصی ادمین)
        try {
          await initAdminBot(bot.telegram);
        } catch (err: any) {
          logger.warn('خطا در راه‌اندازی ربات دوم ادمین:', err.message);
        }

        // پاکسازی وبهوک و شروع Polling
        try {
          const whInfo = await bot.telegram.getWebhookInfo().catch(() => null);
          if (whInfo && whInfo.url) {
            logger.info(`وبهوک قبلی تلگرام (${whInfo.url}) در حال پاکسازی است...`);
            await bot.telegram.deleteWebhook({ drop_pending_updates: true });
            logger.info('وبهوک با موفقیت حذف شد؛ پیام‌های معلق تلگرام پاکسازی شدند.');
          }

          bot.launch({ dropPendingUpdates: true }).then(() => {
            logger.info(`ربات تلگرام @${bot.botInfo.username} در حالت دریافت مستقیم و بلادرنگ (Polling) فعال شد.`);
          }).catch((err: any) => {
            logger.warn('خطا در اجرای polling ربات:', err.message);
          });
        } catch (err: any) {
          logger.warn('خطا در بررسی/حذف وب‌هوک و شروع Polling:', err.message);
        }
      } else {
        logger.warn('به دلیل عدم تایید توکن ربات تلگرام (401: Unauthorized)، اجرای Polling معلق شد تا توکن معتبر تنظیم شود.');
      }
    })();
    ready.catch((e: any) => logger.error('خطای غیرمنتظره در راه‌اندازی:', e.message));

    app = createWebApp({ bot, ready });

    const publicAdminPath = path.join(process.cwd(), 'world-war-fire', 'public', 'admin.html');

    // اولویت قطعی برای باز شدن پنل مدیریت روی ریشه سایت
    app.get(['/', '/admin', '/admin/*'], (req: express.Request, res: express.Response) => {
      res.sendFile(publicAdminPath);
    });

    if (process.env.NODE_ENV !== 'production') {
      const { createServer: createViteServer } = await import('vite');
      const vite = await createViteServer({
        server: { middlewareMode: true },
        appType: 'custom',
      });

      // مسیر دسترسی اختیاری به شبیه‌ساز تست بازی
      app.get(['/simulator', '/simulator/*'], async (req: express.Request, res: express.Response, next: express.NextFunction) => {
        try {
          const fs = await import('fs');
          const template = await fs.promises.readFile(path.join(process.cwd(), 'index.html'), 'utf-8');
          const html = await vite.transformIndexHtml(req.originalUrl, template);
          res.status(200).set({ 'Content-Type': 'text/html' }).end(html);
        } catch (e) {
          next(e);
        }
      });

      app.use(vite.middlewares);
    } else {
      const distDir = path.join(process.cwd(), 'dist');
      app.use(express.static(distDir));
      app.get(['/simulator', '/simulator/*'], (req: express.Request, res: express.Response) => {
        res.sendFile(path.join(distDir, 'index.html'));
      });
      app.get('*', (req: express.Request, res: express.Response, next: express.NextFunction) => {
        if (req.path.startsWith('/api') || req.path.startsWith('/telegram') || req.path.startsWith('/miniapp') || req.path.startsWith('/flags') || req.path.startsWith('/uploads')) {
          return next();
        }
        res.sendFile(publicAdminPath);
      });
    }
  } catch (err: any) {

    logger.warn('راه‌اندازی با تنظیمات فعلی:', err.message);
    app = express();
    // هندلر اضطراری جهت پاسخ ۲۰۰ فوری به تلگرام در صورت ارسال وبهوک تا خطای ۳۰۲ برطرف گردد
    const fallbackWebhook = (req: express.Request, res: express.Response) => res.status(200).json({ ok: true, fallback: true });
    app.post('/telegram/webhook', fallbackWebhook);
    app.post('/api/telegram/webhook', fallbackWebhook);
    app.all('/telegram/*', fallbackWebhook);

    const publicDir = path.join(process.cwd(), 'world-war-fire', 'public');
    app.use(express.static(publicDir));
    app.get('/', (req, res) => res.sendFile(path.join(publicDir, 'admin.html')));
    app.get('/admin', (req, res) => res.sendFile(path.join(publicDir, 'admin.html')));
    app.get('/health', (req, res) => res.json({ ok: false, error: err.message }));
  }

  const server = app.listen(PORT, '0.0.0.0', () => {
    logger.info(`داشبورد و سرور World War Fire روی پورت ${PORT} فعال شد.`);
  });

  const shutdown = (sig: string) => {
    logger.info(`${sig} دریافت شد؛ خاموش‌سازی...`);
    stopGameLoop();
    if (bot) bot.stop(sig);
    server.close(() => process.exit(0));
    setTimeout(() => process.exit(0), 5000).unref();
  };
  process.once('SIGTERM', () => shutdown('SIGTERM'));
  process.once('SIGINT', () => shutdown('SIGINT'));
}

startServer();
