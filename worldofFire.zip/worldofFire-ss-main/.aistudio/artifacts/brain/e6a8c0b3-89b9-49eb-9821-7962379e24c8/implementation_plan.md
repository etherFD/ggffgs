# World War Fire: Currency Overhaul, Reference Button Styling & Admin Bot Acceleration

A comprehensive overhaul transitioning the primary in-game currency to **Dollar ($)**, converting **Shahi Coin (سکه شاهی)** into an admin-backed external currency with custom daily missions and an admin-set exchange rate, restyling the UI buttons to match the exact military aesthetic from the reference screenshot, optimizing the Admin Bot for instantaneous response, and enabling direct country-based player messaging from the admin panel.

---

## User Review & Critical Decisions

> [!IMPORTANT]
> The following key decisions were confirmed during the interactive clarification phase:

- **Confirmed Decision 1 (Currency Roles & Shahi Coin Utility)**:
  - **Dollar ($ / دلار)** is now the primary in-game currency for all operational costs (treasury, attacks, oil exploration, maintenance, trade, and market purchases).
  - **Shahi Coin (سکه شاهی)** is the external/premium unit granted directly by Admins or earned via daily missions. Players can convert Shahi Coins directly into Dollars at an exchange rate configured by the Admin.
- **Confirmed Decision 2 (Admin Player Messaging)**:
  - Admin panel provides a dedicated country selection dropdown to choose any active nation and send a direct private message to the player leading that country.
- **Confirmed Decision 3 (Admin-Managed Daily Missions)**:
  - Admin configures custom daily missions specifying a title, target completion count, and Shahi Coin reward. Players track and claim these in-game.
- **Confirmed Decision 4 (UI & Button Styling Matching Reference)**:
  - Completely remove the previous arbitrary rainbow gradient menu block.
  - Apply the exact military command button visual hierarchy from the user's reference screenshot:
    - **Terracotta / Dark Brick Red** (`#8f3d38`): War, Attack, Nuclear Program (`حمله`, `اعلام جنگ`, `برنامه هسته‌ای`).
    - **Dark Forest Green** (`#2b6a33` / `#356d35`): Economy & Oil (`اقتصاد و نفت`).
    - **Slate Blue / Dark Teal** (`#245873` / `#2b6782`): Defense, Straits, Military Base, Inflation (`دفاع`, `تنگه‌ها`, `پایگاه نظامی`, `تورم`).
    - **Dark Slate / Charcoal** (`#222a32` / `#28323c` with border `#333f4c`): Navigation, diplomacy, espionage, provinces, and general commands.

---

## 1. Overview & Core Concept

- **What It Does**:
  - Replaces all legacy coin references with **Dollar ($)** as the everyday national budget and trade medium.
  - Establishes **Shahi Coin (سکه شاهی)** as a prestigious secondary currency, earned through Admin-authored daily tasks or granted directly, convertible to national Dollars at the admin-configured rate.
  - Re-themes both the Telegram Mini App and Web Dashboard to match the user's provided screenshot layout and color scheme.
  - Accelerates the secondary Admin Bot by caching country lookups in-memory, responding immediately to Telegram callback queries (`answerCbQuery`) before executing heavy operations, and eliminating sequential bottlenecks.
  - Adds a streamlined country-picker flow in the Admin Bot to message players directly.
- **Target Audience**:
  - Players managing nations, commanding armies, trading oil, and completing daily state directives.
  - Game Administrators managing economies, reviewing complaints, dispatching diplomatic notes, and tuning currency parameters.

---

## 2. User Experience & Visual Design

### Key User Flows

1. **Player Economic & Mission Flow**:
   - Player views their balance: **Treasury: $X** and **Shahi Coins: 👑 Y**.
   - Player opens "Daily Missions" (ماموریت‌های روزانه), views active tasks created by the Admin, tracks progress, and claims Shahi Coin bounties.
   - Player visits the Currency Exchange tab to convert Shahi Coins into Dollars based on the active rate (e.g., 1 Shahi Coin = $10,000,000).
2. **Admin Direct Messaging Flow**:
   - In the Admin Bot, Admin taps `📨 ارسال پیام به بازیکن`.
   - Admin picks the target nation from an inline country selection list (e.g., `🇮🇷 ایران`, `🇷🇺 روسیه`, `🇺🇸 آمریکا`).
   - Admin sends the custom message text.
   - The bot delivers the message straight to the player's Telegram PV with clear official admin headers.
3. **Admin Daily Missions & Currency Management Flow**:
   - Admin opens `🎯 مدیریت ماموریت‌های روزانه`: creates/edits tasks (Title, Goal Target, Shahi Coin Reward) and toggles active status.
   - Admin opens `🪙 نرخ تبدیل سکه شاهی`: updates how many Dollars 1 Shahi Coin is worth, or directly grants Shahi Coins to a country.
4. **Visual Interface Experience**:
   - Full alignment with the user's reference image:
     - Header displays state emblem, Dollar treasury, Shahi Coin vault, oil capacity, and military status.
     - Grid layout of beveled command buttons strictly partitioned into the 4 defined color categories (Terracotta Red, Forest Green, Slate Teal, and Charcoal Slate).
     - Removal of the previous rainbow gradient block in favor of this coherent command center design.

---

## 3. Key Product Decisions & Trade-Offs

- **Decision 1: Dual Currency Separation (Dollar vs. Shahi Coin)**:
  - *Chosen Approach*: `dollar` (stored as `balance` / treasury in Firestore) is used for all simulation costs (troops, attacks, $450M oil survey, buildings, infrastructure). `shahiCoins` is a separate player attribute stored in the country/user document.
  - *Why*: Clear boundary between in-game economic activity and high-value admin/mission rewards, preventing inflation exploits while giving Admins complete macroeconomic control.
- **Decision 2: In-Memory Country Cache & Callback Snappiness**:
  - *Chosen Approach*: Cache active country list and global config in memory in `adminBotService.js` with short TTL (30 seconds) and invalidation on update. Always call `ctx.answerCbQuery()` before awaiting Firestore promises.
  - *Why*: Eliminates Telegram's spinning loading indicator and provides instant tactile feedback to the admin.
- **Decision 3: Country Selection for Admin DMs**:
  - *Chosen Approach*: Paginated inline keyboard list of active countries with flags and names, rather than requiring the admin to memorize 10-digit Telegram user IDs.
  - *Why*: Directly aligns with how roleplay war games operate—admins interact with countries and leaders.

---

## 4. Technical Architecture & Data Strategy

```
┌────────────────────────────────────────────────────────────────────────┐
│                        WORLD WAR FIRE SYSTEM                           │
└────────────────────────────────────────────────────────────────────────┘
                                    │
          ┌─────────────────────────┴─────────────────────────┐
          ▼                                                   ▼
┌───────────────────────────┐                       ┌───────────────────────────┐
│     MAIN PLAYER BOT &     │                       │     DEDICATED ADMIN       │
│     TELEGRAM MINI APP     │                       │       MANAGEMENT BOT      │
│  - Dollar Treasury ($)    │                       │  - Fast Cached Navigation │
│  - Shahi Coin Vault (👑)  │                       │  - Instant answerCbQuery  │
│  - Daily Missions Viewer  │                       │  - Country DM Dispatcher  │
│  - Shahi -> $ Converter   │                       │  - Shahi Exchange Config  │
│  - Reference Button Style │                       │  - Daily Missions Setup   │
│    (Red/Green/Teal/Slate) │                       │  - Oil Richness & Capital │
└─────────────┬─────────────┘                       └─────────────┬─────────────┘
              │                                                   │
              └─────────────────────┬─────────────────────────────┘
                                    ▼
┌────────────────────────────────────────────────────────────────────────┐
│                      FIRESTORE PERSISTENCE                             │
│  - /seasons/{id}/countries: { balance ($), shahiCoins, ... }           │
│  - /seasons/{id}/config: { shahiExchangeRate, capitalChangeCost, ... } │
│  - /seasons/{id}/daily_missions: [ { id, title, target, rewardShahi } ]│
└────────────────────────────────────────────────────────────────────────┘
```

### Data Model Additions & Updates

1. **Country Document (`countries/{countryId}`)**:
   - `balance`: Numerical Dollar balance (formerly generic coins).
   - `shahiCoins`: Numerical Shahi Coin balance (default 0).
   - `missionProgress`: Record of active daily mission progress.
2. **Season Config Document (`seasons/{seasonId}`)**:
   - `shahiToDollarRate`: Number (e.g. 10,000,000 Dollars per 1 Shahi Coin).
   - `dailyMissions`: Array of objects `{ id, title, targetCount, rewardShahi, active }`.
3. **Formatting & Text Localization**:
   - Update all user-facing strings across `views.js`, `empire.js`, `warService.js`, `miniapp.html`, and `App.tsx` from `سکه` to `دلار ($)` and introduce `سکه شاهی (👑)`.

---

## Verification & Deployment Plan

1. **Synthesize & Implement Backend Modules**:
   - Add Shahi Coin transaction methods in `gameService.js` and `tradeService.js`.
   - Add daily missions configuration and player country direct message dispatch in `adminBotService.js`.
   - Optimize callback query resolution in `adminBotService.js` with instant acknowledgment and in-memory country cache.
2. **Restyle Mini App & Web Dashboard**:
   - Purge rainbow gradient styling from `miniapp.html` and `src/App.tsx`.
   - Implement the exact reference button palette (Terracotta Red `#8f3d38`, Forest Green `#2b6a33`, Slate Teal `#245873`, Charcoal Slate `#222a32`).
3. **Verify Applet Compilation & Syntax**:
   - Run `compile_applet` to verify Vite + TypeScript.
   - Run `check-syntax.js` to ensure zero syntax errors across the modified codebase.
   - Test endpoints `/` and `/miniapp` to verify smooth operation.
