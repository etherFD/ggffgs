# World War Fire: System Stability, Admin Material Governance & Strategic Ministry Expansion

Comprehensive engineering plan to resolve distributed lock exceptions, empower admin construction configuration, fix custom enterprise registration, unlock infinite telecom upgrades with channel broadcasts and web activity logs, unify global commodity markets, implement a real-money VIP Shahi Coin purchasing and receipt-verification system with admin Toman price governance, introduce a full-fledged Commander/Minister appointment system for unassigned citizens, and enhance UI with full-spectrum colorized controls and rich iconography.

---

### User Review & Critical Decisions

> [!IMPORTANT]
> The following architectural decisions incorporate user clarifications and govern the implementation:

- **Confirmed Decision 1 (Real-Money Shahi Coin VIP Purchasing Flow)**:
  - Buying Shahi Coins operates **identically to the VIP country acquisition system** using real currency (Toman).
  - Admin can configure and update the **exact price of 1 Shahi Coin in Tomans** (`shahi_coin_real_price_toman`) in the Admin Panel / Admin Bot.
  - In the bot/web menu, players select a coin package (e.g. 5, 10, 20, 50, or custom quantity). The system computes the total Toman amount, presents the official card number and holder name, and prompts the user to upload their photo receipt or transaction code.
  - The request is placed in the Admin Verification Queue. Upon admin approval, the Shahi Coins are automatically deposited to the player's account with an instant congratulatory notification.
- **Confirmed Decision 2 (Commander & Minister Appointment)**: Players appoint their Minister or Supreme Commander by choosing from a live in-game roster of active registered players who do not currently own a country. The appointed player is notified immediately and granted cabinet co-governance status.
- **Confirmed Decision 3 (Admin Project Materials)**: Administrators can multi-select any required commodities (`steel`, `iron`, `copper`, `wood`, `cement`, `oil`) and enter precise required quantities per project directly in the Admin Panel.

---

### 1. Overview & Core Concept

World War Fire simulates global statecraft, diplomacy, macroeconomic resource management, and military strategy. This update delivers eight interconnected features:
1. **Core Runtime Stability**: Resolves the `acquireLock is not a function` runtime error by implementing atomic lock acquisition and release mechanics in `locks.js`.
2. **Dynamic Project Material Governance**: Admins can customize the exact material composition and quantities for every national megaproject rather than relying on hardcoded recipes.
3. **Enterprise Registration Continuity**: Fixes the bot flow dispatching mechanism so custom enterprise names and emojis are accurately captured, validated, and persisted.
4. **Infinite Telecom Infrastructure**: Lifts the legacy 6G cap on internet upgrades, dynamically computing costs, scientific yields, and public satisfaction for 7G, 8G, and beyond without upper bound.
5. **Channel-Centric Research Logs & Web Monitoring**: Upgrades and research breakthroughs no longer generate repetitive direct-message spam. Announcements are routed to the official broadcast channel, while an operations feed is rendered directly on the web application.
6. **Unified Economy & Global Commodities**: Merges the Global Market entry into the Economy view while keeping it easily reachable from My Empire, providing seamless buying and selling of base commodities.
7. **VIP Real-Money Shahi Coin Economy**: Equips the platform with admin-controlled Toman pricing per coin, card-to-card receipt uploads, and admin verification queues matching the VIP country flow.
8. **Ministry of War & Commander System**: Enables heads of state to recruit unassigned citizens as military ministers or commanders, enhancing team play.

---

### 2. User Experience & Visual Design

#### Key User Flows

```
┌─────────────────────────────────────────────────────────────────────────────┐
│ 1. REAL-MONEY VIP SHAHI COIN PURCHASE FLOW (LIKE VIP COUNTRY)               │
│ Player selects "👑 خرید سکه شاهی (VIP)"                                     │
│   ──► Chooses package [۵ سکه] [۱۰ سکه] [۲۰ سکه] or [تعداد دلخواه]           │
│   ──► System displays total Toman price (e.g. ۱۰ سکه × ۵۰,۰۰۰ = ۵۰۰,۰۰۰ ت)  │
│   ──► Shows Card Number, Holder Name & Instructions                         │
│   ──► Player uploads photo receipt or transaction ID                        │
│   ──► Order queued under Admin Panel "🧾 درخواست‌های خرید سکه شاهی"           │
│   ──► Admin reviews receipt & clicks "✅ تایید و واریز سکه"                 │
│   ──► Shahi coins credited instantly & player receives VIP alert           │
└─────────────────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────────────────┐
│ 2. ADMIN SHAHI COIN TOMAN PRICE CONFIGURATION                               │
│ Admin opens Admin Panel ──► "👑 تنظیم نرخ ریالی هر سکه شاهی"                │
│   ──► Inputs new price (e.g. 50,000 Toman per coin)                         │
│   ──► Saved immediately in system settings (`shahi_coin_real_price_toman`)   │
│   ──► All purchase menus and packages reflect the new price dynamically     │
└─────────────────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────────────────┐
│ 3. APPOINT COMMANDER / MINISTER FLOW                                       │
│ Leader opens "🎖️ هیئت وزیران" ──► Clicks "➕ انتصاب وزیر جدید"             │
│   ──► Views roster of registered citizens without countries                 │
│   ──► Selects citizen ──► Telegram alert sent to appointee                  │
│   ──► Country cabinet updated with Minister name, rank & defense perks      │
└─────────────────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────────────────┐
│ 4. ADMIN CUSTOM PROJECT MATERIALS FLOW                                      │
│ Admin opens "🏗️ مدیریت مصالح پروژه‌ها" in Web/Admin Bot                     │
│   ──► Selects project (e.g. جزیره مصنوعی، برج ملی، شهر هوشمند)              │
│   ──► Toggles required materials [☑ فولاد, ☑ سیمان, ☑ نفت خام, etc.]         │
│   ──► Inputs exact amounts ──► Changes persist atomically in Firestore      │
│   ──► Game immediately enforces new requirements for builders               │
└─────────────────────────────────────────────────────────────────────────────┘
```

#### Visual Identity & Full-Spectrum Button Color Palette

Following the Universal Design Constitution and Dashboard Guidelines:
- **Button Vibrancy**: Replace monochrome and muted buttons with intentional high-contrast accent themes:
  - 🟢 **Success & Acquisition** (`emerald-600` / `bg-emerald-500/10`): Purchase, build, appoint, approve.
  - 🔵 **Command & Technology** (`cyan-600` / `sky-500`): Telecom upgrades, research operations, satellite operations.
  - 🟣 **Executive & Shahi Royalty** (`violet-600` / `purple-500`): VIP Shahi coin purchase, card details, minister decrees.
  - 🟡 **Economy & Commodities** (`amber-500` / `amber-400`): Global market exchange, crude oil trades, stock market.
  - 🔴 **Military & Combat Alerts** (`rose-600` / `red-500`): War commands, straits blockade, rebel quelling.
- **Top Bar Contract**: Breadcrumb trail on the left (`World War Fire / فرماندهی کل / اقتصاد و کابینه`), single-line status indicators, and clear action anchors.
- **Zero-Pill Discipline**: Metadata formatted as clean unboxed typography with typographic separators (`·`), avoiding nested candy badges.
- **Tabular Figures**: Enforce `font-variant-numeric: tabular-nums` across all treasury counters, commodity stocks, and transaction ledgers.

---

### 3. Key Product Decisions & Trade-Offs

#### Decision 1: Real-Money VIP Shahi Coin Purchasing System
- **Chosen Approach**: Build a dedicated VIP purchase pipeline mimicking `registration.js` where users choose quantities, receive payment card coordinates, submit receipts, and admins approve from a unified queue.
- **Why**: Matches the existing familiar payment UX of VIP countries and honors the user's real-money monetization model.
- **Alternatives Considered**: In-game currency swap (user explicitly corrected this to real Toman payments).

#### Decision 2: Admin Shahi Coin Price Governance
- **Chosen Approach**: Store `shahi_coin_real_price_toman` in Firestore `settings` collection. Provide editing inputs in both the Web Admin Panel and Admin Telegram Bot (`adbot:shahi:set_real_price`).
- **Why**: Allows instant price adjustments without code redeployments.

#### Decision 3: Distributed Lock Mechanism in `locks.js`
- **Chosen Approach**: Implement `acquireLock(key, ttlMs)` and `releaseLock(key)` backed by an in-memory lock map with automatic TTL expiry, plus transaction-safe Firestore locking when connected to live cloud storage.
- **Why**: Eliminates the catastrophic `TypeError: acquireLock is not a function` across construction, UN voting, straits conquest, and custom enterprise creation.

#### Decision 4: Regex & Parameterized Flow Dispatching in `flows.js`
- **Chosen Approach**: Upgrade `flowMiddleware` in `flows.js` to iterate over registered handlers if a direct `Map.get(flowName)` returns null, matching dynamic regex patterns (e.g. `/^game:ent_name:([a-z]+)$/`) and passing capture groups to handlers.
- **Why**: Allows players to smoothly enter custom enterprise names and brand logos without flows getting discarded.

#### Decision 5: Infinite Internet Upgrades with Channel Broadcasting & Web Activity Logs
- **Chosen Approach**: Dynamically calculate tier progression beyond 6G (`next: (N+1)G`, exponential cost curve, incremental scientific yields). Route upgrade announcements directly to the configured Telegram channel (`CHANNEL_ID`), while saving every research/upgrade event to a centralized `operations_log` collection visible in the Web dashboard.
- **Why**: Keeps player chat free from notification clutter while giving the entire game community public recognition of technological advancements in the channel, with full auditability on the website.

#### Decision 6: Minister / Commander Delegation System
- **Chosen Approach**: Filter active users who have registered in the current season but have not claimed or been assigned a country (`ownCountryId == null`). When selected, store `ministerUserId`, `ministerName`, and `appointedAt` on the country state, giving the minister advisory status and team bonuses.
- **Why**: Encourages multiplayer teamwork, allows latecomers or spectators without a country to participate meaningfully in governance, and prevents multiple leadership conflicts.

---

### 4. Technical Architecture & Data Strategy

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                            SYSTEM ARCHITECTURE                              │
└─────────────────────────────────────────────────────────────────────────────┘

    Telegram Users                       Admin Dashboard / Web App
          │                                          │
          ▼                                          ▼
   ┌───────────────┐                          ┌──────────────┐
   │ Telegraf Bot  │                          │ React / Vite │
   │  Controllers  │                          │  Dashboard   │
   └───────┬───────┘                          └──────┬───────┘
           │                                         │
           ▼                                         ▼
   ┌─────────────────────────────────────────────────────────┐
   │                  Express API Gateway                    │
   │  • /api/shahi/real-price & /api/shahi/purchase-requests │
   │  • /api/admin/projects/materials (Configure Materials)  │
   │  • /api/commander/candidates & /api/commander/appoint   │
   │  • /api/research/logs (Live Research Activity Feed)     │
   └───────────────────────────┬─────────────────────────────┘
                               │
                               ▼
   ┌─────────────────────────────────────────────────────────┐
   │                     Game Services                       │
   │  • centralBankService  (VIP Shahi orders & price logic) │
   │  • constructionService (Dynamic materials, Infinite Net)│
   │  • userService         (Minister appointments & roster) │
   │  • notificationService (Channel-only broadcasts)        │
   │  • locks.js            (acquireLock / releaseLock)      │
   └───────────────────────────┬─────────────────────────────┘
                               │
                               ▼
   ┌─────────────────────────────────────────────────────────┐
   │                   Firestore Storage                     │
   │  • locks collection (TTL-based distributed locks)       │
   │  • shahi_orders (VIP purchase requests with receipts)   │
   │  • country_states (cabinet, internet, customEnterprises)│
   │  • settings (shahi_coin_real_price_toman, materials)    │
   │  • research_logs (live public operations history)       │
   └─────────────────────────────────────────────────────────┘
```

#### State & Data Models

1. **VIP Shahi Coin Order Document (`shahi_orders/{orderId}`)**:
   ```typescript
   interface ShahiCoinOrder {
     id: string;
     userId: string;
     telegramId: number;
     countryId?: string;
     countryName?: string;
     coinsCount: number;
     unitPriceToman: number;
     totalPriceToman: number;
     status: 'awaiting_receipt' | 'pending_admin' | 'approved' | 'rejected';
     receipt: {
       type: 'photo' | 'text';
       fileId?: string;
       text?: string;
       submittedAt: string;
     };
     adminReviewedBy?: string;
     createdAt: string;
     reviewedAt?: string;
   }
   ```

2. **Distributed Lock State (`locks/{lockKey}`)**:
   ```typescript
   interface LockDocument {
     acquiredAt: number;
     expiresAt: number;
     holder?: string;
   }
   ```

3. **Project Materials Configuration (`settings/project_materials`)**:
   ```typescript
   interface ProjectMaterialConfig {
     [projectKey: string]: {
       materials: {
         steel?: number;
         iron?: number;
         copper?: number;
         wood?: number;
         cement?: number;
         oil?: number;
       };
     };
   }
   ```

4. **Commander & Cabinet State (inside `countryState`)**:
   ```typescript
   interface CabinetState {
     ministerUserId: string | null;
     ministerName: string | null;
     ministerTelegramId: number | null;
     appointedAt: string | null;
   }
   ```

5. **Research Operations Feed (`research_logs`)**:
   ```typescript
   interface ResearchLogEntry {
     id: string;
     countryId: string;
     countryName: string;
     countryFlag: string;
     operationType: 'internet_upgrade' | 'megaproject' | 'enterprise_launched' | 'nuclear_progress';
     title: string;
     details: string;
     timestamp: string;
   }
   ```

---

### 5. Step-by-Step Implementation Strategy

1. **Step 1: Implement `acquireLock` and `releaseLock` in `locks.js`**
   - Provide robust implementations with TTL protection and in-memory fallback.
   - Verify syntax and export contracts so all calling services execute without errors.

2. **Step 2: Fix Dynamic Flow Routing in `flows.js`**
   - Support both string keys and RegExp patterns in `flowMiddleware`.
   - Ensure custom enterprise naming (`game:ent_name:*`) and logo selection flows execute cleanly without clearing state prematurely.

3. **Step 3: Uncap Internet Upgrades to Infinity**
   - Replace the static 6G limit with a dynamic tiered calculation in `constructionService.js`.
   - Update `upgradeInternet` to compute costs, science scores, and satisfaction dynamically for any $N \ge 6$.

4. **Step 4: Silent Upgrades, Channel Broadcasts & Web Research Operations Feed**
   - Suppress private bot notifications on upgrades; send high-profile public bulletins to the Telegram channel (`CHANNEL_ID`).
   - Create a centralized research log in Firestore and display the live operations feed on the website dashboard (`src/App.tsx`).

5. **Step 5: Admin Custom Project Materials Configuration**
   - Create endpoints and UI controls in the Admin Panel allowing multi-selection of commodities with custom quantity inputs per project.
   - Wire `constructionService` to read dynamic configurations from `settings` before checking user inventories.

6. **Step 6: Unified Global Market in Economy & My Empire**
   - Add the Global Market shortcut directly into the Economy keyboard and handlers (`emp:economy`), linking both menus seamlessly.

7. **Step 7: Real-Money VIP Shahi Coin Purchasing & Admin Toman Price Management**
   - Add admin controls to set custom price in Tomans per single coin (`shahi_coin_real_price_toman`).
   - Implement the complete VIP purchase flow with card details, photo/text receipt upload, admin approval queue, and automatic coin credit.

8. **Step 8: Commander / Minister System, Vivid Emojis & Colorized Buttons**
   - Implement candidate discovery of unassigned registered users and appointment flow.
   - Enrich all bot and web action buttons with vivid domain colors and expressive emojis.

9. **Step 9: End-to-End Build & Compilation Verification**
   - Verify server and client compilation using `compile_applet`.
   - Verify all unit and integration flows.
