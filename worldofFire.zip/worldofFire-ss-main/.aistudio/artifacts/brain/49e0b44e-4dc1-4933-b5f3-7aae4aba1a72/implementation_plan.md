# World War Fire: Comprehensive Warfare, Economy & Strategic Overhaul

This implementation plan delivers a complete tactical, economic, and operational expansion for World War Fire across both the React Web App and the Telegram Bot backend.

---

## User Review & Critical Decisions

> [!IMPORTANT]
> The following architectural decisions were confirmed during the planning reviews:
> - **Strict 10-Minute Real-Time Battle Resolution**: When an attack or conquest is launched, **no result or conquest is determined immediately**. Instead, an active battle state is initiated for a **full 10 minutes of real time** (`Date.now() + 10 * 60 * 1000`). If the attacker deploys transport carriers (cargo aircraft, armored carriers, transport ships), this real-time countdown can be sped up (down to 4–6 minutes). The defender is alerted immediately and can deploy defensive equipment and readiness. The combat resolution and conquest result calculate **strictly after the real-time timer completes**.
> - **51% Enterprise Control**: Players acquiring 51%+ majority equity gain management privileges, allowing them to rename the corporation and redirect its industrial category for customized strategic bonuses.
> - **Asset Reset on Country Change & New Season**: When a player switches countries or a new season begins, treasury cash, oil reserves, and military units are completely reset to initial starting levels, ensuring a clean and fair state.
> - **Admin Payout Management**: Admins receive dedicated controls to change the income cycle interval (e.g., 5m, 10m, 15m), cancel or freeze scheduled revenue payouts, and resume them on demand.
> - **Mandatory Community Gate**: Strict membership verification checks both the official Telegram channel and official group before granting bot access.
> - **Geographic Logistics**: Landlocked nations must dispatch interactive diplomatic transit requests to neighbors; oceanic/island warfare strictly requires naval transports (`cargo_ship`, `warship`, `aircraft_carrier`).

---

## 1. Overview & Core Concept

1. **Daily Mission System & Tracking Widget**:
   - Missions such as *"Export 50k barrels of oil"* and *"Produce 10k MW electricity"* tracked with interactive progress bars.
   - Embedded dashboard widget displayed prominently in both the **Overview** (`overview`) and **Oil Economy** (`oil_economy`) tabs in `App.tsx` and mirrored in the Telegram bot menu.
   - Rewards: Shahi Coins and bonus oil delivered automatically upon claiming.

2. **Barracks & Battle History ("پادگان")**:
   - A dedicated military command center where leaders review total troop counts, armor, fighters, naval vessels, defense installations, recent combat logs, victory/defeat ratios, and military readiness.

3. **Stock Market & 51% Majority Buyout**:
   - Trade shares of premier national enterprises up to 100%.
   - At 51%+ ownership, player assumes executive management: unlocks custom company renaming, sector redirection, and executive dividends.

4. **Combat Bug Fixes & Refinements**:
   - **Military Power Aggregation**: Ensure all weapon and unit purchases directly increase `military.attack`, `military.defense`, and `military.ground` in country state.
   - **Dynamic Flag Switcher**: Fix flag resolution so chosen government, religion, and custom flags immediately update across user cards, bot views, and leaderboards.
   - **Custom Unit Attack Quantities**: Replace static unit selection with custom numeric inputs allowing leaders to deploy exact battalion counts.
   - **Streamlined Targeting**: Eliminate province selection prompts during foreign invasions; attacks target the sovereign state directly.
   - **Auto-Defense Readiness**: Defending leaders can activate an automated defense posture that deploys pre-configured garrisons and air defense grids during incoming strikes.
   - **10-Minute Real-Time Battle Timer**: Attacks do not resolve instantly. The system initiates a real-time countdown where both sides' forces are deployed, and the battle calculation fires after the 10-minute real-time interval completes.

5. **Diplomatic Transit & Transport Requirements**:
   - Landlocked countries must request and receive safe-passage transit pacts from neighboring border states before ground incursions.
   - Island and coastal invasions mandate transport fleets (`cargo_ship`, `aircraft_carrier`, `cargo_plane`).

6. **Admin Payout Controls & Asset Reset**:
   - Web & Bot admin panel controls to pause/cancel recurring revenue runs, adjust interval duration, and resume payouts.
   - Clean reset trigger clearing cash, oil, and armies when a player transfers leadership or advances to a new season.

---

## 2. User Experience & Visual Design

### A. Web Dashboard (`/src/App.tsx`)
- **Daily Missions Widget**:
  - Located in the Overview hero section and Oil Economy tab.
  - Features real-time progress bars (`bg-amber-500/20` border, `bg-amber-500` fill), mission objectives, reward tags (`+5 Shahi Coins`, `+10,000 Oil Barrels`), and one-click claim buttons.
- **Barracks Tab ("پادگان")**:
  - Tactical military overview grid: Ground Forces, Air Wings, Naval Fleets, Air Defense Grids, and Cyber Warfare.
  - Battle Analytics card: Wins, Defeats, Conquest Success Rate, and casualty audit history.
- **Corporate Equity & 51% Takeover UI**:
  - Percentage ownership dials (0% to 100%).
  - Company takeover badge: When user equity >= 51%, a glowing "Executive Chairman" modal appears allowing company renaming and industry redirection.
- **Combat & Defense Panel**:
  - Real-time active siege countdown banner (e.g. `09:42 remaining until battle outcome`).
  - Auto-defense toggle: "Automated Defensive Readiness" with customizable defense allocation.
  - Custom deployment drawer: Text input for exact unit counts when launching an invasion.
  - Transit authorization badge for landlocked assaults.

### B. Telegram Bot (`/world-war-fire/src/`)
- **Main Menu**: Add `🪖 پادگان` (Barracks) button into `mainInlineMenu` and `empireInlineKeyboard`.
- **Mandatory Channel & Group Verification**: On `/start`, query `getChatMember` for both `channelId` and `groupId`. If missing, display a clean blocking card with direct join links and a refresh button.
- **Attack Flow**: Remove province selection step; prompt directly for target country, verify transit/naval logistics, prompt for unit quantities, and start the 10-minute real-time battle timer.

---

## 3. Key Product Decisions & Trade-Offs

- **Decision 1: Real-Time Battle Resolution Lifecycle**
  - *Chosen Approach*: Conquering/attacking a country creates an active battle session scheduled for 10 minutes in real time. The defender receives immediate alert notifications and can position defense units. The actual winner, casualties, and potential conquest are computed strictly once the real-time timer runs out.
  - *Why*: Eliminates instant conquests ("فتح آبکی") and establishes genuine suspense and strategic countermeasures.
- **Decision 2: Direct State Property Mutation for Military Power**
  - *Chosen Approach*: Replace dotted Firestore path strings (`'military.attack'`) with a unified JavaScript `military` object update on `country_states`.
  - *Why*: Eliminates silent merging bugs in Firestore where dotted strings fail to update nested JSON structures.
- **Decision 3: Zeroing Assets on Country Switch & New Season**
  - *Chosen Approach*: When a player changes countries or a new season is initialized, treasury dollars, oil barrels, and military units reset strictly to clean baseline values ($400M treasury, 1,500 oil barrels, baseline forces).

---

## 4. Technical Architecture & Data Strategy

```
┌────────────────────────────────────────────────────────┐
│               Frontend (React / Tailwind)              │
│  - Daily Missions Tracking Widget (Overview & Oil)     │
│  - Barracks Tab (Army Inspection & Combat Analytics)   │
│  - 51% Stock Buyout & Corporate Management Modal       │
│  - Real-time 10-Minute Battle Countdown Display        │
└──────────────────────────┬─────────────────────────────┘
                           │ Express API & Bot Handlers
┌──────────────────────────▼─────────────────────────────┐
│                 Core Game Services                     │
│  - gameService: Missions, Military Power, Reset        │
│  - warService: 10m Real-Time Battle Scheduler          │
│  - countryService: Dynamic Flag Resolution Engine      │
│  - gameLoopService: Payout Interval & Freeze Toggles   │
└──────────────────────────┬─────────────────────────────┘
                           │ Firestore Data
┌──────────────────────────▼─────────────────────────────┐
│  - /country_states/{season}_{countryId}                │
│  - /daily_missions/{userId}                            │
│  - /corporate_stocks/{companyId}                       │
│  - /active_battles/{battleId} (resolves at t + 10min)  │
│  - /transit_permissions/{fromCountry}_{toCountry}      │
└────────────────────────────────────────────────────────┘
```
